/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   smoke_parse_normalization.c                                +:+   :+: :+: */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parse/parse_normalization.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: report_failure — Compare report failure selon les règles de chaîne du
**       module et retourne le résultat sans modifier les entrées.
** Paramètre: msg — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: check_received_and_kill(), check_shot_and_ignore().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        smoke_parse_normalization.c -> report_failure() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	report_failure(const char *msg)
{
	fprintf(stderr, "FAIL: %s\n", msg);
	return (1);
}

/*
** Rôle: check_received_and_kill — Vérifie received and kill.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> parse_normalization_kill_start(),
**            parse_normalization_received_start(), report_failure().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        smoke_parse_normalization.c -> check_received_and_kill() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_received_and_kill(void)
{
	const char	*line;
	const char	*parsed;

	line = "2026-02-16 12:00:00 Vous avez "
		"re" "\xC3\xA7" "u Animal Oil Residue x (10) Valeur :0.1250 PED.";
	parsed = parse_normalization_received_start(line);
	if (!parsed || strncmp(parsed, "Animal Oil Residue", 17) != 0)
		return (report_failure("received_start accent"));
	line = "2026-02-16 12:00:01 Vous avez tu" "\xC3\xA9"
		" Daikiba Mature.";
	parsed = parse_normalization_kill_start(line);
	if (!parsed || strncmp(parsed, "Daikiba Mature", 13) != 0)
		return (report_failure("kill_start accent"));
	return (0);
}

/*
** Rôle: check_shot_and_ignore — Vérifie tir and ignore.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> parse_normalization_is_strict_shot(),
**            parse_normalization_should_ignore_line(), report_failure().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        smoke_parse_normalization.c -> check_shot_and_ignore() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_shot_and_ignore(void)
{
	const char	*line;

	line = "2026-02-16 12:00:02 Vous avez inflig" "\xC3\xA9"
		" 12 points of damage.";
	if (!parse_normalization_is_strict_shot(line))
		return (report_failure("shot_strict accent"));
	if (!parse_normalization_should_ignore_line(
			"[D" "\xC3\xA9" "butant] hello"))
		return (report_failure("ignore debutant accent"));
	return (0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_received_and_kill(),
**            check_shot_and_ignore().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        smoke_parse_normalization.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	if (check_received_and_kill() || check_shot_and_ignore())
		return (1);
	printf("OK\n");
	return (0);
}
