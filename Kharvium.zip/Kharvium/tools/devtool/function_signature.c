/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   function_signature.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool.h"

#include <ctype.h>
#include <string.h>

/*
** Rôle: dt_signature_start — exécute l’opération interne « signature start »
** avec validation des bornes et erreurs.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: brace — position de l’accolade ouvrant le corps de fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_function_from_brace().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_signature.c -> dt_signature_start() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

size_t	dt_signature_start(const char *masked, size_t brace)
{
	size_t	i;

	i = brace;
	while (i > 0)
	{
		i--;
		if (masked[i] == ';' || masked[i] == '}')
			return (i + 1);
	}
	return (0);
}

/*
** Rôle: dt_matching_open_paren — exécute l’opération interne « matching open
** paren » avec validation des bornes et erreurs.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: close_pos — position de la parenthèse fermante à apparier.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_function_from_brace().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_signature.c -> dt_matching_open_paren() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

size_t	dt_matching_open_paren(const char *text, size_t close_pos)
{
	int		depth;
	size_t	i;

	depth = 0;
	i = close_pos + 1;
	while (i > 0)
	{
		i--;
		if (text[i] == ')')
			depth++;
		else if (text[i] == '(' && --depth == 0)
			return (i);
	}
	return ((size_t)-1);
}

/*
** Rôle: dt_signature_name — valide le nommage snake_case des sources et
** fonctions du projet.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: open — position de parenthèse ouvrante.
** Paramètre: name — nom d’identifiant ou d’option à analyser.
** Paramètre: capacity — capacité maximale du buffer de destination.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_function_from_brace().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_signature.c -> dt_signature_name() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> isalnum(), isspace(),
**              memcpy(), strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_signature_name(const char *text, size_t open, char *name,
	size_t capacity)
{
	size_t	end;
	size_t	begin;
	size_t	len;

	end = open;
	while (end > 0 && isspace((unsigned char)text[end - 1]))
		end--;
	begin = end;
	while (begin > 0 && (isalnum((unsigned char)text[begin - 1])
			|| text[begin - 1] == '_'))
		begin--;
	len = end - begin;
	if (len == 0 || len >= capacity)
		return (0);
	memcpy(name, text + begin, len);
	name[len] = '\0';
	if (!strcmp(name, "if") || !strcmp(name, "for") || !strcmp(name, "while")
		|| !strcmp(name, "switch"))
		return (0);
	return (1);
}

/*
** Rôle: dt_count_parameters — exécute l’opération interne « count parameters
** » avec validation des bornes et erreurs.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: open — position de parenthèse ouvrante.
** Paramètre: close — position de parenthèse fermante.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_function_from_brace().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_signature.c -> dt_count_parameters() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> isspace(), strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=2; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_count_parameters(const char *text, size_t open, size_t close)
{
	int		count;
	int		depth;
	size_t	i;

	count = 0;
	depth = 0;
	i = open + 1;
	while (i < close && isspace((unsigned char)text[i]))
		i++;
	if (i == close || (close - i == 4 && !strncmp(text + i, "void", 4)))
		return (0);
	count = 1;
	while (i < close)
	{
		if (text[i] == '(' || text[i] == '[')
			depth++;
		else if (text[i] == ')' || text[i] == ']')
			depth--;
		else if (text[i] == ',' && depth == 0)
			count++;
		i++;
	}
	return (count);
}
