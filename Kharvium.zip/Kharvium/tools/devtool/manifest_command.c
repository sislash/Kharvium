/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   manifest_command.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
** Rôle: dt_path_compare — construit, collecte ou valide un chemin utilisé par
** les outils de développement.
** Paramètre: left — valeur « left » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Paramètre: right — valeur « right » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        manifest_command.c -> dt_path_compare() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_path_compare(const void *left, const void *right)
{
	const char *const	*a;
	const char *const	*b;

	a = left;
	b = right;
	return (strcmp(*a, *b));
}

/*
** Rôle: dt_manifest_relative — construit ou vérifie le manifeste SHA-256 du
** paquet source.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne le pointeur trouvé ou créé; NULL signale une absence, une
** entrée invalide ou un échec d’allocation/E/S selon le chemin local.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_manifest_write_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        manifest_command.c -> dt_manifest_relative() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strlen(), strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static const char	*dt_manifest_relative(const char *root, const char *path)
{
	size_t	len;

	len = strlen(root);
	if (!strncmp(root, path, len) && (path[len] == '/' || path[len] == '\\'))
		return (path + len + 1);
	return (path);
}

/*
** Rôle: dt_manifest_write_file — construit ou vérifie le manifeste SHA-256 du
** paquet source.
** Paramètre: manifest — flux du manifeste SHA-256 en cours d’écriture.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_manifest_relative(),
**            dt_sha256_file(), dt_sha256_hex().
** Appelants: dt_command_manifest().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        manifest_command.c -> dt_manifest_write_file() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf(), strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_manifest_write_file(FILE *manifest, const char *root,
	const char *path)
{
	unsigned char	digest[32];
	char			hex[65];
	const char		*relative;

	relative = dt_manifest_relative(root, path);
	if (!strcmp(relative, "ARCHIVE_MANIFEST.sha256"))
		return (1);
	if (!dt_sha256_file(path, digest))
		return (0);
	dt_sha256_hex(digest, hex);
	fprintf(manifest, "%s  ./%s\n", hex, relative);
	return (1);
}

/*
** Rôle: dt_manifest_open — construit ou vérifie le manifeste SHA-256 du
** paquet source.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne le pointeur trouvé ou créé; NULL signale une absence, une
** entrée invalide ou un échec d’allocation/E/S selon le chemin local.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_command_manifest().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        manifest_command.c -> dt_manifest_open() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fopen(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static FILE	*dt_manifest_open(const char *root, char path[4096])
{
	if (snprintf(path, 4096, "%s/ARCHIVE_MANIFEST.sha256", root) < 0)
		return (NULL);
	return (fopen(path, "wb"));
}

/*
** Rôle: dt_command_manifest — exécute la sous-commande « manifest » et
** retourne un statut exploitable par le Makefile et la CI.
** Paramètre: argc — nombre d’arguments de la ligne de commande.
** Paramètre: argv — tableau d’arguments de la ligne de commande.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_manifest_open(),
**            dt_manifest_write_file(), dt_paths_collect(), dt_paths_free(),
**            dt_paths_init().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        manifest_command.c -> dt_command_manifest() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fprintf(),
**              perror(), printf(), qsort().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fprintf().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=5; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_manifest(int argc, char **argv)
{
	t_dt_paths	paths;
	char		manifest_path[4096];
	FILE		*manifest;
	size_t		i;
	size_t		count;
	if (argc < 3)
		return (fprintf(stderr, "usage: devtool manifest root\n"), 1);
	dt_paths_init(&paths);
	if (!dt_paths_collect(&paths, argv[2], ""))
		return (dt_paths_free(&paths), 1);
	qsort(paths.items, paths.count, sizeof(*paths.items), dt_path_compare);
	manifest = dt_manifest_open(argv[2], manifest_path);
	if (!manifest)
		return (dt_paths_free(&paths), perror(manifest_path), 1);
	i = 0;
	while (i < paths.count && dt_manifest_write_file(manifest, argv[2],
			paths.items[i]))
		i++;
	fclose(manifest);
	count = paths.count;
	dt_paths_free(&paths);
	if (i != count)
		return (1);
	printf("[manifest-c] %s\n", manifest_path);
	return (0);
}
