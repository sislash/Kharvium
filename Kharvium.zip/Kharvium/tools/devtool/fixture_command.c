/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fixture_command.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int	dt_fixture_generate(const t_dt_fixture *fixture);

/*
** Rôle: dt_fixture_defaults — génère les données synthétiques Tracker
** utilisées pour les tests de charge.
** Paramètre: fixture — configuration déterministe de la fixture Tracker.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_command_fixture().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        fixture_command.c -> dt_fixture_defaults() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_fixture_defaults(t_dt_fixture *fixture, const char *path)
{
	fixture->path = path;
	fixture->kills = 2000;
	fixture->shots = 3;
	fixture->loot_rows = 2;
	fixture->loot_value = 100;
	fixture->ammo_value = 200;
	fixture->decay_value = 150;
	fixture->start_ts = 1700000000;
}

/*
** Rôle: dt_fixture_option — génère les données synthétiques Tracker utilisées
** pour les tests de charge.
** Paramètre: fixture — configuration déterministe de la fixture Tracker.
** Paramètre: name — nom d’identifiant ou d’option à analyser.
** Paramètre: value — valeur associée à l’opération.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_command_fixture().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        fixture_command.c -> dt_fixture_option() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strtol().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_fixture_option(t_dt_fixture *fixture, const char *name,
	const char *value)
{
	long	parsed;

	parsed = strtol(value, NULL, 10);
	if (!strcmp(name, "--kills"))
		fixture->kills = parsed;
	else if (!strcmp(name, "--shots"))
		fixture->shots = parsed;
	else if (!strcmp(name, "--loot_rows"))
		fixture->loot_rows = parsed;
	else if (!strcmp(name, "--loot_uPED5"))
		fixture->loot_value = parsed;
	else if (!strcmp(name, "--ammo_uPED5"))
		fixture->ammo_value = parsed;
	else if (!strcmp(name, "--decay_uPED5"))
		fixture->decay_value = parsed;
	else if (!strcmp(name, "--start_ts"))
		fixture->start_ts = parsed;
	else
		return (0);
	return (1);
}

/*
** Rôle: dt_command_fixture — exécute la sous-commande « fixture » et retourne
** un statut exploitable par le Makefile et la CI.
** Paramètre: argc — nombre d’arguments de la ligne de commande.
** Paramètre: argv — tableau d’arguments de la ligne de commande.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_fixture_defaults(),
**            dt_fixture_generate(), dt_fixture_option().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        fixture_command.c -> dt_command_fixture() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_fixture(int argc, char **argv)
{
	t_dt_fixture	fixture;
	int				i;

	if (argc < 3)
	{
		fprintf(stderr, "usage: devtool fixture out.csv [options]\n");
		return (1);
	}
	dt_fixture_defaults(&fixture, argv[2]);
	i = 3;
	while (i + 1 < argc)
	{
		if (!dt_fixture_option(&fixture, argv[i], argv[i + 1]))
			return (fprintf(stderr, "unknown option: %s\n", argv[i]), 1);
		i += 2;
	}
	if (fixture.kills <= 0 || fixture.shots < 0 || fixture.loot_rows < 0)
		return (fprintf(stderr, "invalid fixture dimensions\n"), 1);
	return (dt_fixture_generate(&fixture));
}
