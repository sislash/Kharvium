/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strict42_lines.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <string.h>

/*
** Rôle: dt_has_42_header — exécute l’opération interne « has 42 header » avec
** validation des bornes et erreurs.
** Paramètre: text — buffer de texte source et sa longueur.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_strict_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_lines.c -> dt_has_42_header() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_has_42_header(const char *text)
{
	if (!text)
		return (0);
	return (!strncmp(text, "/* ************************", 27));
}

/*
** Rôle: dt_utf8_columns — exécute l’opération interne « utf8 columns » avec
** validation des bornes et erreurs.
** Paramètre: start — borne de début inclusive de la zone analysée.
** Paramètre: len — valeur « len » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_check_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_lines.c -> dt_utf8_columns() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static size_t	dt_utf8_columns(const char *start, size_t len)
{
	size_t	i;
	size_t	columns;

	i = 0;
	columns = 0;
	while (i < len)
	{
		if (start[i] == '\t')
			columns += 4 - (columns % 4);
		else if (((unsigned char)start[i] & 0xC0) != 0x80)
			columns++;
		i++;
	}
	return (columns);
}

/*
** Rôle: dt_check_line — exécute l’opération interne « check line » avec
** validation des bornes et erreurs.
** Paramètre: start — borne de début inclusive de la zone analysée.
** Paramètre: len — valeur « len » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: counts — compteurs Strict42 accumulés pour le rapport.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_utf8_columns().
** Appelants: dt_strict_check_lines().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_lines.c -> dt_check_line() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_check_line(const char *start, size_t len,
	t_dt_strict_counts *counts)
{
	if (dt_utf8_columns(start, len) > 80)
		counts->line_too_long++;
	if (len > 0 && (start[len - 1] == ' ' || start[len - 1] == '\t'))
		counts->trailing_whitespace++;
}

/*
** Rôle: dt_strict_check_lines — analyse la conformité structurelle Strict42
** et met à jour les compteurs correspondants.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: counts — compteurs Strict42 accumulés pour le rapport.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_check_line().
** Appelants: dt_strict_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_lines.c -> dt_strict_check_lines() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strchr(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_strict_check_lines(const char *text, t_dt_strict_counts *counts)
{
	const char	*line;
	const char	*end;
	int			previous_empty;

	line = text;
	previous_empty = 0;
	while (line && *line)
	{
		end = strchr(line, '\n');
		if (!end)
			end = line + strlen(line);
		dt_check_line(line, (size_t)(end - line), counts);
		if (end == line && previous_empty)
			counts->double_empty_line++;
		previous_empty = (end == line);
		if (*end == '\n')
			line = end + 1;
		else
			line = end;
	}
}
