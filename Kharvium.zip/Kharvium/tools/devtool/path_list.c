/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   path_list.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool.h"

#include <stdlib.h>
#include <string.h>

/*
** Rôle: dt_paths_init — construit, collecte ou valide un chemin utilisé par
** les outils de développement.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_command_doc_audit(), dt_command_duplicates(),
**            dt_command_manifest(), dt_command_naming(),
**            dt_command_package_audit(), dt_paths_free() (+2; index complet
**            dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère path_list.c
**        -> dt_paths_init() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_paths_init(t_dt_paths *paths)
{
	if (!paths)
		return ;
	paths->items = NULL;
	paths->count = 0;
	paths->capacity = 0;
}

/*
** Rôle: dt_paths_free — construit, collecte ou valide un chemin utilisé par
** les outils de développement.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_paths_init().
** Appelants: dt_command_doc_audit(), dt_command_duplicates(),
**            dt_command_manifest(), dt_command_naming(),
**            dt_command_package_audit(), dt_command_strict42() (+1; index
**            complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère path_list.c
**        -> dt_paths_free() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_paths_free(t_dt_paths *paths)
{
	size_t	i;

	if (!paths)
		return ;
	i = 0;
	while (i < paths->count)
		free(paths->items[i++]);
	free(paths->items);
	dt_paths_init(paths);
}

/*
** Rôle: dt_paths_grow — construit, collecte ou valide un chemin utilisé par
** les outils de développement.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_paths_push().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère path_list.c
**        -> dt_paths_grow() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> realloc().
** Mémoire: opérations directes -> realloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_paths_grow(t_dt_paths *paths)
{
	char	**items;
	size_t	capacity;

	capacity = paths->capacity * 2;
	if (capacity < 32)
		capacity = 32;
	items = realloc(paths->items, capacity * sizeof(*items));
	if (!items)
		return (0);
	paths->items = items;
	paths->capacity = capacity;
	return (1);
}

/*
** Rôle: dt_paths_push — construit, collecte ou valide un chemin utilisé par
** les outils de développement.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_paths_grow().
** Appelants: dt_collect_posix(), dt_windows_entry().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère path_list.c
**        -> dt_paths_push() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> malloc(), memcpy(),
**              strlen().
** Mémoire: opérations directes -> malloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_paths_push(t_dt_paths *paths, const char *path)
{
	size_t	len;
	char	*copy;

	if (!paths || !path)
		return (0);
	if (paths->count == paths->capacity && !dt_paths_grow(paths))
		return (0);
	len = strlen(path);
	copy = malloc(len + 1);
	if (!copy)
		return (0);
	memcpy(copy, path, len + 1);
	paths->items[paths->count++] = copy;
	return (1);
}
