/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   duplicates_command.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int	dt_duplicate_append(t_dt_duplicate **records, size_t *count,
		const char *path);
void	dt_duplicate_records_free(t_dt_duplicate *records, size_t count);

/*
** Rôle: dt_duplicate_allowed — normalise, collecte ou compare les fonctions
** afin de détecter les duplications accidentelles.
** Paramètre: a — valeur « a » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: b — valeur « b » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_duplicate_count().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        duplicates_command.c -> dt_duplicate_allowed() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strncmp(),
**              strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_duplicate_allowed(const t_dt_duplicate *a,
	const t_dt_duplicate *b)
{
	int	windows;
	int	x11;

	if (strcmp(a->name, b->name))
		return (0);
	if ((!strcmp(a->name, "platform_thread_start")
			|| !strcmp(a->name, "platform_thread_join"))
		&& !strcmp(a->path, b->path))
		return (1);
	if (strncmp(a->name, "window_", 7))
		return (0);
	windows = (strstr(a->path, "windows_window_") != NULL
			|| strstr(b->path, "windows_window_") != NULL);
	x11 = (strstr(a->path, "x11_window_") != NULL
			|| strstr(b->path, "x11_window_") != NULL);
	return (windows && x11);
}

/*
** Rôle: dt_duplicate_count — normalise, collecte ou compare les fonctions
** afin de détecter les duplications accidentelles.
** Paramètre: records — valeur « records » utilisée uniquement selon le
** contrat et les validations de cette fonction.
** Paramètre: count — valeur « count » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_duplicate_allowed().
** Appelants: dt_command_duplicates().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        duplicates_command.c -> dt_duplicate_count() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=2; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_duplicate_count(t_dt_duplicate *records, size_t count)
{
	size_t	i;
	size_t	j;
	int		findings;

	findings = 0;
	i = 0;
	while (i < count)
	{
		j = i + 1;
		while (j < count)
		{
			if (!dt_duplicate_allowed(&records[i], &records[j])
				&& (!strcmp(records[i].name, records[j].name)
					|| (records[i].hash == records[j].hash
						&& !strcmp(records[i].body, records[j].body))))
				findings++;
			j++;
		}
		i++;
	}
	return (findings);
}

/*
** Rôle: dt_command_duplicates — exécute la sous-commande « duplicates » et
** retourne un statut exploitable par le Makefile et la CI.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_duplicate_append(),
**            dt_duplicate_count(), dt_duplicate_records_free(),
**            dt_paths_collect(), dt_paths_free(), dt_paths_init().
** Appelants: dt_command_all(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        duplicates_command.c -> dt_command_duplicates() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> free(), printf().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=6; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_duplicates(void)
{
	t_dt_paths		paths;
	t_dt_duplicate	*records;
	size_t			count;
	size_t			i;
	int				findings;

	dt_paths_init(&paths);
	if (!dt_paths_collect(&paths, "src", ".c"))
		return (dt_paths_free(&paths), 1);
	records = NULL;
	count = 0;
	i = 0;
	while (i < paths.count)
	{
		if (!dt_duplicate_append(&records, &count, paths.items[i]))
			return (dt_paths_free(&paths), free(records), 1);
		i++;
	}
	findings = dt_duplicate_count(records, count);
	dt_duplicate_records_free(records, count);
	dt_paths_free(&paths);
	printf("[duplicates-c] PASS=%d findings=%d\n", findings == 0, findings);
	return (findings != 0);
}
