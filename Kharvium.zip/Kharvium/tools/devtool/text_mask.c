/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   text_mask.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool.h"

#include <stdlib.h>
#include <string.h>

/*
** Rôle: dt_mask_replace — masque les zones non exécutables du C en préservant
** les positions et retours ligne.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: index — valeur « index » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_mask_comment(), dt_mask_quote().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère text_mask.c
**        -> dt_mask_replace() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_mask_replace(char *masked, size_t index)
{
	if (masked[index] != '\n')
		masked[index] = ' ';
}

/*
** Rôle: dt_mask_quote — masque les zones non exécutables du C en préservant
** les positions et retours ligne.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: i — valeur « i » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: len — valeur « len » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: quote — valeur « quote » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_mask_replace().
** Appelants: dt_mask_code().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère text_mask.c
**        -> dt_mask_quote() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static size_t	dt_mask_quote(char *masked, size_t i, size_t len, char quote)
{
	dt_mask_replace(masked, i++);
	while (i < len)
	{
		if (masked[i] == '\\' && i + 1 < len)
		{
			dt_mask_replace(masked, i++);
			dt_mask_replace(masked, i++);
		}
		else if (masked[i] == quote)
			return (dt_mask_replace(masked, i), i + 1);
		else
			dt_mask_replace(masked, i++);
	}
	return (i);
}

/*
** Rôle: dt_mask_comment — localise et valide le bloc documentaire
** immédiatement associé à une fonction.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: i — valeur « i » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: len — valeur « len » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: block — bloc binaire de 64 octets traité par SHA-256.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_mask_replace().
** Appelants: dt_mask_code().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère text_mask.c
**        -> dt_mask_comment() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static size_t	dt_mask_comment(char *masked, size_t i, size_t len, int block)
{
	dt_mask_replace(masked, i++);
	dt_mask_replace(masked, i++);
	while (i < len)
	{
		if (!block && masked[i] == '\n')
			return (i);
		if (block && i + 1 < len && masked[i] == '*' && masked[i + 1] == '/')
		{
			dt_mask_replace(masked, i++);
			dt_mask_replace(masked, i++);
			return (i);
		}
		dt_mask_replace(masked, i++);
	}
	return (i);
}

/*
** Rôle: dt_mask_code — masque les zones non exécutables du C en préservant
** les positions et retours ligne.
** Paramètre: text — buffer de texte source et sa longueur.
** Retour: Retourne le pointeur trouvé ou créé; NULL signale une absence, une
** entrée invalide ou un échec d’allocation/E/S selon le chemin local.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_mask_comment(), dt_mask_quote().
** Appelants: dt_doc_check_file(), dt_duplicate_append(),
**            dt_check_function_names(), dt_strict_check_file(),
**            dt_ui_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère text_mask.c
**        -> dt_mask_code() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> malloc(), memcpy().
** Mémoire: opérations directes -> malloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

char	*dt_mask_code(const t_dt_text *text)
{
	char	*masked;
	size_t	i;

	if (!text || !text->data)
		return (NULL);
	masked = malloc(text->len + 1);
	if (!masked)
		return (NULL);
	memcpy(masked, text->data, text->len + 1);
	i = 0;
	while (i < text->len)
	{
		if (masked[i] == '"' || masked[i] == '\'')
			i = dt_mask_quote(masked, i, text->len, masked[i]);
		else if (i + 1 < text->len && masked[i] == '/' && masked[i + 1] == '*')
			i = dt_mask_comment(masked, i, text->len, 1);
		else if (i + 1 < text->len && masked[i] == '/' && masked[i + 1] == '/')
			i = dt_mask_comment(masked, i, text->len, 0);
		else
			i++;
	}
	return (masked);
}
