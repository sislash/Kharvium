/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sha256_file.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <string.h>

static const uint32_t g_sha_init[8] = {
	0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
	0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
};

/*
** Rôle: dt_sha_init — initialise la structure fournie dans un état vide et
** cohérent avant son premier usage.
** Paramètre: ctx — contexte interne possédant l’état de calcul en cours.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_sha256_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sha256_file.c -> dt_sha_init() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memcpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_sha_init.
** Concurrence: état global mutable détecté (g_sha_init); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_sha_init(t_dt_sha256 *ctx)
{
	memcpy(ctx->state, g_sha_init, sizeof(g_sha_init));
	ctx->bits = 0;
	ctx->buffer_len = 0;
}

/*
** Rôle: dt_sha_update — exécute l’opération interne « sha update » avec
** validation des bornes et erreurs.
** Paramètre: ctx — contexte interne possédant l’état de calcul en cours.
** Paramètre: data — valeur « data » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Paramètre: len — valeur « len » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_sha_compress().
** Appelants: dt_sha256_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sha256_file.c -> dt_sha_update() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memcpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_sha_update(t_dt_sha256 *ctx, const unsigned char *data,
	size_t len)
{
	size_t	copy;

	ctx->bits += (uint64_t)len * 8;
	while (len > 0)
	{
		copy = 64 - ctx->buffer_len;
		if (copy > len)
			copy = len;
		memcpy(ctx->buffer + ctx->buffer_len, data, copy);
		ctx->buffer_len += copy;
		data += copy;
		len -= copy;
		if (ctx->buffer_len == 64)
		{
			dt_sha_compress(ctx, ctx->buffer);
			ctx->buffer_len = 0;
		}
	}
}

/*
** Rôle: dt_sha_write_digest — exécute l’opération interne « sha write digest
** » avec validation des bornes et erreurs.
** Paramètre: ctx — contexte interne possédant l’état de calcul en cours.
** Paramètre: digest — buffer de 32 octets recevant l’empreinte SHA-256.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_sha_final().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sha256_file.c -> dt_sha_write_digest() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_sha_write_digest(t_dt_sha256 *ctx, unsigned char digest[32])
{
	int	i;

	i = 0;
	while (i < 32)
	{
		digest[i] = (unsigned char)(ctx->state[i / 4]
				>> (24 - (i % 4) * 8));
		i++;
	}
}

/*
** Rôle: dt_sha_final — exécute l’opération interne « sha final » avec
** validation des bornes et erreurs.
** Paramètre: ctx — contexte interne possédant l’état de calcul en cours.
** Paramètre: digest — buffer de 32 octets recevant l’empreinte SHA-256.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_sha_compress(),
**            dt_sha_write_digest().
** Appelants: dt_sha256_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sha256_file.c -> dt_sha_final() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=3; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_sha_final(t_dt_sha256 *ctx, unsigned char digest[32])
{
	uint64_t	bits;
	int			i;

	bits = ctx->bits;
	ctx->buffer[ctx->buffer_len++] = 0x80;
	if (ctx->buffer_len > 56)
	{
		while (ctx->buffer_len < 64)
			ctx->buffer[ctx->buffer_len++] = 0;
		dt_sha_compress(ctx, ctx->buffer);
		ctx->buffer_len = 0;
	}
	while (ctx->buffer_len < 56)
		ctx->buffer[ctx->buffer_len++] = 0;
	i = 0;
	while (i < 8)
	{
		ctx->buffer[63 - i] = (unsigned char)(bits >> (i * 8));
		i++;
	}
	dt_sha_compress(ctx, ctx->buffer);
	dt_sha_write_digest(ctx, digest);
}

/*
** Rôle: dt_sha256_file — calcule ou formate une empreinte SHA-256 déterministe.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: digest — buffer de 32 octets recevant l’empreinte SHA-256.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_sha_final(), dt_sha_init(),
**            dt_sha_update().
** Appelants: dt_manifest_write_file(), dt_manifest_line_check().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sha256_file.c -> dt_sha256_file() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), ferror(),
**              fopen(), fread().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fread().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=3; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_sha256_file(const char *path, unsigned char digest[32])
{
	t_dt_sha256	ctx;
	FILE			*file;
	unsigned char	buffer[8192];
	size_t		read_count;

	file = fopen(path, "rb");
	if (!file)
		return (0);
	dt_sha_init(&ctx);
	read_count = fread(buffer, 1, sizeof(buffer), file);
	while (read_count > 0)
	{
		dt_sha_update(&ctx, buffer, read_count);
		read_count = fread(buffer, 1, sizeof(buffer), file);
	}
	if (ferror(file))
		return (fclose(file), 0);
	fclose(file);
	dt_sha_final(&ctx, digest);
	return (1);
}

