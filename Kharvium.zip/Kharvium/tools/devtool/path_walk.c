/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   path_walk.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool.h"

#include <stdio.h>
#include <string.h>

#ifdef _WIN32
# include <windows.h>
#else
# include <dirent.h>
# include <sys/stat.h>
#endif

/*
** Rôle: dt_join_path — construit, collecte ou valide un chemin utilisé par
** les outils de développement.
** Paramètre: out — valeur « out » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: cap — valeur « cap » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Paramètre: name — nom d’identifiant ou d’option à analyser.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_collect_posix(), dt_collect_windows().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère path_walk.c
**        -> dt_join_path() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_join_path(char *out, size_t cap, const char *root,
	const char *name)
{
	int	written;

	written = snprintf(out, cap, "%s/%s", root, name);
	return (written >= 0 && (size_t)written < cap);
}

#ifndef _WIN32
/*
** Rôle: dt_collect_posix — exécute l’opération interne « collect posix » avec
** validation des bornes et erreurs.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Paramètre: suffix — suffixe de fichier recherché.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_collect_posix(), dt_join_path(),
**            dt_path_has_suffix(), dt_paths_push().
** Appelants: dt_collect_posix(), dt_paths_collect().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère path_walk.c
**        -> dt_collect_posix() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> S_ISDIR(), S_ISREG(),
**              closedir(), opendir(), readdir(), stat(), strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> closedir(), opendir(),
**      readdir(), stat().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=4; dépendances
**              externes/macros=7. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_collect_posix(t_dt_paths *paths, const char *root,
	const char *suffix)
{
	char		path[4096];
	struct dirent	*entry;
	struct stat	st;
	DIR			*dir;

	dir = opendir(root);
	if (!dir)
		return (0);
	entry = readdir(dir);
	while (entry)
	{
		if (strcmp(entry->d_name, ".") && strcmp(entry->d_name, "..")
			&& dt_join_path(path, sizeof(path), root, entry->d_name)
			&& stat(path, &st) == 0)
		{
			if (S_ISDIR(st.st_mode) && !dt_collect_posix(paths, path, suffix))
				return (closedir(dir), 0);
			if (S_ISREG(st.st_mode) && dt_path_has_suffix(path, suffix)
				&& !dt_paths_push(paths, path))
				return (closedir(dir), 0);
		}
		entry = readdir(dir);
	}
	closedir(dir);
	return (1);
}
#endif

#ifdef _WIN32
static int	dt_collect_windows(t_dt_paths *paths, const char *root,
		const char *suffix);

/*
** Rôle: dt_windows_entry — exécute l’opération interne « windows entry » avec
** validation des bornes et erreurs.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: data — valeur « data » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Paramètre: suffix — suffixe de fichier recherché.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_collect_windows(),
**            dt_path_has_suffix(), dt_paths_push().
** Appelants: dt_collect_windows().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère path_walk.c
**        -> dt_windows_entry() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_windows_entry(t_dt_paths *paths, const char *path,
	const WIN32_FIND_DATAA *data, const char *suffix)
{
	if (data->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		return (dt_collect_windows(paths, path, suffix));
	if (dt_path_has_suffix(path, suffix))
		return (dt_paths_push(paths, path));
	return (1);
}

/*
** Rôle: dt_collect_windows — exécute l’opération interne « collect windows »
** avec validation des bornes et erreurs.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Paramètre: suffix — suffixe de fichier recherché.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_join_path(), dt_windows_entry().
** Appelants: dt_paths_collect(), dt_windows_entry().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère path_walk.c
**        -> dt_collect_windows() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> FindClose(),
**              FindFirstFileA(), FindNextFileA(), snprintf(), strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_collect_windows(t_dt_paths *paths, const char *root,
	const char *suffix)
{
	char			pattern[4096];
	char			path[4096];
	WIN32_FIND_DATAA	data;
	HANDLE			find;

	if (snprintf(pattern, sizeof(pattern), "%s/*", root) < 0)
		return (0);
	find = FindFirstFileA(pattern, &data);
	if (find == INVALID_HANDLE_VALUE)
		return (0);
	while (1)
	{
		if (strcmp(data.cFileName, ".") && strcmp(data.cFileName, "..")
			&& dt_join_path(path, sizeof(path), root, data.cFileName)
			&& !dt_windows_entry(paths, path, &data, suffix))
			return (FindClose(find), 0);
		if (!FindNextFileA(find, &data))
			break ;
	}
	FindClose(find);
	return (1);
}
#endif

/*
** Rôle: dt_paths_collect — construit, collecte ou valide un chemin utilisé
** par les outils de développement.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Paramètre: suffix — suffixe de fichier recherché.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_collect_posix(),
**            dt_collect_windows().
** Appelants: dt_command_duplicates(), dt_command_manifest(),
**            dt_command_package_audit(), dt_collect_root(),
**            dt_command_ui_text().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère path_walk.c
**        -> dt_paths_collect() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_paths_collect(t_dt_paths *paths, const char *root,
	const char *suffix)
{
#ifdef _WIN32
	return (dt_collect_windows(paths, root, suffix));
#else
	return (dt_collect_posix(paths, root, suffix));
#endif
}
