/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   package_policy_selftest.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>

/*
** Rôle: dt_policy_expect_forbidden — vérifie la politique d’exclusion des
** artefacts et scripts du paquet source.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_is_forbidden_package_path().
** Appelants: dt_command_package_policy_selftest().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_policy_selftest.c -> dt_policy_expect_forbidden() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_policy_expect_forbidden(const char *path)
{
	if (!dt_is_forbidden_package_path(path))
	{
		fprintf(stderr, "[package-policy-c] expected forbidden: %s\n", path);
		return (0);
	}
	return (1);
}

/*
** Rôle: dt_policy_expect_allowed — vérifie la politique d’exclusion des
** artefacts et scripts du paquet source.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_is_forbidden_package_path().
** Appelants: dt_command_package_policy_selftest().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_policy_selftest.c -> dt_policy_expect_allowed() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_policy_expect_allowed(const char *path)
{
	if (dt_is_forbidden_package_path(path))
	{
		fprintf(stderr, "[package-policy-c] expected allowed: %s\n", path);
		return (0);
	}
	return (1);
}

/*
** Rôle: dt_command_package_policy_selftest — exécute la sous-commande «
** package policy selftest » et retourne un statut exploitable par le Makefile
** et la CI.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_policy_expect_allowed(),
**            dt_policy_expect_forbidden().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_policy_selftest.c -> dt_command_package_policy_selftest()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> puts().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_package_policy_selftest(void)
{
	int	ok;

	ok = dt_policy_expect_forbidden("stage/tools/obsolete.py");
	ok = ok && dt_policy_expect_forbidden("stage/tools/obsolete.sh");
	ok = ok && dt_policy_expect_forbidden("stage/tools/windows_test.bat");
	ok = ok && dt_policy_expect_forbidden("stage/logs/runtime.log");
	ok = ok && dt_policy_expect_forbidden("stage/finance_book.csv");
	ok = ok && dt_policy_expect_forbidden("stage/build/unit.o");
	ok = ok && dt_policy_expect_forbidden("stage/tests/run.csv.idxstate");
	ok = ok && dt_policy_expect_allowed("stage/src/main.c");
	ok = ok && dt_policy_expect_allowed("stage/tools/devtool/main.c");
	ok = ok && dt_policy_expect_allowed("stage/tests/fixtures/baseline.csv");
	ok = ok && dt_policy_expect_allowed("stage/data/catalog/items.csv");
	if (!ok)
		return (1);
	puts("[package-policy-c] PASS");
	return (0);
}
