/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   duplicates_collect.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdlib.h>
#include <string.h>

/*
** Rôle: dt_duplicate_fill — normalise, collecte ou compare les fonctions afin
** de détecter les duplications accidentelles.
** Paramètre: record — valeur « record » utilisée uniquement selon le contrat
** et les validations de cette fonction.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: function — description de la fonction C en cours d’analyse.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_hash_text(),
**            dt_normalize_function_body().
** Appelants: dt_duplicate_store().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        duplicates_collect.c -> dt_duplicate_fill() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset(), strncpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_duplicate_fill(t_dt_duplicate *record, const char *path,
	const t_dt_text *text, const t_dt_function *function)
{
	memset(record, 0, sizeof(*record));
	strncpy(record->name, function->name, sizeof(record->name) - 1);
	strncpy(record->path, path, sizeof(record->path) - 1);
	record->line = function->start_line;
	if (!dt_normalize_function_body(text, function, &record->body))
		return (0);
	record->hash = dt_hash_text(record->body);
	return (1);
}

/*
** Rôle: dt_duplicate_store — normalise, collecte ou compare les fonctions
** afin de détecter les duplications accidentelles.
** Paramètre: records — valeur « records » utilisée uniquement selon le
** contrat et les validations de cette fonction.
** Paramètre: count — valeur « count » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Paramètre: source — valeur « source » utilisée uniquement selon le contrat
** et les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_duplicate_fill().
** Appelants: dt_duplicate_append().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        duplicates_collect.c -> dt_duplicate_store() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> realloc().
** Mémoire: opérations directes -> realloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_duplicate_store(t_dt_duplicate **records, size_t *count,
	const t_dt_duplicate_source *source)
{
	t_dt_duplicate	*next;
	size_t			i;

	next = realloc(*records, (*count + source->functions->count)
			* sizeof(**records));
	if (!next)
		return (0);
	*records = next;
	i = 0;
	while (i < source->functions->count)
	{
		if (!dt_duplicate_fill(&(*records)[*count], source->path,
				source->text, &source->functions->items[i]))
			return (0);
		(*count)++;
		i++;
	}
	return (1);
}

/*
** Rôle: dt_duplicate_append — normalise, collecte ou compare les fonctions
** afin de détecter les duplications accidentelles.
** Paramètre: records — valeur « records » utilisée uniquement selon le
** contrat et les validations de cette fonction.
** Paramètre: count — valeur « count » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_duplicate_store(),
**            dt_functions_free(), dt_functions_init(), dt_functions_parse(),
**            dt_mask_code(), dt_text_free(), dt_text_read().
** Appelants: dt_command_duplicates().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        duplicates_collect.c -> dt_duplicate_append() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=7; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_duplicate_append(t_dt_duplicate **records, size_t *count,
	const char *path)
{
	t_dt_text		text;
	t_dt_functions	functions;
	char			*masked;
	int				ok;
	t_dt_duplicate_source	source;

	if (!dt_text_read(path, &text))
		return (0);
	masked = dt_mask_code(&text);
	dt_functions_init(&functions);
	if (!masked || !dt_functions_parse(&text, masked, &functions))
		return (free(masked), dt_text_free(&text), 0);
	source.path = path;
	source.text = &text;
	source.functions = &functions;
	ok = dt_duplicate_store(records, count, &source);
	dt_functions_free(&functions);
	free(masked);
	dt_text_free(&text);
	return (ok);
}

/*
** Rôle: dt_duplicate_records_free — normalise, collecte ou compare les
** fonctions afin de détecter les duplications accidentelles.
** Paramètre: records — valeur « records » utilisée uniquement selon le
** contrat et les validations de cette fonction.
** Paramètre: count — valeur « count » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_command_duplicates().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        duplicates_collect.c -> dt_duplicate_records_free() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_duplicate_records_free(t_dt_duplicate *records, size_t count)
{
	size_t	i;

	i = 0;
	while (i < count)
		free(records[i++].body);
	free(records);
}
