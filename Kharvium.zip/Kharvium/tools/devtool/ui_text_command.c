/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_text_command.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char	*g_ui_list_paths[] = {
	"src/ui/ui_widget_list.c", "src/ui/ui_widget_list_row.c", NULL};
static const char	*g_ui_text_paths[] = {"src/ui/ui_widget_text.c", NULL};
/*
** Rôle: dt_ui_raw_allowed — vérifie les règles de clipping et de rendu borné
** des textes UI.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: window_call — valeur « window_call » utilisée uniquement selon
** le contrat et les validations de cette fonction.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_ui_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        ui_text_command.c -> dt_ui_raw_allowed() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_ui_raw_allowed(const char *path, int window_call)
{
	if (window_call)
		return (strstr(path, "src/ui/ui_text_fit.c") != NULL);
	return (strstr(path, "src/ui/ui_widgets.c")
		|| strstr(path, "src/ui/ui_text_fit.c"));
}

/*
** Rôle: dt_ui_check_file — vérifie les règles de clipping et de rendu borné
** des textes UI.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_mask_code(), dt_text_free(),
**            dt_text_read(), dt_ui_raw_allowed().
** Appelants: dt_command_ui_text().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        ui_text_command.c -> dt_ui_check_file() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> free(), strstr().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_ui_check_file(const char *path)
{
	t_dt_text	text;
	char		*masked;
	int			findings;

	if (!dt_text_read(path, &text))
		return (1);
	findings = 0;
	masked = dt_mask_code(&text);
	if (!masked)
		return (dt_text_free(&text), 1);
	if (strstr(masked, "window_draw_text(")
		&& !dt_ui_raw_allowed(path, 1))
		findings++;
	if (strstr(masked, "ui_draw_text(") && !dt_ui_raw_allowed(path, 0))
		findings++;
	free(masked);
	dt_text_free(&text);
	return (findings);
}

/*
** Rôle: dt_ui_group_has — vérifie les règles de clipping et de rendu borné
** des textes UI.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Paramètre: needle — valeur « needle » utilisée uniquement selon le contrat
** et les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_file_contains().
** Appelants: dt_ui_check_scroll().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        ui_text_command.c -> dt_ui_group_has() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_ui_group_has(const char **paths, const char *needle)
{
	int	i;

	i = 0;
	while (paths[i])
	{
		if (dt_file_contains(paths[i], needle))
			return (1);
		i++;
	}
	return (0);
}

/*
** Rôle: dt_ui_check_scroll — vérifie les règles de clipping et de rendu borné
** des textes UI.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_ui_group_has().
** Appelants: dt_command_ui_text().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        ui_text_command.c -> dt_ui_check_scroll() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_ui_list_paths,
**               g_ui_text_paths.
** Concurrence: état global mutable détecté (g_ui_list_paths,
**              g_ui_text_paths); synchronisation externe requise si
**              plusieurs threads y accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_ui_check_scroll(void)
{
	int	findings;

	findings = 0;
	if (!dt_ui_group_has(g_ui_list_paths, "window_set_clip_rectangle")
		|| !dt_ui_group_has(g_ui_list_paths, "window_clear_clip_rectangle"))
		findings++;
	if (!dt_ui_group_has(g_ui_list_paths, "ui_draw_text_fit")
		&& !dt_ui_group_has(g_ui_list_paths, "ui_draw_text_ellipsis"))
		findings++;
	if (!dt_ui_group_has(g_ui_text_paths, "window_set_clip_rectangle")
		|| !dt_ui_group_has(g_ui_text_paths, "window_clear_clip_rectangle"))
		findings++;
	if (!dt_ui_group_has(g_ui_text_paths, "ui_draw_text_fit")
		&& !dt_ui_group_has(g_ui_text_paths, "ui_draw_text_ellipsis"))
		findings++;
	return (findings);
}

/*
** Rôle: dt_command_ui_text — exécute la sous-commande « ui text » et retourne
** un statut exploitable par le Makefile et la CI.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_paths_collect(), dt_paths_free(),
**            dt_paths_init(), dt_ui_check_file(), dt_ui_check_scroll().
** Appelants: dt_command_all(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        ui_text_command.c -> dt_command_ui_text() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=5; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_ui_text(void)
{
	t_dt_paths	paths;
	size_t		i;
	int			findings;

	dt_paths_init(&paths);
	if (!dt_paths_collect(&paths, "src/app", ".c")
		|| !dt_paths_collect(&paths, "src/ui", ".c"))
		return (dt_paths_free(&paths), 1);
	findings = 0;
	i = 0;
	while (i < paths.count)
		findings += dt_ui_check_file(paths.items[i++]);
	findings += dt_ui_check_file("src/main.c");
	findings += dt_ui_check_scroll();
	dt_paths_free(&paths);
	if (findings)
		printf("[ui-text-c] FAIL: %d finding(s)\n", findings);
	else
		printf("[ui-text-c] PASS: 0 finding(s)\n");
	return (findings != 0);
}
