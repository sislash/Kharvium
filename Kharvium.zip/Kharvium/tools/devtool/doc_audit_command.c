/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   doc_audit_command.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int	dt_comment_is_precise(const t_dt_text *text,
		const t_dt_function *function);

static const char	*g_doc_tokens[] = {
	"** Rôle:", "** Retour:", "** Effets:", "** Invariants:",
	"** Relations:", "** Appelants:", "** Index:", "** Dépendances:",
	"** Mémoire:", "** État partagé:", "** Concurrence:", "** I/O:",
	"** Unités:", "** Performance:", "** Portabilité:", NULL};

/*
** Rôle: dt_doc_function_ok — contrôle la présence et la précision de la
** documentation technique des fonctions.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: function — description de la fonction C en cours d’analyse.
** Paramètre: graph — valeur « graph » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_comment_before_function(),
**            dt_comment_is_precise().
** Appelants: dt_doc_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        doc_audit_command.c -> dt_doc_function_ok() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_doc_tokens.
** Concurrence: état global mutable détecté (g_doc_tokens); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_doc_function_ok(const t_dt_text *text,
	const t_dt_function *function, const char *graph)
{
	int	i;

	i = 0;
	while (g_doc_tokens[i])
	{
		if (!dt_comment_before_function(text, function, g_doc_tokens[i]))
			return (0);
		i++;
	}
	if (!dt_comment_is_precise(text, function))
		return (0);
	return (strstr(graph, function->name) != NULL);
}

/*
** Rôle: dt_doc_check_file — contrôle la présence et la précision de la
** documentation technique des fonctions.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: graph — valeur « graph » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Paramètre: total — valeur « total » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_doc_function_ok(),
**            dt_functions_free(), dt_functions_init(), dt_functions_parse(),
**            dt_mask_code(), dt_text_free(), dt_text_read().
** Appelants: dt_command_doc_audit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        doc_audit_command.c -> dt_doc_check_file() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf(), free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=7; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

/*
** Rôle: dt_doc_count_missing — compte les fonctions dont le contrat ou les
** liens documentaires sont absents du fichier et du graphe fournis.
** Paramètre: path — chemin source affiché dans le diagnostic.
** Paramètre: text — texte source déjà chargé et conservé par l’appelant.
** Paramètre: functions — collection des fonctions détectées dans ce texte.
** Paramètre: graph — contenu courant du graphe d’appels C.
** Retour: nombre de fonctions non documentées ou dont l’index est absent.
** Effets: écrit uniquement les diagnostics d’échec sur stderr.
** Invariants: les collections restent détenues et libérées par l’appelant.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_doc_function_ok(), fprintf().
** Appelants: dt_doc_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        doc_audit_command.c -> dt_doc_count_missing().
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation ou libération directe.
** État partagé: aucun état global mutable référencé.
** Concurrence: réentrant pour des entrées indépendantes.
** I/O: diagnostics stderr uniquement lorsqu’un contrat manque.
** Unités: nombre de fonctions détectées.
** Performance: O(n) sur le nombre de fonctions du fichier.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	dt_doc_count_missing(const char *path, const t_dt_text *text,
	const t_dt_functions *functions, const char *graph)
{
	size_t	i;
	int		missing;

	missing = 0;
	i = 0;
	while (i < functions->count)
	{
		if (!dt_doc_function_ok(text, &functions->items[i], graph))
		{
			fprintf(stderr, "[doc-c] missing: %s::%s\n", path,
				functions->items[i].name);
			missing++;
		}
		i++;
	}
	return (missing);
}

static int	dt_doc_check_file(const char *path, const char *graph, int *total)
{
	t_dt_text		text;
	t_dt_functions	functions;
	char			*masked;
	int				missing;

	if (!dt_text_read(path, &text))
		return (1);
	masked = dt_mask_code(&text);
	dt_functions_init(&functions);
	if (!masked || !dt_functions_parse(&text, masked, &functions))
		return (free(masked), dt_text_free(&text), 1);
	*total += (int)functions.count;
	missing = dt_doc_count_missing(path, &text, &functions, graph);
	dt_functions_free(&functions);
	free(masked);
	dt_text_free(&text);
	return (missing);
}

/*
** Rôle: dt_doc_load_graph — contrôle la présence et la précision de la
** documentation technique des fonctions.
** Paramètre: graph — valeur « graph » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_text_read().
** Appelants: dt_command_doc_audit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        doc_audit_command.c -> dt_doc_load_graph() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_doc_load_graph(t_dt_text *graph)
{
	if (!dt_text_read("docs/FUNCTION_CALL_GRAPH.md", graph))
	{
		fprintf(stderr, "[doc-c] missing FUNCTION_CALL_GRAPH.md\n");
		return (0);
	}
	return (1);
}

/*
** Rôle: dt_command_doc_audit — exécute la sous-commande « doc audit » et
** retourne un statut exploitable par le Makefile et la CI.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_collect_sources(),
**            dt_doc_check_file(), dt_doc_load_graph(), dt_paths_free(),
**            dt_paths_init(), dt_text_free().
** Appelants: dt_command_all(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        doc_audit_command.c -> dt_command_doc_audit() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_doc_audit(void)
{
	t_dt_paths	paths;
	t_dt_text	graph;
	size_t		i;
	int			missing;
	int			total;

	dt_paths_init(&paths);
	if (!dt_collect_sources(&paths, 0) || !dt_doc_load_graph(&graph))
		return (dt_paths_free(&paths), 1);
	missing = 0;
	total = 0;
	i = 0;
	while (i < paths.count)
		missing += dt_doc_check_file(paths.items[i++], graph.data, &total);
	dt_text_free(&graph);
	dt_paths_free(&paths);
	printf("[doc-c] definitions=%d missing_or_stale=%d\n", total, missing);
	if (missing)
		return (1);
	printf("[doc-c] OK: role, relations, ownership, units and portability\n");
	return (0);
}
