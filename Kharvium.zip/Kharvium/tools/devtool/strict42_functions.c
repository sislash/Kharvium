/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strict42_functions.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <string.h>

/*
** Rôle: dt_return_valid — exécute l’opération interne « return valid » avec
** validation des bornes et erreurs.
** Paramètre: start — borne de début inclusive de la zone analysée.
** Paramètre: semicolon — valeur « semicolon » utilisée uniquement selon le
** contrat et les validations de cette fonction.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_check_returns().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_functions.c -> dt_return_valid() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_return_valid(const char *start, const char *semicolon)
{
	while (start < semicolon && (*start == ' ' || *start == '\t'))
		start++;
	if (start == semicolon)
		return (1);
	while (semicolon > start
		&& (semicolon[-1] == ' ' || semicolon[-1] == '\t'))
		semicolon--;
	return (*start == '(' && semicolon > start && semicolon[-1] == ')');
}

/*
** Rôle: dt_check_returns — exécute l’opération interne « check returns » avec
** validation des bornes et erreurs.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: function — description de la fonction C en cours d’analyse.
** Paramètre: counts — compteurs Strict42 accumulés pour le rapport.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_return_valid().
** Appelants: dt_check_one_function().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_functions.c -> dt_check_returns() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strchr(), strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_check_returns(const char *masked, const t_dt_function *function,
	t_dt_strict_counts *counts)
{
	const char	*cursor;
	const char	*end;
	const char	*semicolon;

	cursor = masked + function->body_start + 1;
	end = masked + function->body_end;
	while (cursor < end && (cursor = strstr(cursor, "return")) && cursor < end)
	{
		if ((cursor > masked && (cursor[-1] == '_'
				|| (cursor[-1] >= 'a' && cursor[-1] <= 'z')
				|| (cursor[-1] >= 'A' && cursor[-1] <= 'Z')))
			|| ((cursor[6] >= 'a' && cursor[6] <= 'z') || cursor[6] == '_'))
		{
			cursor += 6;
			continue ;
		}
		semicolon = strchr(cursor + 6, ';');
		if (!semicolon || semicolon > end)
			break ;
		if (!dt_return_valid(cursor + 6, semicolon))
			counts->return_not_parenthesized++;
		cursor = semicolon + 1;
	}
}

/*
** Rôle: dt_check_one_function — analyse les signatures, corps ou collections
** de fonctions C.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: function — description de la fonction C en cours d’analyse.
** Paramètre: counts — compteurs Strict42 accumulés pour le rapport.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_check_returns(), dt_is_snake_case().
** Appelants: dt_strict_check_functions().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_functions.c -> dt_check_one_function() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_check_one_function(const char *masked,
	const t_dt_function *function, t_dt_strict_counts *counts)
{
	if (function->end_line - function->body_line - 1 > 25)
		counts->function_too_long++;
	if (function->parameters > 4)
		counts->too_many_parameters++;
	if (!dt_is_snake_case(function->name))
		counts->function_not_snake++;
	dt_check_returns(masked, function, counts);
}

/*
** Rôle: dt_strict_check_functions — analyse la conformité structurelle
** Strict42 et met à jour les compteurs correspondants.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: functions — collection de fonctions détectées dans le fichier.
** Paramètre: counts — compteurs Strict42 accumulés pour le rapport.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_check_one_function().
** Appelants: dt_strict_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_functions.c -> dt_strict_check_functions() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_strict_check_functions(const char *masked,
	const t_dt_functions *functions, t_dt_strict_counts *counts)
{
	size_t	i;

	if (functions->count > 5)
		counts->too_many_functions++;
	i = 0;
	while (i < functions->count)
	{
		dt_check_one_function(masked, &functions->items[i], counts);
		i++;
	}
}
