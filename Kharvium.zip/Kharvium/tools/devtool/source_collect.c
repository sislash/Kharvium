/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   source_collect.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <string.h>

/*
** Rôle: dt_collect_root — exécute l’opération interne « collect root » avec
** validation des bornes et erreurs.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_paths_collect().
** Appelants: dt_collect_sources().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        source_collect.c -> dt_collect_root() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_collect_root(t_dt_paths *paths, const char *root)
{
	if (!dt_paths_collect(paths, root, ".c"))
		return (0);
	if (!dt_paths_collect(paths, root, ".h"))
		return (0);
	return (1);
}

/*
** Rôle: dt_collect_sources — collecte les sources C entrant dans les audits
** du projet.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Paramètre: production_only — indique si seuls les fichiers de production
** doivent être collectés.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_collect_root().
** Appelants: dt_command_doc_audit(), dt_command_naming(),
**            dt_command_strict42().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        source_collect.c -> dt_collect_sources() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_collect_sources(t_dt_paths *paths, int production_only)
{
	if (!dt_collect_root(paths, "src"))
		return (0);
	if (!dt_collect_root(paths, "includes"))
		return (0);
	if (production_only)
		return (1);
	if (!dt_collect_root(paths, "tests"))
		return (0);
	if (!dt_collect_root(paths, "tools"))
		return (0);
	return (1);
}

/*
** Rôle: dt_file_contains — exécute l’opération interne « file contains » avec
** validation des bornes et erreurs.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: needle — valeur « needle » utilisée uniquement selon le contrat
** et les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_text_free(), dt_text_read().
** Appelants: dt_package_brand_ok(), dt_ui_group_has().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        source_collect.c -> dt_file_contains() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_file_contains(const char *path, const char *needle)
{
	t_dt_text	text;
	int			found;

	if (!dt_text_read(path, &text))
		return (0);
	found = (strstr(text.data, needle) != NULL);
	dt_text_free(&text);
	return (found);
}
