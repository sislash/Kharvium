/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   function_list.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool.h"

#include <stdlib.h>

/*
** Rôle: dt_functions_init — analyse les signatures, corps ou collections de
** fonctions C.
** Paramètre: functions — collection de fonctions détectées dans le fichier.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_doc_check_file(), dt_duplicate_append(),
**            dt_functions_free(), dt_check_function_names(),
**            dt_strict_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_list.c -> dt_functions_init() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_functions_init(t_dt_functions *functions)
{
	if (!functions)
		return ;
	functions->items = NULL;
	functions->count = 0;
	functions->capacity = 0;
}

/*
** Rôle: dt_functions_free — analyse les signatures, corps ou collections de
** fonctions C.
** Paramètre: functions — collection de fonctions détectées dans le fichier.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_functions_init().
** Appelants: dt_doc_check_file(), dt_duplicate_append(),
**            dt_check_function_names(), dt_strict_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_list.c -> dt_functions_free() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_functions_free(t_dt_functions *functions)
{
	if (!functions)
		return ;
	free(functions->items);
	dt_functions_init(functions);
}

/*
** Rôle: dt_functions_push — analyse les signatures, corps ou collections de
** fonctions C.
** Paramètre: functions — collection de fonctions détectées dans le fichier.
** Paramètre: item — élément source copié dans la collection.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_functions_parse().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_list.c -> dt_functions_push() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> realloc().
** Mémoire: opérations directes -> realloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_functions_push(t_dt_functions *functions, const t_dt_function *item)
{
	t_dt_function	*items;
	size_t			capacity;

	if (functions->count == functions->capacity)
	{
		capacity = functions->capacity * 2;
		if (capacity < 16)
			capacity = 16;
		items = realloc(functions->items, capacity * sizeof(*items));
		if (!items)
			return (0);
		functions->items = items;
		functions->capacity = capacity;
	}
	functions->items[functions->count++] = *item;
	return (1);
}
