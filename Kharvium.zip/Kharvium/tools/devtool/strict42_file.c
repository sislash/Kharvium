/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strict42_file.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdlib.h>
#include <string.h>

int		dt_has_42_header(const char *text);
void	dt_strict_check_lines(const char *text, t_dt_strict_counts *counts);
void	dt_strict_check_functions(const char *masked,
			const t_dt_functions *functions, t_dt_strict_counts *counts);

/*
** Rôle: dt_strict_check_file — analyse la conformité structurelle Strict42 et
** met à jour les compteurs correspondants.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: counts — compteurs Strict42 accumulés pour le rapport.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_functions_free(),
**            dt_functions_init(), dt_functions_parse(), dt_has_42_header(),
**            dt_mask_code(), dt_strict_check_functions(),
**            dt_strict_check_lines(), dt_text_free() (+1; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Appelants: dt_command_strict42().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_file.c -> dt_strict_check_file() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> free(), strchr().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=9; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_strict_check_file(const char *path, t_dt_strict_counts *counts)
{
	t_dt_text		text;
	t_dt_functions	functions;
	char			*masked;

	if (!dt_text_read(path, &text))
		return (0);
	masked = dt_mask_code(&text);
	if (!masked)
		return (dt_text_free(&text), 0);
	dt_functions_init(&functions);
	if (!dt_functions_parse(&text, masked, &functions))
		return (free(masked), dt_text_free(&text), 0);
	if (!dt_has_42_header(text.data))
		counts->missing_header++;
	dt_strict_check_lines(text.data, counts);
	if (strchr(masked, '?'))
		counts->ternary_forbidden++;
	dt_strict_check_functions(masked, &functions, counts);
	dt_functions_free(&functions);
	free(masked);
	dt_text_free(&text);
	return (1);
}
