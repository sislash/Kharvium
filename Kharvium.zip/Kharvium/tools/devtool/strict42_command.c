/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strict42_command.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: dt_strict_total — analyse la conformité structurelle Strict42 et met
** à jour les compteurs correspondants.
** Paramètre: c — valeur « c » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_command_strict42(), dt_strict_report().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_command.c -> dt_strict_total() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_strict_total(const t_dt_strict_counts *c)
{
	return (c->line_too_long + c->trailing_whitespace
		+ c->double_empty_line + c->missing_header + c->too_many_functions
		+ c->function_too_long + c->too_many_parameters
		+ c->function_not_snake + c->return_not_parenthesized
		+ c->ternary_forbidden);
}

/*
** Rôle: dt_strict_report — analyse la conformité structurelle Strict42 et met
** à jour les compteurs correspondants.
** Paramètre: c — valeur « c » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: files — valeur « files » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_strict_total().
** Appelants: dt_command_strict42().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_command.c -> dt_strict_report() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_strict_report(const t_dt_strict_counts *c, size_t files)
{
	printf("[strict42-c] files checked: %zu\n", files);
	printf("[strict42-c] findings: %d\n", dt_strict_total(c));
	printf("[strict42-c] long=%d params=%d file_functions=%d\n",
		c->function_too_long, c->too_many_parameters, c->too_many_functions);
	printf("[strict42-c] lines=%d returns=%d names=%d ternary=%d\n",
		c->line_too_long + c->trailing_whitespace + c->double_empty_line,
		c->return_not_parenthesized, c->function_not_snake,
		c->ternary_forbidden);
}

/*
** Rôle: dt_command_strict42 — exécute la sous-commande « strict42 » et
** retourne un statut exploitable par le Makefile et la CI.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_collect_sources(), dt_paths_free(),
**            dt_paths_init(), dt_strict_check_file(), dt_strict_report(),
**            dt_strict_total().
** Appelants: dt_command_all(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        strict42_command.c -> dt_command_strict42() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset(), printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=6; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_strict42(void)
{
	t_dt_strict_counts	counts;
	t_dt_paths			paths;
	size_t				i;

	memset(&counts, 0, sizeof(counts));
	dt_paths_init(&paths);
	if (!dt_collect_sources(&paths, 0))
		return (dt_paths_free(&paths), 1);
	i = 0;
	while (i < paths.count)
	{
		if (!dt_strict_check_file(paths.items[i], &counts))
			return (dt_paths_free(&paths), 1);
		i++;
	}
	dt_strict_report(&counts, paths.count);
	i = (size_t)dt_strict_total(&counts);
	dt_paths_free(&paths);
	if (i != 0)
		return (1);
	printf("[strict42-c] OK\n");
	return (0);
}
