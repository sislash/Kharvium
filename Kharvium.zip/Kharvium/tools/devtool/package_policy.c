/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   package_policy.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <string.h>

static const char	*g_forbidden_suffixes[] = {
	".o", ".a", ".so", ".dll", ".exe", ".log", ".bak", ".tmp",
	".offset", ".lock", ".idxstate", ".gcda", ".gcno", ".pyc", ".zip",
	".tar",
	".tar.gz", ".py", ".sh", ".bat", NULL
};

/*
** Rôle: dt_forbidden_suffix — exécute l’opération interne « forbidden suffix
** » avec validation des bornes et erreurs.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_path_has_suffix().
** Appelants: dt_is_forbidden_package_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_policy.c -> dt_forbidden_suffix() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_forbidden_suffixes.
** Concurrence: état global mutable détecté (g_forbidden_suffixes);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_forbidden_suffix(const char *path)
{
	int	i;

	i = 0;
	while (g_forbidden_suffixes[i])
	{
		if (dt_path_has_suffix(path, g_forbidden_suffixes[i]))
			return (1);
		i++;
	}
	return (0);
}

/*
** Rôle: dt_is_forbidden_package_path — construit, collecte ou valide un
** chemin utilisé par les outils de développement.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_forbidden_suffix(),
**            dt_path_basename(), dt_path_has_suffix().
** Appelants: dt_package_files_ok(), dt_policy_expect_allowed(),
**            dt_policy_expect_forbidden().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_policy.c -> dt_is_forbidden_package_path() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_is_forbidden_package_path(const char *path)
{
	if (!path)
		return (1);
	if (strstr(path, "/.git/") || strstr(path, "/build/")
		|| strstr(path, "/bin/") || strstr(path, "/dist/")
		|| strstr(path, "/logs/") || strstr(path, "/scripts/")
		|| strstr(path, "/__pycache__/"))
		return (1);
	if (dt_forbidden_suffix(path) || strstr(path, "finance_book.csv"))
		return (1);
	if (dt_path_has_suffix(path, ".csv")
		&& !strstr(path, "/tests/fixtures/")
		&& !strstr(path, "/data/catalog/"))
		return (1);
	if (strstr(path, "/docs/refactor/")
		|| strstr(dt_path_basename(path), "ETAPE")
		|| strstr(dt_path_basename(path), "QA_STEP"))
		return (1);
	return (0);
}
