/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   function_parse.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <string.h>

/*
** Rôle: dt_body_end — exécute l’opération interne « body end » avec
** validation des bornes et erreurs.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: opening — position de l’accolade ouvrante.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_function_from_brace().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_parse.c -> dt_body_end() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static size_t	dt_body_end(const char *masked, size_t opening)
{
	int		depth;
	size_t	i;

	depth = 1;
	i = opening + 1;
	while (masked[i] && depth > 0)
	{
		if (masked[i] == '{')
			depth++;
		else if (masked[i] == '}')
			depth--;
		if (depth == 0)
			return (i);
		i++;
	}
	return ((size_t)-1);
}

/*
** Rôle: dt_function_lines — analyse les signatures, corps ou collections de
** fonctions C.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: function — description de la fonction C en cours d’analyse.
** Paramètre: start — borne de début inclusive de la zone analysée.
** Paramètre: brace — position de l’accolade ouvrant le corps de fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_line_number().
** Appelants: dt_function_from_brace().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_parse.c -> dt_function_lines() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_function_lines(const t_dt_text *text, t_dt_function *function,
	size_t start, size_t brace)
{
	function->signature_start = start;
	function->body_start = brace;
	function->start_line = dt_line_number(text->data, start);
	function->body_line = dt_line_number(text->data, brace);
	function->end_line = dt_line_number(text->data, function->body_end);
}

/*
** Rôle: dt_signature_is_macro — exécute l’opération interne « signature is
** macro » avec validation des bornes et erreurs.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: open — position de parenthèse ouvrante.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_function_from_brace().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_parse.c -> dt_signature_is_macro() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_signature_is_macro(const char *masked, size_t open)
{
	size_t	line;

	line = open;
	while (line > 0 && masked[line - 1] != '\n')
		line--;
	while (masked[line] == ' ' || masked[line] == '\t')
		line++;
	return (masked[line] == '#');
}

/*
** Rôle: dt_function_from_brace — analyse les signatures, corps ou collections
** de fonctions C.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: brace — position de l’accolade ouvrant le corps de fonction.
** Paramètre: function — description de la fonction C en cours d’analyse.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_body_end(), dt_count_parameters(),
**            dt_function_lines(), dt_matching_open_paren(),
**            dt_signature_is_macro(), dt_signature_name(),
**            dt_signature_start().
** Appelants: dt_functions_parse().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_parse.c -> dt_function_from_brace() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=7; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_function_from_brace(const t_dt_text *text, const char *masked,
	size_t brace, t_dt_function *function)
{
	size_t	start;
	size_t	close;
	size_t	open;

	start = dt_signature_start(masked, brace);
	close = brace;
	while (close > start && masked[close - 1] != ')')
		close--;
	if (close <= start)
		return (0);
	close--;
	open = dt_matching_open_paren(masked, close);
	if (open == (size_t)-1 || open < start
		|| dt_signature_is_macro(masked, open))
		return (0);
	if (!dt_signature_name(masked, open, function->name,
			sizeof(function->name)))
		return (0);
	function->body_end = dt_body_end(masked, brace);
	if (function->body_end == (size_t)-1)
		return (0);
	dt_function_lines(text, function, start, brace);
	function->parameters = dt_count_parameters(masked, open, close);
	return (1);
}

/*
** Rôle: dt_functions_parse — analyse les signatures, corps ou collections de
** fonctions C.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: masked — vue du code où commentaires et littéraux sont masqués.
** Paramètre: functions — collection de fonctions détectées dans le fichier.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_function_from_brace(),
**            dt_functions_push().
** Appelants: dt_doc_check_file(), dt_duplicate_append(),
**            dt_check_function_names(), dt_strict_check_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        function_parse.c -> dt_functions_parse() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_functions_parse(const t_dt_text *text, const char *masked,
	t_dt_functions *functions)
{
	size_t			i;
	int				depth;
	t_dt_function	function;

	i = 0;
	depth = 0;
	while (i < text->len)
	{
		if (masked[i] == '{' && depth == 0
			&& dt_function_from_brace(text, masked, i, &function))
		{
			if (!dt_functions_push(functions, &function))
				return (0);
			i = function.body_end + 1;
			continue ;
		}
		if (masked[i] == '{')
			depth++;
		else if (masked[i] == '}' && depth > 0)
			depth--;
		i++;
	}
	return (1);
}
