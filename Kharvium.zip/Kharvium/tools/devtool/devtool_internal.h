/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   devtool_internal.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DEVTOOL_INTERNAL_H
# define DEVTOOL_INTERNAL_H

# include "devtool.h"

typedef struct s_dt_sha256
{
	uint32_t	state[8];
	uint64_t	bits;
	unsigned char	buffer[64];
	size_t		buffer_len;
}t_dt_sha256;

typedef struct s_dt_strict_counts
{
	int	line_too_long;
	int	trailing_whitespace;
	int	double_empty_line;
	int	missing_header;
	int	too_many_functions;
	int	function_too_long;
	int	too_many_parameters;
	int	function_not_snake;
	int	return_not_parenthesized;
	int	ternary_forbidden;
}t_dt_strict_counts;

typedef struct s_dt_fixture
{
	const char	*path;
	long		kills;
	long		shots;
	long		loot_rows;
	long		loot_value;
	long		ammo_value;
	long		decay_value;
	long		start_ts;
}t_dt_fixture;

typedef struct s_dt_baseline
{
	long long	loot;
	long long	expense;
	long long	rows;
}t_dt_baseline;

typedef struct s_dt_duplicate
{
	char		name[128];
	char		path[512];
	int			line;
	uint64_t	hash;
	char		*body;
}t_dt_duplicate;

typedef struct s_dt_duplicate_source
{
	const char			*path;
	const t_dt_text		*text;
	const t_dt_functions	*functions;
}t_dt_duplicate_source;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_functions_push — analyse les signatures, corps et collections de
** fonctions C.
** Paramètre: functions — collection de fonctions analysées.
** Paramètre: item — élément copié dans la collection.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_functions_push().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_functions_push(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		dt_functions_push(t_dt_functions *functions,
			const t_dt_function *item);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_signature_start — expose l’opération interne « signature start »
** aux autres modules C de l’outil.
** Paramètre: masked — vue du code avec commentaires/littéraux masqués.
** Paramètre: brace — valeur « brace » dont le sens est défini par le type et
** les validations de l’implémentation.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_signature_start().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_signature_start(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
size_t	dt_signature_start(const char *masked, size_t brace);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_matching_open_paren — expose l’opération interne « matching open
** paren » aux autres modules C de l’outil.
** Paramètre: text — texte source chargé et sa longueur.
** Paramètre: close_pos — valeur « close_pos » dont le sens est défini par le
** type et les validations de l’implémentation.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_matching_open_paren().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_matching_open_paren(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
size_t	dt_matching_open_paren(const char *text, size_t close_pos);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_signature_name — expose l’opération interne « signature name » aux
** autres modules C de l’outil.
** Paramètre: text — texte source chargé et sa longueur.
** Paramètre: open — valeur « open » dont le sens est défini par le type et
** les validations de l’implémentation.
** Paramètre: name — nom d’identifiant analysé.
** Paramètre: capacity — capacité du buffer de destination.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_signature_name().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_signature_name(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		dt_signature_name(const char *text, size_t open, char *name,
			size_t capacity);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_count_parameters — expose l’opération interne « count parameters »
** aux autres modules C de l’outil.
** Paramètre: text — texte source chargé et sa longueur.
** Paramètre: open — valeur « open » dont le sens est défini par le type et
** les validations de l’implémentation.
** Paramètre: close — valeur « close » dont le sens est défini par le type et
** les validations de l’implémentation.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_count_parameters().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_count_parameters(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		dt_count_parameters(const char *text, size_t open, size_t close);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_collect_sources — collecte les sources C entrant dans les audits.
** Paramètre: paths — collection de chemins modifiée ou consultée selon le
** contrat.
** Paramètre: production_only — valeur « production_only » dont le sens est
** défini par le type et les validations de l’implémentation.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_collect_sources().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_collect_sources(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		dt_collect_sources(t_dt_paths *paths, int production_only);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_normalize_function_body — analyse les signatures, corps et
** collections de fonctions C.
** Paramètre: text — texte source chargé et sa longueur.
** Paramètre: function — valeur « function » dont le sens est défini par le
** type et les validations de l’implémentation.
** Paramètre: normalized — valeur « normalized » dont le sens est défini par
** le type et les validations de l’implémentation.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_normalize_function_body().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_normalize_function_body(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		dt_normalize_function_body(const t_dt_text *text,
			const t_dt_function *function, char **normalized);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_comment_before_function — analyse les signatures, corps et
** collections de fonctions C.
** Paramètre: text — texte source chargé et sa longueur.
** Paramètre: function — valeur « function » dont le sens est défini par le
** type et les validations de l’implémentation.
** Paramètre: token — valeur « token » dont le sens est défini par le type et
** les validations de l’implémentation.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_comment_before_function().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_comment_before_function(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		dt_comment_before_function(const t_dt_text *text,
			const t_dt_function *function, const char *token);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_file_contains — expose l’opération interne « file contains » aux
** autres modules C de l’outil.
** Paramètre: path — chemin ciblé par l’opération.
** Paramètre: needle — valeur « needle » dont le sens est défini par le type
** et les validations de l’implémentation.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_file_contains().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_file_contains(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		dt_file_contains(const char *path, const char *needle);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_is_forbidden_package_path — manipule ou collecte les chemins
** nécessaires aux audits C.
** Paramètre: path — chemin ciblé par l’opération.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_is_forbidden_package_path().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_is_forbidden_package_path(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		dt_is_forbidden_package_path(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_sha_compress — calcule ou formate les données SHA-256 utilisées
** pour garantir l’intégrité du paquet.
** Paramètre: ctx — contexte interne de calcul.
** Paramètre: block — bloc SHA-256 de 64 octets.
** Retour: Ne retourne rien; les sorties éventuelles sont écrites uniquement
** dans les objets explicitement fournis.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_sha_compress().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_sha_compress(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		dt_sha_compress(t_dt_sha256 *ctx, const unsigned char block[64]);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_strict_check_file — contrôle les règles structurelles Strict42 et
** renseigne leurs compteurs.
** Paramètre: path — chemin ciblé par l’opération.
** Paramètre: counts — valeur « counts » dont le sens est défini par le type
** et les validations de l’implémentation.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_strict_check_file().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_strict_check_file(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		dt_strict_check_file(const char *path, t_dt_strict_counts *counts);

#endif
