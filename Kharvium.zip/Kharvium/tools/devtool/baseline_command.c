/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   baseline_command.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
** Rôle: dt_baseline_field — calcule les totaux de référence d’un CSV Hunt
** sans modifier le fichier.
** Paramètre: line — valeur « line » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Paramètre: field — valeur « field » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne le pointeur trouvé ou créé; NULL signale une absence, une
** entrée invalide ou un échec d’allocation/E/S selon le chemin local.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_baseline_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        baseline_command.c -> dt_baseline_field() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strtok().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static char	*dt_baseline_field(char *line, int field)
{
	char	*token;
	int		index;

	token = strtok(line, ",\r\n");
	index = 0;
	while (token && index < field)
	{
		token = strtok(NULL, ",\r\n");
		index++;
	}
	return (token);
}

/*
** Rôle: dt_baseline_expense — calcule les totaux de référence d’un CSV Hunt
** sans modifier le fichier.
** Paramètre: type — valeur « type » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_baseline_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        baseline_command.c -> dt_baseline_expense() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_baseline_expense(const char *type)
{
	return (!strcmp(type, "SPEND") || !strcmp(type, "AMMO")
		|| !strcmp(type, "DECAY") || !strcmp(type, "REPAIR")
		|| strstr(type, "SPEND") || strstr(type, "AMMO")
		|| strstr(type, "DECAY") || strstr(type, "REPAIR"));
}

/*
** Rôle: dt_baseline_line — calcule les totaux de référence d’un CSV Hunt sans
** modifier le fichier.
** Paramètre: line — valeur « line » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Paramètre: total — valeur « total » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_baseline_expense(),
**            dt_baseline_field().
** Appelants: dt_command_baseline().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        baseline_command.c -> dt_baseline_line() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strncmp(),
**              strncpy(), strtoll().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_baseline_line(char *line, t_dt_baseline *total)
{
	char		copy_type[8192];
	char		copy_value[8192];
	char		*type;
	char		*value;
	long long	amount;

	if (line[0] == '#' || !strncmp(line, "timestamp_unix", 14))
		return ;
	strncpy(copy_type, line, sizeof(copy_type) - 1);
	strncpy(copy_value, line, sizeof(copy_value) - 1);
	copy_type[sizeof(copy_type) - 1] = '\0';
	copy_value[sizeof(copy_value) - 1] = '\0';
	type = dt_baseline_field(copy_type, 1);
	value = dt_baseline_field(copy_value, 4);
	if (!type || !value)
		return ;
	amount = strtoll(value, NULL, 10);
	if (!strcmp(type, "SWEAT") || !strncmp(type, "LOOT", 4)
		|| !strncmp(type, "RECEIVED", 8))
		total->loot += amount;
	else if (dt_baseline_expense(type))
		total->expense += amount;
	total->rows++;
}

/*
** Rôle: dt_command_baseline — exécute la sous-commande « baseline » et
** retourne un statut exploitable par le Makefile et la CI.
** Paramètre: argc — nombre d’arguments de la ligne de commande.
** Paramètre: argv — tableau d’arguments de la ligne de commande.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_baseline_line().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        baseline_command.c -> dt_command_baseline() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fgets(), fopen(),
**              memset(), perror(), printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=6. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_baseline(int argc, char **argv)
{
	const char		*path;
	FILE				*file;
	char				line[8192];
	t_dt_baseline	total;

	path = "tests/fixtures/baseline_hunt_log.csv";
	if (argc >= 3)
		path = argv[2];
	file = fopen(path, "rb");
	if (!file)
		return (perror(path), 1);
	memset(&total, 0, sizeof(total));
	while (fgets(line, sizeof(line), file))
		dt_baseline_line(line, &total);
	fclose(file);
	printf("rows=%lld\nloot_uPED=%lld\nexpense_uPED=%lld\n",
		total.rows, total.loot, total.expense);
	printf("net_uPED=%lld\n", total.loot - total.expense);
	if (total.expense > 0)
		printf("roi_tt_percent=%.2f\n",
			(double)total.loot / (double)total.expense * 100.0);
	else
		printf("roi_tt_percent=0.00\n");
	return (0);
}
