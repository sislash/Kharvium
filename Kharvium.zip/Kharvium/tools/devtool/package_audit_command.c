/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   package_audit_command.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <string.h>

int	dt_manifest_audit(const char *root, size_t expected_files);

/*
** Rôle: dt_package_brand_ok — vérifie qu’un paquet source est propre, complet
** et compatible avec sa politique de livraison.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_file_contains().
** Appelants: dt_command_package_audit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_audit_command.c -> dt_package_brand_ok() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_package_brand_ok(const t_dt_paths *paths)
{
	size_t	i;

	i = 0;
	while (i < paths->count)
	{
		if (dt_file_contains(paths->items[i], "RCE" " Nexus")
			|| dt_file_contains(paths->items[i], "RCE_" "Nexus")
			|| dt_file_contains(paths->items[i], "rce_" "nexus"))
			return (0);
		i++;
	}
	return (1);
}

/*
** Rôle: dt_package_files_ok — vérifie qu’un paquet source est propre, complet
** et compatible avec sa politique de livraison.
** Paramètre: paths — collection de chemins détenue par l’appelant.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_is_forbidden_package_path().
** Appelants: dt_command_package_audit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_audit_command.c -> dt_package_files_ok() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_package_files_ok(const t_dt_paths *paths)
{
	size_t	i;

	i = 0;
	while (i < paths->count)
	{
		if (dt_is_forbidden_package_path(paths->items[i]))
		{
			fprintf(stderr, "[package-c] forbidden: %s\n", paths->items[i]);
			return (0);
		}
		i++;
	}
	return (1);
}

/*
** Rôle: dt_package_active_data_ok — vérifie qu’un paquet source est propre,
** complet et compatible avec sa politique de livraison.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_command_package_audit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_audit_command.c -> dt_package_active_data_ok() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_package_active_data_ok(const char *root)
{
	char	weapons[4096];
	char	markup[4096];
	char	fishing[4096];
	FILE	*file;

	snprintf(weapons, sizeof(weapons), "%s/weapons.ini", root);
	snprintf(markup, sizeof(markup), "%s/markup.ini", root);
	snprintf(fishing, sizeof(fishing), "%s/fishing_rods.ini", root);
	file = fopen(weapons, "rb");
	if (!file)
		return (0);
	fclose(file);
	file = fopen(markup, "rb");
	if (!file)
		return (0);
	fclose(file);
	file = fopen(fishing, "rb");
	if (!file)
		return (0);
	fclose(file);
	return (1);
}

/*
** Rôle: dt_command_package_audit — exécute la sous-commande « package audit »
** et retourne un statut exploitable par le Makefile et la CI.
** Paramètre: argc — nombre d’arguments de la ligne de commande.
** Paramètre: argv — tableau d’arguments de la ligne de commande.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_manifest_audit(),
**            dt_package_active_data_ok(), dt_package_brand_ok(),
**            dt_package_files_ok(), dt_paths_collect(), dt_paths_free(),
**            dt_paths_init().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_audit_command.c -> dt_command_package_audit() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf(), printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=7; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_package_audit(int argc, char **argv)
{
	t_dt_paths	paths;
	const char	*root;
	int			ok;

	if (argc < 3)
		return (fprintf(stderr, "usage: devtool package-audit root\n"), 1);
	root = argv[2];
	dt_paths_init(&paths);
	if (!dt_paths_collect(&paths, root, ""))
		return (dt_paths_free(&paths), 1);
	ok = dt_package_files_ok(&paths) && dt_package_active_data_ok(root)
		&& dt_package_brand_ok(&paths) && dt_manifest_audit(root, paths.count);
	if (ok)
		printf("[package-c] PASS: %zu files\n", paths.count);
	else
		printf("[package-c] FAIL: %zu files\n", paths.count);
	dt_paths_free(&paths);
	return (!ok);
}
