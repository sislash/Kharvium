/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fixture_generate.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>

/*
** Rôle: dt_fixture_shots — génère les données synthétiques Tracker utilisées
** pour les tests de charge.
** Paramètre: file — flux de fichier ouvert dont le cycle de vie reste celui
** de l’appelant.
** Paramètre: f — valeur « f » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: ts — valeur « ts » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_fixture_one_kill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        fixture_generate.c -> dt_fixture_shots() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_fixture_shots(FILE *file, const t_dt_fixture *f, long ts)
{
	long	i;

	i = 0;
	while (i < f->shots)
	{
		fprintf(file, "%ld,SHOT,,1,0,0,0,You inflicted 1.0 points of damage\n",
			ts);
		i++;
	}
}

/*
** Rôle: dt_fixture_loot — génère les données synthétiques Tracker utilisées
** pour les tests de charge.
** Paramètre: file — flux de fichier ouvert dont le cycle de vie reste celui
** de l’appelant.
** Paramètre: f — valeur « f » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: ts — valeur « ts » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: kill_id — valeur « kill_id » utilisée uniquement selon le
** contrat et les validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_fixture_one_kill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        fixture_generate.c -> dt_fixture_loot() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf(), fputs().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_fixture_loot(FILE *file, const t_dt_fixture *f,
	long ts, long kill_id)
{
	long	i;

	i = 0;
	while (i < f->loot_rows)
	{
		fprintf(file, "%ld,LOOT_ITEM,Animal Oil Residue,1,%ld,%ld,3,",
			ts, f->loot_value, kill_id);
		fputs("You received Animal Oil Residue\n", file);
		i++;
	}
}

/*
** Rôle: dt_fixture_one_kill — génère les données synthétiques Tracker
** utilisées pour les tests de charge.
** Paramètre: file — flux de fichier ouvert dont le cycle de vie reste celui
** de l’appelant.
** Paramètre: f — valeur « f » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: ts — valeur « ts » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Paramètre: kill_id — valeur « kill_id » utilisée uniquement selon le
** contrat et les validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_fixture_loot(), dt_fixture_shots().
** Appelants: dt_fixture_generate().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        fixture_generate.c -> dt_fixture_one_kill() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf(), fputs().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_fixture_one_kill(FILE *file, const t_dt_fixture *f,
	long ts, long kill_id)
{
	dt_fixture_shots(file, f, ts);
	fprintf(file, "%ld,KILL,Daikiba Mature,1,0,%ld,2,", ts, kill_id);
	fputs("You killed Daikiba Mature.\n", file);
	dt_fixture_loot(file, f, ts, kill_id);
	if (f->ammo_value > 0)
		fprintf(file, "%ld,AMMO,Weapon,1,%ld,0,1,AMMO\n",
			ts, f->ammo_value);
	if (f->decay_value > 0)
		fprintf(file, "%ld,DECAY,Weapon,1,%ld,0,1,DECAY\n",
			ts, f->decay_value);
}

/*
** Rôle: dt_fixture_generate — génère les données synthétiques Tracker
** utilisées pour les tests de charge.
** Paramètre: fixture — configuration déterministe de la fixture Tracker.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_fixture_one_kill().
** Appelants: dt_command_fixture().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        fixture_generate.c -> dt_fixture_generate() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(), fputs(),
**              perror(), printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_fixture_generate(const t_dt_fixture *fixture)
{
	FILE	*file;
	long	i;

	file = fopen(fixture->path, "wb");
	if (!file)
		return (perror(fixture->path), 1);
	fputs("timestamp_unix,event_type,target_or_item,qty,value_uPED5,", file);
	fputs("kill_id,flags,raw\n", file);
	i = 0;
	while (i < fixture->kills)
	{
		dt_fixture_one_kill(file, fixture, fixture->start_ts + i, i + 1);
		i++;
	}
	fclose(file);
	printf("[fixture-c] %s: kills=%ld\n", fixture->path, fixture->kills);
	return (0);
}
