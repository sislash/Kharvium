/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   naming_command.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char	*g_legacy_prefixes[] = {
	"tl_", "tm_", "ihm_", "cfg_", "kv_", "db_", "mob_",
	"tracker_stats_", NULL
};

/*
** Rôle: dt_name_stem — valide le nommage snake_case des sources et fonctions
** du projet.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: stem — valeur « stem » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Paramètre: capacity — capacité maximale du buffer de destination.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_path_basename().
** Appelants: dt_command_naming().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        naming_command.c -> dt_name_stem() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memcpy(), strlen(),
**              strrchr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_name_stem(const char *path, char *stem, size_t capacity)
{
	const char	*base;
	const char	*dot;
	size_t		len;

	base = dt_path_basename(path);
	dot = strrchr(base, '.');
	if (dot)
		len = (size_t)(dot - base);
	else
		len = strlen(base);
	if (len == 0 || len >= capacity)
		return (0);
	memcpy(stem, base, len);
	stem[len] = '\0';
	return (1);
}

/*
** Rôle: dt_name_has_legacy_prefix — valide le nommage snake_case des sources
** et fonctions du projet.
** Paramètre: name — nom d’identifiant ou d’option à analyser.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_check_function_names(), dt_command_naming().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        naming_command.c -> dt_name_has_legacy_prefix() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strlen(), strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_legacy_prefixes.
** Concurrence: état global mutable détecté (g_legacy_prefixes);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_name_has_legacy_prefix(const char *name)
{
	int		i;

	i = 0;
	while (g_legacy_prefixes[i])
	{
		if (!strncmp(name, g_legacy_prefixes[i], strlen(g_legacy_prefixes[i])))
			return (1);
		i++;
	}
	return (0);
}

/*
** Rôle: dt_check_function_names — analyse les signatures, corps ou
** collections de fonctions C.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_functions_free(),
**            dt_functions_init(), dt_functions_parse(), dt_is_snake_case(),
**            dt_mask_code(), dt_name_has_legacy_prefix(), dt_text_free(),
**            dt_text_read().
** Appelants: dt_command_naming().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        naming_command.c -> dt_check_function_names() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=8; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_check_function_names(const char *path)
{
	t_dt_text		text;
	t_dt_functions	functions;
	char			*masked;
	size_t			i;
	int				findings;

	if (!dt_text_read(path, &text))
		return (1);
	masked = dt_mask_code(&text);
	dt_functions_init(&functions);
	if (!masked || !dt_functions_parse(&text, masked, &functions))
		return (free(masked), dt_text_free(&text), 1);
	findings = 0;
	i = 0;
	while (i < functions.count)
	{
		if (!dt_is_snake_case(functions.items[i].name)
			|| dt_name_has_legacy_prefix(functions.items[i].name))
			findings++;
		i++;
	}
	dt_functions_free(&functions);
	free(masked);
	dt_text_free(&text);
	return (findings);
}

/*
** Rôle: dt_command_naming — exécute la sous-commande « naming » et retourne
** un statut exploitable par le Makefile et la CI.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_check_function_names(),
**            dt_collect_sources(), dt_is_snake_case(),
**            dt_name_has_legacy_prefix(), dt_name_stem(),
**            dt_path_has_suffix(), dt_paths_free(), dt_paths_init().
** Appelants: dt_command_all(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        naming_command.c -> dt_command_naming() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=8; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_command_naming(void)
{
	t_dt_paths	paths;
	char		stem[256];
	size_t		i;
	int			findings;

	dt_paths_init(&paths);
	if (!dt_collect_sources(&paths, 1))
		return (dt_paths_free(&paths), 1);
	findings = 0;
	i = 0;
	while (i < paths.count)
	{
		if (!dt_name_stem(paths.items[i], stem, sizeof(stem))
			|| !dt_is_snake_case(stem) || dt_name_has_legacy_prefix(stem))
			findings++;
		if (dt_path_has_suffix(paths.items[i], ".c"))
			findings += dt_check_function_names(paths.items[i]);
		i++;
	}
	dt_paths_free(&paths);
	if (findings)
		printf("[naming-c] FAIL: %d finding(s)\n", findings);
	else
		printf("[naming-c] PASS: 0 finding(s)\n");
	return (findings != 0);
}
