/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sha256_core.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdint.h>
#include <string.h>

static const uint32_t g_sha_k[64] = {
	0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,
	0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,
	0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,
	0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
	0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,
	0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,
	0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,
	0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
	0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,
	0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,
	0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};

/*
** Rôle: dt_rotr — exécute l’opération interne « rotr » avec validation des
** bornes et erreurs.
** Paramètre: value — valeur associée à l’opération.
** Paramètre: bits — valeur « bits » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_sha_compress(), dt_sha_schedule().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sha256_core.c -> dt_rotr() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static uint32_t	dt_rotr(uint32_t value, unsigned int bits)
{
	return ((value >> bits) | (value << (32 - bits)));
}

/*
** Rôle: dt_sha_schedule — exécute l’opération interne « sha schedule » avec
** validation des bornes et erreurs.
** Paramètre: block — bloc binaire de 64 octets traité par SHA-256.
** Paramètre: words — valeur « words » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_rotr().
** Appelants: dt_sha_compress().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sha256_core.c -> dt_sha_schedule() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static void	dt_sha_schedule(const unsigned char block[64], uint32_t words[64])
{
	int			i;
	uint32_t	s0;
	uint32_t	s1;

	i = 0;
	while (i < 16)
	{
		words[i] = ((uint32_t)block[i * 4] << 24)
			| ((uint32_t)block[i * 4 + 1] << 16)
			| ((uint32_t)block[i * 4 + 2] << 8) | block[i * 4 + 3];
		i++;
	}
	while (i < 64)
	{
		s0 = dt_rotr(words[i - 15], 7) ^ dt_rotr(words[i - 15], 18)
			^ (words[i - 15] >> 3);
		s1 = dt_rotr(words[i - 2], 17) ^ dt_rotr(words[i - 2], 19)
			^ (words[i - 2] >> 10);
		words[i] = words[i - 16] + s0 + words[i - 7] + s1;
		i++;
	}
}

/*
** Rôle: dt_sha_compress — exécute l’opération interne « sha compress » avec
** validation des bornes et erreurs.
** Paramètre: ctx — contexte interne possédant l’état de calcul en cours.
** Paramètre: block — bloc binaire de 64 octets traité par SHA-256.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_rotr(), dt_sha_schedule().
** Appelants: dt_sha_final(), dt_sha_update().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sha256_core.c -> dt_sha_compress() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memcpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_sha_k.
** Concurrence: état global mutable détecté (g_sha_k); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_sha_compress(t_dt_sha256 *ctx, const unsigned char block[64])
{
	uint32_t	w[64];
	uint32_t	v[8];
	uint32_t	t1;
	uint32_t	t2;
	int			i;

	dt_sha_schedule(block, w);
	memcpy(v, ctx->state, sizeof(v));
	i = 0;
	while (i < 64)
	{
		t1 = v[7] + (dt_rotr(v[4], 6) ^ dt_rotr(v[4], 11) ^ dt_rotr(v[4], 25))
			+ ((v[4] & v[5]) ^ (~v[4] & v[6])) + g_sha_k[i] + w[i];
		t2 = (dt_rotr(v[0], 2) ^ dt_rotr(v[0], 13) ^ dt_rotr(v[0], 22))
			+ ((v[0] & v[1]) ^ (v[0] & v[2]) ^ (v[1] & v[2]));
		v[7]=v[6]; v[6]=v[5]; v[5]=v[4]; v[4]=v[3]+t1;
		v[3]=v[2]; v[2]=v[1]; v[1]=v[0]; v[0]=t1+t2;
		i++;
	}
	i = 0;
	while (i < 8)
	{
		ctx->state[i] += v[i];
		i++;
	}
}
