/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sha256_hex.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool.h"

/*
** Rôle: dt_sha256_hex — calcule ou formate une empreinte SHA-256 déterministe.
** Paramètre: digest — buffer de 32 octets recevant l’empreinte SHA-256.
** Paramètre: hex — buffer de 65 octets recevant l’empreinte SHA-256
** hexadécimale.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_manifest_write_file(), dt_manifest_line_check().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sha256_hex.c -> dt_sha256_hex() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_sha256_hex(const unsigned char digest[32], char hex[65])
{
	static const char	digits[] = "0123456789abcdef";
	int				i;

	i = 0;
	while (i < 32)
	{
		hex[i * 2] = digits[digest[i] >> 4];
		hex[i * 2 + 1] = digits[digest[i] & 15];
		i++;
	}
	hex[64] = '\0';
}
