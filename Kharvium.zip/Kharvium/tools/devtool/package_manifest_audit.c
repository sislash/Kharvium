/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   package_manifest_audit.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: dt_manifest_line_check — construit ou vérifie le manifeste SHA-256 du
** paquet source.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Paramètre: line — valeur « line » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_sha256_file(), dt_sha256_hex().
** Appelants: dt_manifest_audit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_manifest_audit.c -> dt_manifest_line_check() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf(), strcmp(),
**              strcspn(), strlen(), strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_manifest_line_check(const char *root, char *line)
{
	unsigned char	digest[32];
	char			hex[65];
	char			path[4096];
	char			*relative;

	if (strlen(line) < 68 || line[64] != ' ' || line[65] != ' ')
		return (0);
	line[64] = '\0';
	relative = line + 66;
	while (*relative == ' ')
		relative++;
	if (!strncmp(relative, "./", 2))
		relative += 2;
	relative[strcspn(relative, "\r\n")] = '\0';
	if (snprintf(path, sizeof(path), "%s/%s", root, relative) < 0)
		return (0);
	if (!dt_sha256_file(path, digest))
		return (0);
	dt_sha256_hex(digest, hex);
	return (!strcmp(line, hex));
}

/*
** Rôle: dt_manifest_audit — construit ou vérifie le manifeste SHA-256 du
** paquet source.
** Paramètre: root — répertoire racine de l’analyse ou du paquet.
** Paramètre: expected_files — nombre total de fichiers attendu, manifeste
** inclus.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_manifest_line_check().
** Appelants: dt_command_package_audit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        package_manifest_audit.c -> dt_manifest_audit() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fgets(), fopen(),
**              snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_manifest_audit(const char *root, size_t expected_files)
{
	char	path[4096];
	char	line[8192];
	FILE	*file;
	size_t	count;

	if (snprintf(path, sizeof(path), "%s/ARCHIVE_MANIFEST.sha256", root) < 0)
		return (0);
	file = fopen(path, "rb");
	if (!file)
		return (0);
	count = 0;
	while (fgets(line, sizeof(line), file))
	{
		if (!dt_manifest_line_check(root, line))
			return (fclose(file), 0);
		count++;
	}
	fclose(file);
	return (count + 1 == expected_files);
}
