/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: dt_command_all — exécute la sous-commande « all » et retourne un
** statut exploitable par le Makefile et la CI.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_command_doc_audit(),
**            dt_command_duplicates(), dt_command_naming(),
**            dt_command_strict42(), dt_command_ui_text().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère main.c ->
**        dt_command_all() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_command_all(void)
{
	if (dt_command_strict42())
		return (1);
	if (dt_command_naming() || dt_command_duplicates())
		return (1);
	if (dt_command_ui_text() || dt_command_doc_audit())
		return (1);
	return (0);
}

/*
** Rôle: dt_usage — exécute l’opération interne « usage » avec validation des
** bornes et erreurs.
** Paramètre: program — nom de l’exécutable affiché dans l’aide.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère main.c ->
**        dt_usage() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_usage(const char *program)
{
	fprintf(stderr, "usage: %s <command> [args]\n", program);
	fprintf(stderr, "commands: all strict42 naming duplicates ui-text\n");
	fprintf(stderr, "          doc-audit fixture baseline manifest\n");
	fprintf(stderr, "          package-audit package-policy-selftest\n");

	return (1);
}

/*
** Rôle: main — route la ligne de commande vers la sous-commande C de
** développement demandée et propage son code de sortie.
** Paramètre: argc — nombre d’arguments de la ligne de commande.
** Paramètre: argv — tableau d’arguments de la ligne de commande.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_command_all(), dt_command_baseline(),
**            dt_command_doc_audit(), dt_command_duplicates(),
**            dt_command_fixture(), dt_command_manifest(),
**            dt_command_naming(), dt_command_package_audit() (+4; index
**            complet dans docs/FUNCTION_CALL_GRAPH.md).
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère main.c ->
**        main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=12;
**              dépendances externes/macros=1. Le coût des fonctions appelées
**              peut dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	main(int argc, char **argv)
{
	if (argc < 2)
		return (dt_usage(argv[0]));
	if (!strcmp(argv[1], "all"))
		return (dt_command_all());
	if (!strcmp(argv[1], "strict42"))
		return (dt_command_strict42());
	if (!strcmp(argv[1], "naming"))
		return (dt_command_naming());
	if (!strcmp(argv[1], "duplicates"))
		return (dt_command_duplicates());
	if (!strcmp(argv[1], "ui-text"))
		return (dt_command_ui_text());
	if (!strcmp(argv[1], "doc-audit"))
		return (dt_command_doc_audit());
	if (!strcmp(argv[1], "fixture"))
		return (dt_command_fixture(argc, argv));
	if (!strcmp(argv[1], "baseline"))
		return (dt_command_baseline(argc, argv));
	if (!strcmp(argv[1], "manifest"))
		return (dt_command_manifest(argc, argv));
	if (!strcmp(argv[1], "package-audit"))
		return (dt_command_package_audit(argc, argv));
	if (!strcmp(argv[1], "package-policy-selftest"))
		return (dt_command_package_policy_selftest());
	return (dt_usage(argv[0]));
}
