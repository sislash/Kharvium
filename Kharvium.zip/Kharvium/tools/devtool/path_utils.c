/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   path_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool.h"

#include <string.h>

/*
** Rôle: dt_path_has_suffix — construit, collecte ou valide un chemin utilisé
** par les outils de développement.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: suffix — suffixe de fichier recherché.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_command_naming(), dt_forbidden_suffix(),
**            dt_is_forbidden_package_path(), dt_collect_posix(),
**            dt_windows_entry().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        path_utils.c -> dt_path_has_suffix() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_path_has_suffix(const char *path, const char *suffix)
{
	size_t	path_len;
	size_t	suffix_len;

	if (!path || !suffix)
		return (0);
	path_len = strlen(path);
	suffix_len = strlen(suffix);
	if (suffix_len > path_len)
		return (0);
	return (strcmp(path + path_len - suffix_len, suffix) == 0);
}

/*
** Rôle: dt_path_basename — construit, collecte ou valide un chemin utilisé
** par les outils de développement.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Retour: Retourne le pointeur trouvé ou créé; NULL signale une absence, une
** entrée invalide ou un échec d’allocation/E/S selon le chemin local.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_name_stem(), dt_is_forbidden_package_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        path_utils.c -> dt_path_basename() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strrchr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

const char	*dt_path_basename(const char *path)
{
	const char	*slash;
	const char	*backslash;

	if (!path)
		return ("");
	slash = strrchr(path, '/');
	backslash = strrchr(path, '\\');
	if (!slash || (backslash && backslash > slash))
		slash = backslash;
	if (!slash)
		return (path);
	return (slash + 1);
}

/*
** Rôle: dt_is_snake_case — exécute l’opération interne « is snake case » avec
** validation des bornes et erreurs.
** Paramètre: name — nom d’identifiant ou d’option à analyser.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_check_function_names(), dt_command_naming(),
**            dt_check_one_function().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        path_utils.c -> dt_is_snake_case() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_is_snake_case(const char *name)
{
	size_t	i;

	if (!name || name[0] < 'a' || name[0] > 'z')
		return (0);
	i = 1;
	while (name[i])
	{
		if (!((name[i] >= 'a' && name[i] <= 'z')
				|| (name[i] >= '0' && name[i] <= '9') || name[i] == '_'))
			return (0);
		if (name[i] == '_' && name[i - 1] == '_')
			return (0);
		i++;
	}
	return (name[i - 1] != '_');
}

/*
** Rôle: dt_hash_text — charge, libère ou indexe un texte source utilisé par
** les audits.
** Paramètre: text — buffer de texte source et sa longueur.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_duplicate_fill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        path_utils.c -> dt_hash_text() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> UINT64_C().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

uint64_t	dt_hash_text(const char *text)
{
	uint64_t	hash;

	hash = UINT64_C(1469598103934665603);
	while (text && *text)
	{
		hash ^= (unsigned char)*text;
		hash *= UINT64_C(1099511628211);
		text++;
	}
	return (hash);
}
