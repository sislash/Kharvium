/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   duplicate_body.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <ctype.h>
#include <stdlib.h>

/*
** Rôle: dt_normalize_function_body — analyse les signatures, corps ou
** collections de fonctions C.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: function — description de la fonction C en cours d’analyse.
** Paramètre: normalized — valeur « normalized » utilisée uniquement selon le
** contrat et les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_duplicate_fill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        duplicate_body.c -> dt_normalize_function_body() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> isspace(), malloc().
** Mémoire: opérations directes -> malloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_normalize_function_body(const t_dt_text *text,
	const t_dt_function *function, char **normalized)
{
	char	*body;
	size_t	i;
	size_t	out;

	if (!text || !function || !normalized)
		return (0);
	body = malloc(function->body_end - function->body_start + 1);
	if (!body)
		return (0);
	i = function->body_start + 1;
	out = 0;
	while (i < function->body_end)
	{
		if (!isspace((unsigned char)text->data[i]))
			body[out++] = text->data[i];
		i++;
	}
	body[out] = '\0';
	*normalized = body;
	return (1);
}
