/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   doc_comment.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool_internal.h"

#include <string.h>

static const char	*g_vague_roles[] = {
	"Prend en charge",
	"Réalise l’opération dédiée",
	"dans le contexte de",
	NULL
};

/*
** Rôle: dt_comment_bounds — localise et valide le bloc documentaire
** immédiatement associé à une fonction.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: position — position absolue dans le texte source.
** Paramètre: start — borne de début inclusive de la zone analysée.
** Paramètre: end — borne de fin de la zone analysée.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_comment_before_function(), dt_comment_is_precise().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        doc_comment.c -> dt_comment_bounds() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_comment_bounds(const t_dt_text *text, size_t position,
	size_t *start, size_t *end)
{
	size_t	i;

	i = position;
	while (i >= 2)
	{
		if (text->data[i - 2] == '*' && text->data[i - 1] == '/')
		{
			*end = i;
			while (i >= 2)
			{
				if (text->data[i - 2] == '/' && text->data[i - 1] == '*')
					return (*start = i - 2, 1);
				i--;
			}
			return (0);
		}
		i--;
	}
	return (0);
}

/*
** Rôle: dt_comment_has_token — localise et valide le bloc documentaire
** immédiatement associé à une fonction.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: start — borne de début inclusive de la zone analysée.
** Paramètre: end — borne de fin de la zone analysée.
** Paramètre: token — valeur « token » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_comment_before_function(), dt_comment_is_precise().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        doc_comment.c -> dt_comment_has_token() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static int	dt_comment_has_token(const t_dt_text *text, size_t start,
	size_t end, const char *token)
{
	const char	*found;

	found = strstr(text->data + start, token);
	return (found && (size_t)(found - text->data) < end);
}

/*
** Rôle: dt_comment_before_function — localise et valide le bloc documentaire
** immédiatement associé à une fonction.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: function — description de la fonction C en cours d’analyse.
** Paramètre: token — valeur « token » utilisée uniquement selon le contrat et
** les validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_comment_bounds(),
**            dt_comment_has_token().
** Appelants: dt_doc_function_ok().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        doc_comment.c -> dt_comment_before_function() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_comment_before_function(const t_dt_text *text,
	const t_dt_function *function, const char *token)
{
	size_t	start;
	size_t	end;

	if (!dt_comment_bounds(text, function->body_start, &start, &end))
		return (0);
	return (dt_comment_has_token(text, start, end, token));
}

/*
** Rôle: dt_comment_is_precise — localise et valide le bloc documentaire
** immédiatement associé à une fonction.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: function — description de la fonction C en cours d’analyse.
** Retour: Retourne 1 lorsque la condition est satisfaite et 0 dans le cas
** contraire.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_comment_bounds(),
**            dt_comment_has_token().
** Appelants: dt_doc_function_ok().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        doc_comment.c -> dt_comment_is_precise() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_vague_roles.
** Concurrence: état global mutable détecté (g_vague_roles); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_comment_is_precise(const t_dt_text *text,
	const t_dt_function *function)
{
	size_t	start;
	size_t	end;
	int		i;

	if (!dt_comment_bounds(text, function->body_start, &start, &end))
		return (0);
	i = 0;
	while (g_vague_roles[i])
	{
		if (dt_comment_has_token(text, start, end, g_vague_roles[i]))
			return (0);
		i++;
	}
	return (1);
}
