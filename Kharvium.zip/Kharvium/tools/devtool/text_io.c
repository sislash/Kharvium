/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   text_io.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "devtool.h"

#include <stdio.h>
#include <stdlib.h>

/*
** Rôle: dt_file_size — exécute l’opération interne « file size » avec
** validation des bornes et erreurs.
** Paramètre: file — flux de fichier ouvert dont le cycle de vie reste celui
** de l’appelant.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_text_read().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère text_io.c
**        -> dt_file_size() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fseek(), ftell().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

static long	dt_file_size(FILE *file)
{
	long	size;

	if (fseek(file, 0, SEEK_END) != 0)
		return (-1);
	size = ftell(file);
	if (size < 0 || fseek(file, 0, SEEK_SET) != 0)
		return (-1);
	return (size);
}

/*
** Rôle: dt_text_read — charge, libère ou indexe un texte source utilisé par
** les audits.
** Paramètre: path — chemin de fichier ou de répertoire analysé sans être
** modifié.
** Paramètre: text — buffer de texte source et sa longueur.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> dt_file_size(), dt_text_free().
** Appelants: dt_doc_check_file(), dt_doc_load_graph(),
**            dt_duplicate_append(), dt_check_function_names(),
**            dt_file_contains(), dt_strict_check_file() (+1; index complet
**            dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère text_io.c
**        -> dt_text_read() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(), fread(),
**              malloc().
** Mémoire: opérations directes -> malloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fread().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_text_read(const char *path, t_dt_text *text)
{
	FILE	*file;
	long	size;

	if (!path || !text)
		return (0);
	text->data = NULL;
	text->len = 0;
	file = fopen(path, "rb");
	if (!file)
		return (0);
	size = dt_file_size(file);
	if (size < 0)
		return (fclose(file), 0);
	text->data = malloc((size_t)size + 1);
	if (!text->data)
		return (fclose(file), 0);
	text->len = fread(text->data, 1, (size_t)size, file);
	fclose(file);
	if (text->len != (size_t)size)
		return (dt_text_free(text), 0);
	text->data[text->len] = '\0';
	return (1);
}

/*
** Rôle: dt_text_free — charge, libère ou indexe un texte source utilisé par
** les audits.
** Paramètre: text — buffer de texte source et sa longueur.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_command_doc_audit(), dt_doc_check_file(),
**            dt_duplicate_append(), dt_check_function_names(),
**            dt_file_contains(), dt_strict_check_file() (+2; index complet
**            dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère text_io.c
**        -> dt_text_free() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	dt_text_free(t_dt_text *text)
{
	if (!text)
		return ;
	free(text->data);
	text->data = NULL;
	text->len = 0;
}

/*
** Rôle: dt_line_number — exécute l’opération interne « line number » avec
** validation des bornes et erreurs.
** Paramètre: text — buffer de texte source et sa longueur.
** Paramètre: position — position absolue dans le texte source.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: dt_function_lines().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère text_io.c
**        -> dt_line_number() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	dt_line_number(const char *text, size_t position)
{
	int		line;
	size_t	i;

	line = 1;
	i = 0;
	while (text && text[i] && i < position)
	{
		if (text[i] == '\n')
			line++;
		i++;
	}
	return (line);
}
