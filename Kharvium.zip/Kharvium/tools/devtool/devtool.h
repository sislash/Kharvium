/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   devtool.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DEVTOOL_H
# define DEVTOOL_H

# include <stddef.h>
# include <stdint.h>

typedef struct s_dt_text
{
	char	*data;
	size_t	len;
}t_dt_text;

typedef struct s_dt_paths
{
	char	**items;
	size_t	count;
	size_t	capacity;
}t_dt_paths;

typedef struct s_dt_function
{
	char	name[128];
	size_t	signature_start;
	size_t	body_start;
	size_t	body_end;
	int		start_line;
	int		body_line;
	int		end_line;
	int		parameters;
}t_dt_function;

typedef struct s_dt_functions
{
	t_dt_function	*items;
	size_t			count;
	size_t			capacity;
}t_dt_functions;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_paths_init — manipule ou collecte les chemins nécessaires aux
** audits C.
** Paramètre: paths — collection de chemins modifiée ou consultée selon le
** contrat.
** Retour: Ne retourne rien; les sorties éventuelles sont écrites uniquement
** dans les objets explicitement fournis.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_paths_init().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_paths_init(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		dt_paths_init(t_dt_paths *paths);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_paths_free — manipule ou collecte les chemins nécessaires aux
** audits C.
** Paramètre: paths — collection de chemins modifiée ou consultée selon le
** contrat.
** Retour: Ne retourne rien; les sorties éventuelles sont écrites uniquement
** dans les objets explicitement fournis.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_paths_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_paths_free(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		dt_paths_free(t_dt_paths *paths);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_paths_push — manipule ou collecte les chemins nécessaires aux
** audits C.
** Paramètre: paths — collection de chemins modifiée ou consultée selon le
** contrat.
** Paramètre: path — chemin ciblé par l’opération.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_paths_push().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_paths_push(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_paths_push(t_dt_paths *paths, const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_paths_collect — manipule ou collecte les chemins nécessaires aux
** audits C.
** Paramètre: paths — collection de chemins modifiée ou consultée selon le
** contrat.
** Paramètre: root — répertoire racine parcouru.
** Paramètre: suffix — suffixe de fichier filtrant la collecte.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_paths_collect().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_paths_collect(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_paths_collect(t_dt_paths *paths, const char *root,
				const char *suffix);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_text_read — charge, masque ou indexe le texte source sans perdre
** les positions.
** Paramètre: path — chemin ciblé par l’opération.
** Paramètre: text — texte source chargé et sa longueur.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_text_read().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_text_read(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_text_read(const char *path, t_dt_text *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_text_free — charge, masque ou indexe le texte source sans perdre
** les positions.
** Paramètre: text — texte source chargé et sa longueur.
** Retour: Ne retourne rien; les sorties éventuelles sont écrites uniquement
** dans les objets explicitement fournis.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_text_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_text_free(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		dt_text_free(t_dt_text *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_mask_code — expose l’opération interne « mask code » aux autres
** modules C de l’outil.
** Paramètre: text — texte source chargé et sa longueur.
** Retour: Retourne un pointeur valide sur la ressource demandée ou NULL
** lorsque le contrat signale une absence/erreur.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_mask_code().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_mask_code(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
char		*dt_mask_code(const t_dt_text *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_line_number — expose l’opération interne « line number » aux
** autres modules C de l’outil.
** Paramètre: text — texte source chargé et sa longueur.
** Paramètre: position — position absolue dans le texte.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_line_number().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_line_number(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_line_number(const char *text, size_t position);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_functions_init — analyse les signatures, corps et collections de
** fonctions C.
** Paramètre: functions — collection de fonctions analysées.
** Retour: Ne retourne rien; les sorties éventuelles sont écrites uniquement
** dans les objets explicitement fournis.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_functions_init().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_functions_init(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		dt_functions_init(t_dt_functions *functions);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_functions_free — analyse les signatures, corps et collections de
** fonctions C.
** Paramètre: functions — collection de fonctions analysées.
** Retour: Ne retourne rien; les sorties éventuelles sont écrites uniquement
** dans les objets explicitement fournis.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_functions_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_functions_free(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		dt_functions_free(t_dt_functions *functions);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_functions_parse — analyse les signatures, corps et collections de
** fonctions C.
** Paramètre: text — texte source chargé et sa longueur.
** Paramètre: masked — vue du code avec commentaires/littéraux masqués.
** Paramètre: functions — collection de fonctions analysées.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_functions_parse().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_functions_parse(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_functions_parse(const t_dt_text *text, const char *masked,
				t_dt_functions *functions);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_strict42 — exécute la sous-commande C « strict42 » et
** propage un statut de succès ou d’erreur.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_strict42().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_strict42(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_strict42(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_naming — exécute la sous-commande C « naming » et propage
** un statut de succès ou d’erreur.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_naming().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_naming(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_naming(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_duplicates — exécute la sous-commande C « duplicates » et
** propage un statut de succès ou d’erreur.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_duplicates().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_duplicates(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_duplicates(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_ui_text — exécute la sous-commande C « ui text » et
** propage un statut de succès ou d’erreur.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_ui_text().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_ui_text(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_ui_text(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_doc_audit — exécute la sous-commande C « doc audit » et
** propage un statut de succès ou d’erreur.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_doc_audit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_doc_audit(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_doc_audit(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_fixture — exécute la sous-commande C « fixture » et
** propage un statut de succès ou d’erreur.
** Paramètre: argc — nombre d’arguments CLI.
** Paramètre: argv — arguments CLI.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_fixture().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_fixture(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_fixture(int argc, char **argv);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_baseline — exécute la sous-commande C « baseline » et
** propage un statut de succès ou d’erreur.
** Paramètre: argc — nombre d’arguments CLI.
** Paramètre: argv — arguments CLI.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_baseline().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_baseline(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_baseline(int argc, char **argv);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_package_audit — exécute la sous-commande C « package audit
** » et propage un statut de succès ou d’erreur.
** Paramètre: argc — nombre d’arguments CLI.
** Paramètre: argv — arguments CLI.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_package_audit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_package_audit(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_package_audit(int argc, char **argv);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_package_policy_selftest — exécute la sous-commande C «
** package policy selftest » et propage un statut de succès ou d’erreur.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_package_policy_selftest().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_package_policy_selftest(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_package_policy_selftest(void);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_path_has_suffix — manipule ou collecte les chemins nécessaires aux
** audits C.
** Paramètre: path — chemin ciblé par l’opération.
** Paramètre: suffix — suffixe de fichier filtrant la collecte.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_path_has_suffix().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_path_has_suffix(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_path_has_suffix(const char *path, const char *suffix);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_path_basename — manipule ou collecte les chemins nécessaires aux
** audits C.
** Paramètre: path — chemin ciblé par l’opération.
** Retour: Retourne un pointeur valide sur la ressource demandée ou NULL
** lorsque le contrat signale une absence/erreur.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_path_basename().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_path_basename(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*dt_path_basename(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_is_snake_case — expose l’opération interne « is snake case » aux
** autres modules C de l’outil.
** Paramètre: name — nom d’identifiant analysé.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_is_snake_case().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_is_snake_case(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_is_snake_case(const char *name);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_hash_text — charge, masque ou indexe le texte source sans perdre
** les positions.
** Paramètre: text — texte source chargé et sa longueur.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_hash_text().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_hash_text(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
uint64_t	dt_hash_text(const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_sha256_file — calcule ou formate les données SHA-256 utilisées
** pour garantir l’intégrité du paquet.
** Paramètre: path — chemin ciblé par l’opération.
** Paramètre: digest — buffer de 32 octets recevant l’empreinte.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_sha256_file().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_sha256_file(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_sha256_file(const char *path, unsigned char digest[32]);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_sha256_hex — calcule ou formate les données SHA-256 utilisées pour
** garantir l’intégrité du paquet.
** Paramètre: digest — buffer de 32 octets recevant l’empreinte.
** Paramètre: hex — buffer recevant 64 caractères hexadécimaux plus NUL.
** Retour: Ne retourne rien; les sorties éventuelles sont écrites uniquement
** dans les objets explicitement fournis.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_sha256_hex().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_sha256_hex(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		dt_sha256_hex(const unsigned char digest[32], char hex[65]);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: dt_command_manifest — exécute la sous-commande C « manifest » et
** propage un statut de succès ou d’erreur.
** Paramètre: argc — nombre d’arguments CLI.
** Paramètre: argv — arguments CLI.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: dt_command_manifest().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                dt_command_manifest(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			dt_command_manifest(int argc, char **argv);

#endif
