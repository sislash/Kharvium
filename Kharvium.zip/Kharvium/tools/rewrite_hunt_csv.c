/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rewrite_hunt_csv.c                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "io/csv_persistence.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>

/*
** Rôle: print_usage — Écrit print usage dans le fichier ou flux prévu en
**       respectant le format persistant et les erreurs d’E/S.
** Paramètre: argv0 — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        rewrite_hunt_csv.c -> print_usage() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	print_usage(const char *argv0)
{
	fprintf(stderr, "Usage: %s <src.csv> <dst.csv>\n", argv0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètre: argc — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : argv.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_persistence_rewrite_hunt_atomic(),
**            print_usage().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        rewrite_hunt_csv.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf(), strerror().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(int argc, char **argv)
{
	if (argc != 3)
	{
		print_usage(argv[0]);
		return (2);
	}
	if (csv_persistence_rewrite_hunt_atomic(argv[1], argv[2]) != 0)
	{
		fprintf(stderr, "rewrite failed: %s\n", strerror(errno));
		return (1);
	}
	return (0);
}
