# Configuration

Par defaut, le programme lit :
- `weapons.ini`
- `markup.ini`

Les fichiers dans ce dossier sont des **exemples**.

Apres clonage:
```bash
cp config/weapons.ini.example weapons.ini
cp config/markup.ini.example markup.ini
```

Puis edite `weapons.ini` pour:
- `PLAYER.name`
- tes armes/amps
- MU ammo/weapon/amp si necessaire
