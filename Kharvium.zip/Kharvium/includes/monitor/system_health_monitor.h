/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   system_health_monitor.h                           +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef SYSTEM_HEALTH_MONITOR_H
# define SYSTEM_HEALTH_MONITOR_H

#include <stdint.h>

/* Health levels for operator trust (RCE safe). */
typedef enum e_health_level
{
	HEALTH_OK = 0,
	HEALTH_WARN = 1,
	HEALTH_FAIL = 2
} 	t_health_level;

#define HEALTH_ERR_RING 10
#define HEALTH_ERR_MSG  160

typedef struct s_health_error
{
	t_health_level	level;
	uint64_t	ts_ms;
	int		err_no;
	int		ferror_code;
	char		msg[HEALTH_ERR_MSG];
} 	t_health_error;

typedef struct s_monitor_health
{
	uint64_t	now_ms;
	uint64_t	last_event_ms;
	uint64_t	last_flush_ms;

	/* Files */
	long		chat_size;
	long		chat_pos;
	long		csv_size;
	int		rotation_detected;

	/* Counters */
	int		io_errors;
	int		parse_errors;
	int		last_errno;
	int		last_ferror;

	/* Derived / operator view */
	int		events_per_sec_x100; /* avg 10s * 100 */
	long long	lag_ms;            /* now - last_event */
	t_health_level	io_level;
	t_health_level	lag_level;

	/* Ring buffer */
	t_health_error	errors[HEALTH_ERR_RING];
	int		errors_count;
} 	t_monitor_health;

/* Called when opening a session / (re)starting parser. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: monitor_health_reset — Réinitialise l’état associé à surveillance
**       santé.
** Paramètre: chat_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: monitor_health_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                monitor_health_reset(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	monitor_health_reset(const char *chat_path, const char *csv_path);

/* Parser thread hooks */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: monitor_health_on_event — Traite monitor health on événement et met
**       à jour uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: now_ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: monitor_health_on_event().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                monitor_health_on_event(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	monitor_health_on_event(uint64_t now_ms);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: monitor_health_on_flush — Force l’écriture de monitor health on
**       vers la destination prévue en respectant
**       le format, les bornes et la politique
**       d’erreur du module.
** Paramètre: now_ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: ok — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: err_no — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: ferror_code — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: monitor_health_on_flush().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                monitor_health_on_flush(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	monitor_health_on_flush(uint64_t now_ms, int ok, int err_no,
				int ferror_code);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: monitor_health_on_io_error — Construit ou traite l’erreur associée
**       à surveillance santé on io.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: err_no — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: ferror_code — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: monitor_health_on_io_error().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                monitor_health_on_io_error(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	monitor_health_on_io_error(const char *ctx, int err_no,
	int ferror_code);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: monitor_health_on_parse_error — Analyse monitor health on erreur
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: monitor_health_on_parse_error().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                monitor_health_on_parse_error(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	monitor_health_on_parse_error(const char *ctx);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: monitor_health_update_io — Met à jour monitor health à partir des
**       valeurs courantes et conserve l’état partagé cohérent pour la suite
**       de la frame ou du calcul.
** Paramètre: chat_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: chat_pos — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: rotated — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: monitor_health_update_io().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                monitor_health_update_io(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	monitor_health_update_io(const char *chat_path, long chat_pos,
				const char *csv_path, int rotated);

/* UI thread: consistent snapshot (lock-free). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: monitor_health_snapshot — Construit ou traite le snapshot de
**       surveillance santé.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: now_ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: monitor_health_snapshot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                monitor_health_snapshot(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	monitor_health_snapshot(t_monitor_health *out, uint64_t now_ms);

#endif
