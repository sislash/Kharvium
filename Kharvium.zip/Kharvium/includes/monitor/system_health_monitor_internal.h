/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   system_health_monitor_internal.h                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SYSTEM_HEALTH_MONITOR_INTERNAL_H
# define SYSTEM_HEALTH_MONITOR_INTERNAL_H

# include <stdatomic.h>
# include <stdint.h>
# include "monitor/system_health_monitor.h"

# define HEALTH_SLOTS 10

typedef struct s_health_slot
{
	uint64_t	sec;
	int		count;
} 	t_health_slot;

typedef struct s_health_state
{
	_Atomic unsigned	seq;

	char	chat_path[1024];
	char	csv_path[1024];

	uint64_t	last_event_ms;
	uint64_t	last_flush_ms;

	long	chat_size;
	long	chat_pos;
	long	csv_size;
	int		rotation_detected;

	int		io_errors;
	int		parse_errors;
	int		last_errno;
	int		last_ferror;

	t_health_slot	slots[HEALTH_SLOTS];

	t_health_error	err_ring[HEALTH_ERR_RING];
	int		err_head;  /* next write */
	int		err_count; /* <= RING */
} 	t_health_state;

typedef struct s_health_snapshot_copy
{
	t_monitor_health	view;
	t_health_slot		slots[HEALTH_SLOTS];
	t_health_error		error_ring[HEALTH_ERR_RING];
	int				error_head;
	int				error_count;
} 	t_health_snapshot_copy;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: health_monitor_state — Consulte ou prépare l’état nécessaire à
**       santé surveillance.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: health_monitor_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                health_monitor_state(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_health_state	*health_monitor_state(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: health_monitor_advance_sequence — Met à jour health monitor advance
**       sequence en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: health_monitor_advance_sequence().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                health_monitor_advance_sequence(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	health_monitor_advance_sequence(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: health_monitor_clear_paths — Réinitialise health monitor paths en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: health_monitor_clear_paths().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                health_monitor_clear_paths(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	health_monitor_clear_paths(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: health_monitor_clear_metrics — Réinitialise health monitor metrics en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: health_monitor_clear_metrics().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                health_monitor_clear_metrics(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	health_monitor_clear_metrics(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: health_monitor_clear_errors — Réinitialise health monitor errors en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: health_monitor_clear_errors().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                health_monitor_clear_errors(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	health_monitor_clear_errors(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: health_monitor_store_error — Construit ou traite l’erreur associée
**       à santé surveillance store.
** Paramètre: error — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: health_monitor_store_error().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                health_monitor_store_error(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	health_monitor_store_error(const t_health_error *error);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: health_monitor_add_event_slot — Ajoute health monitor événement slot
**       dans la collection concernée en respectant sa capacité, son ordre
**       logique et la propriété de ses éléments.
** Paramètre: now_ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: health_monitor_add_event_slot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                health_monitor_add_event_slot(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	health_monitor_add_event_slot(uint64_t now_ms);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: health_monitor_copy_state — Copie health monitor état en préservant
**       la propriété des ressources, les compteurs et la cohérence de la
**       destination.
** Paramètre: copy — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : copy.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: health_monitor_copy_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                health_monitor_copy_state(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	health_monitor_copy_state(t_health_snapshot_copy *copy);

#endif
