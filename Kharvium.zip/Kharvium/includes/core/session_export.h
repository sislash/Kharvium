/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_export.h                                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SESSION_EXPORT_H
# define SESSION_EXPORT_H

# include <stddef.h>
# include "analytics/hunt_stats.h"

typedef struct s_session_range_info
{
	long	start_offset;
	long	end_offset;
	char	start_timestamp[64];
	char	end_timestamp[64];
}t_session_range_info;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_export_stats_csv_with_offsets — Exporte session with
**       offsets vers la destination
**       prévue en respectant le
**       format, les bornes et la
**       politique d’erreur du
**       module.
** Paramètre: out_csv_path — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: stats — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: range — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_export_stats_csv_with_offsets().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_export_stats_csv_with_offsets(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	session_export_stats_csv_with_offsets(const char *out_csv_path,
		const t_hunt_stats *stats, const t_session_range_info *range);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_export_stats_csv — Exporte session vers la destination
**       prévue en respectant le format, les
**       bornes et la politique d’erreur du
**       module.
** Paramètre: out_csv_path — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: stats — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: start_ts — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: end_ts — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: session_export_stats_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_export_stats_csv(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	session_export_stats_csv(const char *out_csv_path,
		const t_hunt_stats *stats, const char *start_ts,
		const char *end_ts);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_extract_range_timestamps — Calcule session extract plage
**       timestamps à partir de l’état
**       courant en respectant les
**       unités, bornes et conventions du
**       module.
** Paramètre: hunt_csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: range — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : range.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_extract_range_timestamps().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_extract_range_timestamps(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	session_extract_range_timestamps(const char *hunt_csv_path,
		t_session_range_info *range);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_extract_timestamps_from_offset — Construit à partir de
**       session extract timestamps
**       offset en appliquant les
**       validations, bornes et
**       effets explicitement
**       définis par ce module.
** Paramètre: hunt_csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: range — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : range.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_extract_timestamps_from_offset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_extract_timestamps_from_offset(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	session_extract_timestamps_from_offset(const char *hunt_csv_path,
		t_session_range_info *range);

#endif
