/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_runtime.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef SESSION_RUNTIME_H
# define SESSION_RUNTIME_H

/*
** Session: gestion d'un offset/point de depart pour les stats (hunt session).
*/

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_load_offset — Calcule session load offset à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_load_offset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_load_offset(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
long	session_load_offset(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_save_offset — Calcule session save offset à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: offset — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_save_offset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_save_offset(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		session_save_offset(const char *path, long offset);

/*
** Optional: session "range" (start,end) in data-line indices
** (0-based, header ignored).
** If end is -1, it means "until EOF".
** File format: "<start> <end>\n".
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_load_range — Calcule session load plage à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: out_start — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_end — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants :
**         out_start, out_end.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_load_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_load_range(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		session_load_range(const char *path, long *out_start, long *out_end);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_save_range — Calcule session save plage à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: start — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: end — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_save_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_save_range(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		session_save_range(const char *path, long start, long end);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_clear_range — Calcule session clear plage à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_clear_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_clear_range(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		session_clear_range(const char *path);

/*
** Compte le nombre de lignes de DONNEES dans un CSV (ignore l'en-tete si
** presente). Retourne 0 si fichier absent.
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_count_data_lines — Compte session data lignes en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_count_data_lines().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_count_data_lines(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
long	session_count_data_lines(const char *csv_path);

#endif
