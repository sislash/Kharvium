/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   data_provenance.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DATA_PROVENANCE_H
# define DATA_PROVENANCE_H

# include <stdint.h>

# define DATA_SOURCE_LABEL_CAP 96
# define DATA_PARSER_VERSION_CAP 32
# define DATA_CONTENT_HASH_CAP 65
# define DATA_SOURCE_NOTES_CAP 160

/*
** Stable categories describing where a record came from. UNKNOWN is zero so
** legacy records with no provenance fields deserialize conservatively.
*/
typedef enum e_data_source_kind
{
	DATA_SOURCE_UNKNOWN = 0,
	DATA_SOURCE_CHAT_LOG = 1,
	DATA_SOURCE_TRACKER_CSV = 2,
	DATA_SOURCE_CRAFT_CSV = 3,
	DATA_SOURCE_MANUAL = 4,
	DATA_SOURCE_OFFICIAL = 5,
	DATA_SOURCE_COMMUNITY = 6,
	DATA_SOURCE_IMPORTED_FILE = 7
}	t_data_source_kind;

/*
** Evidence describes how strongly a fact is supported. UNKNOWN is zero to
** prevent historical records from being upgraded silently during migration.
*/
typedef enum e_evidence_level
{
	EVIDENCE_UNKNOWN = 0,
	EVIDENCE_OFFICIAL = 1,
	EVIDENCE_OFFICIAL_AGGREGATE = 2,
	EVIDENCE_COMMUNITY_VERIFIED = 3,
	EVIDENCE_USER_OBSERVED = 4,
	EVIDENCE_MANUAL = 5,
	EVIDENCE_INFERRED = 6
}	t_evidence_level;

/*
** Quality reports data completeness, not trustworthiness. Evidence and
** quality are intentionally independent so an official record can still be
** incomplete for a specific financial calculation.
*/
typedef enum e_data_quality
{
	DATA_UNKNOWN = 0,
	DATA_COMPLETE = 1,
	DATA_PARTIAL_COST = 2,
	DATA_PARTIAL_VALUE = 3,
	DATA_PARTIAL_CONTEXT = 4,
	DATA_INFERRED = 5
}	t_data_quality;

typedef struct s_data_provenance_ref
{
	int64_t				source_id;
	t_evidence_level	evidence;
	t_data_quality		quality;
}	t_data_provenance_ref;

typedef struct s_source_record
{
	int64_t				source_id;
	t_data_source_kind	kind;
	int64_t				imported_at;
	char				parser_version[DATA_PARSER_VERSION_CAP];
	char				content_hash[DATA_CONTENT_HASH_CAP];
	char				label[DATA_SOURCE_LABEL_CAP];
	char				notes[DATA_SOURCE_NOTES_CAP];
}	t_source_record;

#endif
