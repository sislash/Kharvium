/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_catalog.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/12                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SESSION_CATALOG_H
# define SESSION_CATALOG_H

# include <stddef.h>

/*
 * session_statistics.csv reader (append-only):
 *
 * Legacy columns (v1):
 *   session_start,session_end,weapon,kills,shots,loot_ped,expense_ped,
 *   net_ped,return_pct
 *
 * New columns (v2, optional at end):
 *   ...,start_offset,end_offset

 * New columns (v3, optional at end):
 *   ...,mob
 *
 * We keep backward compatibility by accepting both formats line-by-line.
 */

typedef struct s_session_entry
{
	char	start_ts[64];
	char	end_ts[64];
	char	weapon[128];
	long	kills;
	long	shots;
	double	loot_ped;
	double	expense_ped;
	double	net_ped;
	double	return_pct;
	long	start_offset;
	long	end_offset;
	int	has_offsets;
	char	mob[128];
	int	has_mob;
} 		t_session_entry;

typedef struct s_sessions_list
{
	t_session_entry	*items;
	size_t			count;
} 		t_sessions_list;

/* Load up to max_items last sessions (0 => load all). Returns 0 on success. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sessions_list_load — Charge l’état associé à sessions liste.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: maximum_items — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; effectue
**         directement des E/S fichier ou une modification de chemin; peut
**         modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sessions_list_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sessions_list_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		sessions_list_load(const char *csv_path, size_t max_items,
			t_sessions_list *out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sessions_list_free — Libère l’état associé à sessions liste.
** Paramètre: list — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : list.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sessions_list_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sessions_list_free(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	sessions_list_free(t_sessions_list *l);

/* Build a compact label for UI lists. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sessions_format_label — Retourne sessions format libellé dans la
**       forme directement utilisable par le rendu ou l’appelant.
** Paramètre: entry — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sessions_format_label().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sessions_format_label(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		sessions_format_label(const t_session_entry *e, char *out,
	size_t outsz);

#endif
