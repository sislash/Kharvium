/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core_loot_aggregate.h                                       +:+  :+: :+: */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CORE_LOOT_AGGREGATE_H
# define CORE_LOOT_AGGREGATE_H

# include <time.h>
# include <stdint.h>

/*
 * Loot envelope aggregation truth:
 * - Preferred grouping key: kill_id (when present).
 * - Fallback: same timestamp second when kill_id is missing.
 * - Valid game data has at most one mob kill per timestamp second.
 */

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_loot_should_merge — Fusionne l’état associé à cœur loot
**       should.
** Paramètre: last_t — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: last_kill_id — identifiant stable servant à retrouver ou
**            associer l’élément.
** Paramètre: t — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: kill_id — identifiant stable servant à retrouver ou associer
**            l’élément.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: core_loot_should_merge().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_loot_should_merge(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	core_loot_should_merge(time_t last_t,
				int64_t last_kill_id,
				time_t t,
				int64_t kill_id);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_time_relative_seconds — Met à jour temps relative seconds en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: t0 — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: t — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: core_time_relative_seconds().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_time_relative_seconds(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	core_time_relative_seconds(time_t t0, time_t t);

#endif
