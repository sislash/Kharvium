/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core_roi.h                                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CORE_ROI_H
# define CORE_ROI_H

# include <stdint.h>
# include "common/money.h"

/*
 * Cost/ROI helpers.
 * - Inputs stay in fixed-point t_money (uPED).
 * - Only the final rendering uses double.
 */

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_money_add_clamped — Ajoute clamped dans la collection concernée
**       en respectant sa capacité, son ordre logique et la propriété de ses
**       éléments.
** Paramètre: a — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: b — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: core_money_add_clamped().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_money_add_clamped(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	core_money_add_clamped(t_money a, t_money b);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_money_multiply_long_clamped — Met à jour multiply long clamped
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: v — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: n — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne un montant monétaire entier avec saturation explicite
**         des dépassements, compatible avec la précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les limites des entiers sont traitées explicitement avant
**             tout dépassement.
** --- Liens API auto-vérifiés ---
** Implémentation: core_money_multiply_long_clamped().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_money_multiply_long_clamped(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	core_money_multiply_long_clamped(t_money v, long n);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_cost_pick_maximum — Calcule coût pick maximum à partir de
**       l’état courant en respectant les unités,
**       bornes et conventions du module.
** Paramètre: logged_cost — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Paramètre: model_cost — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: core_cost_pick_maximum().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_cost_pick_maximum(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	core_cost_pick_maximum(t_money logged_cost, t_money model_cost);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_roi_percent — Met à jour roi mode pourcentage en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: loot_uPED — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Paramètre: cost_uPED — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: core_roi_percent().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_roi_percent(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double		core_roi_percent(t_money loot_uPED, t_money cost_uPED);

#endif
