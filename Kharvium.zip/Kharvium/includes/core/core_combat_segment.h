/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core_combat_segment.h                                     +:+    :+: :+: */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CORE_COMBAT_SEGMENT_H
# define CORE_COMBAT_SEGMENT_H

/*
 * Combat segment truth (RCE / UX): counters are reset on each KILL.
 * This module is UI-agnostic: it only holds counters.
 */

typedef struct s_core_combat_seg
{
	long	shots;
	long	hits;
} 	t_core_combat_seg;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_combat_segment_reset — Réinitialise l’état associé à cœur
**       combat segment.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: core_combat_segment_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_combat_segment_reset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	core_combat_segment_reset(t_core_combat_seg *s);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_combat_segment_on_shot — Met à jour combat segment on tir en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: is_hit — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: core_combat_segment_on_shot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_combat_segment_on_shot(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	core_combat_segment_on_shot(t_core_combat_seg *s, int is_hit);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_combat_segment_take_on_kill — Traite l’événement kill associé
**       à cœur combat segment take on.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: out_shots — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_hits — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s, out_shots,
**         out_hits.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: core_combat_segment_take_on_kill().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_combat_segment_take_on_kill(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	core_combat_segment_take_on_kill(t_core_combat_seg *s,
					long *out_shots,
					long *out_hits);

#endif
