/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tracker_event.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TRACKER_EVENT_H
# define TRACKER_EVENT_H

# include <stdint.h>
# include "tracker_types.h"

# define TRACKER_EVENT_FLAG_VALUE_KNOWN (1u << 0)
# define TRACKER_EVENT_FLAG_ENVELOPE_LINKED (1u << 1)
# define TRACKER_EVENT_FLAG_INFERRED (1u << 2)
# define TRACKER_EVENT_FLAG_PARTIAL_CONTEXT (1u << 3)
# define TRACKER_EVENT_FLAG_LEGACY_SOURCE (1u << 4)

/*
** Stable high-level activity identifiers for the normalized Tracker journal.
** New gameplay systems may be appended without changing legacy Hunt/Fishing
** parsing rules. Zero is reserved for UNKNOWN in persistent data.
*/
typedef enum e_tracker_activity_type
{
	TRACKER_ACTIVITY_TYPE_UNKNOWN = 0,
	TRACKER_ACTIVITY_TYPE_HUNTING = 1,
	TRACKER_ACTIVITY_TYPE_FISHING = 2,
	TRACKER_ACTIVITY_TYPE_MINING_PLANETSIDE = 3,
	TRACKER_ACTIVITY_TYPE_MINING_SPACE = 4,
	TRACKER_ACTIVITY_TYPE_CRAFTING = 5,
	TRACKER_ACTIVITY_TYPE_COOKING = 6,
	TRACKER_ACTIVITY_TYPE_HARVESTING = 7,
	TRACKER_ACTIVITY_TYPE_SWEATING = 8,
	TRACKER_ACTIVITY_TYPE_SERVICE = 9,
	TRACKER_ACTIVITY_TYPE_TRANSPORT = 10,
	TRACKER_ACTIVITY_TYPE_TRADING = 11,
	TRACKER_ACTIVITY_TYPE_INVESTMENT = 12,
	TRACKER_ACTIVITY_TYPE_OTHER = 13
} t_tracker_activity_type;

typedef struct s_tracker_event_record
{
	t_unix_time			timestamp_unix;
	int64_t				event_id;
	int64_t				parent_event_id;
	int64_t				session_id;
	t_tracker_activity_type	activity_type;
	const char			*event_type;
	const char			*target_or_item;
	long				quantity;
	t_uped				value_uPED;
	int64_t				envelope_id;
	uint32_t			flags;
	const char			*raw;
} t_tracker_event_record;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_activity_type_name — Retourne le nom persistant lisible d'un
**       type d'activité générique du Tracker.
** Paramètre: type — type d'activité stable à convertir.
** Retour: chaîne statique non modifiable; "UNKNOWN" pour toute valeur hors
**         domaine.
** Effets: aucun.
** Invariants: aucune allocation; les noms retournés sont stables pour la
**             persistance V4.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_activity_type_name().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_activity_type_name().
** --- Fin des liens API auto-vérifiés ---
*/
const char	*tracker_activity_type_name(t_tracker_activity_type type);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_activity_type_parse — Convertit un nom persistant d'activité
**       en identifiant stable sans inventer une correspondance inconnue.
** Paramètre: text — nom d'activité lu depuis une source persistante.
** Retour: type reconnu ou TRACKER_ACTIVITY_TYPE_UNKNOWN.
** Effets: aucun.
** Invariants: une chaîne absente ou inconnue reste UNKNOWN.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_activity_type_parse().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_activity_type_parse().
** --- Fin des liens API auto-vérifiés ---
*/
t_tracker_activity_type	tracker_activity_type_parse(const char *text);

#endif
