/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   entity_id.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENTITY_ID_H
# define ENTITY_ID_H

# include <stdint.h>

/*
** Canonical identifiers are positive signed 64-bit integers. Zero is the
** explicit UNKNOWN value and negative values are invalid/reserved.
*/
typedef int64_t	t_entity_id;

# define ENTITY_ID_UNKNOWN ((t_entity_id)0)
# define ENTITY_ID_INVALID ((t_entity_id)-1)

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: entity_id_is_valid — Vérifie qu'un identifiant canonique peut
**       référencer une entité persistante réelle.
** Paramètre: id — identifiant canonique à contrôler.
** Retour: Retourne 1 si id est strictement positif, 0 sinon.
** Effets: aucun.
** Invariants: zéro reste réservé à UNKNOWN et les valeurs négatives sont
**             invalides.
** --- Liens API auto-vérifiés ---
** Implémentation: entity_id_is_valid().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                entity_id_is_valid().
** --- Fin des liens API auto-vérifiés ---
*/
int	entity_id_is_valid(t_entity_id id);

#endif
