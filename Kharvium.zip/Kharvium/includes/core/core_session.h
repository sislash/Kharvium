/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core_session.h                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CORE_SESSION_H
# define CORE_SESSION_H

#include "common/money.h"
# include "core/core_combat_segment.h"

/*
 * Session truth (totals + current combat segment). No UI.
 * Notes:
 * - Time windowing / bucketing stays outside (analytics).
 */

typedef struct s_core_session
{
	long			shots_total;
	long			hits_total;
	long			kills_total;
	t_money		loot_total_uPED;
	t_money		expense_total_uPED;
	t_core_combat_seg	combat_seg;
} 	t_core_session;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_session_reset — Réinitialise l’état associé à cœur session.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: core_session_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_session_reset(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	core_session_reset(t_core_session *s);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_session_on_shot — Met à jour session on tir en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: is_hit — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: core_session_on_shot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_session_on_shot(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	core_session_on_shot(t_core_session *s, int is_hit);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_session_on_kill — Traite l’événement kill associé à cœur
**       session on.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: out_seg_shots — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: out_seg_hits — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s,
**         out_seg_shots, out_seg_hits.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: core_session_on_kill().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_session_on_kill(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	core_session_on_kill(t_core_session *s,
					long *out_seg_shots,
					long *out_seg_hits);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_session_add_loot — Ajoute session loot dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: v_uPED — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: core_session_add_loot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_session_add_loot(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	core_session_add_loot(t_core_session *s, t_money v_uPED);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: core_session_add_expense — Ajoute session expense dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: v_uPED — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: core_session_add_expense().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                core_session_add_expense(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	core_session_add_expense(t_core_session *s, t_money v_uPED);

#endif
