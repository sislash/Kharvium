/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FISHING_LOADOUT_H
# define FISHING_LOADOUT_H

# include "catalog/catalog_registry.h"
# include "core/data_provenance.h"

# define FISHING_LOADOUT_COMPONENTS 5

typedef struct s_fishing_component_snapshot
{
	t_entity_id		item_type_id;
	t_fishing_gear_slot	slot;
	t_money			tt_before;
	t_money			tt_after;
	t_money			acquisition_tt;
	t_money			acquisition_cost;
	int			has_tt_before;
	int			has_tt_after;
	int			has_acquisition_basis;
}	t_fishing_component_snapshot;

typedef struct s_fishing_ammo_snapshot
{
	t_entity_id	item_type_id;
	int64_t		quantity_before;
	int64_t		quantity_after;
	int64_t		acquisition_quantity;
	t_money		acquisition_cost;
	int			has_quantity_before;
	int			has_quantity_after;
	int			has_acquisition_basis;
}	t_fishing_ammo_snapshot;

typedef struct s_fishing_loadout_stats
{
	int32_t	strength_x100;
	int32_t	flexibility_x100;
	int32_t	reel_strength_x100;
	int32_t	reel_speed_x100;
	int32_t	line_length_cm;
	int32_t	lure_depth_cm;
	int32_t	lure_quality_x100;
}	t_fishing_loadout_stats;

typedef struct s_fishing_loadout_snapshot
{
	t_fishing_component_snapshot	components[FISHING_LOADOUT_COMPONENTS];
	t_fishing_ammo_snapshot		ammo;
	t_fishing_loadout_stats		stats;
	t_data_provenance_ref		provenance;
}	t_fishing_loadout_snapshot;

typedef struct s_fishing_loadout_cost
{
	t_money		gear_tt_decay;
	t_money		gear_cost_basis_consumed;
	t_money		ammo_tt_cost;
	t_money		ammo_cost_basis_consumed;
	t_money		total_tt_cost;
	t_money		total_cost_basis_consumed;
	t_data_quality	tt_quality;
	t_data_quality	cost_basis_quality;
}	t_fishing_loadout_cost;

typedef struct s_fishing_loadout_estimate
{
	t_money		gear_tt_per_attempt;
	t_money		ammo_tt_per_attempt;
	t_money		total_tt_per_attempt;
	int		known_components;
	int		unknown_components;
	int		ammo_required;
	int		ammo_known;
	t_data_quality	quality;
}	t_fishing_loadout_estimate;

void	fishing_loadout_initialize(t_fishing_loadout_snapshot *snapshot);
int	fishing_loadout_set_component(t_fishing_loadout_snapshot *snapshot,
		const t_catalog_fishing_gear *gear, t_money tt_before,
		t_money tt_after);
int	fishing_loadout_set_component_basis(t_fishing_loadout_snapshot *snapshot,
		t_fishing_gear_slot slot, t_money acquisition_tt,
		t_money acquisition_cost);
int	fishing_loadout_set_ammo(t_fishing_loadout_snapshot *snapshot,
		const t_catalog_fishing_ammo *ammo, int64_t before, int64_t after);
int	fishing_loadout_set_ammo_basis(t_fishing_loadout_snapshot *snapshot,
		int64_t acquisition_quantity, t_money acquisition_cost);
int	fishing_loadout_compute_stats(t_fishing_loadout_snapshot *snapshot,
		const t_catalog_registry *catalog);
int	fishing_loadout_calculate_cost(const t_fishing_loadout_snapshot *snapshot,
		const t_catalog_registry *catalog, t_fishing_loadout_cost *cost);
int	fishing_loadout_estimate_tt_per_attempt(
		const t_fishing_loadout_snapshot *snapshot,
		const t_catalog_registry *catalog,
		t_fishing_loadout_estimate *estimate);

#endif
