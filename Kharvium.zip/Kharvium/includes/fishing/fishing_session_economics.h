/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_session_economics.h                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FISHING_SESSION_ECONOMICS_H
# define FISHING_SESSION_ECONOMICS_H

# include <stdint.h>
# include "core/data_provenance.h"
# include "fishing/fishing_loadout.h"

typedef struct s_fishing_session_events
{
	int64_t			session_id;
	long			attempts;
	long			confirmed_attempts;
	long			catches;
	long			loot_rows;
	long			loot_rows_without_value;
	t_money			loot_tt;
	t_data_quality		loot_quality;
	int			found;
} t_fishing_session_events;

typedef struct s_fishing_session_economics
{
	t_fishing_session_events	events;
	t_money			gear_tt_decay;
	t_money			ammo_tt_cost;
	t_money			total_tt_cost;
	t_money			gear_cost_basis;
	t_money			ammo_cost_basis;
	t_money			total_cost_basis;
	t_money			tt_net;
	t_money			cost_basis_net;
	t_money			tt_cost_per_attempt;
	t_money			tt_cost_per_catch;
	t_money			basis_cost_per_attempt;
	t_money			basis_cost_per_catch;
	t_data_quality		tt_cost_quality;
	t_data_quality		cost_basis_quality;
	t_data_quality		tt_result_quality;
	t_data_quality		basis_result_quality;
	int			has_tt_result;
	int			has_basis_result;
} t_fishing_session_economics;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: fishing_session_events_read_v4 — Agrège une session Fishing depuis
**       le journal Tracker V4 sans utiliser les enveloppes V3 legacy.
** Paramètre: path — chemin du fichier tracker_events.csv à lire.
** Paramètre: session_id — identifiant V4 strictement positif à sélectionner.
** Paramètre: events — destination totalement réinitialisée puis renseignée.
** Retour: 1 si le fichier est lisible et valide, 0 sur erreur/corruption.
** Effets: lit le fichier en séquence; aucune écriture ni allocation dynamique.
** Invariants: seuls les événements d'activité FISHING de la session comptent.
** --- Liens API auto-vérifiés ---
** Implémentation: fishing_session_events_read_v4().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                fishing_session_events_read_v4().
** --- Fin des liens API auto-vérifiés ---
*/
int	fishing_session_events_read_v4(const char *path, int64_t session_id,
		t_fishing_session_events *events);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: fishing_session_economics_build — Combine les événements V4 et les
**       coûts mesurés E88 sans inventer de valeur manquante.
** Paramètre: events — agrégat V4 de la session consulté en lecture seule.
** Paramètre: cost — coût de loadout E88 déjà calculé et qualifié.
** Paramètre: output — résumé économique de session entièrement renseigné.
** Retour: 1 si les entrées sont cohérentes, 0 sinon.
** Effets: modifie seulement output; aucune E/S ni allocation.
** Invariants: Net n'est disponible que si loot et coût sont complets.
** --- Liens API auto-vérifiés ---
** Implémentation: fishing_session_economics_build().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                fishing_session_economics_build().
** --- Fin des liens API auto-vérifiés ---
*/
int	fishing_session_economics_build(
		const t_fishing_session_events *events,
		const t_fishing_loadout_cost *cost,
		t_fishing_session_economics *output);

#endif
