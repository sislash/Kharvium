/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_event_model.h                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FISHING_EVENT_MODEL_H
# define FISHING_EVENT_MODEL_H

# include <stdint.h>

# define FISHING_EVENT_ATTEMPT "FISHING_ATTEMPT"
# define FISHING_EVENT_CATCH "FISHING_CATCH"
# define FISHING_EVENT_SKILL "FISHING_SKILL"
# define FISHING_EVENT_CANDIDATE "FISHING_CANDIDATE"

/*
** Stable semantic result of one Fishing attempt. Chat-log reconstruction can
** prove only CONFIRMED_CATCH today; the remaining values are reserved for
** future explicit/manual sources and must never be inferred from silence.
*/
typedef enum e_fishing_attempt_result
{
	FISHING_ATTEMPT_UNKNOWN = 0,
	FISHING_ATTEMPT_CONFIRMED_CATCH = 1,
	FISHING_ATTEMPT_NO_BITE = 2,
	FISHING_ATTEMPT_FAILED_REEL = 3,
	FISHING_ATTEMPT_CANCELLED = 4,
	FISHING_ATTEMPT_INTERRUPTED = 5
} t_fishing_attempt_result;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: fishing_attempt_result_name — Retourne le libellé persistant d'un
**       résultat de tentative Fishing sans inventer une valeur inconnue.
** Paramètre: result — résultat stable à convertir.
** Retour: chaîne statique read-only; "UNKNOWN" hors domaine.
** Effets: aucun.
** Invariants: les libellés sont stables pour les événements V4.
** --- Liens API auto-vérifiés ---
** Implémentation: fishing_attempt_result_name().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                fishing_attempt_result_name().
** --- Fin des liens API auto-vérifiés ---
*/
const char	*fishing_attempt_result_name(t_fishing_attempt_result result);

#endif
