/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rules.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FISHING_RULES_H
# define FISHING_RULES_H

# include "catalog/catalog_registry.h"
# include "hunt/hunt_rules.h"

int	fishing_parse_loot_line(const char *line, t_hunt_event *event);
t_fishing_output_role	fishing_event_role(const t_catalog_registry *catalog,
		const t_hunt_event *event);
int	fishing_event_confirms_catch(const t_catalog_registry *catalog,
		const t_hunt_event *event);
int	fishing_event_can_name_catch(const t_catalog_registry *catalog,
		const t_hunt_event *event);
int	fishing_parse_skill_line(const t_catalog_registry *catalog,
		const char *line, t_hunt_event *event);

#endif
