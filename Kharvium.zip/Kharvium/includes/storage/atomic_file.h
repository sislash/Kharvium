/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   atomic_file.h                                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ATOMIC_FILE_H
# define ATOMIC_FILE_H

# include <stddef.h>
# include <stdio.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: storage_temp_path — Construit ou résout le chemin utilisé par
**       storage temp.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Paramètre: dst_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: storage_temp_path().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                storage_temp_path(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		storage_temp_path(char *out, size_t cap, const char *dst_path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: storage_temp_path_alloc — Alloue temp chemin en appliquant les
**       validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: dst_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: storage_temp_path_alloc().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                storage_temp_path_alloc(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
char	*storage_temp_path_alloc(const char *dst_path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: storage_flush_sync — Synchronise l’état associé à storage flush.
** Paramètre: stream — flux de fichier déjà ouvert dont le cycle de vie
**            reste celui prévu par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : stream.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: storage_flush_sync().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                storage_flush_sync(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		storage_flush_sync(FILE *stream);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: storage_sync_close — Ferme l’état associé à storage sync.
** Paramètre: stream — flux de fichier déjà ouvert dont le cycle de vie
**            reste celui prévu par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : stream.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: storage_sync_close().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                storage_sync_close(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		storage_sync_close(FILE *stream);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: storage_replace_temp — Met à jour replace temp en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: tmp_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: dst_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: storage_replace_temp().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                storage_replace_temp(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		storage_replace_temp(const char *tmp_path, const char *dst_path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: storage_discard_temp — Met à jour discard temp en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: tmp_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: storage_discard_temp().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                storage_discard_temp(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	storage_discard_temp(const char *tmp_path);

#endif
