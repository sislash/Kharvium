/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_engine.h                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PARSE_ENGINE_H
# define PARSE_ENGINE_H

# include <stdatomic.h>

# include "app/app_state_fwd.h"

/*
** Parse engine: reads chat.log (replay or live) and writes hunt CSV.
** NO UI here.
*/

/* API canonique (FR) */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_engine_set_player_name — Retourne set player nom dans la forme
**       directement utilisable par le rendu ou l’appelant.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_engine_set_player_name().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_engine_set_player_name(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	parse_engine_set_player_name(t_app_state *app, const char *name);

/* Compat legacy (ancien nom EN) */

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_run_replay — Analyse run REPLAY depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: chatlog_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: stop_flag — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : app, stop_flag.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_run_replay().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_run_replay(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		parse_run_replay(t_app_state *app, const char *chatlog_path,
			const char *csv_path, atomic_int *stop_flag);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_run_live — Analyse run LIVE depuis la source fournie, contrôle
**       le format utile et ne renseigne la destination qu’avec des données
**       validées.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: chatlog_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: stop_flag — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : app, stop_flag.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_run_live().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_run_live(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		parse_run_live(t_app_state *app, const char *chatlog_path,
			const char *csv_path, atomic_int *stop_flag);

#endif
