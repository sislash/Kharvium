/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_normalization.h                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PARSE_NORMALIZATION_H
# define PARSE_NORMALIZATION_H

# include <stddef.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_normalization_should_ignore_line — Détermine si normalization
**       ignore ligne respecte la condition attendue, sans modifier les
**       données consultées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_normalization_should_ignore_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_normalization_should_ignore_line(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			parse_normalization_should_ignore_line(const char *line);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_normalization_is_strict_shot — Détermine si normalization
**       strict tir respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_normalization_is_strict_shot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_normalization_is_strict_shot(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			parse_normalization_is_strict_shot(const char *line);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_normalization_is_critical_shot — Détermine si normalization
**       critical tir respecte la condition attendue, sans modifier les
**       données consultées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_normalization_is_critical_shot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_normalization_is_critical_shot(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			parse_normalization_is_critical_shot(const char *line);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_normalization_received_start — Démarre l’état associé à
**       parsing normalisation received.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_normalization_received_start().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_normalization_received_start(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*parse_normalization_received_start(const char *line);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_normalization_kill_start — Démarre l’état associé à parsing
**       normalisation kill.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_normalization_kill_start().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_normalization_kill_start(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*parse_normalization_kill_start(const char *line);

#endif
