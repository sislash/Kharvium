/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_file_system.h                            +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PLATFORM_FILE_SYSTEM_H
# define PLATFORM_FILE_SYSTEM_H

# include <stddef.h>
# include <stdint.h>
# include <stdio.h>

/* fd / process */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_stream_file_descriptor — Met à jour stream descriptor en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_stream_file_descriptor().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_stream_file_descriptor(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_stream_file_descriptor(FILE *f);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_sync_file_descriptor — Met à jour sync descriptor en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: fd — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_sync_file_descriptor().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_sync_file_descriptor(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_sync_file_descriptor(int fd);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_process_id — Traite id en appliquant les validations et
**       transformations propres à cette opération, puis laisse les données
**       concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_process_id().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_process_id(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_process_id(void);

/* 64-bit stream positioning */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_stream_seek64 — Met à jour stream seek64 en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: off — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: whence — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_stream_seek64().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_stream_seek64(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_stream_seek64(FILE *f, int64_t off, int whence);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_stream_tell64 — Met à jour stream tell64 en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Retourne le résultat de type int64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_stream_tell64().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_stream_tell64(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int64_t		platform_stream_tell64(FILE *f);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_stream_truncate — Met à jour stream truncate en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: new_size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_stream_truncate().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_stream_truncate(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_stream_truncate(FILE *f, int64_t new_size);

/* Paths */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_path_separator — Localise ou traite le séparateur utilisé
**       par platform chemin.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type char; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_path_separator().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_path_separator(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
char		platform_path_separator(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_home_directory — Met à jour home répertoire en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_home_directory().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_home_directory(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*platform_home_directory(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_path_exists — Met à jour chemin exists en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_path_exists().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_path_exists(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_path_exists(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_replace_file — Met à jour replace en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: tmp_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: dst_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_replace_file().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_replace_file(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_replace_file(const char *tmp_path, const char *dst_path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_get_executable_path — Retourne executable chemin en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv0 — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_get_executable_path().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_get_executable_path(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_get_executable_path(char *out, size_t outsz,
	const char *argv0);

/* FS helpers */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_create_directory — Crée répertoire à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_create_directory().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_create_directory(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_create_directory(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_path_is_directory — Détermine si chemin répertoire respecte
**       la condition attendue, sans modifier les données consultées.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_path_is_directory().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_path_is_directory(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_path_is_directory(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_change_directory — Met à jour change répertoire en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_change_directory().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_change_directory(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_change_directory(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_open_shared_read — Lit l’état associé à platform open
**       shared.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_open_shared_read().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_open_shared_read(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
FILE		*platform_open_shared_read(const char *path);

/* low-level FD IO */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_open_exclusive_write — Écrit l’état associé à platform
**       open exclusive.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_open_exclusive_write().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_open_exclusive_write(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_open_exclusive_write(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_write_file_descriptor — Écrit descriptor vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: fd — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: buf — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: n — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_write_file_descriptor().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_write_file_descriptor(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
long		platform_write_file_descriptor(int fd, const void *buf, size_t n);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_close_file_descriptor — Ferme descriptor en appliquant les
**       transitions d’état et la gestion d’erreur nécessaires pour que la
**       ressource reste cohérente.
** Paramètre: fd — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_close_file_descriptor().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_close_file_descriptor(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_close_file_descriptor(int fd);

#endif
