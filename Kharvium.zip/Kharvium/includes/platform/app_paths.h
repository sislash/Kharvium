/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths.h                                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef APP_PATHS_H
# define APP_PATHS_H

# include <stddef.h>

/*
** Tracker Modulaire - core_paths
**
** Centralise les chemins de fichiers/dossiers.
**
** Regle: aucun autre module ne doit hardcoder "logs/...".
*/

# define APP_DIR_LOGS               "logs"
# define APP_FILE_HUNT_CSV          "logs/hunt_log.csv"
# define APP_FILE_SESSION_OFFSET    "logs/hunt_session.offset"
# define APP_FILE_SESSION_RANGE     "logs/hunt_session.range"
# define APP_FILE_SELECTED_WEAPON   "logs/selected_weapon.txt"
# define APP_FILE_SELECTED_FISHING_ROD "logs/selected_fishing_rod.txt"
# define APP_FILE_SELECTED_CREATURE "logs/selected_creature.txt"
# define APP_FILE_WEAPONS_INI         "weapons.ini"
# define APP_FILE_FISHING_RODS_INI    "fishing_rods.ini"
# define APP_FILE_OPTIONS_CONFIG       "logs/options.cfg"
# define APP_FILE_HOTKEYS_LOG       "logs/hotkeys.log"
# define APP_FILE_SESSION_STATISTICS_CSV "logs/session_statistics.csv"
/* Globals / HOF / ATH (mob + craft) */
# define APP_FILE_GLOBAL_EVENTS_CSV "logs/global_events.csv"
# define APP_FILE_MARKUP_INI "markup.ini"
# define APP_FILE_FINANCE_BOOK "logs/finance_book.csv"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_markup_ini — Met à jour chemin ini en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_markup_ini().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_markup_ini(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_markup_ini(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_finance_book — Met à jour chemin book en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_finance_book().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_finance_book(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_finance_book(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_global_events_csv — Traite chemin et met à jour uniquement
**       l’état d’entrée ou d’interface
**       correspondant à cet événement.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_global_events_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_global_events_csv(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_global_events_csv(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_session_statistics_csv — Met à jour chemin session
**       statistics en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_session_statistics_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_session_statistics_csv(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char  *app_path_session_statistics_csv(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_options_config — Met à jour chemin options en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_options_config().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_options_config(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char  *app_path_options_config(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_hunt_csv — Met à jour chemin en appliquant explicitement les
**       paramètres, bornes et invariants décrits par le contrat de cette
**       fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_hunt_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_hunt_csv(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_hunt_csv(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_session_offset — Calcule chemin session offset à partir de
**       l’état courant en respectant les unités,
**       bornes et conventions du module.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_session_offset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_session_offset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_session_offset(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_session_range — Calcule ou applique la plage utilisée par
**       application chemin session.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_session_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_session_range(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_session_range(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_selected_weapon — Met à jour chemin sélection en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_selected_weapon().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_selected_weapon(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_selected_weapon(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_selected_creature — Met à jour chemin sélection creature en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_selected_creature().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_selected_creature(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_selected_creature(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_weapons_ini — Met à jour chemin weapons ini en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_weapons_ini().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_weapons_ini(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_weapons_ini(void);

const char	*app_path_selected_fishing_rod(void);
const char	*app_path_fishing_rods_ini(void);

/* Initialise les chemins a partir du chemin de l'executable.
 * Permet de lancer le programme depuis n'importe quel dossier
 * (double-clic .exe).
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_paths_initialize — Initialise l’état associé à application
**       chemins.
** Paramètre: argv0 — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_paths_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_paths_initialize(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			 app_paths_initialize(const char *argv0);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_root_path — Construit ou résout le chemin utilisé par
**       application root.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_root_path().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_root_path(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_root_path(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: assets_root_path — Construit ou résout le chemin utilisé par assets
**       root.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: assets_root_path().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                assets_root_path(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*assets_root_path(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_logs_dir — Met à jour chemin logs répertoire en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_logs_dir().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_logs_dir(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_logs_dir(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_parser_debug_log — Met à jour chemin parser debug log en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_parser_debug_log().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_parser_debug_log(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_parser_debug_log(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_path_hotkeys_log — Met à jour chemin raccourcis clavier log en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_path_hotkeys_log().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_path_hotkeys_log(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*app_path_hotkeys_log(void);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_paths_ensure_logs_directory — Garantit paths logs répertoire en
**       appliquant les validations,
**       bornes et effets explicitement
**       définis par ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_paths_ensure_logs_directory().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_paths_ensure_logs_directory(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			 app_paths_ensure_logs_directory(void);

#endif
