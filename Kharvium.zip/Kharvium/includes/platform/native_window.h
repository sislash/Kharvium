/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   native_window.h                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/04                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NATIVE_WINDOW_H
# define NATIVE_WINDOW_H

/*
** Small integer point used by higher-level UI primitives (graphs, etc.).
** Kept minimal to stay portable (avoid Win32 POINT / X11 XPoint in headers).
*/
typedef struct s_point_i
{
	int	x;
	int	y;
}	t_point_i;

typedef enum e_window_font_role
{
	WINDOW_FONT_BODY = 0,
	WINDOW_FONT_SMALL,
	WINDOW_FONT_BUTTON,
	WINDOW_FONT_TITLE,
	WINDOW_FONT_ROLE_COUNT
}	t_window_font_role;

typedef struct s_window_clip_rectangle
{
	int	x;
	int	y;
	int	width;
	int	height;
	int	active;
}   t_window_clip_rectangle;

typedef struct s_window_overlay_request
{
	const char	*title;
	int			width;
	int			height;
	int			topmost;
	int			alpha_0_255;
}   t_window_overlay_request;

typedef struct s_window_hotkey_descriptions
{
	char	*overlay;
	int	overlay_size;
	char	*click;
	int	click_size;
}   t_window_hotkey_descriptions;

typedef struct s_window_draw_rectangle
{
	int	x;
	int	y;
	int	width;
	int	height;
	int	color;
}   t_window_draw_rectangle;

typedef struct s_window_draw_text_request
{
	int			x;
	int			y;
	const char	*text;
	int			color;
	t_window_font_role	font_role;
}   t_window_draw_text_request;

typedef struct s_window_draw_line_request
{
	int	x0;
	int	y0;
	int	x1;
	int	y1;
	int	color;
}   t_window_draw_line_request;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_clip_intersection — Rend clip intersection avec les primitives
**       UI disponibles en respectant la zone d’affichage et l’état de la
**       frame courante.
** Paramètre: parent — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: child — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type t_window_clip_rectangle; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_clip_intersection().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_clip_intersection(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_window_clip_rectangle	window_clip_intersection(
	t_window_clip_rectangle parent, t_window_clip_rectangle child);

typedef struct s_window
{
    int				running;
    int				close_requested;
    const char		*title;
    int				width;
    int				height;

    int				key_up;
    int				key_down;
    int				key_enter;
    int				key_escape;

    int			key_z;
	int			key_q;
	int			key_s;
	int			key_d;

	/* Mouse (frame-based): position + click pulse */
	int			mouse_x;
	int			mouse_y;
	int			mouse_left_click;
	/* Mouse button state (persistent) */
	int			mouse_left_down;

	/* UI drag state (for scrollbars, sliders, etc.) */
	int			ui_active_id;
	int			ui_drag_offset_y;

	t_window_clip_rectangle	clip_current;
	t_window_clip_rectangle	clip_stack[8];
	int			clip_stack_size;

	/* Mouse wheel (frame-based): +1 up, -1 down (can accumulate) */
	int			mouse_wheel;

	/* Text input (frame-based): collected during window_poll_events() */
	char			text_input[64];
	int			text_len;
	int			key_backspace;
	int			key_delete;
	int			key_tab;
	int			key_o;
	int			key_h;
	int			key_p;

    int				use_buffer;

	/* Opaque user pointer (app/core context). */
	void			*user;

    void			*backend_1;
    void			*backend_2;
    void			*backend_3;

    unsigned int	*pixels;
    int				pitch;
}	t_window;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_initialize — Initialise l’état associé à fenêtre.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: title — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_initialize(), window_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_initialize(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		window_initialize(t_window *w, const char *title, int width,
	int height);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_initialize_overlay — Initialise une fenêtre overlay native à
**       partir des paramètres demandés.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_initialize_overlay(), window_initialize_overlay().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_initialize_overlay(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		window_initialize_overlay(t_window *w,
			const t_window_overlay_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_set_minimum_size — Calcule set minimum taille à partir des
**       entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_set_minimum_size(), window_set_minimum_size().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_set_minimum_size(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_set_minimum_size(t_window *w, int width, int height);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_poll_events — Traite poll et met à jour uniquement l’état
**       d’entrée ou d’interface correspondant à cet
**       événement.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_poll_events(), window_poll_events().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_poll_events(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_poll_events(t_window *w);

/* Overlay (best-effort): make the window mouse click-through. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_set_overlay_click_through — Met à jour click through à partir
**       des valeurs courantes et conserve l’état partagé cohérent pour la
**       suite de la frame ou du calcul.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: on — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_set_overlay_click_through(),
**                 window_set_overlay_click_through().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_set_overlay_click_through(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_set_overlay_click_through(t_window *w, int on);

/*
** Global hotkeys (best-effort).
** Return value is a bitmask:
**  - bit0 (1): overlay toggle hotkey available
**  - bit1 (2): click-through (LOCK) hotkey available
** If out buffers are provided, a short ASCII description is written
** (ex: "Ctrl+Alt+O").
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_get_hotkeys — Retourne raccourcis clavier en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: descriptions — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, descriptions.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_get_hotkeys(), window_get_hotkeys().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_get_hotkeys(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		window_get_hotkeys(t_window *w,
			t_window_hotkey_descriptions *descriptions);

/*
** Rebind global hotkeys (best-effort).
** combo lists are comma-separated, each combo as "Ctrl+Alt+O".
** Returns a bitmask like window_get_hotkeys().
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_rebind_hotkeys — Prépare ou applique les raccourcis clavier
**       de fenêtre rebind.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: overlay_list — objet source consulté en lecture seule par
**            cette fonction.
** Paramètre: click_list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_rebind_hotkeys(), window_rebind_hotkeys().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_rebind_hotkeys(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		window_rebind_hotkeys(t_window *w,
			const char *overlay_list, const char *click_list);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_clear — Vide l’état associé à fenêtre.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_clear(), window_clear().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_clear(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_clear(t_window *w, int color);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_fill_rectangle — Calcule le rectangle de mise en page
**       utilisé par fenêtre fill.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_fill_rectangle(), window_fill_rectangle().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_fill_rectangle(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_fill_rectangle(t_window *w, t_window_draw_rectangle request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_draw_text — Dessine texte dans le contexte graphique courant
**       en respectant la géométrie, le clipping et l’état des widgets
**       fournis.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_draw_text(), window_draw_text().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_draw_text(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_draw_text(t_window *w,
			const t_window_draw_text_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_measure_text_width — Calcule la largeur nécessaire à fenêtre
**       measure texte.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_measure_text_width(), window_measure_text_width().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_measure_text_width(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		window_measure_text_width(t_window *w, const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_measure_text_height — Calcule la hauteur nécessaire à
**       fenêtre measure texte.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_measure_text_height(),
**                 window_measure_text_height().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_measure_text_height(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		window_measure_text_height(t_window *w);

/*
** Mesure le texte avec le rôle typographique réellement rendu. Les backends
** utilisent leurs métriques natives; aucun coefficient de largeur estimé
** n'est appliqué par cette API.
*/
int		window_measure_text_width_role(t_window *w, const char *text,
			t_window_font_role role);
int		window_measure_text_height_role(t_window *w,
			t_window_font_role role);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_set_clip_rectangle — Calcule set clip rectangle à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: rectangle — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_set_clip_rectangle(), window_set_clip_rectangle().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_set_clip_rectangle(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_set_clip_rectangle(t_window *w,
			t_window_clip_rectangle rectangle);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_clear_clip_rectangle — Calcule clear clip rectangle à partir
**       de la géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_clear_clip_rectangle(),
**                 window_clear_clip_rectangle().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_clear_clip_rectangle(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_clear_clip_rectangle(t_window *w);

/* Simple line primitive (used by graphs, separators, etc.). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_draw_line — Dessine ligne dans le contexte graphique courant
**       en respectant la géométrie, le clipping et l’état des widgets
**       fournis.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_draw_line(), window_draw_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_draw_line(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_draw_line(t_window *w, t_window_draw_line_request request);

/*
** Polyline primitive (optimized for graphs).
** Draws connected segments through all points (n >= 2).
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_draw_polyline — Dessine polyline dans le contexte graphique
**       courant en respectant la géométrie, le clipping et l’état des
**       widgets fournis.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: points — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_draw_polyline(), window_draw_polyline().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_draw_polyline(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_draw_polyline(t_window *w, const t_point_i *pts,
			int n, int color);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_present — Met à jour present en appliquant explicitement les
**       paramètres, bornes et invariants décrits par le contrat de cette
**       fonction.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_present(), window_present().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_present(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_present(t_window *w);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_destroy — Détruit proprement l’état associé à fenêtre.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_destroy(), window_destroy().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_destroy(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_destroy(t_window *w);

#endif
