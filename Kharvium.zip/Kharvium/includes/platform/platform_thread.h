/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_thread.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PLATFORM_THREAD_H
# define PLATFORM_THREAD_H

# include <stdint.h>

typedef void	*(*t_platform_thread_fn)(void *);

typedef struct s_platform_thread
{
	int			valid;
	uintptr_t	storage[4];
} 					t_platform_thread;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_thread_start — Démarre l’état associé à platform thread.
** Paramètre: t — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: fn — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: arg — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : t, arg.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_thread_start(), platform_thread_start().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_thread_start(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		platform_thread_start(t_platform_thread *t, t_platform_thread_fn fn,
	void *arg);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_thread_join — Met à jour thread join en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: t — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : t.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_thread_join(), platform_thread_join().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_thread_join(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	platform_thread_join(t_platform_thread *t);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_thread_is_valid — Détermine si thread valide respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: thread — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_thread_is_valid().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_thread_is_valid(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		platform_thread_is_valid(const t_platform_thread *t);

#endif
