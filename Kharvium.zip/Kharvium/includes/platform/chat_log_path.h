/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   chat_log_path.h                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef CHAT_LOG_PATH_H
# define CHAT_LOG_PATH_H

# include <stddef.h>

/*
** Construit le chemin vers chat.log en fonction des variables d'environnement.
**
** Windows: %USERPROFILE%\Documents\Entropia Universe\chat.log
** Linux:  $HOME/... (a adapter selon ton setup; par defaut $HOME/chat.log)
*/

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: chat_log_build_path — Construit chat log chemin à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: chat_log_build_path().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                chat_log_build_path(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	chat_log_build_path(char *out, size_t out_size);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: chat_log_is_available — Détermine si chat log available respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_size — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: chat_log_is_available().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                chat_log_is_available(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	chat_log_is_available(char *out, size_t out_size);

#endif
