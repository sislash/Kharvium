/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hotkey_log.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 15:55:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 15:55:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HOTKEY_LOG_H
# define HOTKEY_LOG_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_hotkey_log_message — Traite raccourci clavier log message
**       et met à jour uniquement l’état
**       d’entrée ou d’interface correspondant
**       à cet événement.
** Paramètre: format — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: ? — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_hotkey_log_message().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_hotkey_log_message(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	platform_hotkey_log_message(const char *format, ...);

#endif
