/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_console_internal.h                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PLATFORM_CONSOLE_INTERNAL_H
# define PLATFORM_CONSOLE_INTERNAL_H

# if !defined(_WIN32) && !defined(_WIN64)
#  include <termios.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_console_set_raw_mode — configure ou restaure l’état du
** terminal natif utilisé pour la saisie clavier.
** Paramètre: old — attributs POSIX du terminal sauvegardés/restaurés.
** Retour: Retourne le statut ou résultat entier défini par l’implémentation;
** les erreurs sont propagées sans être masquées.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_console_set_raw_mode().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_console_set_raw_mode(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		platform_console_set_raw_mode(struct termios *old);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_console_restore_mode — configure ou restaure l’état du
** terminal natif utilisé pour la saisie clavier.
** Paramètre: old — attributs POSIX du terminal sauvegardés/restaurés.
** Retour: Ne retourne rien; les sorties éventuelles sont écrites uniquement
** dans les objets explicitement fournis.
** Effets: respecte exactement les mutations, E/S et transferts de propriété
** documentés par l’implémentation correspondante.
** Invariants: les pointeurs, capacités et états obligatoires doivent
** satisfaire les validations de l’implémentation avant usage.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_console_restore_mode().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_console_restore_mode(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	platform_console_restore_mode(const struct termios *old);
# endif

#endif
