/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_time.h                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PLATFORM_TIME_H
# define PLATFORM_TIME_H

# include <stdint.h>
# include <time.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_sleep_milliseconds — Met à jour sleep milliseconds en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_sleep_milliseconds().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_sleep_milliseconds(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		platform_sleep_milliseconds(int ms);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_time_milliseconds — Met à jour temps milliseconds en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Retour: Retourne le résultat de type uint64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: platform_time_milliseconds().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_time_milliseconds(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
uint64_t	platform_time_milliseconds(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: platform_localtime_safe — Convertit un time_t en heure locale de
**       manière sûre avec l'API native disponible sur Windows ou POSIX.
** Paramètre: out — structure tm destination entièrement renseignée en cas
**            de succès.
** Paramètre: t — horodatage source consulté sans être modifié.
** Retour: Retourne 0 si la conversion réussit et -1 si la conversion échoue.
** Effets: modifie uniquement la structure out fournie par l'appelant.
** Invariants: n'expose pas le buffer statique non réentrant de localtime().
** --- Liens API auto-vérifiés ---
** Implémentation: platform_localtime_safe().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                platform_localtime_safe(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			platform_localtime_safe(struct tm *out, const time_t *t);

#endif
