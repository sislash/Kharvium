/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hotkey_combination.h                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 16:01:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 16:01:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HOTKEY_COMBINATION_H
# define HOTKEY_COMBINATION_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkey_list_next_combination — Traite raccourci clavier liste next
**       combination et met à jour uniquement
**       l’état d’entrée ou d’interface
**       correspondant à cet événement.
** Paramètre: cursor — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: output_capacity — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkey_list_next_combination().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkey_list_next_combination(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hotkey_list_next_combination(const char **cursor, char *output,
		int output_capacity);

#endif
