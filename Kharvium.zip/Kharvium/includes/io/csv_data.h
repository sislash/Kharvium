/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   csv_data.h                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef CSV_DATA_H
# define CSV_DATA_H

# include <stddef.h>
# include <stdint.h>

/* Optional: sparse index for fast timestamp seeks (load_since_indexed). */
# include "io/csv_index.h"

typedef struct s_csv_data_row
{
	long long	timestamp;
	char		*event_type;      /* UTF-8, heap allocated */
	double		value;
	int			hit_count_reset;  /* 0/1 */
}	t_csv_data_row;

typedef struct s_csv_data
{
	t_csv_data_row	*rows;
	size_t		count;
	size_t		capacity;
}	t_csv_data;

/* -------------------- CSV load configuration/reporting -------------------- */

typedef enum e_csv_error_policy
{
	CSV_ERROR_SKIP = 0,
	CSV_ERROR_STOP = 1
}	t_csv_error_policy;

typedef enum e_csv_load_status
{
	CSV_LOAD_OK = 0,
	CSV_LOAD_OPEN_FAILED,
	CSV_LOAD_IO_ERROR,
	CSV_LOAD_CHECKSUM_MISMATCH,
	CSV_LOAD_TOO_BIG,
	CSV_LOAD_TOO_MANY_ROWS,
	CSV_LOAD_BAD_FORMAT,
	CSV_LOAD_OOM
}	t_csv_load_status;

typedef struct s_csv_load_options
{
	t_csv_error_policy	policy;            /* skip malformed lines or stop */
	int				log_stderr;        /* 1 => limited warnings to stderr */
	size_t			max_file_bytes;    /* 0 => unlimited (not recommended) */
	size_t			max_rows;          /* 0 => unlimited (not recommended) */
	size_t			max_error_samples; /* Maximum warning samples. */
	size_t			max_line_bytes;    /* 0 => default internal limit */
	int				verify_crc32; /* Verify footer when present. */
}	t_csv_load_options;

typedef struct s_csv_load_report
{
	t_csv_load_status	status;
	size_t			first_error_line;  /* 0 if none */
	size_t			last_error_line;   /* 0 if none */
	size_t			loaded_rows;
	size_t			skipped_lines;
	size_t			bytes_read;
	char			first_error[256];  /* reason + preview (first error only) */
	char			delimiter;         /* detected delimiter: ',' or ';' */
	int				has_crc32;         /* footer was present */
	uint32_t		expected_crc32;
	uint32_t		computed_crc32;
	int				crc32_ok;          /* 1 if verified and matches */
}	t_csv_load_report;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_load_options_default — Charge options par défaut depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: options — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : options.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_load_options_default().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_load_options_default(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void				csv_load_options_default(t_csv_load_options *opt);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_load_report_initialize — Initialise l’état associé à CSV load
**       report.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_load_report_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_load_report_initialize(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void				csv_load_report_initialize(t_csv_load_report *report);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_data_load — Charge l’état associé à CSV données.
** Paramètre: filename — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_data_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_data_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_csv_data		*csv_data_load(const char *filename,
						const t_csv_load_options *opt,
							t_csv_load_report *out_report);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_data_load_since — Charge data since depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: filename — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: min_timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_data_load_since().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_data_load_since(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_csv_data		*csv_data_load_since(const char *filename,
					long long min_timestamp,
					const t_csv_load_options *opt,
						t_csv_load_report *out_report);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_data_load_since_indexed — Charge data since indexed depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: filename — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: min_timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_data_load_since_indexed().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_data_load_since_indexed(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_csv_data		*csv_data_load_since_indexed(const char *filename,
					long long min_timestamp,
					const t_csv_load_options *opt,
						t_csv_load_report *out_report);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_last_report — Met à jour last report en appliquant explicitement
**       les paramètres, bornes et invariants décrits par le contrat de cette
**       fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_last_report().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_last_report(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const t_csv_load_report	*csv_last_report(void);

/* -------------------- CSV write configuration/reporting ------------------- */

typedef enum e_csv_write_status
{
	CSV_WRITE_OK = 0,
	CSV_WRITE_OPEN_FAILED,
	CSV_WRITE_IO_ERROR,
	CSV_WRITE_RENAME_FAILED,
	CSV_WRITE_OOM
}	t_csv_write_status;

typedef struct s_csv_write_options
{
	char			delimiter;          /* ',' (default) or ';' */
	int				atomic_write; /* Write with temporary file. */
	int				fsync_on_close; /* Flush storage on close. */
	int				write_crc32_footer; /* Add CRC32 footer. */
}	t_csv_write_options;

typedef struct s_csv_write_report
{
	t_csv_write_status	status;
	char			delimiter;
	int				has_crc32;
	uint32_t		crc32;
	char			error[256];
}	t_csv_write_report;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_write_options_default — Écrit options par défaut vers la
**       destination prévue en respectant le format persistant, les capacités
**       de buffer et la propagation des erreurs.
** Paramètre: options — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : options.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_write_options_default().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_write_options_default(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void				csv_write_options_default(t_csv_write_options *opt);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_data_save — Sauvegarde l’état associé à CSV données.
** Paramètre: filename — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: data — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : data, output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_data_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_data_save(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int				csv_data_save(const char *filename, t_csv_data *data,
						const t_csv_write_options *opt,
							t_csv_write_report *out_report);

/* Streaming writer (large data / real-time logging) */

typedef struct s_csv_writer	t_csv_writer;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_writer_open — Ouvre l’état associé à CSV écriture.
** Paramètre: filename — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_writer_open().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_writer_open(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_csv_writer		*csv_writer_open(const char *filename,
						const t_csv_write_options *opt,
							t_csv_write_report *out_report);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_writer_write_data_row — Écrit writer data ligne vers la
**       destination prévue en respectant le format persistant, les capacités
**       de buffer et la propagation des erreurs.
** Paramètre: writer — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : writer.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_writer_write_data_row().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_writer_write_data_row(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int				csv_writer_write_data_row(t_csv_writer *w,
	const t_csv_data_row *row);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_writer_close — Ferme l’état associé à CSV écriture.
** Paramètre: writer — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : writer.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_writer_close().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_writer_close(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	csv_writer_close(t_csv_writer *w);

/* ------------------- Journal append (fast incremental logging) ------------ */
/*
 * Journal strategy:
 * - Snapshot file: <base>.csv (your normal file, can have #crc32 footer)
	 * - Journal file : <base>.csv.journal  (append-only)
	 *   no footer; may be compacted later
 * On load, you can read snapshot then apply journal rows.
 */

typedef enum e_csv_journal_status
{
	CSV_JOURNAL_OK = 0,
	CSV_JOURNAL_LOCKED,
	CSV_JOURNAL_OPEN_FAILED,
	CSV_JOURNAL_IO_ERROR,
	CSV_JOURNAL_OOM
}	t_csv_journal_status;

typedef struct s_csv_journal_options
{
	char	delimiter;			/* , (default) or ; */
	int		fsync_on_append;	/* 1 => fflush + fsync/ _commit */
	int		use_lock_file;		/* 1 => create <journal>.lock with O_EXCL */
	/* Optional: maintain a sparse index for the journal itself (<journal>.idx)
	 * incrementally at append time.
	 *
	 * - update_journal_index: enable/disable.
	 * - journal_index_stride_rows: checkpoint stride (e.g. 1024).
	 * - journal_index_best_effort: if 1 (default),
	 	journal appends still succeed
	 *   even if the index/state update fails.
	 */
	int		update_journal_index;
	size_t	journal_index_stride_rows;
	int		journal_index_best_effort;
}	t_csv_journal_options;

typedef struct s_csv_journal_report
{
	t_csv_journal_status	status;
	char				delimiter;
	char				journal_path[512];
	int				index_updated;
	t_csv_index_report		index_report;
	char				error[256];
}	t_csv_journal_report;

typedef struct s_csv_journal_load_report
{
	t_csv_load_report	base;
	t_csv_load_report	journal;
	int				journal_present;
}	t_csv_journal_load_report;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_journal_options_default — Fournit la valeur ou configuration
**       par défaut de CSV journal options.
** Paramètre: options — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : options.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_journal_options_default().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_journal_options_default(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		csv_journal_options_default(t_csv_journal_options *opt);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_journal_append_data_row — Ajoute journal data ligne vers la
**       destination prévue en respectant le format persistant, les capacités
**       de buffer et la propagation des erreurs.
** Paramètre: base_csv — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_journal_append_data_row().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_journal_append_data_row(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_journal_append_data_row(const char *base_csv,
				const t_csv_data_row *row,
				const t_csv_journal_options *opt,
					t_csv_journal_report *out_report);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_journal_load — Charge l’état associé à CSV journal.
** Paramètre: base_csv — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_journal_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_journal_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_csv_data	*csv_journal_load(const char *base_csv,
				const t_csv_load_options *opt,
				t_csv_journal_load_report *out_report);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_journal_load_since — Charge journal since depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: base_csv — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_journal_load_since().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_journal_load_since(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_csv_data	*csv_journal_load_since(const char *base_csv,
				long long min_timestamp,
				const t_csv_load_options *opt,
				t_csv_journal_load_report *out_report);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_journal_load_since_indexed — Charge journal since indexed depuis
**       la source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: base_csv — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_journal_load_since_indexed().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_journal_load_since_indexed(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_csv_data	*csv_journal_load_since_indexed(const char *base_csv,
				long long min_timestamp,
				const t_csv_load_options *opt,
				t_csv_journal_load_report *out_report);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_journal_load_default — Charge journal par défaut depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: base_csv — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_journal_load_default().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_journal_load_default(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_csv_data	*csv_journal_load_default(const char *base_csv);

/* ------------------- Journal rotation / compaction ------------------------ */

typedef enum e_csv_journal_rotate_status
{
	CSV_JOURNAL_ROTATE_OK = 0,
	CSV_JOURNAL_ROTATE_NOOP,
	CSV_JOURNAL_ROTATE_LOCKED,
	CSV_JOURNAL_ROTATE_OPEN_FAILED,
	CSV_JOURNAL_ROTATE_IO_ERROR,
	CSV_JOURNAL_ROTATE_OOM
} 	t_csv_journal_rotate_status;

typedef enum e_csv_journal_rotate_reason
{
	CSV_JOURNAL_ROTATE_NONE = 0,
	CSV_JOURNAL_ROTATE_BY_BYTES,
	CSV_JOURNAL_ROTATE_BY_ROWS,
	CSV_JOURNAL_ROTATE_FORCE
} 	t_csv_journal_rotate_reason;

typedef struct s_csv_journal_rotate_options
{
	size_t	max_journal_bytes;	/* 0 => disable byte trigger */
	size_t	max_journal_rows;	/* 0 => disable row trigger (approx count) */
	int		archive_old_journal; /* Archive previous journal. */
	int		rebuild_index; /* Rebuild index after rotation. */
	size_t	index_stride_rows; /* Index checkpoint stride. */
} 	t_csv_journal_rotate_options;

typedef struct s_csv_journal_rotate_report
{
	t_csv_journal_rotate_status	status;
	int					rotated;
	t_csv_journal_rotate_reason	reason;
	long					journal_size;
	size_t				approx_journal_rows;
	char					journal_path[512];
	char					archive_path[512];
	t_csv_write_report			snapshot_write;
	int				index_rebuilt;
	t_csv_index_report			index_report;
	char					error[256];
} 	t_csv_journal_rotate_report;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_journal_rotate_options_default — Fournit la valeur ou
**       configuration par défaut de CSV journal rotate options.
** Paramètre: options — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : options.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_journal_rotate_options_default().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_journal_rotate_options_default(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	csv_journal_rotate_options_default(t_csv_journal_rotate_options *opt);

typedef struct s_csv_journal_rotation_request
{
	const char					*base_csv;
	const t_csv_journal_rotate_options	*rotate_options;
	const t_csv_load_options			*load_options;
	const t_csv_write_options			*snapshot_write_options;
	const t_csv_journal_options			*journal_options;
} 	t_csv_journal_rotation_request;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_journal_rotate_if_needed — Effectue la rotation de journal if
**       needed en appliquant la gestion
**       d’erreur et les transitions d’état
**       nécessaires pour rester
**       réutilisable.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_journal_rotate_if_needed().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_journal_rotate_if_needed(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_journal_rotate_if_needed(
			const t_csv_journal_rotation_request *request,
			t_csv_journal_rotate_report *out_report);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_journal_compact — Met à jour journal compact en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_journal_compact().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_journal_compact(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_journal_compact(
			const t_csv_journal_rotation_request *request,
			t_csv_journal_rotate_report *out_report);

/* Legacy APIs */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_data_save_default — Enregistre data par défaut vers la
**       destination prévue en respectant le format persistant, les capacités
**       de buffer et la propagation des erreurs.
** Paramètre: filename — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: data — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : data.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_data_save_default().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_data_save_default(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int				csv_data_save_default(const char *filename, t_csv_data *data);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_data_load_default — Charge data par défaut depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: filename — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_data_load_default().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_data_load_default(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_csv_data		*csv_data_load_default(const char *filename);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_data_free — Libère l’état associé à CSV données.
** Paramètre: data — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : data.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_data_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_data_free(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void				csv_data_free(t_csv_data *data);

#endif
