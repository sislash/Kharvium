/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   csv_persistence.h                            +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CSV_PERSISTENCE_H
# define CSV_PERSISTENCE_H

/*
 * Crash-safe CSV persistence helpers.
 * - clear_*: write a fresh header to a tmp file then replace the destination.
 * - rewrite_*: normalize a CSV by parsing rows then rewriting them in V2.
 */

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_persistence_clear_hunt_atomic — Réinitialise persistence atomic
**       en appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_persistence_clear_hunt_atomic().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_persistence_clear_hunt_atomic(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	csv_persistence_clear_hunt_atomic(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_persistence_clear_global_events_atomic — Réinitialise persistence
**       atomic en appliquant les validations et transformations propres à
**       cette opération, puis laisse les données concernées dans un état
**       cohérent.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_persistence_clear_global_events_atomic().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_persistence_clear_global_events_atomic(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	csv_persistence_clear_global_events_atomic(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_persistence_rewrite_hunt_atomic — Met à jour persistence rewrite
**       atomic en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: src_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: dst_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_persistence_rewrite_hunt_atomic().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_persistence_rewrite_hunt_atomic(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	csv_persistence_rewrite_hunt_atomic(const char *src_path,
	const char *dst_path);

#endif
