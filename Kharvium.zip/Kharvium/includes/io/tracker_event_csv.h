/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tracker_event_csv.h                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TRACKER_EVENT_CSV_H
# define TRACKER_EVENT_CSV_H

# include <stddef.h>
# include <stdio.h>
# include "core/tracker_event.h"

# define TRACKER_EVENT_CSV_COLUMNS 12
# define TRACKER_EVENT_CSV_FILE "tracker_events.csv"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_event_csv_ensure_header — Garantit l'en-tête V4 sur un
**       journal générique vide puis replace le flux en fin de fichier.
** Paramètre: file — flux ouvert en lecture/écriture par l'appelant.
** Retour: 1 si le flux est utilisable, 0 si une opération fichier échoue.
** Effets: peut écrire l'en-tête persistant dans le flux.
** Invariants: un fichier non vide n'est jamais réécrit par cette fonction.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_event_csv_ensure_header().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_event_csv_ensure_header().
** --- Fin des liens API auto-vérifiés ---
*/
int	tracker_event_csv_ensure_header(FILE *file);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_event_csv_write — Écrit un événement normalisé V4 en CSV
**       avec les mêmes unités fixed-point que le Tracker historique.
** Paramètre: file — flux de destination déjà ouvert.
** Paramètre: record — événement validé consulté en lecture seule.
** Retour: 1 si la ligne est écrite sans erreur, 0 sinon.
** Effets: écrit exactement une ligne dans le flux.
** Invariants: event_id et session_id doivent être strictement positifs;
**             parent_event_id peut être zéro lorsque l'événement est racine.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_event_csv_write().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_event_csv_write().
** --- Fin des liens API auto-vérifiés ---
*/
int	tracker_event_csv_write(FILE *file, const t_tracker_event_record *record);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_event_csv_parse_line — Analyse une ligne V4 en place et
**       retourne une vue dont les chaînes pointent dans le buffer fourni.
** Paramètre: line — buffer CSV modifiable conservé vivant par l'appelant.
** Paramètre: record — destination renseignée seulement si la ligne est valide.
** Retour: 1 pour une ligne V4 valide, 0 sinon.
** Effets: modifie le buffer line lors du découpage CSV.
** Invariants: aucune allocation; les champs numériques sont validés sans
**             conversion flottante.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_event_csv_parse_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_event_csv_parse_line().
** --- Fin des liens API auto-vérifiés ---
*/
int	tracker_event_csv_parse_line(char *line, t_tracker_event_record *record);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_event_csv_tail_ids — Recherche les plus grands event_id et
**       session_id valides déjà persistés afin de reprendre les séquences.
** Paramètre: path — chemin du journal Tracker V4.
** Paramètre: event_id — destination du maximum event_id, zéro si absent.
** Paramètre: session_id — destination du maximum session_id, zéro si absent.
** Retour: 1 si le fichier absent/valide a été traité, 0 sur erreur de lecture.
** Effets: lit le fichier sans le modifier.
** Invariants: les lignes invalides sont ignorées, jamais utilisées pour
**             avancer une séquence persistante.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_event_csv_tail_ids().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_event_csv_tail_ids().
** --- Fin des liens API auto-vérifiés ---
*/
int	tracker_event_csv_tail_ids(const char *path, int64_t *event_id,
		int64_t *session_id);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_event_csv_sibling_path — Construit le chemin du journal V4
**       à côté du hunt_log.csv fourni, sans dépendre du séparateur OS.
** Paramètre: hunt_path — chemin historique servant uniquement de répertoire.
** Paramètre: output — buffer de destination.
** Paramètre: capacity — taille totale disponible dans output.
** Retour: 1 si le chemin complet tient dans le buffer, 0 sinon.
** Effets: écrit uniquement output.
** Invariants: aucun chemin n'est tronqué silencieusement.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_event_csv_sibling_path().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_event_csv_sibling_path().
** --- Fin des liens API auto-vérifiés ---
*/
int	tracker_event_csv_sibling_path(const char *hunt_path, char *output,
		size_t capacity);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_event_csv_migrate_v3 — Convertit un journal Hunt V3 vers le
**       journal événementiel V4 sans modifier la source historique.
** Paramètre: hunt_path — fichier V3 source.
** Paramètre: event_path — nouveau fichier V4 de destination.
** Retour: 1 si la migration ou l'absence de données réussit, 0 sinon.
** Effets: crée/remplace event_path uniquement après conversion complète.
** Invariants: kill_id reste envelope_id legacy; les relations parent sont
**             reconstruites seulement lorsqu'un lien V3 explicite existe.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_event_csv_migrate_v3().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_event_csv_migrate_v3().
** --- Fin des liens API auto-vérifiés ---
*/
int	tracker_event_csv_migrate_v3(const char *hunt_path,
		const char *event_path);

#endif
