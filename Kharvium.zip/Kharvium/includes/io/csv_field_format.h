/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   csv_field_format.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 15:42:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 15:42:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CSV_FIELD_FORMAT_H
# define CSV_FIELD_FORMAT_H

# include <stddef.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_format_double_value — Calcule format double valeur à partir des
**       entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Paramètre: value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_format_double_value().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_format_double_value(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	csv_format_double_value(char *dst, size_t cap, double value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_field_requires_quotes — Met à jour champ requires quotes en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: separator — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_field_requires_quotes().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_field_requires_quotes(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_field_requires_quotes(const char *text, char separator);

#endif
