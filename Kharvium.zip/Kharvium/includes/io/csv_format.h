/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   csv_format.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/31                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CSV_FORMAT_H
# define CSV_FORMAT_H

# include <stdio.h>

/*
 * CSV policy (portable Windows/Linux):
 * - UTF-8 bytes (no transcoding)
 * - RFC4180-ish quoting: fields containing separator/quotes/CR/LF are quoted,
 *   quotes are escaped as "".
 */
# define CSV_SEP ','

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_split_fields — Met à jour split champs en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : line, output.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_split_fields().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_split_fields(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_split_fields(char *line, char **out, int n);
/* Strict: returns 1 only if the line has exactly n columns */
/* (no more, no less). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_split_exact_fields — Met à jour split exact champs en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : line, output.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_split_exact_fields().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_split_exact_fields(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_split_exact_fields(char *line, char **out, int n);

/* Variants with explicit separator (e.g. ';' for Excel locales). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_split_fields_with_separator — Met à jour split champs with
**       separator en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Paramètre: separator — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : line, output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_split_fields_with_separator().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_split_fields_with_separator(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_split_fields_with_separator(char *line, char **out, int n,
	char sep);
/* Strict: exactly n columns for the given separator. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_split_exact_fields_with_separator — Met à jour split exact champs
**       with separator en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Paramètre: separator — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : line, output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_split_exact_fields_with_separator().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_split_exact_fields_with_separator(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_split_exact_fields_with_separator(char *line, char **out, int n,
	char sep);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_write_field — Écrit champ vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : f.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_write_field().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_write_field(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	csv_write_field(FILE *f, const char *s);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_write_field_with_separator — Écrit champ with separator vers la
**       destination prévue en respectant le format persistant, les capacités
**       de buffer et la propagation des erreurs.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: separator — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_write_field_with_separator().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_write_field_with_separator(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	csv_write_field_with_separator(FILE *f, const char *s, char sep);
/* Generic row writer (n fields). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_write_row — Écrit ligne vers la destination prévue en respectant
**       le format persistant, les capacités de buffer et la propagation des
**       erreurs.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: fields — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : f.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_write_row().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_write_row(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	csv_write_row(FILE *f, const char **fields, int n);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_write_row_with_separator — Écrit ligne with separator vers la
**       destination prévue en respectant le format persistant, les capacités
**       de buffer et la propagation des erreurs.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: fields — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: separator — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_write_row_with_separator().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_write_row_with_separator(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	csv_write_row_with_separator(FILE *f, const char **fields, int n,
	char sep);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_ensure_six_field_header — Construit ou rend l’en-tête utilisé
**       par CSV ensure six champ.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : f.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_ensure_six_field_header().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_ensure_six_field_header(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	csv_ensure_six_field_header(FILE *f);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_ensure_six_field_header_with_separator — Localise ou traite le
**       séparateur utilisé par CSV ensure six champ header with.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: separator — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_ensure_six_field_header_with_separator().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_ensure_six_field_header_with_separator(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	csv_ensure_six_field_header_with_separator(FILE *f, char sep);

#endif
