/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   csv_index.h                                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef CSV_INDEX_H
# define CSV_INDEX_H

# include <stddef.h>
# include <stdint.h>

/*
 * Lightweight sparse index to accelerate "load since timestamp".
 *
 * Index file path: <csv_path>.idx
 *
 * File format (text, UTF-8):
 *   #csv_index_v1 stride=<N>
 *   row_index,timestamp,byte_offset
 */

typedef enum e_csv_index_status
{
	CSV_INDEX_OK = 0,
	CSV_INDEX_OPEN_FAILED,
	CSV_INDEX_IO_ERROR,
	CSV_INDEX_BAD_FORMAT,
	CSV_INDEX_OOM
} 	t_csv_index_status;

typedef struct s_csv_index_options
{
	size_t	stride_rows; /* e.g. 1024 */
} 	t_csv_index_options;

typedef struct s_csv_index_report
{
	t_csv_index_status	status;
	size_t			stride_rows;
	size_t			entries;
	char			index_path[512];
	char			error[256];
} 	t_csv_index_report;

/* Persistent state to support incremental (append-time) sparse indexing.
 * State file path: <csv_path>.idxstate
 */
typedef struct s_csv_index_state
{
	unsigned long long	data_rows; /* number of data rows (header excluded) */
	unsigned long long	bytes;     /* last known file size in bytes */
	long long			last_ts; /* Last appended timestamp. */
} 	t_csv_index_state;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_index_options_default — Fournit la valeur ou configuration par
**       défaut de CSV index options.
** Paramètre: options — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : options.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_index_options_default().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_index_options_default(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	csv_index_options_default(t_csv_index_options *opt);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_index_build — Construit l’état associé à CSV index.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: options — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out_report — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out_report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_index_build().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_index_build(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_index_build(const char *csv_path,
						const t_csv_index_options *opt,
						t_csv_index_report *out_report);

/* Incremental helpers (best-effort, safe under external locking). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_index_state_load — Charge l’état associé à CSV index état.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: out_state — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_report — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out_state,
**         out_report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_index_state_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_index_state_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_index_state_load(const char *csv_path,
						t_csv_index_state *out_state,
						t_csv_index_report *out_report);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_index_state_store — Enregistre en mémoire les données de CSV
**       index état.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: state — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out_report — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : out_report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_index_state_store().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_index_state_store(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_index_state_store(const char *csv_path,
						const t_csv_index_state *state,
						t_csv_index_report *out_report);

/* Rebuilds state by scanning the CSV (used when state is missing/corrupt). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_index_state_rebuild — Reconstruit les données dérivées de CSV
**       index état.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: out_state — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_report — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants :
**         out_state, out_report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_index_state_rebuild().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_index_state_rebuild(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_index_state_rebuild(const char *csv_path,
						t_csv_index_state *out_state,
						t_csv_index_report *out_report);

typedef struct s_csv_index_checkpoint_request
{
	const char			*csv_path;
	size_t				stride_rows;
	unsigned long long	row_index;
	long long			timestamp;
	unsigned long long	byte_offset;
}t_csv_index_checkpoint_request;

typedef struct s_csv_index_timestamp_query
{
	const char	*csv_path;
	long long	timestamp;
}t_csv_index_timestamp_query;

typedef struct s_csv_index_row_query
{
	const char			*csv_path;
	unsigned long long	row_index;
}t_csv_index_row_query;

typedef struct s_csv_index_checkpoint
{
	unsigned long long	byte_offset;
	unsigned long long	row_index;
	long long			timestamp;
}t_csv_index_checkpoint;

/* Appends a checkpoint when row_index falls on the configured stride. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_index_append_checkpoint_if_needed — Ajoute index checkpoint if
**       needed vers la destination prévue en respectant le format
**       persistant, les capacités de buffer et la propagation des erreurs.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: out_report — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out_report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_index_append_checkpoint_if_needed().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_index_append_checkpoint_if_needed(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_index_append_checkpoint_if_needed(
						const t_csv_index_checkpoint_request *request,
						t_csv_index_report *out_report);

/* Finds the best checkpoint whose timestamp is <= the target timestamp. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_index_lookup_timestamp_offset — Calcule index lookup timestamp
**       offset à partir de la géométrie et de l’état courants sans dépasser
**       les limites disponibles.
** Paramètre: query — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out_checkpoint — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: out_report — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out_checkpoint,
**         out_report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_index_lookup_timestamp_offset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_index_lookup_timestamp_offset(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_index_lookup_timestamp_offset(
						const t_csv_index_timestamp_query *query,
						t_csv_index_checkpoint *out_checkpoint,
						t_csv_index_report *out_report);

/* Finds the best checkpoint whose row_index is <= the target row_index. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_index_lookup_row_offset — Calcule index lookup ligne offset à
**       partir de la géométrie et de l’état courants sans dépasser les
**       limites disponibles.
** Paramètre: query — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out_checkpoint — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: out_report — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out_checkpoint,
**         out_report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_index_lookup_row_offset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_index_lookup_row_offset(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_index_lookup_row_offset(const t_csv_index_row_query *query,
						t_csv_index_checkpoint *out_checkpoint,
						t_csv_index_report *out_report);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: csv_index_remove — Supprime l’état associé à CSV index.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: csv_index_remove().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                csv_index_remove(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		csv_index_remove(const char *csv_path);

#endif
