/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_csv.h                                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/12                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_CSV_H
# define HUNT_CSV_H

/*
** Hunt CSV (V2 strict) = "coeur de verite" pour la chasse.
**
** Format (8 colonnes):
**   timestamp_unix,event_type,target_or_item,quantite,valeur_uPED,
**   id_kill,drapeaux,brut
**
** - timestamp_unix : int64 seconds (local time converted via mktime)
** - valeur_uPED     : int64 fixed point (see common/money.h) 1 PED =
	100000 uPED
** - id_kill        : int64 (incremental id for each KILL)
** - drapeaux          : uint32 bitfield
**     bit0: a_valeur
**     bit1: has_kill_id
*/

# include <stdint.h>
# include <stddef.h>
# include <stdio.h>

# include "tracker_types.h"
# include "common/money.h"

typedef struct s_hunt_csv_row_view
{
	t_unix_time	timestamp_unix;      /* epoch seconds */
	const char	*type_evenement;
	const char	*cible;
	long		quantite;
	t_uped		valeur_uPED;
	int			a_valeur;
	int64_t		id_kill;
	uint32_t	drapeaux;
	const char	*brut;
}   t_hunt_csv_row_view;

/* -------------------------------------------------------------------------- */
/* Loot envelope details used by the hover panel. */

# define HUNT_CSV_LOOT_ENVELOPE_MAX_ITEMS 64
# define HUNT_CSV_LOOT_GROUPE_MAX_LIGNES HUNT_CSV_LOOT_ENVELOPE_MAX_ITEMS

typedef struct s_hunt_csv_loot_line
{
	char		cible[128];
	long		quantite;
	t_uped		valeur_uPED;
	int			has_value;
}   t_hunt_csv_loot_line;

typedef struct s_hunt_csv_loot_envelope
{
	t_unix_time	timestamp_unix;
	int64_t		kill_id;
	char			creature[128];
	int			item_count;
	int			stored_item_count;
	int			items_without_value;
	t_uped			total_uPED;
	int			truncated;
}   t_hunt_csv_loot_envelope;

typedef struct s_hunt_csv_loot_query
{
	const char			*csv_path;
	t_unix_time		timestamp_unix;
	int64_t			kill_id;
	t_hunt_csv_loot_line	*lines;
	int				line_capacity;
}   t_hunt_csv_loot_query;

/*
 * One mob kill maps to one loot envelope. The envelope can contain one or
 * many LOOT_ITEM rows. kill_id is the authoritative envelope key whenever
 * available. Valid game logs contain at most one mob kill per timestamp
 * second, which keeps timestamp grouping safe as a legacy fallback.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_collect_loot_envelope — Met à jour collect loot enveloppe en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: query — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out_envelope — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants :
**         out_envelope.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_collect_loot_envelope().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_collect_loot_envelope(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_csv_collect_loot_envelope(const t_hunt_csv_loot_query *query,
			t_hunt_csv_loot_envelope *out_envelope);

/* Ensure current header if file is empty. Keeps file position at end. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_ensure_header_v3 — Garantit en-tête v3 en appliquant les
**       validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_ensure_header_v3().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_ensure_header_v3(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_csv_ensure_header_v3(FILE *f);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_ensure_header_v2 — Garantit en-tête v2 en appliquant les
**       validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : f.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_ensure_header_v2().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_ensure_header_v2(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_csv_ensure_header_v2(FILE *f);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_migrate_money_scale — Migre scale en appliquant les
**       validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_migrate_money_scale().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_migrate_money_scale(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_csv_migrate_money_scale(const char *path);

/*
 * Crash-safety: if the CSV ended with a partial line (no trailing '\n'),
 * truncate it back to the last complete row.
 * Returns 1 on success (or nothing to do), 0 on error.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_repair_trailing_partial_line — Construit ou traite une
**       ligne appartenant à chasse CSV repair trailing partial.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_repair_trailing_partial_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_repair_trailing_partial_line(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_csv_repair_trailing_partial_line(FILE *f);

/*
 * Crash-safety (extra): if the CSV ends with one or more malformed rows
 * (even if they have a trailing '\n'), truncate them back to the last
 * valid row (or header).
 *
 * max_lines_back: how many tail rows to validate (typ: 8).
 * Returns 1 on success (or nothing to do), 0 on error.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_repair_trailing_invalid_rows — Construit les lignes de
**       données destinées à chasse CSV repair trailing invalid.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: max_lines_back — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_repair_trailing_invalid_rows().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_repair_trailing_invalid_rows(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_csv_repair_trailing_invalid_rows(FILE *f, int max_lines_back);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_line_is_header — Détermine si ligne en-tête respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_line_is_header().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_line_is_header(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_csv_line_is_header(const char *line);

/* Parse one CSV line (in-place). Returns 1 on success, 0 otherwise. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_parse_row_inplace — Analyse ligne inplace depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : line, out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_parse_row_inplace().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_parse_row_inplace(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_csv_parse_row_inplace(char *line,
			t_hunt_csv_row_view *out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_row_has_value — Détermine si ligne valeur respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_row_has_value().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_row_has_value(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_csv_row_has_value(const t_hunt_csv_row_view *row);

/* Timestamp conversions */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_timestamp_text_to_unix — Convertit vers timestamp texte
**       unix en appliquant les
**       validations, bornes et effets
**       explicitement définis par ce
**       module.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: out_unix — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out_unix.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_timestamp_text_to_unix().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_timestamp_text_to_unix(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int         hunt_csv_timestamp_text_to_unix(const char *ts_text,
	int64_t *out_unix);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_format_local_timestamp — Formate local timestamp dans le
**       buffer ou la représentation demandée sans dépasser la capacité
**       fournie par l’appelant.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_format_local_timestamp().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_format_local_timestamp(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_csv_format_local_timestamp(char *dst, size_t cap,
			int64_t timestamp_unix);

/* Best-effort scan of last chunk to resume id_kill. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_tail_maximum_kill_id — Met à jour fin du fichier maximum
**       kill id en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_tail_maximum_kill_id().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_tail_maximum_kill_id(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int64_t     hunt_csv_tail_maximum_kill_id(const char *path);

/* Write one V2 row. Returns 0 on success, -1 on error. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_csv_write_v2 — Écrit v2 vers la destination prévue en respectant
**       le format persistant, les capacités de buffer et la propagation des
**       erreurs.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_csv_write_v2().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_csv_write_v2(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_csv_write_v2(FILE *f, const t_hunt_csv_row_view *row);

#endif
