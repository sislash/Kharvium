/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series.h                                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef HUNT_SERIES_H
# define HUNT_SERIES_H

# include <time.h>
# include <stdint.h>
# include "common/money.h"
# include "core/core_session.h"

/*
 * Hunt time-series helper used by the LIVE graph screen.
 *
 * - We bucket events by fixed time slices (default: 60s) and keep a sliding
 *   window so the graph stays fast even on long sessions.
 * - For some UI views (ex: kills), we also keep a lightweight list of events
 *   to display one point per event.
 */

/*
 * Capacity targets (RCE-safe):
 * - Buckets: 60s buckets for ~11.4 days @ 16384
 * - Events: 262k loot envelopes / kills / shots (intensive hunts)
 */
# ifndef HS_MAX_POINTS
#  define HS_MAX_POINTS 16384
# endif
# ifndef HS_MAX_EVENTS
#  define HS_MAX_EVENTS 262144
# endif
/* When HS_MAX_EVENTS is reached, evict by chunk to avoid O(n). */
# ifndef HS_EVICT_CHUNK
#  define HS_EVICT_CHUNK 4096
# endif

typedef enum e_hs_metric
{
	HS_METRIC_SHOTS = 0,
	HS_METRIC_HITS,
	HS_METRIC_KILLS,
	HS_METRIC_LOOT_PED
} 	t_hs_metric;

typedef struct s_hs_bucket
{
	int		shots;
	int		hits;
	int		kills;
	t_money	loot_uPED;
	/* Logged expenses (AMMO/DECAY/REPAIR/SPEND...) if present in CSV. */
	t_money	expense_uPED;
} 	t_hs_bucket;

typedef struct s_hunt_series
{
	int		initialized;
	long		start_offset;
	int		bucket_sec;
	long		file_pos;

	time_t		t0;
	time_t		last_t;

	/* Core truth (totals + current combat segment). */
	t_core_session	core;

	long		first_bucket; /* absolute bucket index */
	int		count;        /* number of buckets stored */
	t_hs_bucket	buckets[HS_MAX_POINTS];

	/* Event list relative to t0, used for one point per kill. */
	int		kill_ev_count;
	int		kill_ev_sec[HS_MAX_EVENTS];

	/* Hits per kill (1 point per kill). */
	int		hits_ev_count;
	int		hits_ev_sec[HS_MAX_EVENTS];
	int		hits_ev_hits[HS_MAX_EVENTS];

	/* Shots per kill (1 point per kill). */
	/* Stores both shots and hits for hit-rate. */
	int		shots_ev_count;
	int		shots_ev_sec[HS_MAX_EVENTS];
	int		shots_ev_shots[HS_MAX_EVENTS];
	int		shots_ev_hits[HS_MAX_EVENTS];
	/* segment counters are stored in core.combat_seg */

	/* Loot envelopes (1 point per killed mob / envelope) */
	int		loot_ev_count;
	int		loot_ev_sec[HS_MAX_EVENTS];
	t_money	loot_ev_uPED[HS_MAX_EVENTS];
	/* How many CSV rows were aggregated into this loot envelope */
	/* (for UI marker N). */
	int		loot_ev_group_count[HS_MAX_EVENTS];
	/* kill_id associated with this loot envelope (0 if unknown/missing). */
	int64_t		loot_ev_kill_id[HS_MAX_EVENTS];
	unsigned char	loot_ev_has_kill[HS_MAX_EVENTS];
	time_t		last_loot_ev_t;
	int64_t		last_loot_ev_kill_id;

	/* Incremented when new rows are successfully integrated (UI caches). */
	uint32_t	version;
} 	t_hunt_series;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_reset — Réinitialise l’état associé à chasse série.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: start_offset — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: bucket_sec — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_reset(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_series_reset(t_hunt_series *s, long start_offset, int bucket_sec);

/*
 * Incrementally updates the series by reading newly appended CSV rows.
 * Returns 1 on success (even if no new data), 0 on error.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_update — Met à jour l’état associé à chasse série.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_update().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_update(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_series_update(t_hunt_series *s, const char *csv_path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_elapsed_seconds — Met à jour elapsed seconds en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_elapsed_seconds().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_elapsed_seconds(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	hunt_series_elapsed_seconds(const t_hunt_series *series);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_sanity_check — Vérifie les invariants internes d’une
**       série Hunt : bornes des compteurs, cohérence des événements et
**       validité des relations utilisées par les statistiques.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_sanity_check().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_sanity_check(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_series_sanity_check(const t_hunt_series *series);

typedef enum e_hunt_series_event_metric
{
	HUNT_SERIES_EVENT_KILLS = 0,
	HUNT_SERIES_EVENT_HITS,
	HUNT_SERIES_EVENT_SHOTS,
	HUNT_SERIES_EVENT_HIT_RATE
} 	t_hunt_series_event_metric;

typedef struct s_hunt_series_output
{
	double			*values;
	int			*x_seconds;
	int			*group_counts;
	int64_t			*kill_ids;
	unsigned char		*has_kill;
	int			count;
	double			maximum;
} 	t_hunt_series_output;

typedef enum e_hunt_series_bucket_mode
{
	HUNT_SERIES_BUCKET_METRIC = 0,
	HUNT_SERIES_BUCKET_COST,
	HUNT_SERIES_BUCKET_ROI
} 	t_hunt_series_bucket_mode;

typedef struct s_hunt_series_bucket_request
{
	const t_hunt_series		*series;
	t_hunt_series_bucket_mode	mode;
	int				last_n_buckets;
	t_hs_metric			metric;
	int				cumulative;
	t_money				cost_shot_uped;
} 	t_hunt_series_bucket_request;

typedef struct s_hunt_series_event_request
{
	const t_hunt_series		*series;
	int				last_minutes;
	t_hunt_series_event_metric	metric;
} 	t_hunt_series_event_request;

typedef struct s_hunt_series_loot_request
{
	const t_hunt_series	*series;
	int			last_minutes;
	int			cumulative;
} 	t_hunt_series_loot_request;

typedef struct s_hunt_series_range_request
{
	const char	*csv_path;
	long		start_line;
	long		end_line;
	int		bucket_sec;
} 	t_hunt_series_range_request;

typedef struct s_hunt_series_segment
{
	long	shots;
	long	hits;
	double	hit_rate_pct;
	int	relative_sec;
} 	t_hunt_series_segment;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_build_bucket — Construit bucket à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_build_bucket().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_build_bucket(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_series_build_bucket(
			const t_hunt_series_bucket_request *request,
			t_hunt_series_output *output);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_build_event — Construit événement à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_build_event().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_build_event(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_series_build_event(
			const t_hunt_series_event_request *request,
			t_hunt_series_output *output);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_build_loot — Construit loot à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_build_loot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_build_loot(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_series_build_loot(
			const t_hunt_series_loot_request *request,
			t_hunt_series_output *output);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_get_segment_current — Retourne segment courant en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: segment — série Tracker reconstruite à partir des événements
**            de chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : segment.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_get_segment_current().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_get_segment_current(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_series_get_segment_current(const t_hunt_series *series,
			t_hunt_series_segment *segment);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_get_last_kill_segment — Retourne last kill segment en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: segment — série Tracker reconstruite à partir des événements
**            de chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : segment.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_get_last_kill_segment().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_get_last_kill_segment(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_series_get_last_kill_segment(const t_hunt_series *series,
			t_hunt_series_segment *segment);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_rebuild_range — Calcule ou applique la plage utilisée
**       par chasse série rebuild.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_rebuild_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_rebuild_range(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_series_rebuild_range(t_hunt_series *series,
			const t_hunt_series_range_request *request);

#endif
