/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_live.h                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/09                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_SERIES_LIVE_H
# define HUNT_SERIES_LIVE_H

# include "hunt/hunt_series.h"

/*
 * Live series cache shared by multiple screens.
 *
 * Goal:
 *  - ne pas "re-initialiser" le graph LIVE quand on sort/re-rentre
 *  - permettre de continuer a alimenter la serie meme hors de l'ecran graphe
 *
 * Contrainte:
 *  - l'update doit etre appele depuis le thread UI (pas thread-safe).
 */

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_live_force_reset — Réinitialise l’état associé à chasse
**       série LIVE force.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_live_force_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_live_force_reset(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void					hunt_series_live_force_reset(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_live_tick — Exécute un cycle l’état associé à chasse
**       série LIVE.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_live_tick().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_live_tick(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void					hunt_series_live_tick(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_live_get — Retourne l’état associé à chasse série LIVE.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_live_get().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_live_get(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const t_hunt_series	*hunt_series_live_get(void);

/* View mode helpers (useful for UI labels). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_live_is_range — Détermine si LIVE plage respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_live_is_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_live_is_range(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int								hunt_series_live_is_range(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_live_get_range — Calcule LIVE get plage à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: out_start — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_end_raw — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_end_resolved — destination renseignée avec le résultat,
**            dans la capacité fournie par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out_start,
**         out_end_raw, out_end_resolved.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_live_get_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_live_get_range(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void						hunt_series_live_get_range(long *out_start,
									long *out_end_raw,
									long *out_end_resolved);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_live_get_offset — Calcule LIVE get offset à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_live_get_offset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_live_get_offset(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
long							hunt_series_live_get_offset(void);

/* Regression guards / debug helpers (optional for UI). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_live_has_warning — Détermine si LIVE warning respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_live_has_warning().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_live_has_warning(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int							hunt_series_live_has_warning(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_live_warning_text — Construit ou transforme le texte
**       utilisé par chasse série LIVE warning.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_live_warning_text().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_live_warning_text(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char						*hunt_series_live_warning_text(void);

/*
 * Recharge V2 au demarrage:
 * - Reconstruit le cache a partir du Hunt CSV V2 existant.
 * - Respecte l'offset de session (logs/session_offset.txt) si present.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_live_bootstrap — Met à jour LIVE bootstrap en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_live_bootstrap().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_live_bootstrap(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void					hunt_series_live_bootstrap(void);

#endif
