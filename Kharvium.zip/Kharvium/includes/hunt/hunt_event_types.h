/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_event_types.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 15:05:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 15:05:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_EVENT_TYPES_H
# define HUNT_EVENT_TYPES_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_event_type_is_loot — Détermine si événement type loot respecte
**       la condition attendue, sans modifier les données consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_event_type_is_loot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_event_type_is_loot(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_event_type_is_loot(const char *type);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_event_type_is_envelope_item — Détermine si événement type
**       enveloppe objet respecte la condition attendue, sans modifier les
**       données consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_event_type_is_envelope_item().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_event_type_is_envelope_item(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_event_type_is_envelope_item(const char *type);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_event_type_is_sweat — Détermine si événement type sweat respecte
**       la condition attendue, sans modifier les données consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_event_type_is_sweat().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_event_type_is_sweat(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_event_type_is_sweat(const char *type);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_event_type_is_loot_or_sweat — Détermine si événement type loot
**       or sweat respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_event_type_is_loot_or_sweat().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_event_type_is_loot_or_sweat(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_event_type_is_loot_or_sweat(const char *type);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_event_type_is_expense — Détermine si événement type expense
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_event_type_is_expense().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_event_type_is_expense(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_event_type_is_expense(const char *type);

#endif
