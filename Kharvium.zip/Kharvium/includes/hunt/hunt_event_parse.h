/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_event_parse.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_EVENT_PARSE_H
# define HUNT_EVENT_PARSE_H

# include "hunt/hunt_rules.h"

# define TRACKER_CHAT_LINE_CAP 2048

void	hunt_event_initialize_from_chat_line(const char *line_in,
		t_hunt_event *event, char *line, char *timestamp);
int		parse_received_line(const char *line, const char *timestamp,
		t_hunt_event *event);

#endif
