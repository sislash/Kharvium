/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_rules.h                                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef HUNT_RULES_H
# define HUNT_RULES_H

# include <stddef.h>
# include <time.h>

/*
** Hunt rules = toutes les regles de parsing (patterns).
**
** Ici, tu modifies les chaines/patterns, sans toucher au tail/replay.
*/

typedef enum e_tracker_activity_mode
{
	TRACKER_ACTIVITY_HUNT = 0,
	TRACKER_ACTIVITY_FISHING = 1
} 	t_tracker_activity_mode;

typedef struct s_hunt_event
{
	char	ts[32];
	char	type[32];
	char	name[256];
	char	qty[32];
	char	value[64];
	char	raw[1024];
} t_hunt_event;

typedef struct s_hunt_rules
{
	t_tracker_activity_mode	activity_mode;
	int			has_pending;
	t_hunt_event	pending;
	char			player_name[128];
	char			last_kill_ts[32];
	time_t			last_loot_t;
	time_t			last_combat_t;
	time_t			last_explicit_kill_t;
} 	t_hunt_rules;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_rules_initialize — Initialise l’état associé à chasse rules.
** Paramètre: r — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : r.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_rules_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_rules_initialize(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_rules_initialize(t_hunt_rules *r);

/*
** Définit le type d'activité suivi par le parseur Tracker. Le changement
** doit être réalisé lorsque le worker est arrêté afin qu'une session ne
** mélange jamais les règles de chasse et de pêche.
*/
void	hunt_rules_set_activity_mode(t_hunt_rules *r,
		t_tracker_activity_mode mode);

/* Retourne le mode courant; HUNT est la valeur sûre si r est NULL. */
t_tracker_activity_mode	hunt_rules_get_activity_mode(const t_hunt_rules *r);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_rules_set_player_name — Retourne rules set player nom dans la
**       forme directement utilisable par le rendu ou l’appelant.
** Paramètre: r — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : r.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_rules_set_player_name().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_rules_set_player_name(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_rules_set_player_name(t_hunt_rules *r, const char *name);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_should_ignore_line — Détermine si ignore ligne respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_should_ignore_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_should_ignore_line(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_should_ignore_line(const char *line);

/*
** hunt_parse_line():
**  - remplit 'ev' avec le 1er evenement extrait de 'line'
**  - retourne:
**      0 : 1 evenement pret (ev)
**      1 : 1 evenement pret (ev) + un evenement "pending" a recuperer
**     -1 : ligne non reconnue / erreur
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_parse_line — Analyse ligne depuis la source fournie, contrôle le
**       format utile et ne renseigne la destination qu’avec des données
**       validées.
** Paramètre: r — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: line_in — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : r, ev.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_parse_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_parse_line(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_parse_line(t_hunt_rules *r, const char *line, t_hunt_event *ev);

/*
** Permet de recuperer un evenement supplementaire produit par
** hunt_parse_line()
** (ex: LOOT_ITEM + KILL deduplique).
** Retourne 1 si un evenement a ete copie dans 'ev', sinon 0.
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_pending_pop — Retire pending dans la collection concernée en
**       respectant sa capacité, son ordre et ses
**       invariants de propriété.
** Paramètre: r — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : r, ev.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_pending_pop().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_pending_pop(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_pending_pop(t_hunt_rules *r, t_hunt_event *ev);

#endif
