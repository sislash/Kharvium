/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_live_view_state.h                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 15:51:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 15:51:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_LIVE_VIEW_STATE_H
# define HUNT_LIVE_VIEW_STATE_H

typedef struct s_hunt_live_view_state
{
	int		ready;
	int		mode;
	long	offset;
	long	range_start;
	long	range_end;
	long	range_end_raw;
} t_hunt_live_view_state;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_live_view_state_reset — Réinitialise l’état associé à chasse
**       LIVE view état.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : state.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_live_view_state_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_live_view_state_reset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_live_view_state_reset(t_hunt_live_view_state *state);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_live_view_range_normalize — Normalise les données de chasse
**       LIVE view plage vers leur forme canonique.
** Paramètre: start — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: end_raw — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : start, end_raw.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_live_view_range_normalize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_live_view_range_normalize(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_live_view_range_normalize(long *start, long *end_raw);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_live_view_state_is_range — Détermine si LIVE view état plage
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: state — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_live_view_state_is_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_live_view_state_is_range(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_live_view_state_is_range(const t_hunt_live_view_state *state);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_live_view_state_get_range — Calcule LIVE view état get plage à
**       partir de la géométrie et de l’état courants sans dépasser les
**       limites disponibles.
** Paramètre: state — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: start — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: end_raw — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: end_resolved — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : start, end_raw,
**         end_resolved.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_live_view_state_get_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_live_view_state_get_range(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_live_view_state_get_range(const t_hunt_live_view_state *state,
		long *start, long *end_raw, long *end_resolved);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_live_view_state_get_offset — Calcule LIVE view état get offset à
**       partir de la géométrie et de l’état courants sans dépasser les
**       limites disponibles.
** Paramètre: state — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_live_view_state_get_offset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_live_view_state_get_offset(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
long	hunt_live_view_state_get_offset(const t_hunt_live_view_state *state);

#endif
