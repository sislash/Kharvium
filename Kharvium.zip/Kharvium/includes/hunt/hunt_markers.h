/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_markers.h                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_MARKERS_H
# define HUNT_MARKERS_H

# include <stddef.h>

typedef enum e_hunt_marker_kind
{
	HUNT_MARKER_KILL = 1,
	HUNT_MARKER_LOOT = 2
}   t_hunt_marker_kind;

typedef struct s_hunt_marker
{
	int				point_index;
	t_hunt_marker_kind	kind;
	int				group_count;
	double				value;
}   t_hunt_marker;

typedef struct s_hunt_marker_build
{
	const double		*loot_values;
	const int		*group_counts;
	const unsigned char	*has_kill;
	int				count;
	t_hunt_marker		*output;
	int				output_capacity;
	int				*output_count;
}   t_hunt_marker_build;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_markers_build_loot — Construit markers loot à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: build — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_markers_build_loot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_markers_build_loot(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_markers_build_loot(const t_hunt_marker_build *build);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_markers_format_text — Formate markers texte dans le buffer ou la
**       représentation demandée sans dépasser la capacité fournie par
**       l’appelant.
** Paramètre: marker — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: destination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : destination.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_markers_format_text().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_markers_format_text(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_markers_format_text(const t_hunt_marker *marker,
		char *destination, size_t capacity);

#endif
