/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_stats_live.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/12                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_STATS_LIVE_H
# define HUNT_STATS_LIVE_H

# include "analytics/hunt_stats.h"

/*
 * Live incremental stats cache.
 *
 * Goals:
 *  - Avoid rescanning logs/hunt_log.csv every 250ms (overlay + pages).
 *  - Follow current session offset (logs/hunt_session.offset).
 *  - If a session range is loaded (logs/hunt_session.range), compute once.
 *
 * NOTE:
 *  - This cache is updated from the UI thread only.
 */

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_live_force_reset — Réinitialise l’état associé à chasse
**       statistiques LIVE force.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_live_force_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_live_force_reset(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void				hunt_stats_live_force_reset(void);

/* Tick: updates the cache according to current offset/range. */
/* Also accounts for appended CSV lines. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_live_tick — Exécute un cycle l’état associé à chasse
**       statistiques LIVE.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_live_tick().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_live_tick(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void				hunt_stats_live_tick(void);

/* Returns a pointer to the cached stats (or NULL if not ready). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_live_get — Retourne l’état associé à chasse statistiques
**       LIVE.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_live_get().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_live_get(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const t_hunt_stats	*hunt_stats_live_get(void);

/* Range support (Sessions picker). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_live_is_range — Détermine si LIVE plage respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_live_is_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_live_is_range(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int				hunt_stats_live_is_range(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_live_get_range — Calcule LIVE get plage à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: out_start — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_end_raw — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_end_resolved — destination renseignée avec le résultat,
**            dans la capacité fournie par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out_start,
**         out_end_raw, out_end_resolved.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_live_get_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_live_get_range(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void				hunt_stats_live_get_range(long *out_start,
	long *out_end_raw,
									long *out_end_resolved);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_live_get_offset — Calcule LIVE get offset à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_live_get_offset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_live_get_offset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
long				hunt_stats_live_get_offset(void);

/* Bootstrap on startup: run one tick immediately. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_live_bootstrap — Met à jour LIVE bootstrap en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_live_bootstrap().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_live_bootstrap(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void				hunt_stats_live_bootstrap(void);

#endif
