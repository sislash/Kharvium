/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   analytics_stats.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef ANALYTICS_STATS_H
# define ANALYTICS_STATS_H

# include <stdint.h>

typedef struct s_analytics_event_window
{
	const uint64_t	*seconds;
	const int		*counts;
	int				count;
} t_analytics_event_window;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: analytics_events_per_second_hundredths — Traite per second
**       hundredths et met à jour
**       uniquement l’état d’entrée
**       ou d’interface
**       correspondant à cet
**       événement.
** Paramètre: events — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: sec_now — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: window_sec — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: analytics_events_per_second_hundredths().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                analytics_events_per_second_hundredths(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	analytics_events_per_second_hundredths(
		const t_analytics_event_window *events, uint64_t sec_now,
		uint64_t window_sec);

#endif
