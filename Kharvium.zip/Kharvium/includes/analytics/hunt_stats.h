/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_stats.h                                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef HUNT_STATS_H
# define HUNT_STATS_H

# include <stddef.h>
# include "common/money.h"

# define HUNT_STATS_TOP_MOBS 10
# define HUNT_STATS_TOP_LOOT 10
# define HUNT_STATS_HAS_MARKUP 1

typedef struct s_top_mob
{
	char	name[128];
	long	kills;
} 			t_top_mob;

typedef struct s_top_loot
{
	char	name[128];
	t_money	tt_ped;
	t_money	mu_ped;
	t_money	total_mu_ped;
	long	events;
} 			t_top_loot;

typedef struct s_hunt_stats
{
	int			csv_has_header;
	long		data_lines_read;

	long		kills;
	long		shots;

	long		sweat_total;
	long		sweat_events;

	t_money	loot_ped;
	t_money	loot_items_ped;
	long		loot_envelopes;
	long		loot_events;
	long		loot_items_without_value;
	long		loot_empty_envelopes;
	long		loot_orphan_items;
	t_money	loot_envelope_best_ped;
	long		loot_envelope_best_items;
	long		loot_envelope_max_items;

	t_money	expense_ped_logged;
	long		expense_events;

	t_money	expense_ped_calc;
	t_money	expense_used;
	int		expense_used_is_logged;

	t_money	net_ped;

	int		has_weapon;
	char		weapon_name[128];
	char		player_name[128];
	t_money	cost_shot_uPED;
	t_money	ammo_shot_uPED;
	t_money	decay_shot_uPED;
	t_money	amp_ammo_shot_uPED;
	t_money	amp_decay_shot_uPED;
	double		markup; /* affichage seulement */

	size_t		mobs_unique;
	size_t		top_mobs_count;
	t_top_mob	top_mobs[HUNT_STATS_TOP_MOBS];

	/* ====================================================== */
	/* TOP LOOT (per item)                                    */
	/* ====================================================== */
	size_t		top_loot_count;
	t_top_loot	top_loot[HUNT_STATS_TOP_LOOT];

	/* ====================================================== */
	/* MARKUP (TT / MU / TT+MU)                               */
	/* Actif uniquement si HUNT_STATS_HAS_MARKUP est defini     */
	/* ====================================================== */
#ifdef HUNT_STATS_HAS_MARKUP
	t_money	loot_tt_ped;
	t_money	loot_mu_ped;
	t_money	loot_total_mu_ped;
#endif

} 			t_hunt_stats;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_compute — Calcule l’état associé à chasse statistiques.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: start_line — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_compute().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_compute(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_stats_compute(const char *csv_path, long start_line,
			t_hunt_stats *out);

/*
** Compute stats on a data-line range [start_line, end_line).
** - Lines are 0-based data lines (header ignored).
** - If end_line is -1, it means "until EOF".
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_compute_range — Calcule compute plage à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: start_line — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: end_line — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_compute_range().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_compute_range(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_stats_compute_range(const char *csv_path, long start_line,
								  long end_line, t_hunt_stats *out);

#endif
