/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_envelope_stats.h                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_ENVELOPE_STATS_H
# define HUNT_ENVELOPE_STATS_H

# include <stdint.h>
# include "analytics/hunt_stats.h"
# include "io/hunt_csv.h"

typedef struct s_hunt_envelope_accumulator
{
	int64_t		kill_id;
	t_unix_time	timestamp_unix;
	t_money		total_uPED;
	long		item_count;
	int			open;
}   t_hunt_envelope_accumulator;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_envelope_stats_reset — Réinitialise l’état associé à chasse
**       enveloppe statistiques.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : state.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_envelope_stats_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_envelope_stats_reset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_envelope_stats_reset(t_hunt_envelope_accumulator *state);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_envelope_stats_process — Traite l’état associé à chasse
**       enveloppe statistiques.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: stats — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : state, stats.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_envelope_stats_process().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_envelope_stats_process(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_envelope_stats_process(t_hunt_envelope_accumulator *state,
			t_hunt_stats *stats, const t_hunt_csv_row_view *row);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_envelope_stats_finalize — Finalise l’état associé à chasse
**       enveloppe statistiques.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: stats — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : state, stats.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_envelope_stats_finalize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_envelope_stats_finalize(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_envelope_stats_finalize(t_hunt_envelope_accumulator *state,
			t_hunt_stats *stats);

#endif
