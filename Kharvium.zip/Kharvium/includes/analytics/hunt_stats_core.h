/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_stats_core.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_STATS_CORE_H
# define HUNT_STATS_CORE_H

# include <stddef.h>
# include "analytics/hunt_stats.h"
# include "common/money.h"
# include "config/markup_rules.h"
# include "io/hunt_csv.h"

typedef struct s_stats_kv
{
	char	*key;
	long	count;
}t_stats_kv;

typedef struct s_stats_kv_loot
{
	char		*key;
	long		events;
	t_money		tt_sum;
	t_money		final_sum;
}t_stats_kv_loot;

typedef struct s_stats_loot_value
{
	const char	*key;
	t_money		tt;
	t_money		final;
}t_stats_loot_value;

typedef struct s_hunt_stats_row_context
{
	t_hunt_stats		*out;
	const t_markup_db	*markup;
	t_stats_kv_loot		**loot;
	size_t			*loot_len;
	t_stats_kv		**mobs;
	size_t			*mobs_len;
	int			sweat_enabled;
}t_hunt_stats_row_context;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_zero — Met à jour zero en appliquant explicitement
**       les paramètres, bornes et invariants décrits par le contrat de cette
**       fonction.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_zero().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_zero(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_zero(t_hunt_stats *stats);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_load_markup_database — Charge database depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: mu — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : mu.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_load_markup_database().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_load_markup_database(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_stats_core_load_markup_database(t_markup_db *markup);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_initialize_markup_fields — Initialise champs à partir
**       des paramètres fournis et initialise tous les champs requis avant
**       qu’ils soient lus par une autre opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_initialize_markup_fields().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_initialize_markup_fields(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_initialize_markup_fields(t_hunt_stats *stats);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_add_markup_fields — Ajoute champs dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: tt — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: final — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_add_markup_fields().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_add_markup_fields(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_add_markup_fields(t_hunt_stats *stats,
			t_money tt, t_money final);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_apply_markup_value — Calcule apply valeur à partir
**       des entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: mu — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: item_name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: tt_value — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Paramètre: quantity — quantité d’unités lootées; elle est utilisée par le
**            mode unit_value et normalisée à 1 si elle est invalide.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_apply_markup_value().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_apply_markup_value(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money		hunt_stats_core_apply_markup_value(const t_markup_db *markup,
			const char *item_name, t_money tt_value, long quantity);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_load_weapon_model — Charge model depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_load_weapon_model().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_load_weapon_model(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_load_weapon_model(t_hunt_stats *stats);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_is_sweat_enabled — Détermine si sweat activé respecte
**       la condition attendue, sans modifier les données consultées.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_is_sweat_enabled().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_is_sweat_enabled(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hunt_stats_core_is_sweat_enabled(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_key_value_increment — Retourne ou renseigne touche
**       valeur increment dans la
**       représentation directement
**       utilisable par le reste du
**       module.
** Paramètre: arr — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: len — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : arr, len.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_key_value_increment().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_key_value_increment(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_key_value_increment(t_stats_kv **array,
			size_t *length, const char *key);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_key_value_free — Libère l’état associé à chasse
**       statistiques cœur key valeur.
** Paramètre: arr — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: len — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : arr, len.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_key_value_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_key_value_free(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_key_value_free(t_stats_kv **array, size_t *length);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_key_value_loot_add — Ajoute l’état associé à chasse
**       statistiques cœur key valeur loot.
** Paramètre: array — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: length — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : array, length.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_key_value_loot_add().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_key_value_loot_add(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_key_value_loot_add(t_stats_kv_loot **array,
			size_t *length, const t_stats_loot_value *value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_key_value_loot_free — Libère l’état associé à
**       chasse statistiques cœur key valeur loot.
** Paramètre: arr — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: len — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : arr, len.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_key_value_loot_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_key_value_loot_free(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_key_value_loot_free(t_stats_kv_loot **array,
			size_t *length);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_finalize_top_mobs — Finalise top créatures en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: mobs — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: mobs_len — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out, mobs.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_finalize_top_mobs().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_finalize_top_mobs(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_finalize_top_mobs(t_hunt_stats *stats,
			t_stats_kv *mobs, size_t mobs_len);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_finalize_top_loot — Finalise top loot en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: loot — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: loot_len — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out, loot.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_finalize_top_loot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_finalize_top_loot(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_finalize_top_loot(t_hunt_stats *stats,
			t_stats_kv_loot *loot, size_t loot_len);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_process_row_view — Traite ligne view en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_process_row_view().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_process_row_view(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_process_row_view(t_hunt_stats_row_context *context,
			const t_hunt_csv_row_view *row);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_stats_core_compute_costs — Calcule coûts à partir des entrées
**       fournies en respectant les unités, les bornes et les règles
**       d’arrondi propres au module.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_stats_core_compute_costs().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_stats_core_compute_costs(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		hunt_stats_core_compute_costs(t_hunt_stats *stats);

#endif
