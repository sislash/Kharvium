/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_chart_scale.h                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_CHART_SCALE_H
# define UI_CHART_SCALE_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_chart_scale_step — Exécute une étape l’état associé à interface
**       graphique scale.
** Paramètre: minimum — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: maximum — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: target_ticks — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_chart_scale_step().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_chart_scale_step(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	ui_chart_scale_step(double minimum, double maximum,
		int target_ticks);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_chart_scale_align — Rend graphique scale align avec les primitives
**       UI disponibles en respectant la zone d’affichage et l’état de la
**       frame courante.
** Paramètre: minimum — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: maximum — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: target_ticks — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : minimum, maximum.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_chart_scale_align().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_chart_scale_align(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_chart_scale_align(double *minimum, double *maximum,
		int target_ticks);

#endif
