/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_tracker_view.h                               +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef HUNT_TRACKER_VIEW_H
# define HUNT_TRACKER_VIEW_H

/*
** Legacy window-only screen (globals) kept for reference.
**
** - Not used by the main UI flow.
** - Build it only if you compile with: make LEGACY=1
*/

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_view_global_events_menu — Traite view et met à jour
**       uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_view_global_events_menu().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_view_global_events_menu(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	tracker_view_global_events_menu(void);

#endif
