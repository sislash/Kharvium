/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_theme.h                                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_THEME_H
# define UI_THEME_H

/*
** UI module boundary (step 13): theme constants live here.
** Legacy callers still include "ui/ui_theme_types.h".
*/

# include "ui/ui_theme_types.h"

/* Terminal HUD palette (0xRRGGBB). */
# define UI_COL_BG        0x090D13u
# define UI_COL_TEXT      0xE5EDF5u
# define UI_COL_SUCCESS   0x36D399u
# define UI_COL_ACCENT    0x4DA3FFu
# define UI_COL_DANGER    0xFF5C6Cu

#endif
