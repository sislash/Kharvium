/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tracker_overlay.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef TRACKER_OVERLAY_H
# define TRACKER_OVERLAY_H

#include "platform/native_window.h"
#include "analytics/hunt_stats.h"
# include "app/app_state_fwd.h"

#include <stdint.h>

/* Toggleable always-on-top overlay window. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_toggle — Bascule l’état associé à overlay.
** Paramètre: core — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : core.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_toggle().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_toggle(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	overlay_toggle(t_app_state *core);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_is_enabled — Détermine si activé respecte la condition
**       attendue, sans modifier les données consultées.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_is_enabled().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_is_enabled(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		overlay_is_enabled(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_overlay_tick — Exécute un cycle l’état associé à Tracker
**       overlay.
** Paramètre: stats — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: elapsed_ms — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_overlay_tick().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_overlay_tick(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	tracker_overlay_tick(const t_hunt_stats *s,
	unsigned long long elapsed_ms);

/* Session clock used by overlay (shared across screens).
 * - overlay_set_session_start_milliseconds(): one-way push into overlay.
 * - overlay_sync_session_clock(): two-way sync
 *   (lets overlay buttons drive the app clock).
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_set_session_start_milliseconds — Démarre set session
**       milliseconds en appliquant les validations et transformations
**       propres à cette opération, puis laisse les données concernées dans
**       un état cohérent.
** Paramètre: ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_set_session_start_milliseconds().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_set_session_start_milliseconds(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		overlay_set_session_start_milliseconds(uint64_t ms);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_get_session_start_milliseconds — Démarre get session
**       milliseconds en appliquant les validations et transformations
**       propres à cette opération, puis laisse les données concernées dans
**       un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type uint64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_get_session_start_milliseconds().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_get_session_start_milliseconds(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
uint64_t	overlay_get_session_start_milliseconds(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_sync_session_clock — Met à jour sync session clock en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: io_session_start_ms — objet ou buffer fourni par l’appelant;
**            il peut être mis à jour lorsque le contrat de la fonction
**            l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants :
**         io_session_start_ms.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_sync_session_clock().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_sync_session_clock(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		overlay_sync_session_clock(uint64_t *io_session_start_ms);

/* Convenience tick: keeps overlay updating even inside modal screens. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_tick_auto_hunt — Met à jour auto à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: core — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : core.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_tick_auto_hunt().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_tick_auto_hunt(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	overlay_tick_auto_hunt(t_app_state *core);

/* Overlay demo (no parser needed): used for Windows smoke-tests. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_set_demo — Met à jour demo à partir des valeurs courantes et
**       conserve l’état partagé cohérent pour la suite de la frame ou du
**       calcul.
** Paramètre: on — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_set_demo().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_set_demo(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	overlay_set_demo(int on);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_is_demo — Détermine si demo respecte la condition attendue,
**       sans modifier les données consultées.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_is_demo().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_is_demo(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	overlay_is_demo(void);

/* Overlay UX: lock/unlock mouse capture (click-through on Windows). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_toggle_click_through — Met à jour toggle click through en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_toggle_click_through().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_toggle_click_through(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	overlay_toggle_click_through(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_is_click_through — Détermine si click through respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_is_click_through().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_is_click_through(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	overlay_is_click_through(void);

/* UI feedback: display active global hotkeys / fallback state. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_set_hotkeys_enabled — Vérifie si set raccourcis clavier
**       possède l’état activé attendu avant de poursuivre l’opération.
** Paramètre: enabled — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_set_hotkeys_enabled().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_set_hotkeys_enabled(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	overlay_set_hotkeys_enabled(int enabled);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: overlay_set_hotkeys_info — Met à jour raccourcis clavier info à
**       partir des valeurs courantes et conserve l’état partagé cohérent
**       pour la suite de la frame ou du calcul.
** Paramètre: ok_overlay — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: ok_click — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: label_overlay — objet source consulté en lecture seule par
**            cette fonction.
** Paramètre: label_click — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: overlay_set_hotkeys_info().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                overlay_set_hotkeys_info(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	overlay_set_hotkeys_info(int ok_overlay, int ok_click,
			const char *label_overlay, const char *label_click);

#endif
