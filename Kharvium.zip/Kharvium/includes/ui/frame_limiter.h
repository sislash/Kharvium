/* ************************************************************************** */
/*                                                                            */
/*   frame_limiter.h                                   +:+      :+:    :+:   */
/*   frame_limiter.h                                    :+:      :+:    :+:   */
/*   Small FPS limiter utility. */
/*                                                                            */
/* ************************************************************************** */

#ifndef FRAME_LIMITER_H
# define FRAME_LIMITER_H

# include <stdint.h>

typedef struct s_frame_limiter
{
	int		target_ms;
	uint64_t	frame_start_ms;
}   t_frame_limiter;

/* Start of a frame: records current time. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: frame_limiter_begin — Met à jour frame limiter begin en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: fl — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : fl.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: frame_limiter_begin().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                frame_limiter_begin(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	frame_limiter_begin(t_frame_limiter *fl);

/* End of a frame: sleeps the remaining time (if any). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: frame_limiter_end_and_sleep — Met à jour frame limiter end et sleep
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: fl — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : fl.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: frame_limiter_end_and_sleep().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                frame_limiter_end_and_sleep(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	frame_limiter_end_and_sleep(t_frame_limiter *fl);

#endif
