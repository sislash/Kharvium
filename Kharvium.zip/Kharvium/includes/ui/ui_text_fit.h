/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_text_fit.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_TEXT_FIT_H
# define UI_TEXT_FIT_H

# include "ui/ui_layout.h"

typedef struct s_ui_text_fit_style
{
	unsigned int			color;
	t_window_font_role	role;
} t_ui_text_fit_style;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_text_vertical_center — Rend texte vertical center avec les
**       primitives UI disponibles en respectant la zone d’affichage et
**       l’état de la frame courante.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: rectangle — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_text_vertical_center().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_text_vertical_center(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_text_vertical_center(t_window *window, t_rect rectangle);
int		ui_text_vertical_center_role(t_window *window, t_rect rectangle,
			t_window_font_role role);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_text_line_height — Retourne l'avance verticale recommandée pour
**       une ligne selon le rôle typographique et les métriques natives.
** Paramètre: window — fenêtre native ciblée par la mesure.
** Paramètre: role — rôle SMALL/BODY/BUTTON/TITLE utilisé pour le texte.
** Retour: hauteur de ligne en pixels, toujours strictement positive.
** Effets: consulte uniquement les métriques de police du backend.
** Invariants: la hauteur inclut un interligne minimal propre au rôle.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_text_line_height().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_text_line_height().
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_text_line_height(t_window *window, t_window_font_role role);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_draw_text_fit — Dessine texte fit dans le contexte graphique
**       courant en respectant la géométrie, le clipping et l’état des
**       widgets fournis.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: rectangle — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; le rendu respecte les rectangles et capacités
**             fournis afin de rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_draw_text_fit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_draw_text_fit(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_draw_text_fit(t_window *window, t_rect rectangle,
			const char *text, unsigned int color);
void	ui_draw_text_fit_role(t_window *window, t_rect rectangle,
			const char *text, t_ui_text_fit_style style);

#endif
