/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_chrome.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef UI_CHROME_H
# define UI_CHROME_H

# include "platform/native_window.h"
# include "ui/ui_layout.h"
# include "ui/ui_widgets.h"

typedef struct s_ui_chrome_request
{
	const char	*breadcrumb;
	const char	*status;
	const char	*footer_hint;
	int			sidebar_width;
} 	t_ui_chrome_request;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_chrome_render — Rend l’état associé à interface chrome.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type t_rect; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window, ui.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_chrome_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_chrome_render(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_rect	ui_chrome_render(t_window *window, t_ui_state *ui,
			t_ui_chrome_request request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_chrome_render_with_sidebar — Rend chrome with barre latérale dans
**       le contexte graphique courant en respectant la géométrie, le
**       clipping et l’état des widgets fournis.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type t_rect; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window, ui.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_chrome_render_with_sidebar().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_chrome_render_with_sidebar(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_rect	ui_chrome_render_with_sidebar(t_window *window, t_ui_state *ui,
			t_ui_chrome_request request);

#endif
