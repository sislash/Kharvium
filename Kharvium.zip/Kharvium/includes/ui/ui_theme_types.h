/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_theme_types.h                                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef UI_THEME_TYPES_H
# define UI_THEME_TYPES_H

/*
** Simple theme definition for the X11 immediate-mode UI.
** Colors are 0xRRGGBB.
*/

typedef struct s_theme
{
	unsigned int	bg;
	unsigned int	surface;
	unsigned int	surface2;
	unsigned int	border;
	unsigned int	text;
	unsigned int	text2;
	unsigned int	accent;
	unsigned int	success;
	unsigned int	warn;
	unsigned int	danger;
} 	t_theme;

extern const t_theme	g_theme_dark;
extern const t_theme	g_theme_light;

/* Utility: blend two 0xRRGGBB colors. t in [0..255]. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_color_lerp — Retourne ou renseigne couleur lerp dans la
**       représentation directement utilisable par le reste
**       du module.
** Paramètre: a — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: b — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: t — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type unsigned int; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_color_lerp().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_color_lerp(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
unsigned int	ui_color_lerp(unsigned int a, unsigned int b, unsigned int t);

/* Utility: return a readable text color (0x000000 or 0xFFFFFF) on bg. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_color_contrast_text — Construit ou transforme le texte utilisé
**       par interface color contrast.
** Paramètre: bg — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type unsigned int; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_color_contrast_text().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_color_contrast_text(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
unsigned int	ui_color_contrast_text(unsigned int bg);

#endif
