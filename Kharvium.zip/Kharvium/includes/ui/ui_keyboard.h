/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_keyboard.h                                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/25                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_KEYBOARD_H
# define UI_KEYBOARD_H

/*
 * * Retourne 1 si une touche est dispo (non-bloquant), sinon 0.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_key_available — Rend touche available avec les primitives UI
**       disponibles en respectant la zone d’affichage et l’état de la frame
**       courante.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_key_available().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_key_available(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	ui_key_available(void);

/*
 * * Lit 1 char (suppose qu'une touche est dispo), retourne -1 si erreur.
 */

#endif
