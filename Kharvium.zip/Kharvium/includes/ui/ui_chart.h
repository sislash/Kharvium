/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_chart.h                                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef UI_CHART_H
# define UI_CHART_H

# include "ui/ui_widgets.h"

# include <stdint.h>

typedef enum e_ui_chart_annotation_kind
{
	UI_GRAPH_ANNOT_KILL = 1,
	UI_GRAPH_ANNOT_LOOT = 2,
	/* Generic per-point value label (discreet). */
	UI_GRAPH_ANNOT_VALUE = 3
} 	t_ui_chart_annotation_kind;

typedef struct s_ui_chart_annotation
{
	int				point_index;
	t_ui_chart_annotation_kind	kind;
	const char			*text;
} 	t_ui_chart_annotation;

/* -------------------------------------------------------------------------- */
/*  Overview + Zoom state                                                     */
/* -------------------------------------------------------------------------- */

typedef enum e_ui_chart_zoom_mode
{
	UI_GRAPH_ZOOM_NONE = 0,
	UI_GRAPH_ZOOM_MOVE = 1,
	UI_GRAPH_ZOOM_RESIZE_L = 2,
	UI_GRAPH_ZOOM_RESIZE_R = 3
} 	t_ui_chart_zoom_mode;

typedef struct s_ui_chart_zoom
{
	/* X window in "x_seconds" space (seconds since session start) */
	int		t0;
	int		t1;

	/* Drag interaction (overview) */
	t_ui_chart_zoom_mode	mode;
	int		drag_start_x;
	int		drag_t0;
	int		drag_t1;

	/* Double-click reset */
	uint64_t	last_click_ms;
} 	t_ui_chart_zoom;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_chart_zoom_reset — Réinitialise l’état associé à interface
**       graphique zoom.
** Paramètre: zoom — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : zoom.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_chart_zoom_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_chart_zoom_reset(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_chart_zoom_reset(t_ui_chart_zoom *z);

typedef struct s_ui_chart_series
{
	const char			*title;
	const double			*values;
	const int			*x_seconds;
	const int			*badge_counts;
	int				n;
	double				vmax;
	const char			*y_label;
	const char			*unit;
	unsigned int			line_color;
	const t_ui_chart_annotation	*annotations;
	int				annotation_count;
	t_ui_chart_zoom			*zoom;
	uint32_t			series_version;
} 	t_ui_chart_series;

/*
 * Draws a chart from a single configuration object.
 * When series->zoom is non-NULL, overview + zoom rendering is enabled.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_chart_draw — Dessine l’état associé à interface graphique.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: area — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: series — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window, ui.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; le rendu respecte les rectangles et capacités
**             fournis afin de rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_chart_draw().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_chart_draw(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_chart_draw(t_window *w, t_ui_state *ui, t_rect area,
			const t_ui_chart_series *series);

/* -------------------------------------------------------------------------- */
/* Hover info (last drawn graph)                                              */

/* Returns 1 if a point is currently hovered on the last drawn graph.
 * out_src_index: index in the provided values/x_seconds arrays.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_chart_get_last_hover — Retourne graphique last hover en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: out_src_index — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: out_x_seconds — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: out_value — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_badge_count — destination renseignée avec le résultat,
**            dans la capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out_src_index,
**         out_x_seconds, out_value, out_badge_count.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_chart_get_last_hover().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_chart_get_last_hover(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	ui_chart_get_last_hover(int *out_src_index,
						int *out_x_seconds,
						double *out_value,
						int *out_badge_count);

#endif
