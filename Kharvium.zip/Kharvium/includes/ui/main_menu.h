/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_menu.h                                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/04                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MAIN_MENU_H
# define MAIN_MENU_H

# include "platform/native_window.h"

typedef struct s_menu
{
    const char	**items;
    int			count;
    int			selected;

	/* Last render position/metrics (used for mouse click selection) */
	int			render_x;
	int			render_y;
	int			item_w;
	int			item_h;
}	t_menu;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: main_menu_initialize — Initialise l’état associé à main menu.
** Paramètre: menu — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: items — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : menu.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: main_menu_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                main_menu_initialize(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	main_menu_initialize(t_menu *m, const char **items, int count);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: main_menu_update — Met à jour l’état associé à main menu.
** Paramètre: menu — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : menu, window.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: main_menu_update().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                main_menu_update(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		main_menu_update(t_menu *m, t_window *w);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: main_menu_render — Rend l’état associé à main menu.
** Paramètre: menu — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: x — coordonnée ou dimension de la zone graphique concernée.
** Paramètre: y — coordonnée ou dimension de la zone graphique concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : menu, window.
** Invariants: les accès indexés sont bornés avant lecture ou écriture; le
**             rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: main_menu_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                main_menu_render(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	main_menu_render(t_menu *m, t_window *w, int x, int y);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: main_menu_render_screen — Rend screen dans le contexte graphique
**       courant en respectant la géométrie, le clipping et l’état des
**       widgets fournis.
** Paramètre: menu — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: x — coordonnée ou dimension de la zone graphique concernée.
** Paramètre: y — coordonnée ou dimension de la zone graphique concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : menu, window.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: main_menu_render_screen().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                main_menu_render_screen(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void    main_menu_render_screen(t_menu *m, t_window *w, int x, int y);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parser_workers_stop_all — Arrête parser workers all en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: x — coordonnée ou dimension de la zone graphique concernée.
** Paramètre: y — coordonnée ou dimension de la zone graphique concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: parser_workers_stop_all().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parser_workers_stop_all(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	parser_workers_stop_all(t_window *w, int x, int y);

#endif
