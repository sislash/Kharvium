/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_downsample.h                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_DOWNSAMPLE_H
# define UI_DOWNSAMPLE_H

# include "ui/ui_layout.h"
# include "platform/native_window.h"

typedef struct s_ui_downsample_request
{
	const double	*values;
	const int	*x_seconds;
	int			count;
	int			minimum_time;
	int			maximum_time;
	double		minimum_value;
	double		maximum_value;
	t_rect		plot;
}   t_ui_downsample_request;

typedef struct s_ui_downsample_output
{
	t_point_i	*poly_points;
	int			*poly_indices;
	int			poly_capacity;
	t_point_i	*representative_points;
	int			*representative_indices;
	int			representative_capacity;
	int			*representative_count;
}   t_ui_downsample_output;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_downsample_minmax_pixels — Rend downsample minmax pixels avec les
**       primitives UI disponibles en respectant la zone d’affichage et
**       l’état de la frame courante.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_downsample_minmax_pixels().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_downsample_minmax_pixels(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	ui_downsample_minmax_pixels(const t_ui_downsample_request *request,
		t_ui_downsample_output *output);

#endif
