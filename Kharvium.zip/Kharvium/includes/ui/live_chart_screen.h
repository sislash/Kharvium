/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   live_chart_screen.h                               +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef LIVE_CHART_SCREEN_H
# define LIVE_CHART_SCREEN_H

# include "platform/native_window.h"

/* Graph temps reel (session chasse): hits / kills / loot / temps */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: live_chart_screen_run — Exécute l’état associé à LIVE graphique
**       screen.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: live_chart_screen_run().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                live_chart_screen_run(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	live_chart_screen_run(t_window *w);

/* Non-blocking frame API (returns 1=continue, 0=close) */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: live_chart_screen_update — Met à jour l’état associé à LIVE
**       graphique screen.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: live_chart_screen_update().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                live_chart_screen_update(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	live_chart_screen_update(t_window *w);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: live_chart_screen_reset — Réinitialise l’état associé à LIVE
**       graphique screen.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: live_chart_screen_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                live_chart_screen_reset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	live_chart_screen_reset(void);

#endif
