/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_dialog_internal.h                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_DIALOG_INTERNAL_H
# define UI_DIALOG_INTERNAL_H

# include "ui/ui_dialog.h"
# include "ui/ui_widgets.h"

typedef struct s_ui_dialog_frame
{
	t_ui_state	ui;
	t_ui_layout	layout;
	t_rect		content;
	t_rect		list;
	const char	*items[2];
	int			selected;
	int			clicked;
} 	t_ui_dialog_frame;

#endif
