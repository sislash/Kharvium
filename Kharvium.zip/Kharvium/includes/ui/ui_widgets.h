/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_widgets.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef UI_WIDGETS_H
# define UI_WIDGETS_H

# include "platform/native_window.h"
# include "ui/ui_layout.h"
# include "ui/ui_theme_types.h"
# include "ui/ui_text_fit.h"

typedef enum e_ui_button_style
{
	UI_BTN_PRIMARY,
	UI_BTN_SECONDARY,
	UI_BTN_GHOST
} 	t_ui_button_style;

typedef struct s_ui_state
{
	const t_theme	*theme;
} 	t_ui_state;

typedef struct s_ui_text_request
{
	t_window		*w;
	int			x;
	int			y;
	const char		*text;
	unsigned int	color;
	t_window_font_role	font_role;
} 	t_ui_text_request;

typedef struct s_ui_text_ellipsis_request
{
	t_window		*w;
	int			x;
	int			y;
	const char		*text;
	unsigned int	color;
	int			max_width_pixels;
	t_window_font_role	font_role;
} 	t_ui_text_ellipsis_request;

typedef struct s_ui_scroll_request
{
	t_window	*w;
	int		*scroll_y;
	int		content_h;
	int		view_h;
	int		step_px;
} 	t_ui_scroll_request;

typedef struct s_ui_list_request
{
	t_window	*w;
	t_ui_state	*ui;
	t_rect		area;
	const char	**items;
	int		count;
	int		*selected;
	int		item_h;
	int		show_icons;
	int		*scroll_y;
} 	t_ui_list_request;

typedef struct s_ui_button_request
{
	t_window		*w;
	t_ui_state		*ui;
	t_rect			area;
	const char		*label;
	t_ui_button_style	style;
	int			enabled;
} 	t_ui_button_request;

typedef struct s_ui_input_request
{
	t_window	*w;
	t_ui_state	*ui;
	t_rect		area;
	char		*buffer;
	int		buffer_size;
	int		*focus_id;
	int		widget_id;
} 	t_ui_input_request;

typedef struct s_ui_text_lines_request
{
	t_window	*w;
	t_ui_state	*ui;
	t_rect		area;
	const char	**lines;
	int		count;
	int		line_h;
	unsigned int	color;
	int		*scroll_y;
	t_window_font_role	font_role;
} 	t_ui_text_lines_request;

typedef struct s_ui_card_request
{
	t_window	*w;
	t_ui_state	*ui;
	t_rect		area;
	const char	*title;
	const char	*value;
	unsigned int	value_color;
} 	t_ui_card_request;

typedef struct s_ui_badge_request
{
	t_window	*w;
	t_ui_state	*ui;
	t_rect		area;
	const char	*label;
	unsigned int	color;
} 	t_ui_badge_request;

typedef struct s_ui_line_request
{
	t_window	*w;
	int		x;
	int		y;
	int		width;
	unsigned int	color;
} 	t_ui_line_request;

typedef t_ui_text_request		t_txt;
typedef t_ui_text_ellipsis_request	t_elip;
typedef t_ui_scroll_request		t_scr;
typedef t_ui_list_request		t_lst;
typedef t_ui_button_request		t_btn;
typedef t_ui_input_request		t_in;
typedef t_ui_text_lines_request		t_lines;
typedef t_ui_card_request		t_card;
typedef t_ui_badge_request		t_badge;
typedef t_ui_line_request		t_ln;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_draw_panel — Rend et met à jour draw panneau en utilisant le
**       contexte UI courant et les interactions de cette frame.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: r — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: bg — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: border — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_draw_panel().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_draw_panel(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_draw_panel(t_window *w, t_rect r, unsigned int bg,
			unsigned int border);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_text — Construit ou transforme le texte utilisé par interface.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_text().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous ui_text();
**                résolution indirecte possible pour callbacks et backends
**                plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_text(const t_ui_text_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_text_ellipsis — Rend texte ellipsis avec les primitives UI
**       disponibles en respectant la zone d’affichage et l’état de la frame
**       courante.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_text_ellipsis().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_text_ellipsis(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_text_ellipsis(const t_ui_text_ellipsis_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_draw_rectangle_border — Dessine rectangle border dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: rectangle — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; le rendu respecte les rectangles et capacités
**             fournis afin de rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_draw_rectangle_border().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_draw_rectangle_border(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_draw_rectangle_border(t_window *window, t_rect rectangle,
			unsigned int color);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_scroll — Fait défiler l’état associé à interface.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_scroll().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_scroll(); résolution indirecte possible pour callbacks
**                et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_scroll(const t_ui_scroll_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_sidebar_width_for_labels — Construit les libellés utilisés par
**       interface sidebar width for.
** Paramètre: window — fenêtre utilisée pour mesurer le rôle BUTTON natif.
** Paramètre: items — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: pad_px — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_sidebar_width_for_labels().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_sidebar_width_for_labels(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_sidebar_width_for_labels(t_window *window, const char **items,
			int count, int pad_px);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_list_scroll — Fait défiler l’état associé à interface liste.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_list_scroll().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_list_scroll(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_list_scroll(const t_ui_list_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_btn — Rend btn avec les primitives UI disponibles en respectant la
**       zone d’affichage et l’état de la frame courante.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_btn().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous ui_btn();
**                résolution indirecte possible pour callbacks et backends
**                plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_btn(const t_ui_button_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_input — Traite entrée et met à jour uniquement l’état d’entrée
**       ou d’interface correspondant à cet événement.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_input().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous ui_input();
**                résolution indirecte possible pour callbacks et backends
**                plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_input(const t_ui_input_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_lines_scroll — Fait défiler l’état associé à interface lignes.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_lines_scroll().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_lines_scroll(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_lines_scroll(const t_ui_text_lines_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_list — Construit ou parcourt la liste utilisée par interface.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_list().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous ui_list();
**                résolution indirecte possible pour callbacks et backends
**                plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_list(const t_ui_list_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_card — Rend et met à jour card en utilisant le contexte UI courant
**       et les interactions de cette frame.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_card().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous ui_card();
**                résolution indirecte possible pour callbacks et backends
**                plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_card(const t_ui_card_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_badge — Rend badge avec les primitives UI disponibles en
**       respectant la zone d’affichage et l’état de la frame courante.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_badge().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous ui_badge();
**                résolution indirecte possible pour callbacks et backends
**                plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_badge(const t_ui_badge_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_metric_card — Rend et met à jour metric card en utilisant le
**       contexte UI courant et les interactions de cette frame.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_metric_card().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_metric_card(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_metric_card(const t_ui_card_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_hline — Rend hline avec les primitives UI disponibles en
**       respectant la zone d’affichage et l’état de la frame courante.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_hline().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous ui_hline();
**                résolution indirecte possible pour callbacks et backends
**                plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_hline(const t_ui_line_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_section_header_render — Rend l’état associé à interface section
**       header.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: r — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: title — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w, ui.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; le rendu respecte les rectangles et capacités
**             fournis afin de rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_section_header_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_section_header_render(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_section_header_render(t_window *w, t_ui_state *ui,
			t_rect r, const char *title);

#endif
