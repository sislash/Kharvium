/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   global_events_menu.h                              +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef GLOBAL_EVENTS_MENU_H
# define GLOBAL_EVENTS_MENU_H

# include "platform/native_window.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: global_events_menu_render — Rend l’état associé à globaux
**       événements menu.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; le rendu respecte les rectangles et capacités
**             fournis afin de rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: global_events_menu_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                global_events_menu_render(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	global_events_menu_render(t_window *w);

#endif
