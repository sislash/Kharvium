/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_geometry.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 15:20:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 15:20:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_GEOMETRY_H
# define UI_GEOMETRY_H

# include "ui/ui_layout.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_rectangle_contains_point — Calcule le point graphique ou
**       temporel de interface rectangle contains.
** Paramètre: rectangle — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: x — coordonnée ou dimension de la zone graphique concernée.
** Paramètre: y — coordonnée ou dimension de la zone graphique concernée.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_rectangle_contains_point().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_rectangle_contains_point(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	ui_rectangle_contains_point(t_rect rectangle, int x, int y);

#endif
