/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   config_menu.h                                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef CONFIG_MENU_H
# define CONFIG_MENU_H

#include "platform/native_window.h"

/* Modal config editors */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_menu — Met à jour l’état du module en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_menu().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_menu(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_config_menu(t_window *w);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_config_menu — Met à jour l’état du module en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_config_menu().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_config_menu(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	markup_config_menu(t_window *w);

/* Non-blocking frame API (returns 1=continue, 0=close) */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_menu_frame — Traite une frame complète de arme
**       configuration menu.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_menu_frame().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_menu_frame(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	weapon_config_menu_frame(t_window *w);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_config_menu_frame — Traite une frame complète de markup
**       configuration menu.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_config_menu_frame().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_config_menu_frame(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_config_menu_frame(t_window *w);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_menu_reset — Réinitialise l’état associé à arme
**       configuration menu.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_menu_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_menu_reset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_config_menu_reset(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_config_menu_reset — Réinitialise l’état associé à markup
**       configuration menu.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_config_menu_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_config_menu_reset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	markup_config_menu_reset(void);

#endif
