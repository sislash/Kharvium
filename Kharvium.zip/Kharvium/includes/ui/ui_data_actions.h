/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_data_actions.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_DATA_ACTIONS_H
# define UI_DATA_ACTIONS_H

# include "platform/native_window.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_ensure_global_events_csv — Garantit l’état du module en
**       appliquant les validations, bornes et
**       effets explicitement définis par ce
**       module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_ensure_global_events_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_ensure_global_events_csv(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_ensure_global_events_csv(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_ensure_hunt_csv — Garantit l’état du module en appliquant les
**       validations, bornes et effets explicitement
**       définis par ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_ensure_hunt_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_ensure_hunt_csv(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_ensure_hunt_csv(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_action_clear_global_events_csv — Réinitialise action en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_action_clear_global_events_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_action_clear_global_events_csv(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_action_clear_global_events_csv(t_window *window);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_action_clear_hunt_csv — Réinitialise action en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_action_clear_hunt_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_action_clear_hunt_csv(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_action_clear_hunt_csv(t_window *window);

#endif
