/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   creature_prompt.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef CREATURE_PROMPT_H
# define CREATURE_PROMPT_H

# include <stddef.h>
# include "platform/native_window.h"

/*
 * Affiche un prompt "Nom du mob" si aucun mob n'est defini.
 * - Charge logs/selected_creature.txt
 * - Si vide: ecran modal avec input + Valider/Annuler
 * Retour:
 *   1 => mob disponible (out rempli si fourni)
 *   0 => annule
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: creature_prompt_ensure — Garantit creature prompt en appliquant les
**       validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : window, out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: creature_prompt_ensure().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                creature_prompt_ensure(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	creature_prompt_ensure(t_window *w, char *out, size_t outsz);

#endif
