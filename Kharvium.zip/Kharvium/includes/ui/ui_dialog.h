/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_dialog.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_DIALOG_H
# define UI_DIALOG_H

# include "platform/native_window.h"
# include "ui/ui_layout.h"

typedef struct s_ui_line_view
{
	const char	**lines;
	int			count;
	int			line_height;
	unsigned int	color;
	int			scroll_y;
} 	t_ui_line_view;

typedef struct s_ui_dialog_request
{
	const char	*title;
	const char	**lines;
	int			count;
	const char	*warning;
} 	t_ui_dialog_request;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_draw_lines_in_rectangle — Calcule draw lignes in rectangle à
**       partir de la géométrie et de l’état courants sans dépasser les
**       limites disponibles.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: rectangle — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: view — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; le rendu respecte les rectangles et capacités
**             fournis afin de rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_draw_lines_in_rectangle().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_draw_lines_in_rectangle(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_draw_lines_in_rectangle(t_window *window, t_rect rectangle,
			t_ui_line_view view);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_screen_message — Rend screen message avec les primitives UI
**       disponibles en respectant la zone d’affichage et l’état de la frame
**       courante.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_screen_message().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_screen_message(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_screen_message(t_window *window, t_ui_dialog_request request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_screen_confirm — Rend screen confirmation avec les primitives UI
**       disponibles en respectant la zone d’affichage et l’état de la frame
**       courante.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_screen_confirm().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_screen_confirm(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_screen_confirm(t_window *window, t_ui_dialog_request request);

#endif
