/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_layout.h                                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef UI_LAYOUT_H
# define UI_LAYOUT_H

#include "platform/native_window.h"

typedef struct s_rect
{
	int x;
	int y;
	int w;
	int h;
} 	t_rect;

typedef struct s_ui_layout
{
	t_rect	root;
	t_rect	topbar;
	t_rect	footer;
	t_rect	sidebar;
	t_rect	content;
	int		sidebar_w;
	int		top_h;
	int		footer_h;
} 	t_ui_layout;

/* Layout constants (tuned for 1024x768 and scales down reasonably). */
#define UI_TOP_H		84
#define UI_FOOTER_H		32
#define UI_SIDEBAR_W	280
#define UI_SIDEBAR_MIN	220
#define UI_SIDEBAR_MAX	340

/* Generic padding and font sizes (used by widgets/screens). */
#define UI_PAD			16
#define UI_LINE_H		14

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_layout_calculate — Calcule l’état associé à interface mise en
**       page.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: layout — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window, layout.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_layout_calculate().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_layout_calculate(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_layout_calculate(t_window *w, t_ui_layout *out);

/*
 * Like ui_layout_calculate(), but lets the caller suggest a sidebar width.
 * The final width is clamped to sane bounds and to the current window size.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_layout_calculate_with_sidebar — Calcule mise en page with barre
**       latérale à partir des entrées fournies en respectant les unités, les
**       bornes et les règles d’arrondi propres au module.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: layout — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: desired_sidebar_width — identifiant stable servant à retrouver
**            ou associer l’élément.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window, layout.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_layout_calculate_with_sidebar().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_layout_calculate_with_sidebar(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_layout_calculate_with_sidebar(t_window *w, t_ui_layout *out,
	int desired_sidebar_w);

#endif
