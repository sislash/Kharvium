/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ui_console.h                                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UI_CONSOLE_H
# define UI_CONSOLE_H

# define STATUS_WIDTH 75

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_wait_milliseconds — Rend wait milliseconds avec les primitives UI
**       disponibles en respectant la zone d’affichage et l’état de la frame
**       courante.
** Paramètre: ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_wait_milliseconds().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_wait_milliseconds(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_wait_milliseconds(unsigned milliseconds);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_wait_enter — Rend wait enter avec les primitives UI disponibles en
**       respectant la zone d’affichage et l’état de la frame courante.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_wait_enter().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_wait_enter(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_wait_enter(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_clear_screen — Réinitialise screen en appliquant les validations
**       et transformations propres à cette opération, puis laisse les
**       données concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_clear_screen().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_clear_screen(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_clear_screen(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_clear_viewport — Réinitialise viewport en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_clear_viewport().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_clear_viewport(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_clear_viewport(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_cursor_home — Rend curseur home avec les primitives UI disponibles
**       en respectant la zone d’affichage et l’état de la frame courante.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_cursor_home().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_cursor_home(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_cursor_home(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_user_wants_quit — Rend user wants quit avec les primitives UI
**       disponibles en respectant la zone d’affichage et l’état de la frame
**       courante.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_user_wants_quit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_user_wants_quit(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		ui_user_wants_quit(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ui_flush_stdin — Force l’écriture de stdin vers la destination
**       prévue en respectant le format, les bornes et la
**       politique d’erreur du module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ui_flush_stdin().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ui_flush_stdin(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	ui_flush_stdin(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: console_print_horizontal_rule — Met à jour console print horizontal
**       rule en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: console_print_horizontal_rule().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                console_print_horizontal_rule(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	console_print_horizontal_rule(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: console_print_double_horizontal_rule — Met à jour console print
**       double horizontal rule en appliquant explicitement les paramètres,
**       bornes et invariants décrits par le contrat de cette fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: console_print_double_horizontal_rule().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                console_print_double_horizontal_rule(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	console_print_double_horizontal_rule(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: console_print_menu_line — Construit ou traite une ligne appartenant
**       à console print menu.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: console_print_menu_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                console_print_menu_line(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	console_print_menu_line(const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: console_print_status_line — Construit ou traite une ligne
**       appartenant à console print status.
** Paramètre: label — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: console_print_status_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                console_print_status_line(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	console_print_status_line(const char *label, const char *value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: console_print_status_line_formatted — Retourne ou renseigne console
**       print état ligne formatted
**       dans la représentation
**       directement utilisable par le
**       reste du module.
** Paramètre: label — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: fmt — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: ? — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: console_print_status_line_formatted().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                console_print_status_line_formatted(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	console_print_status_line_formatted(const char *label,
			const char *format, ...);

#endif
