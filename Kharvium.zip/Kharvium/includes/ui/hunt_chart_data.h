/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_chart_data.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_CHART_DATA_H
# define HUNT_CHART_DATA_H

# include <stdint.h>
# include "analytics/hunt_stats.h"
# include "hunt/hunt_series.h"

typedef enum e_hunt_chart_metric
{
	HUNT_CHART_SHOTS_PER_KILL = 0,
	HUNT_CHART_HIT_RATE = 1,
	HUNT_CHART_HITS_PER_KILL = 2,
	HUNT_CHART_CUMULATIVE_KILLS = 3,
	HUNT_CHART_LOOT_PER_KILL = 4,
	HUNT_CHART_CUMULATIVE_LOOT = 5,
	HUNT_CHART_CUMULATIVE_COST = 6,
	HUNT_CHART_CUMULATIVE_ROI = 7
}   t_hunt_chart_metric;

typedef struct s_hunt_chart_request
{
	const t_hunt_series	*series;
	const t_hunt_stats	*stats;
	t_hunt_chart_metric	metric;
	int			range_minutes;
}   t_hunt_chart_request;

typedef struct s_hunt_chart_output
{
	double		*values;
	int		*x_seconds;
	int		*group_counts;
	int64_t		*kill_ids;
	unsigned char	*has_kill;
	int		count;
	double		maximum;
}   t_hunt_chart_output;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_chart_build_data — Construit graphique data à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_chart_build_data().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_chart_build_data(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_chart_build_data(const t_hunt_chart_request *request,
		t_hunt_chart_output *output);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_chart_bucket_count_for_minutes — Compte graphique bucket for
**       minutes en appliquant les validations et transformations propres à
**       cette opération, puis laisse les données concernées dans un état
**       cohérent.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: range_minutes — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_chart_bucket_count_for_minutes().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_chart_bucket_count_for_minutes(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_chart_bucket_count_for_minutes(const t_hunt_series *series,
		int range_minutes);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_chart_axis_maximum — Met à jour graphique axis maximum en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: metric — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: data_maximum — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_chart_axis_maximum().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_chart_axis_maximum(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	hunt_chart_axis_maximum(t_hunt_chart_metric metric,
		double data_maximum);

#endif
