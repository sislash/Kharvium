/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tracker_finance.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TRACKER_FINANCE_H
# define TRACKER_FINANCE_H

# include "config/weapon_config.h"
# include "finance/finance_types.h"
# include "analytics/hunt_stats.h"
# include "fishing/fishing_session_economics.h"

typedef struct s_tracker_finance_fishing_input
{
	const t_fishing_session_economics	*economics;
	const char				*location;
	int64_t				timestamp;
}   t_tracker_finance_fishing_input;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_finance_enhancer_break — Met à jour Enhancer break en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: weapon — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: slot_index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book, weapon.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_finance_enhancer_break().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_finance_enhancer_break(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	tracker_finance_enhancer_break(t_finance_book *book,
		t_weapon_stats *weapon, size_t slot_index, int64_t timestamp);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_finance_build_hunt_draft — Construit draft à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: draft — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: stats — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: location — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : draft.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_finance_build_hunt_draft().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_finance_build_hunt_draft(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	tracker_finance_build_hunt_draft(t_finance_activity *draft,
		const t_hunt_stats *stats, const char *location,
		int64_t timestamp);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: tracker_finance_build_fishing_draft — Convertit le résumé E89 en
**       draft Finance E90 sans inventer valeur marché ni mouvement de stock.
** Paramètre: draft — destination Finance réinitialisée puis renseignée.
** Paramètre: input — résumé Fishing, localisation optionnelle et timestamp.
** Retour: 1 si la session V4 est cohérente, 0 sinon.
** Effets: modifie uniquement draft; aucun commit ni accès réseau/fichier.
** Invariants: TT, base historique et marché gardent leurs qualités séparées.
** --- Liens API auto-vérifiés ---
** Implémentation: tracker_finance_build_fishing_draft().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                tracker_finance_build_fishing_draft().
** --- Fin des liens API auto-vérifiés ---
*/
int	tracker_finance_build_fishing_draft(t_finance_activity *draft,
		const t_tracker_finance_fishing_input *input);

#endif
