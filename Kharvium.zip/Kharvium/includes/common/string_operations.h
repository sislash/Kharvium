/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   string_operations.h                                    +:+      :+:  :+: */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STRING_OPERATIONS_H
# define STRING_OPERATIONS_H

# include <stddef.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_copy_bounded — Copie string bounded en préservant la propriété
**       des ressources, les compteurs et la cohérence de la destination.
** Paramètre: destination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: source — source consultée pour produire le résultat sans en
**            modifier la signification.
** Paramètre: destination_size — taille ou longueur utilisée pour borner
**            l’accès aux données.
** Retour: Retourne une taille, un nombre d’éléments ou un indice calculé
**         par cette opération.
** Effets: peut modifier les paramètres non const suivants : destination.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: string_copy_bounded().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_copy_bounded(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
size_t	string_copy_bounded(char *dst, const char *src, size_t dstsz);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_copy_safe — Copie string safe en préservant la propriété des
**       ressources, les compteurs et la cohérence de la destination.
** Paramètre: destination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: destination_size — taille ou longueur utilisée pour borner
**            l’accès aux données.
** Paramètre: source — source consultée pour produire le résultat sans en
**            modifier la signification.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : destination.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: string_copy_safe().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_copy_safe(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	string_copy_safe(char *dst, size_t dstsz, const char *src);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_trim_line_end — Met à jour string trim ligne end en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : text.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: string_trim_line_end().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_trim_line_end(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	string_trim_line_end(char *s);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_trim_left — Met à jour string trim left en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : text.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: string_trim_left().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_trim_left(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	string_trim_left(char **ps);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_trim_right — Met à jour string trim right en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : text.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: string_trim_right().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_trim_right(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	string_trim_right(char *s);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_copy_fits — Copie string fits en préservant la propriété des
**       ressources, les compteurs et la cohérence de la destination.
** Paramètre: destination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: destination_size — taille ou longueur utilisée pour borner
**            l’accès aux données.
** Paramètre: source — source consultée pour produire le résultat sans en
**            modifier la signification.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : destination.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: string_copy_fits().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_copy_fits(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		string_copy_fits(char *dst, size_t dstsz, const char *src);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_contains_case_insensitive — Détermine si string case
**       insensitive respecte la
**       condition indiquée par le nom de
**       la fonction, sans modifier
**       l’état consulté.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: query — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: string_contains_case_insensitive().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_contains_case_insensitive(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		string_contains_case_insensitive(const char *text, const char *query);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_equal_case_insensitive — Compare string case insensitive en
**       appliquant les validations, bornes
**       et effets explicitement définis par
**       ce module.
** Paramètre: left — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: right — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: string_equal_case_insensitive().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_equal_case_insensitive(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		string_equal_case_insensitive(const char *left, const char *right);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_to_lowercase_ascii — Convertit vers string lowercase ascii
**       en appliquant les validations, bornes
**       et effets explicitement définis par ce
**       module.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : text.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: string_to_lowercase_ascii().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_to_lowercase_ascii(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	string_to_lowercase_ascii(char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_empty_if_null — Met à jour string empty if null en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: string_empty_if_null().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_empty_if_null(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*string_empty_if_null(const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_placeholder_if_empty — Vérifie si string placeholder if
**       possède l’état empty attendu avant de poursuivre l’opération.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: string_placeholder_if_empty().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_placeholder_if_empty(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*string_placeholder_if_empty(const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_unknown_if_empty — Vérifie si string unknown if possède l’état
**       empty attendu avant de poursuivre l’opération.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: string_unknown_if_empty().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_unknown_if_empty(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*string_unknown_if_empty(const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_skip_spaces — Calcule les espacements de string skip et
**       renseigne les positions utilisées par la mise
**       en page.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: string_skip_spaces().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_skip_spaces(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*string_skip_spaces(const char *text);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_duplicate — Met à jour string duplicate en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: source — source consultée pour produire le résultat sans en
**            modifier la signification.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: string_duplicate().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_duplicate(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
char	*string_duplicate(const char *s);

#endif
