/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   log_format.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LOG_FORMAT_H
# define LOG_FORMAT_H

# include <stddef.h>

typedef struct s_log_line_target
{
	char		*buffer;
	size_t	capacity;
	const char	*key;
} 	t_log_line_target;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: log_format_line — Formate log ligne dans le buffer ou la
**       représentation demandée sans dépasser la capacité fournie par
**       l’appelant.
** Paramètre: target — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: format — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: ? — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: log_format_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                log_format_line(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	log_format_line(t_log_line_target target, const char *format, ...);

#endif
