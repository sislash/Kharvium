/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   number_parse.h                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NUMBER_PARSE_H
# define NUMBER_PARSE_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: number_parse_flexible_double — Analyse number flexible double depuis
**       la source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: s — objet source consulté en lecture seule par cette fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: number_parse_flexible_double().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                number_parse_flexible_double(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	number_parse_flexible_double(const char *s, double *out);

#endif
