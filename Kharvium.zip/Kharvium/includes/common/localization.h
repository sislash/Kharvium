/* ************************************************************************** */
/*                                                                            */
/*   localization.h                                    +:+      :+:    :+:   */
/*   Simple runtime language change (FR/EN). */
/*   French strings must be ASCII only (no accents). */
/*                                                                            */
/* ************************************************************************** */

#ifndef LOCALIZATION_H
# define LOCALIZATION_H

typedef enum e_language
{
    LANGUAGE_FRENCH = 0,
    LANGUAGE_ENGLISH = 1
}   t_language;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: localization_get_language — Retourne localization langue en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type t_language; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: localization_get_language().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                localization_get_language(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_language   localization_get_language(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: localization_set_language — Met à jour localization langue à partir
**       des valeurs courantes et conserve l’état partagé cohérent pour la
**       suite de la frame ou du calcul.
** Paramètre: lang — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: localization_set_language().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                localization_set_language(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void        localization_set_language(t_language lang);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: localization_toggle_language — Met à jour localization toggle langue
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: localization_toggle_language().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                localization_toggle_language(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void        localization_toggle_language(void);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: localization_load — Charge l’état associé à localization.
** Paramètre: options_cfg_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: localization_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                localization_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void        localization_load(const char *options_cfg_path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: localization_save — Sauvegarde l’état associé à localization.
** Paramètre: options_cfg_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: localization_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                localization_save(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void        localization_save(const char *options_cfg_path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: localization_translate — Met à jour localization translate en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: fr — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: en — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: localization_translate().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                localization_translate(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char  *localization_translate(const char *fr, const char *en);

# define LOCALIZE(FR, EN) localization_translate((FR), (EN))

#endif
