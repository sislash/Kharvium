/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   money.h                                           +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/12                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MONEY_H
# define MONEY_H

/*
** Fixed-point money helpers for Entropia Universe (RCE).
**
** 1 PED = 100 PEC = 100000 internal units.
** 1 internal unit = 0.00001 PED = 0.001 PEC.
** Money never uses float/double for persistence or accounting arithmetic.
*/

# include <stddef.h>
# include <stdint.h>

typedef int64_t				t_money;

# define MONEY_UPED_PER_PED		((t_money)100000)
# define MONEY_UPED_PER_PEC	((t_money)1000)

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_parse_ped — Analyse PED depuis la source fournie, contrôle le
**       format utile et ne renseigne la destination qu’avec des données
**       validées.
** Paramètre: s — objet source consulté en lecture seule par cette fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: money_parse_ped().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_parse_ped(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			money_parse_ped(const char *s, t_money *out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_parse_flexible — Analyse flexible depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: s — objet source consulté en lecture seule par cette fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: money_parse_flexible().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_parse_flexible(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			money_parse_flexible(const char *s, t_money *out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_from_ped_double — Construit à partir de PED double en
**       appliquant les validations, bornes et
**       effets explicitement définis par ce module.
** Paramètre: ped — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne un montant monétaire entier avec saturation explicite
**         des dépassements, compatible avec la précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les limites des entiers sont traitées
**             explicitement avant tout dépassement.
** --- Liens API auto-vérifiés ---
** Implémentation: money_from_ped_double().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_from_ped_double(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	money_from_ped_double(double ped);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_to_ped_double — Convertit vers PED double en appliquant les
**       validations, bornes et effets explicitement
**       définis par ce module.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: money_to_ped_double().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_to_ped_double(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double		money_to_ped_double(t_money v);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_format_ped_5_decimals — Formate PED 5 decimals dans le buffer
**       ou la représentation demandée sans dépasser la capacité fournie par
**       l’appelant.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: money_format_ped_5_decimals().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_format_ped_5_decimals(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void			money_format_ped_5_decimals(char *dst, size_t cap, t_money v);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_format_ped_4_decimals — Formate PED 4 decimals dans le buffer
**       ou la représentation demandée sans dépasser la capacité fournie par
**       l’appelant.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: money_format_ped_4_decimals().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_format_ped_4_decimals(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void			money_format_ped_4_decimals(char *dst, size_t cap, t_money v);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_format_ped_2_decimals — Formate PED 2 decimals dans le buffer
**       ou la représentation demandée sans dépasser la capacité fournie par
**       l’appelant.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: money_format_ped_2_decimals().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_format_ped_2_decimals(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void			money_format_ped_2_decimals(char *dst, size_t cap, t_money v);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_to_pec_rounded — Convertit vers pec rounded en appliquant les
**       validations, bornes et effets explicitement
**       définis par ce module.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne le résultat de type long long; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: money_to_pec_rounded().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_to_pec_rounded(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
long long		money_to_pec_rounded(t_money v);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_abs_i64_unsigned — Met à jour abs i64 unsigned en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type uint64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les limites des entiers sont traitées explicitement avant
**             tout dépassement.
** --- Liens API auto-vérifiés ---
** Implémentation: money_abs_i64_unsigned().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_abs_i64_unsigned(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
uint64_t		money_abs_i64_unsigned(int64_t value);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_add — Ajoute l’état associé à montant.
** Paramètre: a — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: b — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne un montant monétaire entier avec saturation explicite
**         des dépassements, compatible avec la précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les limites des entiers sont traitées explicitement avant
**             tout dépassement.
** --- Liens API auto-vérifiés ---
** Implémentation: money_add().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_add(); résolution indirecte possible pour callbacks
**                et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	money_add(t_money a, t_money b);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_subtract — Met à jour subtract en appliquant explicitement les
**       paramètres, bornes et invariants décrits par le contrat de cette
**       fonction.
** Paramètre: a — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: b — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne un montant monétaire entier avec saturation explicite
**         des dépassements, compatible avec la précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les limites des entiers sont traitées explicitement avant
**             tout dépassement.
** --- Liens API auto-vérifiés ---
** Implémentation: money_subtract().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_subtract(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	money_subtract(t_money a, t_money b);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: money_apply_markup — Applique l’état du module en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: base — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: multiplier — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: money_apply_markup().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                money_apply_markup(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	money_apply_markup(t_money base, int64_t mu_mul_1e4);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ratio_parse_fixed_1e4 — Analyse ratio fixed 1e4 depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: s — objet source consulté en lecture seule par cette fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: ratio_parse_fixed_1e4().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ratio_parse_fixed_1e4(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			ratio_parse_fixed_1e4(const char *s, int64_t *out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: ratio_format_fixed_1e4 — Formate ratio fixed 1e4 dans le buffer ou la
**       représentation demandée sans dépasser la capacité fournie par
**       l’appelant.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Paramètre: value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: ratio_format_fixed_1e4().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                ratio_format_fixed_1e4(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void			ratio_format_fixed_1e4(char *dst, size_t cap, int64_t value);

#endif
