/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   number_math.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 15:45:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 15:45:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NUMBER_MATH_H
# define NUMBER_MATH_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: integer_clamp — Borne l’état associé à integer.
** Paramètre: value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: minimum — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: maximum — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: integer_clamp().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                integer_clamp(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	integer_clamp(int value, int minimum, int maximum);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: number_is_nan — Détermine si number nan respecte la condition
**       attendue, sans modifier les données consultées.
** Paramètre: value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: number_is_nan().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                number_is_nan(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	number_is_nan(double value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: number_safe_divide — Met à jour number safe divide en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: numerator — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: denominator — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: number_safe_divide().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                number_safe_divide(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	number_safe_divide(double numerator, double denominator);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: number_ratio_percentage — Calcule number ratio percentage à partir
**       de l’état courant en respectant les
**       unités, bornes et conventions du module.
** Paramètre: numerator — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: denominator — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: number_ratio_percentage().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                number_ratio_percentage(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	number_ratio_percentage(double numerator, double denominator);

#endif
