/* ************************************************************************** */
/*                                                                            */
/*   options_file.h                                    +:+      :+:    :+:   */
/*   Tiny portable key=value options file helper. */
/*   - Preserves unknown keys when writing (read/modify/write).               */
/*   - ASCII only by design.                                                  */
/*                                                                            */
/* ************************************************************************** */

#ifndef OPTIONS_FILE_H
# define OPTIONS_FILE_H

# include <stddef.h>

/* Returns 1 if found, 0 if not found, -1 on error. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: options_file_get — Retourne l’état associé à options fichier.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_size — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: options_file_get().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                options_file_get(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int options_file_get(const char *path, const char *key, char *out,
	size_t outsz);

/* Returns 0 on success, -1 on error. Creates the file if missing. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: options_file_set — Définit l’état associé à options fichier.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: options_file_set().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                options_file_set(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int options_file_set(const char *path, const char *key, const char *value);

/* Convenience helpers */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: options_file_get_int — Retourne options int en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out_value — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : out_value.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: options_file_get_int().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                options_file_get_int(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int options_file_get_int(const char *path, const char *key, int *out_value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: options_file_set_int — Met à jour options int à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: options_file_set_int().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                options_file_set_int(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int options_file_set_int(const char *path, const char *key, int value);

#endif
