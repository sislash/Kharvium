/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   duration_format.h                                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 13:40:00 by tracker_loot       #+#    #+#            */
/*   Updated: 2026/08/28 13:40:00 by tracker_loot      ###   ########.fr      */
/*                                                                            */
/* ************************************************************************** */

#ifndef DURATION_FORMAT_H
# define DURATION_FORMAT_H

# include <stddef.h>
# include <stdint.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: duration_format_hours_minutes_seconds — Formate duration hours
**       minutes seconds dans le buffer ou la représentation demandée sans
**       dépasser la capacité fournie par l’appelant.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_size — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: milliseconds — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: duration_format_hours_minutes_seconds().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                duration_format_hours_minutes_seconds(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	duration_format_hours_minutes_seconds(char *out, size_t out_size,
	uint64_t milliseconds);

#endif
