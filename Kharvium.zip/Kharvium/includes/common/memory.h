/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   memory.h                                          +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MEMORY_H
# define MEMORY_H

# include <stddef.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: memory_zero — Met à jour memory zero en appliquant explicitement les
**       paramètres, bornes et invariants décrits par le contrat de cette
**       fonction.
** Paramètre: ptr — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: n — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ptr.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: memory_zero().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                memory_zero(); résolution indirecte possible pour callbacks
**                et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	memory_zero(void *ptr, size_t n);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: string_key_array_free — Libère l’état associé à string key array.
** Paramètre: arr — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: len — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Paramètre: stride — identifiant stable servant à retrouver ou associer
**            l’élément.
** Paramètre: key_offset — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : arr.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: string_key_array_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                string_key_array_free(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	string_key_array_free(void *arr, size_t len,
			size_t stride, size_t key_offset);

#endif
