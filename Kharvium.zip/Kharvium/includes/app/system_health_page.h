/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   system_health_page.h                                     +:+     :+: :+: */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/19                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PAGE_HEALTH_H
# define PAGE_HEALTH_H

# include "ui/ui_layout.h"
# include "ui/ui_widgets.h"
# include "app/app_ui_state.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: system_health_page_render — Rend l’état associé à système santé
**       page.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, ui, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; le rendu respecte les rectangles et capacités
**             fournis afin de rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: system_health_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                system_health_page_render(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	system_health_page_render(t_window *w, t_ui_state *ui, t_app *app,
			t_rect content);

#endif
