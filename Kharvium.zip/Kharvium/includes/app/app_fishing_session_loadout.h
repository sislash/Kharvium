/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_fishing_session_loadout.h                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_FISHING_SESSION_LOADOUT_H
# define APP_FISHING_SESSION_LOADOUT_H

# include "app/app_ui_state.h"
# include "hunt/hunt_rules.h"

int		app_fishing_loadout_is_ready(const t_app *app);
int		app_fishing_loadout_estimate_refresh(t_app *app,
			const t_catalog_registry *catalog);
void	app_fishing_session_loadout_capture(t_app *app,
		t_tracker_activity_mode mode);
void	app_fishing_session_loadout_clear(t_app *app);

#endif
