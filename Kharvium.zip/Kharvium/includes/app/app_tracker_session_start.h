/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_tracker_session_start.h                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_TRACKER_SESSION_START_H
# define APP_TRACKER_SESSION_START_H

# include "app/app_ui_state.h"
# include "platform/native_window.h"

# define APP_ACT_NONE 0
# define APP_ACT_START_TRACKER_LIVE 1
# define APP_ACT_START_TRACKER_REPLAY 2

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_tracker_start_live — centralise la demande de démarrage LIVE du
**       Tracker et applique les préconditions Hunt/Fishing avant le parser.
** Paramètre: window — fenêtre propriétaire des dialogues de sélection.
** Paramètre: app — état complet de l'application et du Tracker.
** Retour: aucun; le démarrage ou le dialogue requis est déclenché en place.
** Effets: peut ouvrir une sélection, démarrer le parser et figer le snapshot.
** Invariants: Fishing exige une vraie canne; Hunt exige une créature valide.
** --- Liens API auto-vérifiés ---
** Implémentation: app_tracker_start_live().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_tracker_start_live().
** --- Fin des liens API auto-vérifiés ---
*/
void	app_tracker_start_live(t_window *window, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_tracker_start_replay — centralise la demande REPLAY et applique
**       les mêmes préconditions métier que le démarrage LIVE.
** Paramètre: window — fenêtre propriétaire des dialogues de sélection.
** Paramètre: app — état complet de l'application et du Tracker.
** Retour: aucun; le démarrage ou le dialogue requis est déclenché en place.
** Effets: peut ouvrir une sélection, démarrer le parser et figer le snapshot.
** Invariants: aucune entrée UI ne doit pouvoir contourner les préconditions.
** --- Liens API auto-vérifiés ---
** Implémentation: app_tracker_start_replay().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_tracker_start_replay().
** --- Fin des liens API auto-vérifiés ---
*/
void	app_tracker_start_replay(t_window *window, t_app *app);

#endif
