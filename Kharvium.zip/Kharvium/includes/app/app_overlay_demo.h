/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_overlay_demo.h                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/19                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_OVERLAY_DEMO_H
# define APP_OVERLAY_DEMO_H

# include "app/app_state_fwd.h"

/*
** Runs a standalone overlay demo if "--overlay-demo" is present.
** Returns:
** - -1 if not requested
** - 0 on success
** - 1 on error
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_overlay_demo_run_if_requested — Met à jour demo run if requested
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: argc — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: core — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : argv, core.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_overlay_demo_run_if_requested().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_overlay_demo_run_if_requested(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_overlay_demo_run_if_requested(int argc, char **argv, t_app_state *core);

#endif
