/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_state.h                                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_STATE_H
# define APP_STATE_H

# include <stdatomic.h>
# include <stdio.h>

# include "app/app_state_fwd.h"
# include "platform/platform_thread.h"
# include "hunt/hunt_rules.h"

typedef struct s_parse_worker
{
	atomic_int	stop;
	atomic_int	running;
	int			mode_live;
	t_platform_thread	th;
	FILE		*log;
} 	t_parse_worker;

typedef struct s_global_events_worker
{
	atomic_int	stop;
	atomic_int	running;
	int			mode_live;
	t_platform_thread	th;
} 	t_global_events_worker;

typedef struct s_parse_state
{
	char			my_name[128];
	t_hunt_rules	rules;
} 	t_parse_state;

struct s_app_state
{
	t_parse_state			parse;
	t_parse_worker	parse_worker;
	t_global_events_worker	global_events_worker;
};

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_state_initialize — Initialise l’état associé à application
**       état.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_state_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_state_initialize(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_state_initialize(t_app_state *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_state_shutdown — Arrête proprement application état et libère
**       ses ressources.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_state_shutdown().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_state_shutdown(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_state_shutdown(t_app_state *app);

#endif
