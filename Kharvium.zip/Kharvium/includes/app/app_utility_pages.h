/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_utility_pages.h                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_UTILITY_PAGES_H
# define APP_UTILITY_PAGES_H

# include "app/app_ui_state.h"
# include "platform/native_window.h"
# include "ui/ui_widgets.h"
# include "ui/ui_geometry.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sessions_page_render — Rend l’état associé à sessions page.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : window, ui,
**         app.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: sessions_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sessions_page_render(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	sessions_page_render(t_window *window, t_ui_state *ui, t_app *app,
			t_rect content);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: maintenance_page_render — Rend l’état associé à maintenance page.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : window, ui,
**         app.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: maintenance_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                maintenance_page_render(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	maintenance_page_render(t_window *window, t_ui_state *ui, t_app *app,
			t_rect content);

#endif
