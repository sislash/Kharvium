/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_quit_guard.h                                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_QUIT_GUARD_H
# define APP_QUIT_GUARD_H

# include "app/app_ui_state.h"

typedef enum e_app_quit_guard
{
	APP_QUIT_SAFE = 0,
	APP_QUIT_UNSAVED_FINANCE,
	APP_QUIT_FINANCE_FORM,
	APP_QUIT_ACTIVITY_DRAFT
}   t_app_quit_guard;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_quit_guard_state — Consulte ou prépare l’état nécessaire à
**       application quit guard.
** Paramètre: app — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type t_app_quit_guard; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_quit_guard_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_quit_guard_state(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_app_quit_guard	app_quit_guard_state(const t_app *app);

#endif
