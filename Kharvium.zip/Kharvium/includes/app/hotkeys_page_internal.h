/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hotkeys_page_internal.h                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HOTKEYS_PAGE_INTERNAL_H
# define HOTKEYS_PAGE_INTERNAL_H

# include "app/app_ui_state.h"
# include "ui/ui_widgets.h"

typedef struct s_hotkeys_page_context
{
	t_window	*w;
	t_ui_state	*ui;
	t_app		*app;
	t_rect		panel;
	int			y;
	int			label_width;
} 	t_hotkeys_page_context;

typedef struct s_hotkey_field
{
	const char	*label;
	char		*buffer;
	int			buffer_size;
	int			id;
} 	t_hotkey_field;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkeys_page_ensure_loaded — Garantit raccourcis clavier page
**       loaded en appliquant les validations,
**       bornes et effets explicitement définis
**       par ce module.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkeys_page_ensure_loaded().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkeys_page_ensure_loaded(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hotkeys_page_ensure_loaded(t_app *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkeys_page_apply_rebind — Applique raccourcis clavier page rebind
**       en appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkeys_page_apply_rebind().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkeys_page_apply_rebind(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hotkeys_page_apply_rebind(t_hotkeys_page_context *ctx);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkeys_page_render_status — Retourne raccourcis clavier page render
**       état dans la forme directement utilisable par le rendu ou
**       l’appelant.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkeys_page_render_status().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkeys_page_render_status(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hotkeys_page_render_status(t_hotkeys_page_context *ctx);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkeys_page_render_toggle — Bascule l’état associé à raccourcis
**       page render.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkeys_page_render_toggle().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkeys_page_render_toggle(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hotkeys_page_render_toggle(t_hotkeys_page_context *ctx);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkeys_page_render_values — Rend raccourcis clavier page valeurs
**       dans le contexte graphique courant en respectant la géométrie, le
**       clipping et l’état des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkeys_page_render_values().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkeys_page_render_values(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hotkeys_page_render_values(t_hotkeys_page_context *ctx);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkeys_page_render_fields — Rend raccourcis clavier page champs dans
**       le contexte graphique courant en respectant la géométrie, le
**       clipping et l’état des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkeys_page_render_fields().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkeys_page_render_fields(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hotkeys_page_render_fields(t_hotkeys_page_context *ctx);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkeys_page_render_actions — Rend raccourcis clavier page actions
**       dans le contexte graphique courant en respectant la géométrie, le
**       clipping et l’état des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkeys_page_render_actions().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkeys_page_render_actions(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hotkeys_page_render_actions(t_hotkeys_page_context *ctx);

#endif
