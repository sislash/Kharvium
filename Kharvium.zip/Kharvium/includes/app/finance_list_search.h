/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_list_search.h                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_LIST_SEARCH_H
# define FINANCE_LIST_SEARCH_H

typedef enum e_finance_list_sort
{
	FIN_LIST_SORT_ORIGINAL = 0,
	FIN_LIST_SORT_AZ,
	FIN_LIST_SORT_ZA
}t_finance_list_sort;

typedef struct s_finance_list_order_request
{
	const char		**items;
	int			count;
	t_finance_list_sort	mode;
	int			*order;
	int			capacity;
}t_finance_list_order_request;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_finance_list_find — Recherche l’état associé à application
**       finance liste.
** Paramètre: items — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: query — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: start — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_finance_list_find().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_finance_list_find(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_finance_list_find(const char **items, int count,
		const char *query, int start);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_finance_list_match_count — Compte l’état associé à application
**       finance liste match.
** Paramètre: items — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: query — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_finance_list_match_count().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_finance_list_match_count(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_finance_list_match_count(const char **items, int count,
		const char *query);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_finance_list_build_order — Construit liste order à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_finance_list_build_order().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_finance_list_build_order(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_finance_list_build_order(const t_finance_list_order_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_finance_list_order_position — Met à jour liste order position en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: order — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: source_index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_finance_list_order_position().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_finance_list_order_position(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_finance_list_order_position(const int *order, int count,
		int source_index);

#endif
