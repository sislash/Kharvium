/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_arguments.h                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 15:35:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 15:35:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_ARGUMENTS_H
# define APP_ARGUMENTS_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_argument_exists — Met à jour argument exists en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: argument_count — nombre d’éléments disponibles ou à traiter.
** Paramètre: arguments — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: option — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : arguments.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: app_argument_exists().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_argument_exists(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_argument_exists(int argument_count, char **arguments,
		const char *option);

#endif
