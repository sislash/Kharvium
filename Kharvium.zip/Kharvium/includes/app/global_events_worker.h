/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   global_events_worker.h                            +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef GLOBAL_EVENTS_WORKER_H
# define GLOBAL_EVENTS_WORKER_H

# include "app/app_state_fwd.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: global_events_thread_start_live — Démarre thread LIVE en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: global_events_thread_start_live().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                global_events_thread_start_live(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		global_events_thread_start_live(t_app_state *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: global_events_thread_start_replay — Démarre thread REPLAY en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: global_events_thread_start_replay().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                global_events_thread_start_replay(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		global_events_thread_start_replay(t_app_state *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: global_events_thread_stop — Arrête l’état associé à globaux
**       événements thread.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: global_events_thread_stop().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                global_events_thread_stop(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	global_events_thread_stop(t_app_state *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: global_events_thread_is_running — Détermine si thread running
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: app — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: global_events_thread_is_running().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                global_events_thread_is_running(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		global_events_thread_is_running(const t_app_state *app);

#endif
