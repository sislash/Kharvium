/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_page.h                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PAGE_FINANCE_H
# define PAGE_FINANCE_H

# include "app/app_ui_state.h"
# include "ui/ui_layout.h"
# include "ui/ui_widgets.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_page_is_active — Détermine si page actif respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_page_is_active().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_page_is_active(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		finance_page_is_active(t_page page);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_app_initialize — Initialise l’état associé à finance
**       application.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_app_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_app_initialize(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_app_initialize(t_app *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_finance_shutdown — Arrête proprement application finance et
**       libère ses ressources.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_finance_shutdown().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_finance_shutdown(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_finance_shutdown(t_app *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_finance_save — Sauvegarde l’état associé à application finance.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_finance_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_finance_save(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		app_finance_save(t_app *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_finance_reload — Recharge l’état associé à application finance.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_finance_reload().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_finance_reload(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		app_finance_reload(t_app *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_finance_request_reload — Recharge l’état associé à application
**       finance request.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_finance_request_reload().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_finance_request_reload(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_finance_request_reload(t_app *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_finance_view_reset — Réinitialise l’état associé à application
**       finance view.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: app_finance_view_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_finance_view_reset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_finance_view_reset(t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_dashboard_page_render — Rend l’état associé à finance
**       tableau de bord page.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w, ui, app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable; le rendu
**             respecte les rectangles et capacités fournis afin de rester
**             borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_dashboard_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_dashboard_page_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_dashboard_page_render(t_window *w, t_ui_state *ui,
			t_app *app, t_rect content);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_wallet_page_render — Rend l’état associé à finance
**       portefeuille page.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w, ui, app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable; le rendu
**             respecte les rectangles et capacités fournis afin de rester
**             borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_wallet_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_wallet_page_render(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_wallet_page_render(t_window *w, t_ui_state *ui,
			t_app *app, t_rect content);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_inventory_page_render — Rend l’état associé à finance
**       inventaire page.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w, ui, app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable; le rendu
**             respecte les rectangles et capacités fournis afin de rester
**             borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_inventory_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_inventory_page_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_inventory_page_render(t_window *w, t_ui_state *ui,
			t_app *app, t_rect content);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_trading_page_render — Rend l’état associé à finance trading
**       page.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w, ui, app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable; le rendu
**             respecte les rectangles et capacités fournis afin de rester
**             borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_trading_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_trading_page_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_trading_page_render(t_window *w, t_ui_state *ui,
			t_app *app, t_rect content);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipes_page_render — Rend l’état associé à finance recipes
**       page.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w, ui, app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable; le rendu
**             respecte les rectangles et capacités fournis afin de rester
**             borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipes_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipes_page_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_recipes_page_render(t_window *w, t_ui_state *ui,
			t_app *app, t_rect content);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_capital_page_render — Rend l’état associé à finance capital
**       page.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w, ui, app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable; le rendu
**             respecte les rectangles et capacités fournis afin de rester
**             borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_capital_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_capital_page_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_capital_page_render(t_window *w, t_ui_state *ui,
			t_app *app, t_rect content);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_page_render — Rend l’état associé à finance
**       activité page.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w, ui, app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable; le rendu
**             respecte les rectangles et capacités fournis afin de rester
**             borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_page_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_activity_page_render(t_window *w, t_ui_state *ui,
			t_app *app, t_rect content);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_analysis_page_render — Rend l’état associé à finance
**       analyse page.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : w, ui, app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable; le rendu
**             respecte les rectangles et capacités fournis afin de rester
**             borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_analysis_page_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_analysis_page_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_analysis_page_render(t_window *w, t_ui_state *ui,
			t_app *app, t_rect content);

#endif
