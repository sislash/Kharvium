/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   global_events_parser.h                            +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/25                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GLOBAL_EVENTS_PARSER_H
# define GLOBAL_EVENTS_PARSER_H

# include <stddef.h>

typedef struct s_global_events_event
{
    char	ts[32];      /* "YYYY-MM-DD HH:MM:SS" */
    char	type[32];    /* GLOB_MOB / HOF_MOB / ATH_MOB / GLOB_CRAFT / ... */
    char	name[128];   /* mob name OR item name */
    char	value[32];   /* "96" (PED) */
    char	raw[1024];   /* original line */
}	t_global_events_event;

/*
 * * Parse une ligne du chat.log.
 ** Retour:
 **  1 si un event globals/craft/rare item a ete reconnu
 **  0 sinon
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: global_events_parse_line — Analyse ligne depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : event.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: global_events_parse_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                global_events_parse_line(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	global_events_parse_line(const char *line, t_global_events_event *ev);

#endif
