/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   system_health_page_internal.h                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SYSTEM_HEALTH_PAGE_INTERNAL_H
# define SYSTEM_HEALTH_PAGE_INTERNAL_H

# include "monitor/system_health_monitor.h"
# include "app/app_ui_state.h"
# include "ui/ui_widgets.h"

typedef struct s_system_health_page_context
{
	t_window			*w;
	t_ui_state			*ui;
	t_monitor_health	health;
	uint64_t			now_ms;
	t_rect				io_panel;
	t_rect				latency_panel;
	t_rect				error_panel;
	int				body_text_h;
	int				body_line_h;
	int				small_text_h;
	int				top_panel_h;
} 	t_system_health_page_context;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: system_health_elapsed — Met à jour system health elapsed en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: now_ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: event_ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type uint64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: system_health_elapsed().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                system_health_elapsed(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
uint64_t	system_health_elapsed(uint64_t now_ms, uint64_t event_ms);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: system_health_level_color — Détermine la couleur utilisée par
**       système santé level.
** Paramètre: theme — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: level — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type unsigned int; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: system_health_level_color().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                system_health_level_color(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
unsigned int	system_health_level_color(const t_theme *theme,
				t_health_level level);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: system_health_level_label — Produit le libellé lisible
**       correspondant à système santé level.
** Paramètre: level — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: system_health_level_label().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                system_health_level_label(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*system_health_level_label(t_health_level level);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: system_health_format_bytes — Formate system health bytes dans le
**       buffer ou la représentation demandée sans dépasser la capacité
**       fournie par l’appelant.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_size — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: system_health_format_bytes().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                system_health_format_bytes(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	system_health_format_bytes(char *out, size_t out_size, long value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: system_health_draw_pill — Dessine system health pill dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: x — coordonnée ou dimension de la zone graphique concernée.
** Paramètre: y — coordonnée ou dimension de la zone graphique concernée.
** Paramètre: level — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; le rendu respecte les rectangles et capacités
**             fournis afin de rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: system_health_draw_pill().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                system_health_draw_pill(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	system_health_draw_pill(t_system_health_page_context *ctx,
			int x, int y, t_health_level level);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: system_health_render_io — Rend system health dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: system_health_render_io().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                system_health_render_io(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	system_health_render_io(t_system_health_page_context *ctx);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: system_health_render_latency — Rend system health latency dans le
**       contexte graphique courant en respectant la géométrie, le clipping
**       et l’état des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: system_health_render_latency().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                system_health_render_latency(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	system_health_render_latency(t_system_health_page_context *ctx);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: system_health_render_errors — Rend system health errors dans le
**       contexte graphique courant en respectant la géométrie, le clipping
**       et l’état des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : ctx.
** Invariants: le rendu respecte les rectangles et capacités fournis afin de
**             rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: system_health_render_errors().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                system_health_render_errors(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	system_health_render_errors(t_system_health_page_context *ctx);

#endif
