/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_selftest.h                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/19                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_SELFTEST_H
# define APP_SELFTEST_H

/*
 * CLI selftest (headless): validates writable root + config presence.
 *
 * Usage:
 *   kharvium --selftest
 *
 * Returns:
 *   -1 : not requested
 *    0 : selftest OK
 *    1 : selftest FAILED
 */

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_selftest_run_if_requested — Met à jour selftest run if requested
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: argc — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : argv.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_selftest_run_if_requested().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_selftest_run_if_requested(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_selftest_run_if_requested(int argc, char **argv);

#endif
