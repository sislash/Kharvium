/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hotkey_config.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HOTKEY_CONFIG_H
# define HOTKEY_CONFIG_H

# include <stddef.h>

typedef struct s_hotkey_config
{
	char	overlay_1[32];
	char	overlay_2[32];
	char	overlay_3[32];
	char	lock_1[32];
	char	lock_2[32];
	char	lock_3[32];
	int		enabled;
}   t_hotkey_config;

typedef struct s_hotkey_registration_lists
{
	char	*overlay;
	size_t	overlay_capacity;
	char	*lock;
	size_t	lock_capacity;
}   t_hotkey_registration_lists;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkey_config_set_defaults — Met à jour raccourci clavier defaults à
**       partir des valeurs courantes et conserve l’état partagé cohérent
**       pour la suite de la frame ou du calcul.
** Paramètre: config — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : config.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkey_config_set_defaults().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkey_config_set_defaults(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hotkey_config_set_defaults(t_hotkey_config *config);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkey_config_load — Charge l’état associé à raccourci
**       configuration.
** Paramètre: config — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : config.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkey_config_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkey_config_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hotkey_config_load(t_hotkey_config *config);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkey_config_save — Sauvegarde l’état associé à raccourci
**       configuration.
** Paramètre: config — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkey_config_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkey_config_save(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		hotkey_config_save(const t_hotkey_config *config);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hotkey_config_build_registration_lists — Construit raccourci clavier
**       registration lists à partir des paramètres fournis et initialise
**       tous les champs requis avant qu’ils soient lus par une autre
**       opération.
** Paramètre: config — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: lists — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : lists.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hotkey_config_build_registration_lists().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hotkey_config_build_registration_lists(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hotkey_config_build_registration_lists(const t_hotkey_config *config,
			t_hotkey_registration_lists *lists);

#endif
