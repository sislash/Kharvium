/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_brand.h                                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_BRAND_H
# define APP_BRAND_H

# define APP_BRAND_NAME "Kharvium"
# define APP_BRAND_NAME_UPPER "KHARVIUM"
# define APP_BINARY_NAME "kharvium"
# define APP_WINDOW_MIN_WIDTH 480
# define APP_WINDOW_MIN_HEIGHT 360

#endif
