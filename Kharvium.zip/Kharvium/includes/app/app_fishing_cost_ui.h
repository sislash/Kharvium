/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_fishing_cost_ui.h                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_FISHING_COST_UI_H
# define APP_FISHING_COST_UI_H

# include <stddef.h>
# include "fishing/fishing_loadout.h"

void	app_fishing_cost_format(char *output, size_t capacity,
		const t_fishing_loadout_estimate *estimate);

#endif
