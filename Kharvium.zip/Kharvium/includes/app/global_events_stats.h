/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   global_events_stats.h                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/25                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GLOBAL_EVENTS_STATS_H
# define GLOBAL_EVENTS_STATS_H

# include <stddef.h>

# define GLOBAL_EVENTS_TOP_MAX 10

typedef struct s_global_event_top_entry
{
    char	name[128];
    long	count;
    double	sum_ped;
}	t_global_event_top_entry;

typedef struct s_global_events_stats
{
    int		csv_has_header;
    long	data_lines_read;

    long	creature_events;
    double	creature_sum_ped;

    long	craft_events;
    double	craft_sum_ped;

    long	rare_events;
    double	rare_sum_ped;

    t_global_event_top_entry	top_mobs[GLOBAL_EVENTS_TOP_MAX];
    size_t			top_mobs_count;

    t_global_event_top_entry	top_crafts[GLOBAL_EVENTS_TOP_MAX];
    size_t			top_crafts_count;

    t_global_event_top_entry	top_rares[GLOBAL_EVENTS_TOP_MAX];
    size_t			top_rares_count;
}	t_global_events_stats;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: global_events_stats_compute — Calcule l’état associé à globaux
**       événements statistiques.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: start_line — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: global_events_stats_compute().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                global_events_stats_compute(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	global_events_stats_compute(const char *csv_path, long start_line,
                          t_global_events_stats *out);

#endif
