/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_cache_internal.h                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_CACHE_INTERNAL_H
# define APP_CACHE_INTERNAL_H

# include "app/app_ui_state.h"

# define APP_FEED_LINE_CAP 256

typedef struct s_app_feed_tail_request
{
	const char	*path;
	int			max_lines;
	char		(*output)[APP_FEED_LINE_CAP];
	int			output_capacity;
	int			*output_count;
} t_app_feed_tail_request;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_feed_format_line — Formate flux ligne dans le buffer ou la
**       représentation demandée sans dépasser la capacité fournie par
**       l’appelant.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: dst_size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_feed_format_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_feed_format_line(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		app_feed_format_line(char *dst, size_t dst_size, const char *line);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_feed_read_tail — Lit flux fin du fichier depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_feed_read_tail().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_feed_read_tail(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		app_feed_read_tail(const t_app_feed_tail_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_refresh_cached — Rafraîchit cached à partir des valeurs courantes
**       et conserve l’état partagé cohérent pour la suite de la frame ou du
**       calcul.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_refresh_cached().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_refresh_cached(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_refresh_cached(t_app *app);

#endif
