/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   page_layout.h                                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/19                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PAGE_LAYOUT_H
# define PAGE_LAYOUT_H

# include "platform/native_window.h"
# include "ui/ui_layout.h"
# include "ui/ui_widgets.h"

typedef struct s_page_header_text
{
	const char	*title;
	const char	*subtitle;
}t_page_header_text;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: page_layout_header_text — Construit ou transforme le texte utilisé
**       par page mise en page header.
** Paramètre: title — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: subtitle — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type t_page_header_text; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: page_layout_header_text().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                page_layout_header_text(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_page_header_text	page_layout_header_text(const char *title,
				const char *subtitle);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: page_layout_render_header — Rend page mise en page en-tête dans le
**       contexte graphique courant en respectant la géométrie, le clipping
**       et l’état des widgets fournis.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type t_rect; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut mettre à jour l’état UI et émettre les opérations de rendu
**         prévues par ce module; peut modifier les paramètres non const
**         suivants : window, ui.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; le rendu respecte les rectangles et capacités
**             fournis afin de rester borné dans la zone UI.
** --- Liens API auto-vérifiés ---
** Implémentation: page_layout_render_header().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                page_layout_render_header(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_rect			page_layout_render_header(t_window *window,
				t_ui_state *ui, t_rect content,
				t_page_header_text text);

#endif
