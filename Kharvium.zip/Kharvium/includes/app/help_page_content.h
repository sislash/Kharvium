/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   help_page_content.h                               +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HELP_PAGE_CONTENT_H
# define HELP_PAGE_CONTENT_H

# include "app/app_brand.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: help_page_french_lines — Construit ou traite les lignes appartenant
**       à help page french.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : count.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: help_page_french_lines().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                help_page_french_lines(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	**help_page_french_lines(int *count);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: help_page_english_lines — Construit ou traite les lignes
**       appartenant à help page english.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : count.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: help_page_english_lines().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                help_page_english_lines(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	**help_page_english_lines(int *count);

#endif
