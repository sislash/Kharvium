/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_navigation.h                                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_NAVIGATION_H
# define APP_NAVIGATION_H

# include "app/app_ui_state.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_cursor_for_page — Met à jour navigation curseur for
**       page en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_cursor_for_page().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_cursor_for_page(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_cursor_for_page(t_page page);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_page_for_cursor — Met à jour navigation page for
**       curseur en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: cursor — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: page — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : page.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_page_for_cursor().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_page_for_cursor(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_page_for_cursor(int cursor, t_page *page);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_page_is_valid — Détermine si navigation page valide
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_page_is_valid().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_page_is_valid(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_page_is_valid(t_page page);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_page_uses_modal_frame — Traite une frame complète de
**       application navigation page uses modale.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_page_uses_modal_frame().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_page_uses_modal_frame(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_page_uses_modal_frame(t_page page);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_page_is_tracker — Détermine si navigation page
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_page_is_tracker().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_page_is_tracker(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_page_is_tracker(t_page page);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_back_target — Met à jour navigation retour target en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: previous — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: target — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : target.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_back_target().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_back_target(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_back_target(t_page page, t_page previous,
		t_page *target);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_history_reset — Réinitialise l’état associé à
**       application navigation history.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_history_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_history_reset(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_navigation_history_reset(t_app *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_history_push — Ajoute navigation history dans la
**       collection concernée en respectant sa
**       capacité, son ordre et ses invariants
**       de propriété.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_history_push().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_history_push(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_navigation_history_push(t_app *app, t_page page);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_history_can_back — Détermine si navigation history
**       retour respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: app — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_history_can_back().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_history_can_back(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_history_can_back(const t_app *app);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_history_pop — Retire navigation history dans la
**       collection concernée en respectant sa
**       capacité, son ordre et ses invariants
**       de propriété.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: current — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: target — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : app, target.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_history_pop().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_history_pop(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_history_pop(t_app *app, t_page current,
		t_page *target);

#endif
