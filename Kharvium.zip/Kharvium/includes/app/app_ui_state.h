/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_ui_state.h                                          +:+      :+: :+: */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/19                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_UI_STATE_H
# define APP_UI_STATE_H

# include <stdint.h>

# include "app/app_state.h"
# include "app/hotkey_config.h"
# include "finance/finance_types.h"

/* Legacy data structs used by the UI state (keep compatibility). */
# include "analytics/hunt_stats.h"
# include "app/global_events_stats.h"
# include "config/weapon_config.h"
# include "config/fishing_rod_config.h"
# include "core/session_catalog.h"

/* -------------------------------------------------------------------------- */
/* UI pages */
/* -------------------------------------------------------------------------- */

# define APP_NAV_HISTORY_CAP 32
# define APP_FINANCE_VIEW_COUNT 8

typedef enum e_page
{
	PAGE_DASHBOARD = 0,
	PAGE_FINANCE_WALLET,
	PAGE_FINANCE_INVENTORY,
	PAGE_FINANCE_TRADING,
	PAGE_FINANCE_RECIPES,
	PAGE_FINANCE_CAPITAL,
	PAGE_FINANCE_ACTIVITY,
	PAGE_FINANCE_ANALYSIS,
	PAGE_HUNT,
	PAGE_GLOBAL_EVENTS,
	PAGE_GRAPH_LIVE,
	PAGE_SESSIONS,
	PAGE_CONFIG,
	PAGE_CONFIG_WEAPONS,
	PAGE_CONFIG_MARKUP,
	PAGE_HOTKEYS,
	PAGE_MAINTENANCE,
	PAGE_HELP,
	PAGE_HEALTH
}	t_page;

typedef enum e_finance_analysis_view
{
	FIN_ANALYSIS_RUNS = 0,
	FIN_ANALYSIS_CAPITAL = 1
}   t_finance_analysis_view;

typedef struct s_finance_view_state
{
	int		scroll;
	int		scroll2;
	int		page_scroll;
	int		selected;
	int		selected2;
	char	search[64];
	char	search2[64];
	int		sort;
	int		sort2;
	int		analysis_view;
}	t_finance_view_state;

typedef enum e_finance_form
{
	FIN_FORM_NONE = 0,
	FIN_FORM_SET_PED,
	FIN_FORM_ADD_ASSET,
	FIN_FORM_ADD_PRICE,
	FIN_FORM_ADD_STOCK,
	FIN_FORM_PURCHASE,
	FIN_FORM_SALE,
	FIN_FORM_DEPOSIT,
	FIN_FORM_WITHDRAWAL,
	FIN_FORM_ADD_RECIPE,
	FIN_FORM_ADD_STAGE,
	FIN_FORM_ADD_INGREDIENT,
	FIN_FORM_PRODUCTION_OUTPUT,
	FIN_FORM_ADD_EQUIPMENT,
	FIN_FORM_EQUIPMENT_DECAY,
	FIN_FORM_EQUIPMENT_REPAIR,
	FIN_FORM_WITHDRAWAL_RECEIVE,
	FIN_FORM_ACTIVITY_NEW,
	FIN_FORM_ACTIVITY_CONSUMABLE,
	FIN_FORM_ACTIVITY_DECAY,
	FIN_FORM_ACTIVITY_LOOT,
	FIN_FORM_CONFIRM_RELOAD,
	FIN_FORM_CONFIRM_ABANDON_PRODUCTION,
	FIN_FORM_CONFIRM_CANCEL_DEPOSIT,
	FIN_FORM_CONFIRM_CANCEL_WITHDRAWAL,
	FIN_FORM_CONFIRM_DISCARD_ACTIVITY
}	t_finance_form;

/* -------------------------------------------------------------------------- */
/* Main UI state */
/* -------------------------------------------------------------------------- */

typedef struct s_app
{
	t_app_state		*core;
	t_page		page;
	t_page		prev_page;
	t_page		nav_history[APP_NAV_HISTORY_CAP];
	int			nav_history_count;
	int			nav_cursor;
	int			nav_scroll;
	int			hunt_mode_live;
	int			global_events_mode_live;
	uint64_t	session_start_ms;

	/* caches */
	uint64_t	last_refresh_ms;
	long		last_offset;
	t_hunt_stats	hunt_stats;
	int			hunt_stats_ok;
	t_global_events_stats	global_events_stats;
	int			global_events_stats_ok;

	char		weapon_name[128];
	char		fishing_rod_name[128];
	t_fishing_loadout_snapshot	fishing_loadout;
	t_fishing_loadout_estimate	fishing_loadout_estimate;
	int			fishing_loadout_ready;
	int			fishing_loadout_estimate_ready;
	char		fishing_session_rod_name[128];
	t_fishing_loadout_snapshot	fishing_session_loadout;
	t_fishing_loadout_estimate	fishing_session_loadout_estimate;
	int			fishing_session_loadout_ready;
	int			fishing_session_loadout_estimate_ready;
	int			sweat_enabled;

	/* feed */
	char		hunt_feed_buf[32][256];
	const char	*hunt_feed_lines[32];
	int			hunt_feed_n;
	int			hunt_feed_scroll;
	int			hunt_info_scroll;

	char		global_events_feed_buf[24][256];
	const char	*global_events_feed_lines[24];
	int			global_events_feed_n;
	int			global_events_feed_scroll;
	int			global_events_info_scroll;

	/* Finance manager */
	t_finance_book	finance;
	int			finance_loaded;
	int			finance_dirty;
	int			finance_scroll;
	int			finance_scroll2;
	int			finance_page_scroll;
	int			finance_selected;
	int			finance_selected2;
	char			finance_search[64];
	char			finance_search2[64];
	int			finance_search_focus_id;
	int			finance_sort;
	int			finance_sort2;
	t_finance_form	finance_form;
	int			finance_confirm_index;
	int			finance_confirm_index2;
	int			finance_focus_id;
	char		finance_status[160];
	char		finance_name[FINANCE_NAME_CAP];
	char		finance_value[64];
	char		finance_value2[64];
	char		finance_quantity[64];
	char		finance_note[FINANCE_NOTE_CAP];
	char		finance_target[FINANCE_ACTIVITY_TARGET_CAP];
	char		finance_location[FINANCE_ACTIVITY_LOCATION_CAP];
	char		finance_setup[FINANCE_ACTIVITY_SETUP_CAP];
	t_finance_activity	finance_activity_draft;
	int			finance_activity_draft_active;
	t_finance_activity_kind	finance_activity_kind;
	t_finance_activity_input_kind	finance_input_kind;
	t_finance_activity_decay_kind	finance_decay_kind;
	t_finance_market_mode	finance_price_mode;
	t_finance_analysis_view	finance_analysis_view;
	t_finance_view_state	finance_views[APP_FINANCE_VIEW_COUNT];

	char		sessions_feed_buf[20][256];
	const char	*sessions_feed_lines[20];
	int			sessions_feed_n;
	int			sessions_feed_scroll;

	/* help page */
	int			help_scroll;

	/* Global hotkeys (best-effort): UI-visible state */
	int			hotkeys_mask;
	int			hotkeys_enabled;
	char		hotkey_overlay[32];
	char		hotkey_lock[32];

	/* configurable hotkeys (persisted in logs/options.cfg) */
	t_hotkey_config	hotkey_config;
	int			hotkey_config_loaded;
	int			hotkeys_focus_id;

	/* weapon picker overlay */
	int			weapon_picker_open;
	t_weapon_database	weapon_db;
	int			weapon_db_loaded;
	int			weapon_picker_selected;
	int			weapon_picker_scroll;

	/* fishing rod picker overlay */
	int			fishing_rod_picker_open;
	t_fishing_rod_database	fishing_rod_db;
	int			fishing_rod_db_loaded;
	t_catalog_registry	fishing_rod_catalog;
	int			fishing_rod_catalog_loaded;
	int			fishing_rod_picker_selected;
	int			fishing_rod_picker_scroll;
	int			fishing_rod_custom_mode;
	int			fishing_rod_custom_slot;
	int			fishing_rod_custom_selected;
	int			fishing_rod_custom_scroll;
	t_fishing_rod_preset	fishing_rod_custom_draft;

	/* session picker overlay */
	int			session_picker_open;
	t_sessions_list	session_list;
	int			session_list_loaded;
	int			session_picker_selected;
	int			session_picker_scroll;

	/* modal overlays (non-blocking) */
	int			modal_open;
	int			modal_kind;
	int			modal_selected;
	int			modal_action;
	int			modal_result;
	char		modal_title[64];
	char		modal_buf[8][256];
	const char	*modal_lines[8];
	int			modal_n;
	char		creature_input[128];
	int			creature_focus_id;

	/* session range view (loaded session) */
	int			session_range_active;
	long		session_range_start;
	long		session_range_end;
}	t_app;

#endif
