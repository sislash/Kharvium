/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_operations.h                              +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_OPERATIONS_H
# define FINANCE_OPERATIONS_H

# include "finance/finance_types.h"
# include <stdint.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_record_market_sample — Enregistre un prix courant et une
**       observation historique datée avec sa source.
** Paramètre: book — registre Finance recevant les deux enregistrements.
** Paramètre: price — observation de prix à rendre courante.
** Paramètre: timestamp — horodatage Unix de l’observation.
** Paramètre: source — origine textuelle courte de la cotation.
** Retour: Retourne 1 si l’opération complète réussit et 0 sinon.
** Effets: modifie les collections prices et market_samples du registre.
** Invariants: l’historique n’est jamais remplacé par la nouvelle cotation.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_record_market_sample().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_record_market_sample().
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_record_market_sample(t_finance_book *book,
		const t_finance_price *price, int64_t timestamp, const char *source);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_record_market_sample_with_provenance — Enregistre une
**       observation de marché avec sa référence de source, son niveau de
**       preuve et son niveau de complétude.
** Paramètre: book — registre Finance propriétaire de l'observation.
** Paramètre: price — valeur de marché courante à historiser.
** Paramètre: context — timestamp, libellé lisible et provenance
**            structurée.
** Retour: Retourne 1 si prix courant et historique sont enregistrés.
** Effets: modifie prices et market_samples.
** Invariants: aucune donnée de provenance inconnue n'est élevée
**             implicitement.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_record_market_sample_with_provenance().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_record_market_sample_with_provenance().
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_record_market_sample_with_provenance(t_finance_book *book,
		const t_finance_price *price,
		const t_finance_market_context *context);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_record_purchase — Met à jour enregistrement achat en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: purchase — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_record_purchase().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_record_purchase(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_record_purchase(t_finance_book *book,
		const t_finance_purchase *purchase);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_record_sale — Met à jour enregistrement vente en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: sale — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : book, sale.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_record_sale().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_record_sale(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_record_sale(t_finance_book *book, t_finance_sale *sale);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_record_auction_buy — Met à jour enregistrement enchère buy en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: buy — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : book, buy.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_record_auction_buy().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_record_auction_buy(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_record_auction_buy(t_finance_book *book,
		t_finance_auction_buy *buy);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_record_auction_sale — Met à jour enregistrement enchère vente
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: sale — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : book, sale.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_record_auction_sale().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_record_auction_sale(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_record_auction_sale(t_finance_book *book,
		t_finance_auction_sale *sale);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_record_culture — Met à jour enregistrement culture en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: culture — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : book, culture.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_record_culture().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_record_culture(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_record_culture(t_finance_book *book,
		t_finance_culture *culture);

#endif
