/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_equipment.h                               +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_EQUIPMENT_H
# define FINANCE_EQUIPMENT_H

# include "finance/finance_types.h"

#include "common/money.h"
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_equipment_register — Met à jour équipement register en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: equipment — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_equipment_register().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_equipment_register(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_equipment_register(t_finance_book *book,
		const t_finance_equipment *equipment);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_equipment_decay — Met à jour équipement decay en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: amount — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_equipment_decay().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_equipment_decay(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_equipment_decay(t_finance_book *book, const char *name,
		t_money amount, int64_t timestamp);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_equipment_repair — Répare équipement en appliquant les
**       validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: amount — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_equipment_repair().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_equipment_repair(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_equipment_repair(t_finance_book *book, const char *name,
		t_money amount, int64_t timestamp);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_equipment_enhancer_break — Met à jour équipement Enhancer
**       break en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: input — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_equipment_enhancer_break().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_equipment_enhancer_break(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_equipment_enhancer_break(t_finance_book *book,
		const t_finance_enhancer_break_input *input);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_equipment_cancel_event — Annule équipement événement et ne
**       modifie les écritures métier associées qu’après validation complète
**       des préconditions.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_equipment_cancel_event().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_equipment_cancel_event(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_equipment_cancel_event(t_finance_book *book, size_t index);

#endif
