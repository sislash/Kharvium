/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_book.h                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_BOOK_H
# define FINANCE_BOOK_H

# include "finance/finance_types.h"

#include "common/money.h"
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_initialize — Initialise l’état associé à finance
**       registre financier.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: opening_cash — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_initialize(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_book_initialize(t_finance_book *book, t_money opening_cash);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_initialize_new — Crée book initialize à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_initialize_new().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_initialize_new(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_book_initialize_new(t_finance_book *book);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_is_empty — Détermine si book empty respecte la condition
**       attendue, sans modifier les données consultées.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_is_empty().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_is_empty(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_is_empty(const t_finance_book *book);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_destroy — Détruit proprement l’état associé à finance
**       registre financier.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_destroy().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_destroy(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_book_destroy(t_finance_book *book);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_clone — Clone l’état associé à finance registre
**       financier.
** Paramètre: source — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: destination — registre Finance contenant les écritures et
**            agrégats métier.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : destination.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_clone().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_clone(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_clone(const t_finance_book *source,
		t_finance_book *destination);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_swap — Échange intégralement le contenu de deux
**       registres Finance sans dupliquer leurs
**       allocations ni modifier les données qu’ils
**       contiennent.
** Paramètre: left — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: right — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : left, right.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_swap().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_swap(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_book_swap(t_finance_book *left, t_finance_book *right);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_asset — Ajoute book actif dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_asset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_asset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_asset(t_finance_book *book,
		const t_finance_asset *asset);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_price — Ajoute book prix dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — règle de prix de marché courante utilisée pour la
**            valorisation.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_price().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_price(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_price(t_finance_book *book,
		const t_finance_price *price);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_source_record — Ajoute une source de provenance
**       identifiée au registre Finance sans dupliquer son identifiant.
** Paramètre: book — registre Finance propriétaire de la collection.
** Paramètre: record — description de source copiée dans le registre.
** Retour: Retourne 1 si l'ajout réussit et 0 si la source est invalide,
**         dupliquée ou si l'allocation échoue.
** Effets: peut agrandir la collection dynamique source_records.
** Invariants: source_id est strictement positif et unique dans le registre.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_source_record().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_source_record().
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_source_record(t_finance_book *book,
		const t_source_record *record);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_has_source_record — Vérifie l'existence d'un
**       identifiant
**       de provenance sans modifier le registre.
** Paramètre: book — registre Finance consulté en lecture seule.
** Paramètre: source_id — identifiant de provenance recherché.
** Retour: Retourne 1 si la source existe et 0 sinon.
** Effets: aucun.
** Invariants: seuls les éléments bornés par source_record_count sont lus.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_has_source_record().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_has_source_record().
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_has_source_record(const t_finance_book *book,
		int64_t source_id);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_market_sample — Ajoute une observation de prix
**       datée au registre sans effacer les observations précédentes.
** Paramètre: book — registre Finance propriétaire de la collection.
** Paramètre: sample — observation de prix copiée dans le registre.
** Retour: Retourne 1 en cas de succès et 0 en cas de paramètre ou allocation
**         invalide.
** Effets: peut agrandir la collection dynamique market_samples.
** Invariants: les prix de marché restent datés, sourcés et modifiables.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_market_sample().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_market_sample().
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_market_sample(t_finance_book *book,
		const t_finance_market_sample *sample);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_recipe — Ajoute book recette dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_recipe().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_recipe(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_recipe(t_finance_book *book,
		const t_finance_recipe *recipe);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_purchase — Ajoute book achat dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_purchase().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_purchase(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_purchase(t_finance_book *book,
		const t_finance_purchase *purchase);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_sale — Ajoute book vente dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_sale().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_sale(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_sale(t_finance_book *book,
		const t_finance_sale *sale);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_auction_sale — Ajoute book enchère vente dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_auction_sale().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_auction_sale(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_auction_sale(t_finance_book *book,
		const t_finance_auction_sale *sale);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_auction_buy — Ajoute book enchère buy dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_auction_buy().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_auction_buy(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_auction_buy(t_finance_book *book,
		const t_finance_auction_buy *buy);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_culture — Ajoute book culture dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_culture().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_culture(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_culture(t_finance_book *book,
		const t_finance_culture *culture);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_production — Ajoute book production dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_production().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_production(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_production(t_finance_book *book,
		const t_finance_production *production);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_cash_transaction — Ajoute book trésorerie
**       transaction dans la collection concernée en respectant sa capacité,
**       son ordre logique et la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_cash_transaction().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_cash_transaction(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_cash_transaction(t_finance_book *book,
		const t_finance_cash_tx *tx);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_deposit — Ajoute book dépôt dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_deposit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_deposit(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_deposit(t_finance_book *book,
		const t_finance_deposit *deposit);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_withdrawal — Ajoute book retrait dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_withdrawal().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_withdrawal(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_withdrawal(t_finance_book *book,
		const t_finance_withdrawal *withdrawal);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_equipment — Ajoute book équipement dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_equipment().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_equipment(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_equipment(t_finance_book *book,
		const t_finance_equipment *equipment);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_equipment_event — Ajoute book équipement événement
**       dans la collection concernée en respectant sa capacité, son ordre
**       logique et la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_equipment_event().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_equipment_event(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_equipment_event(t_finance_book *book,
		const t_finance_equipment_event *event);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_activity — Ajoute book activité dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_activity().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_activity(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_activity(t_finance_book *book,
		const t_finance_activity *activity);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_add_snapshot — Ajoute book snapshot dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_add_snapshot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_add_snapshot(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_add_snapshot(t_finance_book *book,
		const t_finance_snapshot *snapshot);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_find_price — Recherche book prix dans la collection ou
**       la source disponible et retourne l’absence selon la convention
**       explicite du module.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_find_price().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_find_price(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const t_finance_price	*finance_book_find_price(const t_finance_book *book,
				const char *name);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_find_recipe — Recherche book recette dans la collection
**       ou la source disponible et retourne l’absence selon la convention
**       explicite du module.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_find_recipe().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_find_recipe(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const t_finance_recipe	*finance_book_find_recipe(const t_finance_book *book,
				const char *name);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_find_recipe_mut — Recherche book recette mut dans la
**       collection ou la source disponible et retourne l’absence selon la
**       convention explicite du module.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_find_recipe_mut().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_find_recipe_mut(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_finance_recipe	*finance_book_find_recipe_mut(t_finance_book *book,
				const char *name);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_find_stock — Recherche book stock dans la collection ou
**       la source disponible et retourne l’absence selon la convention
**       explicite du module.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_find_stock().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_find_stock(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_finance_stock	*finance_book_find_stock(t_finance_book *book,
				const char *name);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_find_equipment — Recherche book équipement dans la
**       collection ou la source disponible et retourne l’absence selon la
**       convention explicite du module.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_find_equipment().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_find_equipment(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_finance_equipment	*finance_book_find_equipment(t_finance_book *book,
				const char *name);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_stock_add — Ajoute l’état associé à finance registre
**       financier stock.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: stock — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_stock_add().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_stock_add(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_stock_add(t_finance_book *book,
		const t_finance_stock *stock);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_stock_take — Met à jour book stock take en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: quantity — quantité d’unités à traiter; les préconditions du
**            module encadrent les valeurs invalides.
** Paramètre: cost_out — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book, cost_out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_stock_take().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_stock_take(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_stock_take(t_finance_book *book, const char *name,
		int64_t quantity, t_money *cost_out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_stock_cost — Calcule le coût correspondant à finance
**       registre financier stock.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: quantity — quantité d’unités à traiter; les préconditions du
**            module encadrent les valeurs invalides.
** Paramètre: cost_out — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : cost_out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_stock_cost().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_stock_cost(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_stock_cost(const t_finance_book *book, const char *name,
		int64_t quantity, t_money *cost_out);

#endif
