/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_capital.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_CAPITAL_H
# define FINANCE_CAPITAL_H

# include "finance/finance_types.h"

#include "common/money.h"
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_deposit_record — Enregistre l’état associé à finance dépôt.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: deposit — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: index_out — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book,
**         index_out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_deposit_record().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_deposit_record(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_deposit_record(t_finance_book *book,
		const t_finance_deposit *deposit, size_t *index_out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_deposit_cancel — Annule l’état associé à finance dépôt.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_deposit_cancel().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_deposit_cancel(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_deposit_cancel(t_finance_book *book, size_t index);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_withdrawal_default_fee — Calcule les frais MindArk par
**       défaut d’un retrait en appliquant
**       le pourcentage prévu et le minimum
**       réglementaire du modèle.
** Paramètre: requested_uPED — montant en représentation entière fixe;
**            aucune valeur flottante persistante n’est requise.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_withdrawal_default_fee().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_withdrawal_default_fee(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_withdrawal_default_fee(t_money requested_uPED);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_withdrawal_request — Enregistre une nouvelle demande de
**       retrait après validation de sa
**       cohérence et de la disponibilité du
**       capital, puis retourne son index.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: withdrawal — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: index_out — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book,
**         index_out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_withdrawal_request().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_withdrawal_request(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_withdrawal_request(t_finance_book *book,
		const t_finance_withdrawal *withdrawal, size_t *index_out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_withdrawal_commit — Valide et applique l’état associé à
**       finance retrait.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_withdrawal_commit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_withdrawal_commit(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_withdrawal_commit(t_finance_book *book, size_t index,
		int64_t timestamp);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_withdrawal_receive — Enregistre la réception de retrait et
**       met à jour les états associés
**       uniquement lorsque les validations
**       métier requises réussissent.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: received — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_withdrawal_receive().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_withdrawal_receive(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_withdrawal_receive(t_finance_book *book, size_t index,
		const t_finance_withdrawal *received);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_withdrawal_cancel — Annule l’état associé à finance
**       retrait.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_withdrawal_cancel().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_withdrawal_cancel(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_withdrawal_cancel(t_finance_book *book, size_t index);

#endif
