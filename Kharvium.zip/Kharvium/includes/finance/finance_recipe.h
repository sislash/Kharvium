/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_recipe.h                                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_RECIPE_H
# define FINANCE_RECIPE_H

# include "finance/finance_types.h"

typedef struct s_finance_recipe_setup
{
	const char			*name;
	t_finance_recipe_kind	kind;
	const char			*product_item;
	int64_t				reference_output_quantity;
}   t_finance_recipe_setup;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_initialize — Initialise l’état associé à finance
**       recette.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: setup — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_initialize(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_recipe_initialize(t_finance_recipe *recipe,
		const t_finance_recipe_setup *setup);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_add_stage — Ajoute recette étape dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_add_stage().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_add_stage(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_recipe_add_stage(t_finance_recipe *recipe, const char *name);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_add_item — Ajoute recette objet dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: stage_index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: item — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_add_item().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_add_item(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_recipe_add_item(t_finance_recipe *recipe, size_t stage_index,
		const t_finance_recipe_item *item);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_remove_item — Supprime recette objet dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: stage_index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: item_index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_remove_item().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_remove_item(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_recipe_remove_item(t_finance_recipe *recipe,
		size_t stage_index, size_t item_index);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_remove_empty_stage — Supprime recette empty étape dans
**       la collection concernée en respectant sa capacité, son ordre logique
**       et la propriété de ses éléments.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: stage_index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_remove_empty_stage().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_remove_empty_stage(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_recipe_remove_empty_stage(t_finance_recipe *recipe,
		size_t stage_index);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_set_archived — Met à jour recette archived à partir
**       des valeurs courantes et conserve l’état partagé cohérent pour la
**       suite de la frame ou du calcul.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: archived — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_set_archived().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_set_archived(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_recipe_set_archived(t_finance_recipe *recipe, int archived);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_best — Met à jour recette best en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: kind — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: output_quantity — quantité d’unités à traiter; les
**            préconditions du module encadrent les valeurs invalides.
** Paramètre: quote_out — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut modifier les paramètres non const suivants : quote_out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_best().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_best(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const t_finance_recipe	*finance_recipe_best(const t_finance_book *book,
		t_finance_recipe_kind kind, int64_t output_quantity,
		t_finance_recipe_quote *quote_out);

#endif
