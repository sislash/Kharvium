/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_calculations.h                            +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_CALCULATIONS_H
# define FINANCE_CALCULATIONS_H

# include "finance/finance_types.h"

#include "common/money.h"
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_price_market_unit — Calcule la valeur de marché courante
**       d’une seule unité.
** Paramètre: price — règle de prix de marché courante utilisée pour la
**            valorisation.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_price_market_unit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_price_market_unit(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_price_market_unit(const t_finance_price *price);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_price_market_total — Calcule la valeur totale au prix de
**       marché courant pour la quantité demandée.
** Paramètre: price — règle de prix de marché courante utilisée pour la
**            valorisation.
** Paramètre: quantity — quantité d’unités à traiter; les préconditions du
**            module encadrent les valeurs invalides.
** Retour: Retourne un montant monétaire entier avec saturation explicite
**         des dépassements, compatible avec la précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les limites des entiers sont traitées
**             explicitement avant tout dépassement; les montants
**             persistants restent en représentation entière fixe, sans
**             dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_price_market_total().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_price_market_total(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_price_market_total(const t_finance_price *price,
				int64_t quantity);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_purchase_total — Calcule le total correspondant à finance
**       achat.
** Paramètre: purchase — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne un montant monétaire entier avec saturation explicite
**         des dépassements, compatible avec la précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les limites des entiers sont traitées
**             explicitement avant tout dépassement; les montants
**             persistants restent en représentation entière fixe, sans
**             dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_purchase_total().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_purchase_total(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_purchase_total(const t_finance_purchase *purchase);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_trade_terminal_cost — Calcule le coût correspondant
**       à finance recette transactions terminal.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: recipe — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_trade_terminal_cost().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_trade_terminal_cost(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_recipe_trade_terminal_cost(const t_finance_book *book,
				const t_finance_recipe *recipe);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_reference_cost — Calcule le coût correspondant à
**       finance recette reference.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: recipe — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_reference_cost().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_reference_cost(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_recipe_reference_cost(const t_finance_book *book,
				const t_finance_recipe *recipe);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_stage_trade_terminal_cost — Calcule le coût
**       correspondant à finance recette stage transactions terminal.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: stage — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_stage_trade_terminal_cost().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_stage_trade_terminal_cost(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_recipe_stage_trade_terminal_cost(const t_finance_book *book,
				const t_finance_recipe_stage *stage);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_stage_reference_cost — Calcule le coût correspondant
**       à finance recette stage reference.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: stage — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_stage_reference_cost().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_stage_reference_cost(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_recipe_stage_reference_cost(const t_finance_book *book,
				const t_finance_recipe_stage *stage);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_cost — Calcule le coût correspondant à finance
**       recette.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: recipe — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_cost().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_cost(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_recipe_cost(const t_finance_book *book,
				const t_finance_recipe *recipe);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_recipe_quote — Calcule un devis de recette Finance à partir
**       des ingrédients, quantités, prix de marché
**       et paramètres économiques applicables.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: recipe — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: quote — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : quote.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_recipe_quote().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_recipe_quote(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			finance_recipe_quote(const t_finance_book *book,
				const t_finance_recipe *recipe,
				t_finance_recipe_quote *quote);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_stock_market_value — Calcule ou retourne la valeur associée
**       à finance stock marché.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_stock_market_value().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_stock_market_value(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	finance_stock_market_value(const t_finance_book *book);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_projection_build — Construit l’état associé à finance
**       projection.
** Paramètre: projection — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : projection.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_projection_build().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_projection_build(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			finance_projection_build(t_finance_projection *projection);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_calculate — Calcule l’état associé à finance
**       activité.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : activity.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_calculate().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_calculate(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		finance_activity_calculate(t_finance_activity *activity);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_summary_build — Construit l’état associé à finance
**       synthèse.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: summary — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : summary.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_summary_build().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_summary_build(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		finance_summary_build(const t_finance_book *book,
				t_finance_summary *summary);

#endif
