/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_activity.h                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_ACTIVITY_H
# define FINANCE_ACTIVITY_H

# include "finance/finance_types.h"

#include "common/money.h"
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_initialize — Initialise l’état associé à finance
**       activité.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: kind — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : activity.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_initialize(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_activity_initialize(t_finance_activity *activity,
		t_finance_activity_kind kind, int64_t timestamp);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_set_details — Met à jour activité details à partir
**       des valeurs courantes et conserve l’état partagé cohérent pour la
**       suite de la frame ou du calcul.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: target — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: location — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : activity.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_set_details().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_set_details(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_activity_set_details(t_finance_activity *activity,
		const char *name, const char *target, const char *location);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_set_setup — Configure l’état associé à finance
**       activité set.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: setup — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : activity.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_set_setup().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_set_setup(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	finance_activity_set_setup(t_finance_activity *activity,
		const char *setup);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_add_consumable — Ajoute activité consommable dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: item — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: quantity — quantité d’unités à traiter; les préconditions du
**            module encadrent les valeurs invalides.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : activity.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_add_consumable().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_add_consumable(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_activity_add_consumable(t_finance_activity *activity,
		const char *item, int64_t quantity);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_add_consumable_kind — Ajoute activité consommable
**       kind dans la collection concernée en respectant sa capacité, son
**       ordre logique et la propriété de ses éléments.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: item — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: quantity — quantité d’unités à traiter; les préconditions du
**            module encadrent les valeurs invalides.
** Paramètre: kind — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : activity.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_add_consumable_kind().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_add_consumable_kind(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_activity_add_consumable_kind(t_finance_activity *activity,
		const char *item, int64_t quantity,
		t_finance_activity_input_kind kind);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_add_decay — Ajoute activité decay dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: equipment — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: amount — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : activity.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_add_decay().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_add_decay(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_activity_add_decay(t_finance_activity *activity,
		const char *equipment, t_money amount);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_add_decay_kind — Ajoute activité decay kind dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: equipment — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: amount — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: kind — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : activity.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_add_decay_kind().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_add_decay_kind(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_activity_add_decay_kind(t_finance_activity *activity,
		const char *equipment, t_money amount,
		t_finance_activity_decay_kind kind);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_add_loot — Ajoute activité loot dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: item — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: quantity — quantité d’unités à traiter; les préconditions du
**            module encadrent les valeurs invalides.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : activity.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_add_loot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_add_loot(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_activity_add_loot(t_finance_activity *activity,
		const char *item, int64_t quantity);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_commit — Valide et applique l’état associé à
**       finance activité.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: activity — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: index_out — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book, activity,
**         index_out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_commit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_commit(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_activity_commit(t_finance_book *book,
		t_finance_activity *activity, size_t *index_out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_kind_name — Retourne activité kind nom dans la forme
**       directement utilisable par le rendu ou l’appelant.
** Paramètre: kind — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_kind_name().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_kind_name(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*finance_activity_kind_name(t_finance_activity_kind kind);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_input_kind_name — Retourne activité entrée kind nom
**       dans la forme directement utilisable par le rendu ou l’appelant.
** Paramètre: kind — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_input_kind_name().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_input_kind_name(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*finance_activity_input_kind_name(
		t_finance_activity_input_kind kind);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_activity_decay_kind_name — Retourne activité decay kind nom
**       dans la forme directement utilisable par le rendu ou l’appelant.
** Paramètre: kind — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_activity_decay_kind_name().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_activity_decay_kind_name(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*finance_activity_decay_kind_name(
		t_finance_activity_decay_kind kind);

#endif
