/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   entropia_economy.h                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/31                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENTROPIA_ECONOMY_H
# define ENTROPIA_ECONOMY_H

/*
** Ce fichier ne contient volontairement aucun prix de marché.
** Les valeurs dépendant de l'offre et de la demande sont des observations
** datées gérées par Finance, jamais des constantes compilées dans Kharvium.
*/

#endif
