/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_production.h                              +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_PRODUCTION_H
# define FINANCE_PRODUCTION_H

# include "finance/finance_types.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_production_start — Démarre l’état associé à finance
**       production.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: recipe_name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Paramètre: index_out — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book,
**         index_out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_production_start().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_production_start(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_production_start(t_finance_book *book, const char *recipe_name,
		int64_t timestamp, size_t *index_out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_production_execute_next — Met à jour production execute
**       suivant en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: production_index — indice de l’élément ciblé dans la
**            collection concernée.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_production_execute_next().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_production_execute_next(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_production_execute_next(t_finance_book *book,
		size_t production_index);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_production_finalize — Finalise l’état associé à finance
**       production.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: production_index — indice de l’élément ciblé dans la
**            collection concernée.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Paramètre: output_quantity — quantité d’unités à traiter; les
**            préconditions du module encadrent les valeurs invalides.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_production_finalize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_production_finalize(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_production_finalize(t_finance_book *book,
		size_t production_index, int64_t timestamp, int64_t output_quantity);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_production_abandon — Abandonne l’état associé à finance
**       production.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: production_index — indice de l’élément ciblé dans la
**            collection concernée.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_production_abandon().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_production_abandon(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_production_abandon(t_finance_book *book,
		size_t production_index, int64_t timestamp);

#endif
