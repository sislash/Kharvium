/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_types.h                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_TYPES_H
# define FINANCE_TYPES_H

# include <stddef.h>
# include <stdint.h>

# include "common/money.h"
# include "core/data_provenance.h"
# include "core/entity_id.h"

# define FINANCE_NAME_CAP 96
# define FINANCE_CATEGORY_CAP 48
# define FINANCE_NOTE_CAP 160
# define FINANCE_CURRENCY_CAP 8
# define FINANCE_SOURCE_CAP 64
# define FINANCE_RECIPE_ITEMS 8
# define FINANCE_RECIPE_STAGES 8
# define FINANCE_STAGE_ITEMS 8
# define FINANCE_ACTIVITY_CONSUMABLES 16
# define FINANCE_ACTIVITY_DECAYS 8
# define FINANCE_ACTIVITY_LOOT 32
# define FINANCE_ACTIVITY_TARGET_CAP 96
# define FINANCE_ACTIVITY_LOCATION_CAP 96
# define FINANCE_ACTIVITY_SETUP_CAP 128
# define FINANCE_MU_TT 10000
# define FINANCE_FIAT_SCALE 10000

typedef enum e_finance_price_kind
{
	FIN_PRICE_COMPONENT = 0,
	FIN_PRICE_FRUIT = 1,
	FIN_PRICE_MINERAL = 2,
	FIN_PRICE_OTHER = 3
}   t_finance_price_kind;

/*
** Le mode FIN_MARKET_UNIT représente un prix de marché unitaire courant.
** Il n'est jamais considéré comme immuable : l'utilisateur peut le mettre
** à jour dès que l'offre, la demande ou les observations du marché changent.
** La valeur numérique 3 est conservée pour la compatibilité des sauvegardes.
*/
typedef enum e_finance_market_mode
{
	FIN_MARKET_PERCENT = 0,
	FIN_MARKET_TT_PLUS_UNIT = 1,
	FIN_MARKET_TT_PLUS_TOTAL = 2,
	FIN_MARKET_UNIT = 3
}   t_finance_market_mode;

typedef enum e_finance_auction_status
{
	FIN_AUCTION_PENDING = 0,
	FIN_AUCTION_SOLD = 1,
	FIN_AUCTION_EXPIRED = 2,
	FIN_AUCTION_WON = 3,
	FIN_AUCTION_LOST = 4
}   t_finance_auction_status;

typedef enum e_finance_cash_kind
{
	FIN_CASH_DEPOSIT = 0,
	FIN_CASH_WITHDRAWAL = 1,
	FIN_CASH_ADJUSTMENT = 2
}   t_finance_cash_kind;

typedef enum e_finance_markup_mode
{
	FIN_MARKUP_PERCENT = 0,
	FIN_MARKUP_TT_PLUS = 1,
	FIN_MARKUP_EXACT = 2
}   t_finance_markup_mode;

typedef enum e_finance_recipe_kind
{
	FIN_RECIPE_CULTURE = 0,
	FIN_RECIPE_CRAFT = 1
}   t_finance_recipe_kind;

typedef enum e_finance_production_status
{
	FIN_PRODUCTION_OPEN = 0,
	FIN_PRODUCTION_COMPLETED = 1,
	FIN_PRODUCTION_ABANDONED = 2
}   t_finance_production_status;

typedef enum e_finance_deposit_mode
{
	FIN_DEPOSIT_ACTUAL_PED = 0,
	FIN_DEPOSIT_RATE = 1
}   t_finance_deposit_mode;

typedef enum e_finance_record_status
{
	FIN_RECORD_ACTIVE = 0,
	FIN_RECORD_CANCELLED = 1
}   t_finance_record_status;

typedef enum e_finance_withdrawal_status
{
	FIN_WITHDRAWAL_REQUESTED = 0,
	FIN_WITHDRAWAL_COMMITTED = 1,
	FIN_WITHDRAWAL_RECEIVED = 2,
	FIN_WITHDRAWAL_CANCELLED = 3
}   t_finance_withdrawal_status;

typedef enum e_finance_equipment_event_kind
{
	FIN_EQUIPMENT_DECAY = 0,
	FIN_EQUIPMENT_REPAIR = 1,
	FIN_EQUIPMENT_ENHANCER_BREAK = 2
}   t_finance_equipment_event_kind;

typedef enum e_finance_activity_kind
{
	FIN_ACTIVITY_HUNT = 0,
	FIN_ACTIVITY_MINING = 1,
	FIN_ACTIVITY_CRAFT = 2,
	FIN_ACTIVITY_CULTURE = 3,
	FIN_ACTIVITY_OTHER = 4,
	FIN_ACTIVITY_FISHING = 5,
	FIN_ACTIVITY_KIND_COUNT = 6
}   t_finance_activity_kind;

typedef enum e_finance_activity_status
{
	FIN_ACTIVITY_DRAFT = 0,
	FIN_ACTIVITY_COMPLETED = 1,
	FIN_ACTIVITY_CANCELLED = 2
}   t_finance_activity_status;

typedef enum e_finance_activity_input_kind
{
	FIN_ACTIVITY_INPUT_OTHER = 0,
	FIN_ACTIVITY_INPUT_AMMO = 1,
	FIN_ACTIVITY_INPUT_HEALING = 2,
	FIN_ACTIVITY_INPUT_PROBE = 3,
	FIN_ACTIVITY_INPUT_MINING = 4,
	FIN_ACTIVITY_INPUT_CRAFT = 5,
	FIN_ACTIVITY_INPUT_CULTURE = 6,
	FIN_ACTIVITY_INPUT_FISHING = 7,
	FIN_ACTIVITY_INPUT_KIND_COUNT = 8
}   t_finance_activity_input_kind;

typedef enum e_finance_activity_decay_kind
{
	FIN_ACTIVITY_DECAY_OTHER = 0,
	FIN_ACTIVITY_DECAY_WEAPON = 1,
	FIN_ACTIVITY_DECAY_ARMOR = 2,
	FIN_ACTIVITY_DECAY_HEALING = 3,
	FIN_ACTIVITY_DECAY_FINDER = 4,
	FIN_ACTIVITY_DECAY_EXTRACTOR = 5,
	FIN_ACTIVITY_DECAY_AMPLIFIER = 6,
	FIN_ACTIVITY_DECAY_FISHING = 7,
	FIN_ACTIVITY_DECAY_KIND_COUNT = 8
}   t_finance_activity_decay_kind;

typedef enum e_finance_activity_tag
{
	FIN_ACTIVITY_TAG_TARGET = 0,
	FIN_ACTIVITY_TAG_LOCATION = 1,
	FIN_ACTIVITY_TAG_SETUP = 2
}   t_finance_activity_tag;

typedef struct s_finance_asset
{
	char		name[FINANCE_NAME_CAP];
	t_money	value_uPED;
}   t_finance_asset;

typedef struct s_finance_price
{
	char				name[FINANCE_NAME_CAP];
	t_entity_id			item_type_id;
	char				category[FINANCE_CATEGORY_CAP];
	t_finance_price_kind	kind;
	t_finance_market_mode	market_mode;
	t_money			tt_unit_uPED;
	int64_t				markup_mul_1e4;
	t_money			market_value_uPED;
	t_money			market_unit_uPED;
	t_money			craft_unit_uPED;
	int				archived;
}   t_finance_price;

typedef struct s_finance_market_sample
{
	char				item[FINANCE_NAME_CAP];
	t_entity_id			item_type_id;
	t_entity_id			world_id;
	char				source[FINANCE_SOURCE_CAP];
	int64_t				timestamp;
	t_finance_market_mode	market_mode;
	t_money			tt_unit_uPED;
	int64_t				markup_mul_1e4;
	t_money			market_value_uPED;
	t_money			market_unit_uPED;
	t_data_provenance_ref	provenance;
}   t_finance_market_sample;

typedef struct s_finance_market_context
{
	int64_t				timestamp;
	t_entity_id			world_id;
	char				source[FINANCE_SOURCE_CAP];
	t_data_provenance_ref	provenance;
}   t_finance_market_context;

typedef struct s_finance_recipe_item
{
	char		name[FINANCE_NAME_CAP];
	int64_t		quantity;
}   t_finance_recipe_item;

typedef struct s_finance_recipe_stage
{
	char				name[FINANCE_NAME_CAP];
	t_finance_recipe_item	items[FINANCE_STAGE_ITEMS];
	size_t				item_count;
}   t_finance_recipe_stage;

typedef struct s_finance_recipe
{
	char				name[FINANCE_NAME_CAP];
	t_finance_recipe_kind	kind;
	char				product_item[FINANCE_NAME_CAP];
	int64_t				reference_output_quantity;
	char				notes[FINANCE_NOTE_CAP];
	int				archived;
	t_finance_recipe_stage	stages[FINANCE_RECIPE_STAGES];
	size_t				stage_count;
	t_finance_recipe_item	items[FINANCE_RECIPE_ITEMS];
	size_t				item_count;
}   t_finance_recipe;

typedef struct s_finance_recipe_quote
{
	int64_t		reference_output_quantity;
	int64_t		requested_output_quantity;
	int64_t		batches_required;
	int64_t		covered_output_quantity;
	t_money	batch_tt_uPED;
	t_money	batch_reference_uPED;
	t_money	tt_per_output_uPED;
	t_money	reference_per_output_uPED;
	t_money	proportional_tt_uPED;
	t_money	proportional_reference_uPED;
	t_money	full_batches_tt_uPED;
	t_money	full_batches_reference_uPED;
	t_money	requested_output_tt_uPED;
	t_money	requested_output_market_uPED;
	t_money	covered_output_market_uPED;
	t_money	theoretical_margin_uPED;
}   t_finance_recipe_quote;

typedef struct s_finance_purchase
{
	int64_t		timestamp;
	t_entity_id	item_type_id;
	char		category[FINANCE_CATEGORY_CAP];
	char		item[FINANCE_NAME_CAP];
	int64_t		quantity;
	t_money	tt_unit_uPED;
	int64_t		markup_mul_1e4;
	t_money	total_uPED;
	char		party[FINANCE_NAME_CAP];
}   t_finance_purchase;

typedef struct s_finance_sale
{
	int64_t		timestamp;
	t_entity_id	item_type_id;
	char		category[FINANCE_CATEGORY_CAP];
	char		item[FINANCE_NAME_CAP];
	int64_t		quantity;
	t_money	revenue_uPED;
	t_money	cost_basis_uPED;
	t_money	profit_uPED;
	int64_t		markup_mul_1e4;
	char		party[FINANCE_NAME_CAP];
}   t_finance_sale;

typedef struct s_finance_auction_sale
{
	int64_t				timestamp;
	t_entity_id			item_type_id;
	char				item[FINANCE_NAME_CAP];
	int64_t				quantity;
	t_money			unit_tt_uPED;
	int64_t				markup_mul_1e4;
	t_money			listing_uPED;
	int64_t				buyout_markup_mul_1e4;
	t_money			buyout_uPED;
	t_money			final_uPED;
	t_money			fee_uPED;
	t_finance_auction_status	status;
	t_money			cost_basis_uPED;
	t_money			profit_uPED;
}   t_finance_auction_sale;

typedef struct s_finance_auction_buy
{
	int64_t				timestamp;
	t_entity_id			item_type_id;
	char				item[FINANCE_NAME_CAP];
	int64_t				quantity;
	t_money			bid_uPED;
	int64_t				markup_mul_1e4;
	t_finance_markup_mode	markup_mode;
	t_money			markup_plus_uPED;
	t_finance_auction_status	status;
	t_money			final_uPED;
}   t_finance_auction_buy;

typedef struct s_finance_stock
{
	char		item[FINANCE_NAME_CAP];
	t_entity_id	item_type_id;
	int64_t		quantity;
	t_money	cost_total_uPED;
	int		cost_known;
	t_money	tt_unit_uPED;
	int64_t		markup_mul_1e4;
}   t_finance_stock;

typedef struct s_finance_culture
{
	int64_t		timestamp;
	char		recipe[FINANCE_NAME_CAP];
	char		harvest_item[FINANCE_NAME_CAP];
	int64_t		harvest_quantity;
	t_money	total_cost_uPED;
	t_money	source_cost_uPED;
	t_money	sale_unit_uPED;
}   t_finance_culture;

typedef struct s_finance_production
{
	int64_t				id;
	int64_t				started_at;
	int64_t				finished_at;
	t_finance_production_status	status;
	t_finance_recipe		recipe_snapshot;
	size_t				next_stage;
	int64_t				actual_output_quantity;
	t_money			book_cost_uPED;
	t_money			tt_cost_uPED;
}   t_finance_production;

typedef struct s_finance_cash_tx
{
	int64_t			timestamp;
	t_finance_cash_kind	kind;
	t_money		amount_uPED;
	char			note[FINANCE_NOTE_CAP];
}   t_finance_cash_tx;

typedef struct s_finance_deposit
{
	int64_t			timestamp;
	char			currency[FINANCE_CURRENCY_CAP];
	int64_t			gross_fiat_x1e4;
	int64_t			fee_fiat_x1e4;
	t_money		ped_per_currency_uPED;
	t_money		ped_credited_uPED;
	t_finance_deposit_mode	mode;
	t_finance_record_status	status;
	char			note[FINANCE_NOTE_CAP];
}   t_finance_deposit;

typedef struct s_finance_withdrawal
{
	int64_t			requested_at;
	int64_t			committed_at;
	int64_t			received_at;
	t_money		requested_uPED;
	t_money		mindark_fee_uPED;
	t_finance_withdrawal_status	status;
	char			currency[FINANCE_CURRENCY_CAP];
	int64_t			received_fiat_x1e4;
	int64_t			bank_fee_fiat_x1e4;
	t_money		effective_ped_per_currency_uPED;
	char			note[FINANCE_NOTE_CAP];
}   t_finance_withdrawal;

typedef struct s_finance_equipment
{
	char		name[FINANCE_NAME_CAP];
	t_entity_id	item_type_id;
	char		catalog_item[FINANCE_NAME_CAP];
	t_money	tt_current_uPED;
	t_money	cumulative_decay_uPED;
	int		repairable;
}   t_finance_equipment;

typedef struct s_finance_equipment_event
{
	int64_t			sequence;
	int64_t			timestamp;
	char			equipment[FINANCE_NAME_CAP];
	char			source_item[FINANCE_NAME_CAP];
	t_finance_equipment_event_kind	kind;
	t_money		tt_before_uPED;
	t_money		amount_uPED;
	t_money		tt_after_uPED;
	t_money		shrapnel_return_uPED;
	t_money		book_loss_uPED;
	int64_t			linked_activity_id;
	int			cancelled;
	char			note[FINANCE_NOTE_CAP];
}   t_finance_equipment_event;

typedef struct s_finance_enhancer_break_input
{
	int64_t		timestamp;
	char		equipment[FINANCE_NAME_CAP];
	char		enhancer[FINANCE_NAME_CAP];
	t_money	enhancer_tt_uPED;
	t_money	acquisition_cost_uPED;
}   t_finance_enhancer_break_input;

typedef struct s_finance_activity_consumable
{
	char		item[FINANCE_NAME_CAP];
	t_entity_id	item_type_id;
	t_finance_activity_input_kind	kind;
	int64_t		quantity;
	t_money	tt_cost_uPED;
	t_money	book_cost_uPED;
}   t_finance_activity_consumable;

typedef struct s_finance_activity_decay
{
	char		equipment[FINANCE_NAME_CAP];
	t_finance_activity_decay_kind	kind;
	t_money	amount_uPED;
	t_money	book_cost_uPED;
}   t_finance_activity_decay;

typedef struct s_finance_activity_quality
{
	t_data_quality	tt_cost;
	t_data_quality	book_cost;
	t_data_quality	loot_tt;
	t_data_quality	loot_market;
	t_data_quality	tt_result;
	t_data_quality	basis_result;
	t_data_quality	market_result;
}   t_finance_activity_quality;

typedef struct s_finance_activity_loot
{
	char		item[FINANCE_NAME_CAP];
	t_entity_id	item_type_id;
	int64_t		quantity;
	t_money	tt_total_uPED;
	t_money	market_total_uPED;
}   t_finance_activity_loot;

typedef struct s_finance_activity
{
	int64_t			id;
	int64_t			timestamp;
	t_entity_id			world_id;
	t_finance_activity_kind	kind;
	char			name[FINANCE_NAME_CAP];
	char			target[FINANCE_ACTIVITY_TARGET_CAP];
	char			location[FINANCE_ACTIVITY_LOCATION_CAP];
	char			setup[FINANCE_ACTIVITY_SETUP_CAP];
	t_finance_activity_status	status;
	t_money		direct_ped_uPED;
	t_finance_activity_consumable	consumables[FINANCE_ACTIVITY_CONSUMABLES];
	size_t			consumable_count;
	t_finance_activity_decay	decays[FINANCE_ACTIVITY_DECAYS];
	size_t			decay_count;
	t_finance_activity_loot	loot[FINANCE_ACTIVITY_LOOT];
	size_t			loot_count;
	t_money		consumables_tt_uPED;
	t_money		consumables_book_uPED;
	t_money		decay_uPED;
	t_money		decay_book_uPED;
	t_money		loot_tt_uPED;
	t_money		loot_market_uPED;
	t_money		cycle_tt_uPED;
	t_money		book_cost_uPED;
	t_money		tt_result_uPED;
	t_money		basis_result_uPED;
	t_money		market_result_uPED;
	int64_t		tracker_session_id;
	t_finance_activity_quality	quality;
	char			note[FINANCE_NOTE_CAP];
}   t_finance_activity;

typedef struct s_finance_activity_aggregate
{
	size_t		run_count;
	t_money	direct_ped_uPED;
	t_money	input_book_uPED[FIN_ACTIVITY_INPUT_KIND_COUNT];
	t_money	input_tt_uPED[FIN_ACTIVITY_INPUT_KIND_COUNT];
	t_money	decay_uPED[FIN_ACTIVITY_DECAY_KIND_COUNT];
	t_money	decay_book_uPED[FIN_ACTIVITY_DECAY_KIND_COUNT];
	t_money	book_cost_uPED;
	t_money	cycle_tt_uPED;
	t_money	loot_tt_uPED;
	t_money	basis_loot_tt_uPED;
	t_money	loot_market_uPED;
	t_money	market_cycle_tt_uPED;
	t_money	tt_result_uPED;
	t_money	basis_result_uPED;
	t_money	market_result_uPED;
	size_t		tt_result_count;
	size_t		basis_result_count;
	size_t		market_result_count;
	double		tt_return_ratio;
	double		basis_return_ratio;
	double		market_return_ratio;
}   t_finance_activity_aggregate;

typedef struct s_finance_snapshot
{
	int64_t		day_key;
	t_money	ped_card_uPED;
	t_money	fortune_uPED;
	t_money	stock_market_uPED;
	t_money	capital_total_uPED;
	t_money	deposits_uPED;
	t_money	realized_profit_uPED;
	t_money	unrealized_gain_uPED;
}   t_finance_snapshot;

typedef struct s_finance_projection
{
	t_money	investment_uPED;
	t_money	cycle_cost_uPED;
	int64_t		yield_quantity;
	t_money	sale_unit_uPED;
	t_money	revenue_cycle_uPED;
	t_money	profit_cycle_uPED;
	int64_t		cycles_to_repay;
	int64_t		units_to_repay;
	t_money	working_capital_uPED;
}   t_finance_projection;

typedef struct s_finance_summary
{
	t_money	assets_uPED;
	t_money	purchases_uPED;
	t_money	sales_revenue_uPED;
	t_money	realized_profit_uPED;
	t_money	auction_fees_uPED;
	t_money	stock_cost_uPED;
	t_money	stock_market_uPED;
	size_t		stock_unknown_cost_lines;
	t_money	cash_balance_uPED;
	t_money	liquid_wealth_uPED;
	t_money	total_net_worth_uPED;
	t_money	deposits_uPED;
	t_money	withdrawal_reserved_uPED;
	t_money	withdrawal_transit_uPED;
	t_money	withdrawal_received_uPED;
	t_money	withdrawal_fees_uPED;
	t_money	capital_rce_adjusted_uPED;
	t_money	production_cost_uPED;
	t_money	activity_cycle_tt_uPED;
	t_money	activity_book_cost_uPED;
	t_money	activity_loot_tt_uPED;
	t_money	activity_loot_market_uPED;
	t_money	cumulative_decay_uPED;
	t_money	equipment_tt_uPED;
	t_money	unrealized_gain_uPED;
	double		repayment_ratio;
	double		liquid_roi_ratio;
	double		capital_roi_ratio;
}   t_finance_summary;

typedef struct s_finance_book
{
	t_money		opening_cash_uPED;
	t_finance_asset		*assets;
	size_t			asset_count;
	size_t			asset_cap;
	t_source_record		*source_records;
	size_t			source_record_count;
	size_t			source_record_cap;
	t_finance_price		*prices;
	size_t			price_count;
	size_t			price_cap;
	t_finance_market_sample	*market_samples;
	size_t			market_sample_count;
	size_t			market_sample_cap;
	t_finance_recipe	*recipes;
	size_t			recipe_count;
	size_t			recipe_cap;
	t_finance_purchase	*purchases;
	size_t			purchase_count;
	size_t			purchase_cap;
	t_finance_sale		*sales;
	size_t			sale_count;
	size_t			sale_cap;
	t_finance_auction_sale	*auction_sales;
	size_t			auction_sale_count;
	size_t			auction_sale_cap;
	t_finance_auction_buy	*auction_buys;
	size_t			auction_buy_count;
	size_t			auction_buy_cap;
	t_finance_stock		*stocks;
	size_t			stock_count;
	size_t			stock_cap;
	t_finance_culture	*cultures;
	size_t			culture_count;
	size_t			culture_cap;
	t_finance_production	*productions;
	size_t			production_count;
	size_t			production_cap;
	t_finance_cash_tx	*cash_txs;
	size_t			cash_tx_count;
	size_t			cash_tx_cap;
	t_finance_deposit	*deposits;
	size_t			deposit_count;
	size_t			deposit_cap;
	t_finance_withdrawal	*withdrawals;
	size_t			withdrawal_count;
	size_t			withdrawal_cap;
	t_finance_equipment	*equipment;
	size_t			equipment_count;
	size_t			equipment_cap;
	t_finance_equipment_event	*equipment_events;
	size_t			equipment_event_count;
	size_t			equipment_event_cap;
	t_finance_activity	*activities;
	size_t			activity_count;
	size_t			activity_cap;
	t_finance_snapshot	*snapshots;
	size_t			snapshot_count;
	size_t			snapshot_cap;
}   t_finance_book;

#endif
