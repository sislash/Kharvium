/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_persistence.h                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_PERSISTENCE_H
# define FINANCE_PERSISTENCE_H

# include "finance/finance_types.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_save — Sauvegarde l’état associé à finance registre
**       financier.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; effectue
**         directement des E/S fichier ou une modification de chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_save(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_save(const t_finance_book *book, const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_book_load — Charge l’état associé à finance registre
**       financier.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_book_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_book_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_book_load(t_finance_book *book, const char *path);

#endif
