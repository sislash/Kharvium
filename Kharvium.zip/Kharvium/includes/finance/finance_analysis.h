/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_analysis.h                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_ANALYSIS_H
# define FINANCE_ANALYSIS_H

# include "finance/finance_types.h"

typedef struct s_finance_analysis_filter
{
	int			filter_kind;
	t_finance_activity_kind	kind;
}   t_finance_analysis_filter;

typedef struct s_finance_recent_request
{
	size_t			max_runs;
	t_finance_analysis_filter	filter;
}   t_finance_recent_request;

typedef struct s_finance_period_request
{
	int64_t			start_time;
	int64_t			end_time;
	t_finance_analysis_filter	filter;
}   t_finance_period_request;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_analysis_recent — Met à jour analysis recent en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_analysis_recent().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_analysis_recent(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_analysis_recent(const t_finance_book *book,
		const t_finance_recent_request *request,
		t_finance_activity_aggregate *out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_analysis_period — Met à jour analysis period en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_analysis_period().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_analysis_period(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_analysis_period(const t_finance_book *book,
		const t_finance_period_request *request,
		t_finance_activity_aggregate *out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_analysis_tag — Met à jour analysis tag en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: tag — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_analysis_tag().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_analysis_tag(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_analysis_tag(const t_finance_book *book,
		t_finance_activity_tag tag, const char *value,
		t_finance_activity_aggregate *out);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_analysis_latest — Met à jour analysis latest en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_analysis_latest().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_analysis_latest(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const t_finance_activity	*finance_analysis_latest(
	const t_finance_book *book);

#endif
