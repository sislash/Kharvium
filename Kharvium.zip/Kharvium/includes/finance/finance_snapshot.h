/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   finance_snapshot.h                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FINANCE_SNAPSHOT_H
# define FINANCE_SNAPSHOT_H

# include "finance/finance_types.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: finance_snapshot_upsert — Ajoute ou met à jour l’entrée de finance
**       snapshot sans doublon.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: day_key — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: finance_snapshot_upsert().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                finance_snapshot_upsert(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	finance_snapshot_upsert(t_finance_book *book, int64_t day_key);

#endif
