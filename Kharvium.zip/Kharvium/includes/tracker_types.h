/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tracker_types.h                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TRACKER_TYPES_H
# define TRACKER_TYPES_H

# include <stdint.h>
# include <inttypes.h>

/*
 * Time: Unix epoch seconds.
 * Money: fixed-point integer only (no float/double in persistence).
 *
 * Tracker unit = uPED (1 PED = 100,000 uPED).
 * 1 uPED = 0.00001 PED = 0.001 PEC; 1 PEC = 1,000 uPED.
 */

typedef int64_t	t_unix_time;

typedef int64_t	t_uped;
typedef int64_t	t_pec;

# define TRACKER_UPED_PER_PED	((int64_t)100000)
# define TRACKER_PEC_PER_PED	((int64_t)100)
# define TRACKER_UPED_PER_PEC	((int64_t)1000)

/* printf helper (portable): printf("%" TRACKER_I64, (int64_t)x); */
# define TRACKER_I64			PRId64

/*
** Rôle: uped_from_pec — Construit à partir de uPED pec en appliquant les
**       validations, bornes et effets explicitement définis
**       par ce module.
** Paramètre: pec — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type inline t_uped; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        tracker_types.h -> uped_from_pec() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PEC.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static inline t_uped	uped_from_pec(t_pec pec)
{
	return (pec * TRACKER_UPED_PER_PEC);
}

/*
** Rôle: pec_from_uped — Construit à partir de pec uPED en appliquant les
**       validations, bornes et effets explicitement définis
**       par ce module.
** Paramètre: uped — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne le résultat de type inline t_pec; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        tracker_types.h -> pec_from_uped() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PEC.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static inline t_pec	pec_from_uped(t_uped uped)
{
	return (uped / TRACKER_UPED_PER_PEC);
}

/*
** Rôle: uped_is_pec_aligned — Détermine si uped pec aligned respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: uped — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne le résultat de type inline int; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        tracker_types.h -> uped_is_pec_aligned() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PEC.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static inline int	uped_is_pec_aligned(t_uped uped)
{
	return ((uped % TRACKER_UPED_PER_PEC) == 0);
}

typedef enum e_tracker_error
{
	TRACKER_OK = 0,
	TRACKER_ERROR_ALLOC = 1,
	TRACKER_ERROR_IO = 2,
	TRACKER_ERROR_PARSE = 3,
	TRACKER_ERROR_RANGE = 4,
	TRACKER_ERROR_STATE = 5
} 	t_tracker_error;

#endif
