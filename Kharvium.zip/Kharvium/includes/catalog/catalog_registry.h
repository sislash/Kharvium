/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   catalog_registry.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CATALOG_REGISTRY_H
# define CATALOG_REGISTRY_H

# include "core/entity_id.h"
# include "common/money.h"
# include <stddef.h>
# include <stdint.h>

# define CATALOG_NAME_CAP 96
# define CATALOG_CLASS_CAP 48
# define CATALOG_SCHEMA_VERSION 1
# define CATALOG_SKILL_CAP 96

typedef struct s_catalog_item
{
	t_entity_id	item_id;
	char		canonical_name[CATALOG_NAME_CAP];
	char		category[CATALOG_CLASS_CAP];
}   t_catalog_item;

typedef struct s_catalog_world
{
	t_entity_id	world_id;
	t_entity_id	parent_world_id;
	char		canonical_name[CATALOG_NAME_CAP];
	char		world_type[CATALOG_CLASS_CAP];
}   t_catalog_world;

typedef enum e_fishing_output_role
{
	FISHING_OUTPUT_UNKNOWN = 0,
	FISHING_OUTPUT_RAW_FISH = 1,
	FISHING_OUTPUT_FISH_SCRAP = 2,
	FISHING_OUTPUT_FAMILY_FISH_OIL = 3,
	FISHING_OUTPUT_GENERIC_FISH_OIL = 4,
	FISHING_OUTPUT_OTHER = 5
}   t_fishing_output_role;

typedef struct s_catalog_fishing_output
{
	t_entity_id			item_type_id;
	t_fishing_output_role	role;
	char				canonical_name[CATALOG_NAME_CAP];
}   t_catalog_fishing_output;

typedef struct s_catalog_fishing_skill
{
	char	canonical_name[CATALOG_SKILL_CAP];
}   t_catalog_fishing_skill;

typedef enum e_fishing_gear_slot
{
	FISHING_GEAR_SLOT_UNKNOWN = 0,
	FISHING_GEAR_SLOT_ROD = 1,
	FISHING_GEAR_SLOT_REEL = 2,
	FISHING_GEAR_SLOT_BLANK = 3,
	FISHING_GEAR_SLOT_LINE = 4,
	FISHING_GEAR_SLOT_LURE = 5
}   t_fishing_gear_slot;

typedef enum e_fishing_method
{
	FISHING_METHOD_UNKNOWN = 0,
	FISHING_METHOD_BAITFISHING = 1,
	FISHING_METHOD_CASTING = 2,
	FISHING_METHOD_ANGLING = 3,
	FISHING_METHOD_FLY = 4,
	FISHING_METHOD_DEEP_OCEAN = 5,
	FISHING_METHOD_REGULAR = 6
}   t_fishing_method;

typedef enum e_fishing_ammo_kind
{
	FISHING_AMMO_UNKNOWN = 0,
	FISHING_AMMO_SPOOL_CELL = 1,
	FISHING_AMMO_RESTRICTED_SPOOL_CELL = 2
}   t_fishing_ammo_kind;

typedef struct s_catalog_fishing_gear
{
	t_entity_id		item_type_id;
	t_fishing_gear_slot	slot;
	t_fishing_method	method;
	int32_t		strength_x100;
	int32_t		flexibility_x100;
	int32_t		reel_speed_x100;
	int32_t		line_length_cm;
	int32_t		lure_depth_cm;
	int32_t		lure_quality_x100;
	t_money		max_tt;
	t_money		decay_per_use;
	t_entity_id		ammo_item_type_id;
	int64_t		ammo_burn;
	char			canonical_name[CATALOG_NAME_CAP];
}   t_catalog_fishing_gear;

typedef struct s_catalog_fishing_ammo
{
	t_entity_id		item_type_id;
	t_fishing_ammo_kind	kind;
	t_money		unit_tt;
	int			tradeable;
	char			canonical_name[CATALOG_NAME_CAP];
}   t_catalog_fishing_ammo;

typedef struct s_catalog_registry
{
	t_catalog_item	*items;
	size_t		item_count;
	size_t		item_cap;
	t_catalog_world	*worlds;
	size_t		world_count;
	size_t		world_cap;
	t_catalog_fishing_output	*fishing_outputs;
	size_t				fishing_output_count;
	size_t				fishing_output_cap;
	t_catalog_fishing_skill	*fishing_skills;
	size_t				fishing_skill_count;
	size_t				fishing_skill_cap;
	t_catalog_fishing_gear	*fishing_gear;
	size_t				fishing_gear_count;
	size_t				fishing_gear_cap;
	t_catalog_fishing_ammo	*fishing_ammo;
	size_t				fishing_ammo_count;
	size_t				fishing_ammo_cap;
}   t_catalog_registry;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_registry_initialize — Initialise un registre de catalogues
**       vide dont le contenu pourra être chargé depuis des données externes.
** Paramètre: registry — registre propriétaire des collections catalogues.
** Retour: Ne retourne rien.
** Effets: remet les compteurs et pointeurs du registre à zéro.
** Invariants: après l'appel, destroy peut être appelé sans condition.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_registry_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_registry_initialize().
** --- Fin des liens API auto-vérifiés ---
*/
void	catalog_registry_initialize(t_catalog_registry *registry);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_registry_destroy — Libère toutes les collections dynamiques
**       appartenant au registre puis le remet dans un état vide valide.
** Paramètre: registry — registre propriétaire des collections catalogues.
** Retour: Ne retourne rien.
** Effets: libère items et worlds lorsque présents.
** Invariants: aucun pointeur conservé vers les tableaux n'est valide après
**             l'appel.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_registry_destroy().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_registry_destroy().
** --- Fin des liens API auto-vérifiés ---
*/
void	catalog_registry_destroy(t_catalog_registry *registry);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_registry_add_item — Ajoute une définition d'item canonique
**       sans accepter d'identifiant ou de nom déjà utilisé.
** Paramètre: registry — registre propriétaire de la collection.
** Paramètre: item — définition copiée dans le registre.
** Retour: Retourne 1 en cas de succès et 0 si la définition est invalide,
**         dupliquée ou si l'allocation échoue.
** Effets: peut agrandir la collection dynamique items.
** Invariants: item_id est positif et canonical_name est unique.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_registry_add_item().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_registry_add_item().
** --- Fin des liens API auto-vérifiés ---
*/
int	catalog_registry_add_item(t_catalog_registry *registry,
		const t_catalog_item *item);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_registry_add_world — Ajoute un monde canonique sans accepter
**       d'identifiant ou de nom déjà utilisé.
** Paramètre: registry — registre propriétaire de la collection.
** Paramètre: world — définition copiée dans le registre.
** Retour: Retourne 1 en cas de succès et 0 si la définition est invalide,
**         dupliquée ou si l'allocation échoue.
** Effets: peut agrandir la collection dynamique worlds.
** Invariants: parent_world_id vaut UNKNOWN ou un identifiant différent du
**             monde lui-même; les liens sont validés globalement ensuite.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_registry_add_world().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_registry_add_world().
** --- Fin des liens API auto-vérifiés ---
*/
int	catalog_registry_add_world(t_catalog_registry *registry,
		const t_catalog_world *world);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_registry_find_item_by_id — Recherche une définition d'item
**       par identifiant canonique stable.
** Paramètre: registry — registre consulté en lecture seule.
** Paramètre: item_id — identifiant canonique recherché.
** Retour: Retourne un pointeur interne const ou NULL si absent.
** Effets: aucun.
** Invariants: le pointeur retourné reste valide jusqu'à une mutation pouvant
**             réallouer items ou jusqu'à destroy.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_registry_find_item_by_id().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_registry_find_item_by_id().
** --- Fin des liens API auto-vérifiés ---
*/
const t_catalog_item	*catalog_registry_find_item_by_id(
					const t_catalog_registry *registry, t_entity_id item_id);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_registry_find_item_by_name — Recherche une définition
**       d'item
**       par son nom canonique exact.
** Paramètre: registry — registre consulté en lecture seule.
** Paramètre: name — nom canonique recherché.
** Retour: Retourne un pointeur interne const ou NULL si absent.
** Effets: aucun.
** Invariants: la comparaison est exacte et n'invente aucun alias implicite.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_registry_find_item_by_name().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_registry_find_item_by_name().
** --- Fin des liens API auto-vérifiés ---
*/
const t_catalog_item	*catalog_registry_find_item_by_name(
					const t_catalog_registry *registry, const char *name);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_registry_find_world_by_id — Recherche un monde par son
**       identifiant canonique stable.
** Paramètre: registry — registre consulté en lecture seule.
** Paramètre: world_id — identifiant canonique recherché.
** Retour: Retourne un pointeur interne const ou NULL si absent.
** Effets: aucun.
** Invariants: le pointeur retourné reste valide selon les règles du registre.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_registry_find_world_by_id().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_registry_find_world_by_id().
** --- Fin des liens API auto-vérifiés ---
*/
const t_catalog_world	*catalog_registry_find_world_by_id(
					const t_catalog_registry *registry, t_entity_id world_id);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_registry_validate_world_links — Vérifie que les parents des
**       mondes existent et qu'aucun cycle de parentage n'est présent.
** Paramètre: registry — registre consulté en lecture seule.
** Retour: Retourne 1 si tous les liens sont valides, 0 sinon.
** Effets: aucun.
** Invariants: UNKNOWN représente une racine; un cycle rend le catalogue
**             invalide au lieu d'être suivi indéfiniment.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_registry_validate_world_links().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_registry_validate_world_links().
** --- Fin des liens API auto-vérifiés ---
*/
int	catalog_registry_validate_world_links(const t_catalog_registry *registry);

/* Fishing output definitions are data-driven and exact-name matched. */
int	catalog_registry_add_fishing_output(t_catalog_registry *registry,
		const t_catalog_fishing_output *output);
const t_catalog_fishing_output	*catalog_registry_find_fishing_output(
		const t_catalog_registry *registry, const char *name);
int	catalog_registry_add_fishing_skill(t_catalog_registry *registry,
		const t_catalog_fishing_skill *skill);
int	catalog_registry_is_fishing_skill(const t_catalog_registry *registry,
		const char *name);
int	catalog_registry_add_fishing_gear(t_catalog_registry *registry,
		const t_catalog_fishing_gear *gear);
const t_catalog_fishing_gear	*catalog_registry_find_fishing_gear(
		const t_catalog_registry *registry, t_entity_id item_type_id);
const t_catalog_fishing_gear	*catalog_registry_find_fishing_gear_by_name(
		const t_catalog_registry *registry, const char *name);
int	catalog_registry_add_fishing_ammo(t_catalog_registry *registry,
		const t_catalog_fishing_ammo *ammo);
const t_catalog_fishing_ammo	*catalog_registry_find_fishing_ammo(
		const t_catalog_registry *registry, t_entity_id item_type_id);
const t_catalog_fishing_ammo	*catalog_registry_find_fishing_ammo_by_name(
		const t_catalog_registry *registry, const char *name);

#endif
