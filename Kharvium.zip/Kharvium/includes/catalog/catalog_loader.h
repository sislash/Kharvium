/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   catalog_loader.h                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CATALOG_LOADER_H
# define CATALOG_LOADER_H

# include "catalog/catalog_registry.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_load_items_file — Charge un catalogue d'items CSV versionné
**       et ajoute uniquement des entrées entièrement validées.
** Paramètre: registry — registre recevant les définitions.
** Paramètre: path — chemin du fichier CSV à charger.
** Retour: Retourne 1 si le fichier entier est valide, 0 sinon.
** Effets: lit un fichier; en cas d'échec le nombre d'items revient à sa
**         valeur d'entrée.
** Invariants: le format attendu contient schema_version,id,name,category.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_load_items_file().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_load_items_file().
** --- Fin des liens API auto-vérifiés ---
*/
int	catalog_load_items_file(t_catalog_registry *registry, const char *path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: catalog_load_worlds_file — Charge un catalogue de mondes CSV
**       versionné puis valide toutes les relations parent/enfant.
** Paramètre: registry — registre recevant les définitions.
** Paramètre: path — chemin du fichier CSV à charger.
** Retour: Retourne 1 si toutes les lignes et relations sont valides, 0 sinon.
** Effets: lit un fichier; en cas d'échec le nombre de mondes revient à sa
**         valeur d'entrée.
** Invariants: aucun monde chargé ne peut référencer un parent absent ou
**             former un cycle.
** --- Liens API auto-vérifiés ---
** Implémentation: catalog_load_worlds_file().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                catalog_load_worlds_file().
** --- Fin des liens API auto-vérifiés ---
*/
int	catalog_load_worlds_file(t_catalog_registry *registry, const char *path);

/* Charge les rôles Fishing et refuse toute référence item absente. */
int	catalog_load_fishing_outputs_file(t_catalog_registry *registry,
		const char *path);
/* Charge les noms de skills Fishing autorisés pour le parser. */
int	catalog_load_fishing_skills_file(t_catalog_registry *registry,
		const char *path);
int	catalog_load_fishing_gear_file(t_catalog_registry *registry,
		const char *path);
int	catalog_load_fishing_ammo_file(t_catalog_registry *registry,
		const char *path);

#endif
