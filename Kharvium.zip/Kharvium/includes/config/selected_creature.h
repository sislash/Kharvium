/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   selected_creature.h                               +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef SELECTED_CREATURE_H
# define SELECTED_CREATURE_H

# include <stddef.h>

/*
 * selected creature
 * ------------
 * Helper pour memoriser le "mob cible" de la session.
 * Stockage: fichier texte (1 ligne) => portable Linux/Windows.
 */

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: selected_creature_load — Charge l’état associé à sélectionné
**       creature.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: selected_creature_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                selected_creature_load(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	selected_creature_load(const char *path, char *out, size_t outsz);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: selected_creature_save — Sauvegarde l’état associé à sélectionné
**       creature.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: selected_creature_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                selected_creature_save(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	selected_creature_save(const char *path, const char *name);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: selected_creature_clear — Vide l’état associé à sélectionné
**       creature.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: selected_creature_clear().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                selected_creature_clear(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	selected_creature_clear(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: selected_creature_name_is_set — Définit l’état associé à
**       sélectionné creature nom is.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: selected_creature_name_is_set().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                selected_creature_name_is_set(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	selected_creature_name_is_set(const char *name);

/* Nettoie le texte (trim + suppression controles + virgules). */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: selected_creature_sanitize — Met à jour sélection creature sanitize
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: selected_creature_sanitize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                selected_creature_sanitize(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	selected_creature_sanitize(char *s);

#endif
