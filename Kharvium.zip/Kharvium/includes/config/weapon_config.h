/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_config.h                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef WEAPON_CONFIG_H
# define WEAPON_CONFIG_H

/*
 * config_arme.h
 * -------------
 * Charge une base d'armes depuis un fichier INI simple + section PLAYER.
 * Portable Linux / Windows (C standard).
 *
 * IMPORTANT RCE (Real Cash Economy):
 * - Tous les couts sont stockes en fixed-point uPED (1/100000 PED).
 * - Les MU (markup) sont stockes en fixed-point 1e4 (10000 = x1.0000).
 *
 * Section joueur (optionnelle):
 *   [PLAYER]
 *   name=TonNom
 *
 * Section arme:
 *   [Nom Exact de l'arme]
 *   dpp=...
 *   ammo_shot=...          ; PED/shot
 *   decay_shot=...         ; PED/shot
 *   amp_ammo_shot=...      ; PED/shot (ou via amp=)
 *   amp_decay_shot=...     ; PED/shot (ou via amp=)
 *   markup=...             ; legacy MU (1.00=TT, 1.25=125%) applique sur decays
 *   ammo_mu=...            ; MU ammo (1.00 default)
 *   weapon_mu=...          ; MU arme (0 => legacy)
 *   amp_mu=...             ; MU amp (0 => legacy)
 *   amp=A101               ; optionnel: lie les stats AMP:
 *   notes=...
 *
 * Sections amplis:
 *   [AMP:A101]
 *   amp_ammo_shot=...
 *   amp_decay_shot=...
 *   amp_mu=...
 *   notes=...
 */

#include <stddef.h>
#include <stdint.h>
#include "common/money.h"

#define WEAPON_ENHANCER_SLOTS 10

#ifdef __cplusplus
extern "C" {
#endif

    typedef struct s_enhancer_slot
    {
        int         installed;
        char        name[128];
        t_money  tt_uPED;
        t_money  acquisition_cost_uPED;
        int64_t     markup_mu_1e4;
        uint64_t    break_count;
    } t_enhancer_slot;

    typedef struct s_weapon_stats
    {
        char        name[128];       /* Nom de l'arme (section INI) */
        char        notes[256];      /* Texte libre */
        char        amp_name[128];   /* nom de l'amp reference: ex "A101" */

        double      dpp;             /* Damage Per PEC (ou DPP) */

        /* Cout par tir (TT) en uPED */
        t_money  ammo_shot;       /* Cout munition par tir (PED) */
        t_money  decay_shot;      /* Decay arme par tir (PED) */
        t_money  amp_ammo_shot;   /* Munition ampli par tir (PED) */
        t_money  amp_decay_shot;  /* Decay ampli par tir (PED) */

        /* Legacy: MU unique applique sur les decays (EU-correct) */
        int64_t     markup_mu_1e4;   /* 10000=TT, 12500=125% */

        /* NEW: MU separes */
        int64_t     ammo_mu_1e4;     /* ex: 10000 */
        int64_t     weapon_mu_1e4;   /* 0 => legacy */
        int64_t     amp_mu_1e4;      /* 0 => legacy */

        int         tier_x100;       /* 0..1000 => Tier 0.00..10.00 */
        t_enhancer_slot enhancers[WEAPON_ENHANCER_SLOTS];

    } t_weapon_stats;

    typedef struct s_amp_stats
    {
        char        name[128];
        t_money  amp_ammo_shot;
        t_money  amp_decay_shot;
        int64_t     amp_mu_1e4;
        char        notes[256];
    } t_amp_stats;

    typedef struct s_amps_db
    {
        t_amp_stats   *items;
        size_t      count;
    } t_amps_db;

    typedef struct s_weapon_database
    {
        t_weapon_stats  *items;
        size_t      count;

        t_amps_db     amps;

        /* AJOUT: nom du joueur lu dans [PLAYER] name=... */
        char        player_name[128];
    } t_weapon_database;

    /* Charge config/weapons.ini (ou autre chemin).
     * Retour: 1 si OK, 0 si erreur.
     */
    int     weapon_database_load(t_weapon_database *db, const char *path);

	/* Save whole db back to an INI file (rewrite file). */
	/* Returns 1 on success. */
    int     weapon_database_save(const t_weapon_database *db, const char *path);

    /* Libere la memoire. */
    void    weapon_database_free(t_weapon_database *db);

    /* Recherche une arme par nom exact (strcmp).
     * Retour: pointeur vers l'arme, ou NULL.
     */
    const t_weapon_stats *weapon_database_find(const t_weapon_database *db,
    	const char *name);

    /* Calcule cout total par tir.
     * - Mode MU separes (si weapon_mu/amp_mu definis):
     *     cost = ammo_shot*ammo_mu + decay_shot*weapon_mu
     *         + amp_ammo_shot*ammo_mu + amp_decay_shot*amp_mu
     * - Fallback legacy (EU-correct):
     *     cost = ammo_shot + (decay_shot + amp_decay_shot) * markup
     */
    t_money  weapon_cost_per_shot_uped(const t_weapon_stats *w);
double	weapon_cost_per_shot_ped(const t_weapon_stats *weapon);

#ifdef __cplusplus
}
#endif

#endif /* WEAPON_CONFIG_H */
