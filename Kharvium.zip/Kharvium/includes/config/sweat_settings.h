/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sweat_settings.h                                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/* sweat_option.h */
#ifndef SWEAT_SETTINGS_H
# define SWEAT_SETTINGS_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sweat_settings_load — Charge l’état associé à sweat settings.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: enabled — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : enabled.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sweat_settings_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sweat_settings_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int     sweat_settings_load(const char *path, int *enabled);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sweat_settings_save — Sauvegarde l’état associé à sweat settings.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: enabled — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sweat_settings_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sweat_settings_save(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int     sweat_settings_save(const char *path, int enabled);

#endif
