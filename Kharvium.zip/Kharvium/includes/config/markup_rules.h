/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   markup_rules.h                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/27                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MARKUP_RULES_H
# define MARKUP_RULES_H

# include <stddef.h>

typedef enum e_markup_type
{
	MARKUP_PERCENT = 0,
	MARKUP_TT_PLUS = 1,
	MARKUP_UNIT_VALUE = 2
}	t_markup_type;

typedef struct s_markup_rule
{
	char			name[128];
	t_markup_type	type;
	double			value;
	int				value_known;
}	t_markup_rule;

typedef struct s_markup_db
{
	t_markup_rule	*items;
	size_t			count;
	size_t			cap;
}	t_markup_db;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_initialize — Initialise l’état associé à markup
**       base de données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_initialize(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	markup_database_initialize(t_markup_db *db);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_free — Libère l’état associé à markup base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_free(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	markup_database_free(t_markup_db *db);

/*
 * * Charge markup.ini (format: [Item] + type/value).
 ** Retour:
 **  0 OK
 ** -1 erreur (fichier / parse / alloc)
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_load — Charge l’état associé à markup base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		markup_database_load(t_markup_db *db, const char *path);

/* Save whole db back to an INI file (rewrite file). Returns 0 on success. */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_save — Sauvegarde l’état associé à markup base de
**       données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_save(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		markup_database_save(const t_markup_db *db, const char *path);

/*
 * * Recherche une regle par nom complet, sans sensibilite a la casse ASCII.
 ** Retourne 1 si trouve, 0 sinon.
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_get — Retourne l’état associé à markup base de
**       données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: item_name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: le nom complet doit correspondre; seule la casse ASCII est
**             ignoree afin de tolerer les variantes de capitalisation du loot.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_get().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_get(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		markup_database_get(const t_markup_db *db, const char *item_name,
                      t_markup_rule *out);

/*
** Applique une regle a une valeur TT unique.
** percent => tt * value.
** tt_plus => tt + value (surcharge legacy pour la ligne complete).
** unit_value => value pour UNE unite; la multiplication par la quantite
**               appartient au chemin Tracker quantity-aware.
*/
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_apply — Applique l’état associé à markup.
** Paramètre: r — objet source consulté en lecture seule par cette fonction.
** Paramètre: tt_value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_apply().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_apply(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	markup_apply(const t_markup_rule *r, double tt_value);

/*
 * * Fallback rule (percent 1.00)
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_default_rule — Met à jour par défaut rule en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne le résultat de type t_markup_rule; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_default_rule().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_default_rule(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_markup_rule	markup_default_rule(void);

#endif
