/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   markup_ini.h                                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/27                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MARKUP_INI_H
# define MARKUP_INI_H

# include "config/markup_rules.h"

/*
 * * Parse markup.ini et remplit db.
 ** Format:
 **   [Item Name]
 **   type = percent | tt_plus | unit_value
 **   value = 1.025  (percent), 0.10 (tt_plus) ou 0.25 (unit_value/PED)
 */
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_ini_parse_file — Analyse ini depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_ini_parse_file().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_ini_parse_file(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_ini_parse_file(t_markup_db *db, const char *path);

#endif
