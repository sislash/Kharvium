/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   selected_fishing_rod.h                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SELECTED_FISHING_ROD_H
# define SELECTED_FISHING_ROD_H

# include <stddef.h>

int	selected_fishing_rod_load(const char *path, char *output,
		size_t output_size);
int	selected_fishing_rod_save(const char *path, const char *name);

#endif
