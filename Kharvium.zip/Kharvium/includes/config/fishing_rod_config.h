/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config.h                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FISHING_ROD_CONFIG_H
# define FISHING_ROD_CONFIG_H

# include <stddef.h>
# include "catalog/catalog_registry.h"
# include "fishing/fishing_loadout.h"

# define FISHING_ROD_CONFIG_NAME_CAP 128
# define FISHING_ROD_CONFIG_NOTES_CAP 256
# define FISHING_ROD_CUSTOM_NAME "Custom Fishing Loadout"

typedef enum e_fishing_rod_component_kind
{
	FISHING_ROD_COMPONENT_UNKNOWN = 0,
	FISHING_ROD_COMPONENT_GEAR = 1,
	FISHING_ROD_COMPONENT_AMMO = 2
}   t_fishing_rod_component_kind;

typedef struct s_fishing_rod_component
{
	char				name[CATALOG_NAME_CAP];
	t_entity_id			item_id;
	t_fishing_rod_component_kind	kind;
	t_fishing_gear_slot		slot;
}   t_fishing_rod_component;

typedef struct s_fishing_rod_preset
{
	char		name[FISHING_ROD_CONFIG_NAME_CAP];
	char		rod_name[CATALOG_NAME_CAP];
	char		reel_name[CATALOG_NAME_CAP];
	char		blank_name[CATALOG_NAME_CAP];
	char		line_name[CATALOG_NAME_CAP];
	char		lure_name[CATALOG_NAME_CAP];
	char		ammo_name[CATALOG_NAME_CAP];
	char		notes[FISHING_ROD_CONFIG_NOTES_CAP];
	t_entity_id	rod_id;
	t_entity_id	reel_id;
	t_entity_id	blank_id;
	t_entity_id	line_id;
	t_entity_id	lure_id;
	t_entity_id	ammo_id;
	int		complete;
}   t_fishing_rod_preset;

typedef struct s_fishing_rod_database
{
	t_fishing_rod_preset		*items;
	size_t				count;
	size_t				capacity;
	t_fishing_rod_component		*components;
	size_t				component_count;
	size_t				component_capacity;
}   t_fishing_rod_database;

void	fishing_rod_database_initialize(t_fishing_rod_database *database);
int	fishing_rod_database_load(t_fishing_rod_database *database,
		const char *path, const t_catalog_registry *catalog);
int	fishing_rod_database_save(const t_fishing_rod_database *database,
		const char *path);
void	fishing_rod_database_free(t_fishing_rod_database *database);
const t_fishing_rod_preset	*fishing_rod_database_find(
		const t_fishing_rod_database *database, const char *name);
const t_fishing_rod_preset	*fishing_rod_database_default_for_rod(
		const t_fishing_rod_database *database, const char *rod_name);
size_t	fishing_rod_database_collect_default_rods(
		const t_fishing_rod_database *database,
		const t_fishing_rod_preset **output, size_t capacity);
const t_fishing_rod_component	*fishing_rod_database_find_component(
		const t_fishing_rod_database *database, const char *name);
int	fishing_rod_preset_is_complete(const t_fishing_rod_preset *preset,
		const t_catalog_registry *catalog);
int	fishing_rod_preset_apply(t_fishing_loadout_snapshot *snapshot,
		const t_fishing_rod_preset *preset,
		const t_catalog_registry *catalog);
void	fishing_rod_preset_initialize(t_fishing_rod_preset *preset,
		const char *name);
int	fishing_rod_preset_set_component(t_fishing_rod_preset *preset,
		const t_fishing_rod_component *component,
		const t_catalog_registry *catalog);
int	fishing_rod_preset_set_rod_default(t_fishing_rod_preset *preset,
		const t_fishing_rod_database *database,
		const t_fishing_rod_component *component,
		const t_catalog_registry *catalog);
int	fishing_rod_database_upsert_preset(t_fishing_rod_database *database,
		const t_fishing_rod_preset *preset,
		const t_catalog_registry *catalog);
size_t	fishing_rod_database_collect_components(
		const t_fishing_rod_database *database, int selector,
		const t_fishing_rod_component **output, size_t capacity);

#endif
