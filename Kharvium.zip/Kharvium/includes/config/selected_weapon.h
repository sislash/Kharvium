/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   selected_weapon.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef SELECTED_WEAPON_H
# define SELECTED_WEAPON_H

# include <stddef.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: selected_weapon_load — Charge l’état associé à sélectionné arme.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: selected_weapon_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                selected_weapon_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	selected_weapon_load(const char *path, char *out, size_t outsz);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: selected_weapon_save — Sauvegarde l’état associé à sélectionné
**       arme.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: selected_weapon_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                selected_weapon_save(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	selected_weapon_save(const char *path, const char *name);

#endif
