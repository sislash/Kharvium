# Contributing to Kharvium

Kharvium is proprietary software. Contributions are accepted only through
channels authorized by the copyright holder; this document does **not** grant
permission to redistribute the source code or create a public fork.

## Development rules

- Language: C99/C11-compatible C only. No C++.
- Keep modules separated by responsibility (`.c` / `.h`).
- Preserve Windows/Linux portability.
- Monetary source-of-truth values must remain fixed-point integers.
- UI code must not become the source of accounting calculations.
- No personal data, local paths, real `chat.log`, runtime CSV or Finance data in
  commits or delivery archives.
- Keep new code compatible with the project's Strict42 profile.
- Document every function at its definition and every C API prototype.
- Keep caller/callee links synchronized whenever functions are added, moved,
  renamed or removed, then validate them with `make doc-audit`.

## Build and test

```text
make
make LEGACY=1
make test
make norm
make doc-audit
```

For memory/undefined-behavior checks:

```bash
make sanitize
make test-sanitize
```

`test-sanitize` can be slow because several test binaries are rebuilt with
sanitizers.

## Before submitting a change

1. Explain the problem and expected behavior.
2. Keep the change scoped and modular.
3. Add or update tests for behavior that can regress.
4. Verify accounting invariants if Finance or Tracker values change.
5. Update maintained documentation when user-visible behavior changes.
6. Update caller/callee documentation and run `make doc-audit` after any function-level change.
7. Run the clean packaging audit when the change affects release files.

## Financial code requirements

Any operation that changes financial state should be designed so that:

- validation occurs before mutation;
- partial failure does not leave a half-applied transaction;
- historical cost is preserved where required;
- TT value, market value and realized/unrealized result remain distinct;
- no binary floating-point value becomes the authoritative stored money value.

## Packaging

Never hand-build a release ZIP from a working directory. Use:

```bash
make package-clean
make package-audit
make package-selftest
```

The package audit is intentionally strict. If it rejects a file, fix the
source/staging policy rather than bypassing the audit.

## Security reports

Do not publish a suspected vulnerability with private data or account details.
Follow [SECURITY.md](SECURITY.md).
