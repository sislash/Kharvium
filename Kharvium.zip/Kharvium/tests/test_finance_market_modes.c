/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_market_modes.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_calculations.h"
#include "common/money.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: ped — Convertit le texte PED fourni en représentation monétaire
**       entière du projet et retourne zéro si le montant ne peut pas être
**       analysé.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: check_deposit_lifecycle(), check_stock_cost_conservation(),
**            check_withdrawal_lifecycle(), check_market_unit_quantity(),
**            check_market_unit_stock_value(), check_percent_and_plus().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_modes.c -> ped() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static t_money	ped(const char *text)
{
	t_money	value;

	value = 0;
	if (!money_parse_ped(text, &value))
		return (0);
	return (value);
}

/*
** Rôle: check_percent_and_plus — Vérifie percent and plus.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_price_market_total(), ped().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_modes.c -> check_percent_and_plus() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_percent_and_plus(void)
{
	t_finance_price	price;

	memset(&price, 0, sizeof(price));
	price.tt_unit_uPED = ped("2.00000");
	price.market_unit_uPED = ped("99.00000");
	price.market_mode = FIN_MARKET_PERCENT;
	price.markup_mul_1e4 = 15000;
	if (finance_price_market_total(&price, 3) != ped("9.00000"))
		return (0);
	price.market_mode = FIN_MARKET_TT_PLUS_UNIT;
	price.market_value_uPED = ped("0.50000");
	if (finance_price_market_total(&price, 3) != ped("7.50000"))
		return (0);
	price.market_mode = FIN_MARKET_TT_PLUS_TOTAL;
	return (finance_price_market_total(&price, 3) == ped("6.50000"));
}

/*
** Rôle: check_market_unit_quantity — Vérifie marché unitaire quantity.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_price_market_total(),
**            finance_price_market_unit(), ped().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_modes.c -> check_market_unit_quantity() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_market_unit_quantity(void)
{
	t_finance_price	price;

	memset(&price, 0, sizeof(price));
	price.market_mode = FIN_MARKET_UNIT;
	price.market_unit_uPED = ped("17.00000");
	if (finance_price_market_unit(&price) != ped("17.00000"))
		return (0);
	if (finance_price_market_total(&price, 25) != ped("425.00000"))
		return (0);
	price.market_unit_uPED = ped("18.50000");
	return (finance_price_market_total(&price, 25) == ped("462.50000"));
}

/*
** Rôle: check_market_unit_stock_value — Vérifie marché unitaire stock
**       valeur.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_add_price(),
**            finance_book_destroy(), finance_book_initialize(),
**            finance_book_stock_add(), finance_stock_market_value(), ped().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_modes.c -> check_market_unit_stock_value()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_market_unit_stock_value(void)
{
	t_finance_book	book;
	t_finance_price	price;
	t_finance_stock	stock;
	int		ok;

	finance_book_initialize(&book, 0);
	memset(&price, 0, sizeof(price));
	memset(&stock, 0, sizeof(stock));
	snprintf(price.name, sizeof(price.name), "%s", "Bombardo");
	price.market_mode = FIN_MARKET_UNIT;
	price.market_unit_uPED = ped("17.00000");
	snprintf(stock.item, sizeof(stock.item), "%s", "Bombardo");
	stock.quantity = 25;
	ok = finance_book_add_price(&book, &price);
	ok = ok && finance_book_stock_add(&book, &stock);
	ok = ok && finance_stock_market_value(&book) == ped("425.00000");
	book.prices[0].market_unit_uPED = ped("18.50000");
	ok = ok && finance_stock_market_value(&book) == ped("462.50000");
	finance_book_destroy(&book);
	return (ok);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_market_unit_quantity(),
**            check_market_unit_stock_value(), check_percent_and_plus().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_modes.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	if (!check_percent_and_plus() || !check_market_unit_quantity())
		return (1);
	if (!check_market_unit_stock_value())
		return (1);
	printf("test_finance_market_modes: OK\n");
	return (0);
}
