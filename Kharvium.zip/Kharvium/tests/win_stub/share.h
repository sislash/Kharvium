/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   share.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/09/12                               #+#    #+#             */
/*   Updated: 2026/09/12                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef KHARVIUM_TEST_WIN_SHARE_H
# define KHARVIUM_TEST_WIN_SHARE_H

# include <stdio.h>

# define _SH_DENYNO 0

FILE	*_fsopen(const char *path, const char *mode, int share_mode);

#endif
