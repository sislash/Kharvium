/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   io.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/09/12                               #+#    #+#             */
/*   Updated: 2026/09/12                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef KHARVIUM_TEST_WIN_IO_H
# define KHARVIUM_TEST_WIN_IO_H

# include <sys/types.h>

# define _O_CREAT 0100
# define _O_EXCL 0200
# define _O_WRONLY 01
# define _O_BINARY 0
# define _S_IREAD 0400
# define _S_IWRITE 0200
# define _S_IFDIR 0040000

struct _stat
{
	mode_t	st_mode;
};

int	_stat(const char *path, struct _stat *status);
int	_open(const char *path, int flags, ...);
int	_close(int descriptor);

#endif
