/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_envelope_stats.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "analytics/hunt_envelope_stats.h"

#include <string.h>

/*
** Rôle: set_row — Définit ligne.
** Paramètre: row — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: kill_id — identifiant stable servant à retrouver ou associer
**            l’élément.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : row.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: feed_envelope_fixture().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_envelope_stats.c -> set_row() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	set_row(t_hunt_csv_row_view *row, const char *type,
				int64_t kill_id, t_money value)
{
	memset(row, 0, sizeof(*row));
	row->timestamp_unix = (t_unix_time)kill_id;
	row->type_evenement = type;
	row->cible = "fixture";
	row->quantite = 1;
	row->id_kill = kill_id;
	row->valeur_uPED = value;
	row->a_valeur = (value != 0);
	if (row->a_valeur)
		row->drapeaux |= 1u;
	if (kill_id > 0)
		row->drapeaux |= (1u << 1);
}

/*
** Rôle: process_row — Traite ligne.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: stats — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: row — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : state, stats,
**         row.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_envelope_stats_process().
** Appelants: feed_envelope_fixture().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_envelope_stats.c -> process_row() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	process_row(t_hunt_envelope_accumulator *state,
				t_hunt_stats *stats, t_hunt_csv_row_view *row)
{
	hunt_envelope_stats_process(state, stats, row);
}

/*
** Rôle: feed_envelope_fixture — Calcule et retourne flux enveloppe fixture à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: stats — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: row — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : state, stats,
**         row.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> process_row(), set_row().
** Appelants: test_envelope_aggregation().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_envelope_stats.c -> feed_envelope_fixture() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	feed_envelope_fixture(t_hunt_envelope_accumulator *state,
				t_hunt_stats *stats, t_hunt_csv_row_view *row)
{
	set_row(row, "KILL", 1, 0);
	process_row(state, stats, row);
	set_row(row, "LOOT_ITEM", 1, 10000);
	process_row(state, stats, row);
	set_row(row, "LOOT_ITEM", 1, 0);
	process_row(state, stats, row);
	set_row(row, "KILL", 2, 0);
	process_row(state, stats, row);
	set_row(row, "LOOT_ITEM", 99, 90000);
	process_row(state, stats, row);
	set_row(row, "LOOT_ITEM", 2, 50000);
	process_row(state, stats, row);
	set_row(row, "KILL", 3, 0);
	process_row(state, stats, row);
	set_row(row, "KILL", 4, 0);
	process_row(state, stats, row);
}

/*
** Rôle: test_envelope_aggregation — Calcule et retourne enveloppe aggregation
**       à partir des paramètres fournis sans modifier les entrées déclarées
**       en lecture seule.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> feed_envelope_fixture(),
**            hunt_envelope_stats_finalize(), hunt_envelope_stats_reset().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_envelope_stats.c -> test_envelope_aggregation() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_envelope_aggregation(void)
{
	t_hunt_envelope_accumulator	state;
	t_hunt_csv_row_view			row;
	t_hunt_stats				stats;

	memset(&stats, 0, sizeof(stats));
	hunt_envelope_stats_reset(&state);
	feed_envelope_fixture(&state, &stats, &row);
	hunt_envelope_stats_finalize(&state, &stats);
	ASSERT_I64_EQ(stats.loot_events, 3);
	ASSERT_I64_EQ(stats.loot_items_ped, 60000);
	ASSERT_I64_EQ(stats.loot_items_without_value, 1);
	ASSERT_I64_EQ(stats.loot_envelope_best_ped, 50000);
	ASSERT_I64_EQ(stats.loot_envelope_best_items, 1);
	ASSERT_I64_EQ(stats.loot_envelope_max_items, 2);
	ASSERT_I64_EQ(stats.loot_empty_envelopes, 2);
	ASSERT_I64_EQ(stats.loot_orphan_items, 1);
	return (0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_envelope_aggregation().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_envelope_stats.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	ASSERT_I64_EQ(test_envelope_aggregation(), 0);
	return (0);
}
