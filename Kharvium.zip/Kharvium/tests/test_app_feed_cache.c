/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_app_feed_cache.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "app/app_cache_internal.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: write_feed_fixture — Écrit flux fixture.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_feed_cache.c -> write_feed_fixture() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_TRUE(), fclose(),
**              fopen(), fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	write_feed_fixture(const char *path)
{
	FILE	*file;

	file = fopen(path, "wb");
	ASSERT_TRUE(file != NULL);
	fprintf(file, "timestamp_unix,event_type,target_or_item,qty,");
	fprintf(file, "value_uPED,kill_id,flags,raw\n");
	fprintf(file, "1700000000,KILL,Daikiba,1,0,1,2,kill\n");
	fprintf(file, "1700000001,LOOT_ITEM,Animal Oil,10,12500,1,3,loot\n");
	fprintf(file, "1700000002,SHOT,Weapon,1,0,0,0,shot\n");
	fclose(file);
	return (0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_feed_read_tail(),
**            write_feed_fixture().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_feed_cache.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), remove(), strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	const char			*path;
	t_app_feed_tail_request	request;
	char				output[2][APP_FEED_LINE_CAP];
	int				count;

	path = "test_app_feed_cache_tmp.csv";
	ASSERT_I64_EQ(write_feed_fixture(path), 0);
	request = (t_app_feed_tail_request){path, 2, output, 2, &count};
	ASSERT_TRUE(app_feed_read_tail(&request));
	ASSERT_I64_EQ(count, 2);
	ASSERT_TRUE(strstr(output[0], "LOOT_ITEM") != NULL);
	ASSERT_TRUE(strstr(output[0], "Animal Oil") != NULL);
	ASSERT_TRUE(strstr(output[1], "SHOT") != NULL);
	remove(path);
	return (0);
}
