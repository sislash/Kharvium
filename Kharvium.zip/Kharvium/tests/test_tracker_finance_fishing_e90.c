/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_tracker_finance_fishing_e90.c                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_activity.h"
#include "finance/finance_analysis.h"
#include "finance/finance_book.h"
#include "finance/finance_persistence.h"
#include "integration/tracker_finance.h"
#include <stdio.h>
#include <string.h>

#define E90_PATH "tests/tmp_finance_fishing_e90.csv"

/*
** Rôle: e90_seed_economics — Construit un résumé E89 entièrement déterministe
**       avec TT et base historique complets mais sans prix marché.
** Relations: aucune fonction projet appelée directement.
** Appelants: e90_check_complete(), e90_check_partial().
** Mémoire: aucune allocation.
** Invariants: tous les montants utilisent l'unité fixe uPED du projet.
** Retour: aucun.
** Effets: réinitialise puis renseigne economics.
** Index: docs/FUNCTION_CALL_GRAPH.md, section E90.
** Dépendances: C99 et API projet citées dans Relations.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: réentrant pour des objets distincts; la synchronisation
**              reste à la charge de l’appelant si un objet est partagé.
** I/O: aucune E/S directe.
** Unités: uPED, identifiant session.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static void	e90_seed_economics(t_fishing_session_economics *economics)
{
	memset(economics, 0, sizeof(*economics));
	economics->events.session_id = 90;
	economics->events.attempts = 4;
	economics->events.catches = 2;
	economics->events.loot_tt = 3000;
	economics->events.loot_quality = DATA_COMPLETE;
	economics->events.found = 1;
	economics->gear_tt_decay = 1000;
	economics->ammo_tt_cost = 500;
	economics->total_tt_cost = 1500;
	economics->gear_cost_basis = 1800;
	economics->ammo_cost_basis = 700;
	economics->total_cost_basis = 2500;
	economics->tt_cost_quality = DATA_COMPLETE;
	economics->cost_basis_quality = DATA_COMPLETE;
}

/*
** Rôle: e90_check_draft — Vérifie que le bridge conserve les trois dimensions
**       E90 sans convertir l'absence de marché en TT ou en zéro comptable.
** Relations: tracker_finance_build_fishing_draft().
** Appelants: e90_check_complete().
** Mémoire: aucune allocation.
** Invariants: le résultat marché doit rester indisponible.
** Retour: 1 si le draft est exact, 0 sinon.
** Effets: modifie uniquement draft.
** Index: docs/FUNCTION_CALL_GRAPH.md, section E90.
** Dépendances: C99 et API projet citées dans Relations.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: réentrant pour des objets distincts; la synchronisation
**              reste à la charge de l’appelant si un objet est partagé.
** I/O: aucune E/S directe.
** Unités: uPED, secondes, identifiant session.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static int	e90_check_draft(t_finance_activity *draft,
	const t_fishing_session_economics *economics)
{
	t_tracker_finance_fishing_input	input;

	input.economics = economics;
	input.location = "Test Lake";
	input.timestamp = 9000;
	if (!tracker_finance_build_fishing_draft(draft, &input))
		return (0);
	if (draft->kind != FIN_ACTIVITY_FISHING || draft->tracker_session_id != 90)
		return (0);
	if (draft->cycle_tt_uPED != 1500 || draft->book_cost_uPED != 2500)
		return (0);
	if (draft->tt_result_uPED != 1500 || draft->basis_result_uPED != 500)
		return (0);
	if (draft->quality.market_result != DATA_UNKNOWN
		|| draft->market_result_uPED != 0)
		return (0);
	return (draft->decay_book_uPED == 1800
		&& draft->quality.tt_result == DATA_COMPLETE);
}

/*
** Rôle: e90_check_schema_version — Vérifie que l'écriture E90 annonce
**       explicitement le schéma Finance v8 dans la première ligne du CSV.
** Retour: 1 si le préfixe persistant est exactement meta;8;, 0 sinon.
** Effets: ouvre E90_PATH en lecture puis ferme immédiatement le flux.
** Invariants: le test ne modifie jamais le contenu du fichier sauvegardé.
** Relations: aucune fonction projet appelée directement.
** Appelants: e90_check_roundtrip().
** Index: docs/FUNCTION_CALL_GRAPH.md, section E90.
** Dépendances: fopen(), fgets(), fclose(), strncmp().
** Mémoire: uniquement un buffer automatique borné sur la pile.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: le test suppose E90_PATH réservé à ce binaire de test.
** I/O: lecture bornée de la première ligne de E90_PATH.
** Unités: numéro de version persistant.
** Performance: O(1), une seule ligne de fichier est lue.
** Portabilité: C99 portable sous Windows et Linux.
*/
static int	e90_check_schema_version(void)
{
	FILE	*stream;
	char	line[64];
	int		ok;

	stream = fopen(E90_PATH, "rb");
	if (!stream)
		return (0);
	ok = (fgets(line, sizeof(line), stream) != NULL);
	fclose(stream);
	return (ok && strncmp(line, "meta;8;", 7) == 0);
}

/*
** Rôle: e90_check_roundtrip — Commit puis recharge l'activité Fishing et
**       vérifie que l'analyse ignore seulement la dimension marché inconnue.
** Relations: finance_activity_commit(), finance_analysis_recent(),
**            finance_book_load(), finance_book_save().
** Appelants: e90_check_complete().
** Mémoire: les livres Finance gèrent leurs allocations via leur API.
** Invariants: aucun loot/decay synthétique ne doit modifier le stock.
** Retour: 1 si commit, persistance et agrégat E90 sont exacts, 0 sinon.
** Effets: écrit puis supprime E90_PATH.
** Index: docs/FUNCTION_CALL_GRAPH.md, section E90.
** Dépendances: C99 et API projet citées dans Relations.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: réentrant pour des objets distincts; la synchronisation
**              reste à la charge de l’appelant si un objet est partagé.
** I/O: sauvegarde/recharge E90_PATH puis le supprime.
** Unités: uPED, nombre de runs.
** Performance: O(1) pour la fixture bornée.
** Portabilité: C99 Windows/Linux.
*/
static int	e90_check_roundtrip(t_finance_activity *draft)
{
	t_finance_activity_aggregate	agg;
	t_finance_book		book;
	t_finance_book		loaded;
	int			ok;

	finance_book_initialize(&book, 100000);
	ok = finance_activity_commit(&book, draft, NULL);
	ok = ok && book.stock_count == 0 && book.equipment_event_count == 0;
	ok = ok && finance_book_save(&book, E90_PATH);
	ok = ok && e90_check_schema_version();
	finance_book_initialize_new(&loaded);
	ok = ok && finance_book_load(&loaded, E90_PATH);
	ok = ok && loaded.activity_count == 1;
	ok = ok && loaded.activities[0].tracker_session_id == 90;
	ok = ok && loaded.activities[0].decay_book_uPED == 1800;
	ok = ok && loaded.activities[0].quality.loot_market == DATA_UNKNOWN;
	ok = ok && finance_analysis_recent(&loaded,
		&(t_finance_recent_request){10, {0, FIN_ACTIVITY_OTHER}}, &agg);
	ok = ok && agg.tt_result_count == 1 && agg.basis_result_count == 1;
	ok = ok && agg.market_result_count == 0 && agg.loot_market_uPED == 0;
	finance_book_destroy(&loaded);
	finance_book_destroy(&book);
	(void)remove(E90_PATH);
	return (ok);
}

/*
** Rôle: main — Exécute les cas complet et partiel du bridge Fishing E90.
** Relations: e90_check_draft(), e90_check_roundtrip(), e90_seed_economics(),
**            tracker_finance_build_fishing_draft().
** Appelants: aucun appelant direct détecté.
** Mémoire: aucune allocation directe; les livres sont détruits par le test.
** Invariants: un loot partiel ne peut produire aucun Net déclaré complet.
** Retour: 0 si toutes les assertions métier passent, 1 sinon.
** Effets: peut créer temporairement E90_PATH pendant le roundtrip.
** Index: docs/FUNCTION_CALL_GRAPH.md, section E90.
** Dépendances: C99 et API projet citées dans Relations.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: réentrant pour des objets distincts; la synchronisation
**              reste à la charge de l’appelant si un objet est partagé.
** I/O: écrit le verdict sur stdout/stderr; roundtrip fichier indirect.
** Unités: uPED, qualité DATA_*.
** Performance: O(1) pour la fixture bornée.
** Portabilité: C99 Windows/Linux.
*/
int	main(void)
{
	t_fishing_session_economics	economics;
	t_tracker_finance_fishing_input	input;
	t_finance_activity		draft;
	int				ok;

	e90_seed_economics(&economics);
	ok = e90_check_draft(&draft, &economics);
	ok = ok && e90_check_roundtrip(&draft);
	economics.events.loot_quality = DATA_PARTIAL_VALUE;
	input = (t_tracker_finance_fishing_input){&economics, "", 9001};
	ok = ok && tracker_finance_build_fishing_draft(&draft, &input);
	ok = ok && draft.quality.tt_result == DATA_PARTIAL_VALUE;
	ok = ok && draft.quality.basis_result == DATA_PARTIAL_VALUE;
	ok = ok && draft.tt_result_uPED == 0 && draft.basis_result_uPED == 0;
	if (!ok)
		return (fprintf(stderr, "test_tracker_finance_fishing_e90: FAIL\n"), 1);
	printf("test_tracker_finance_fishing_e90: OK\n");
	return (0);
}
