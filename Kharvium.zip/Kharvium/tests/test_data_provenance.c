/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_data_provenance.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_operations.h"
#include "finance/finance_persistence.h"
#include "common/money.h"
#include <stdio.h>
#include <string.h>

#define PROVENANCE_FILE "tests/.tmp_provenance.csv"
#define LEGACY_FILE "tests/.tmp_provenance_legacy.csv"

/*
** Rôle: provenance_fill — Prépare une source et une observation de marché
**       cohérentes afin que le test porte sur la persistance et non sur la
**       saisie.
** Paramètre: source — enregistrement de provenance rempli par la fonction.
** Paramètre: price — prix de marché de test rempli par la fonction.
** Paramètre: context — métadonnées structurées liées à la source numéro 42.
** Retour: Ne retourne rien; les trois structures sont initialisées.
** Effets: écrase uniquement les structures fournies par l'appelant.
** Invariants: le prix reste fixed-point et source_id vaut 42 dans context.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: provenance_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_data_provenance.c -> provenance_fill().
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: réentrant pour des structures distinctes.
** I/O: aucune E/S directe.
** Unités: timestamp Unix et uPED.
** Performance: coût constant.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	provenance_fill(t_source_record *source, t_finance_price *price,
	t_finance_market_context *context)
{
	memset(source, 0, sizeof(*source));
	memset(price, 0, sizeof(*price));
	memset(context, 0, sizeof(*context));
	source->source_id = 42;
	source->kind = DATA_SOURCE_CHAT_LOG;
	source->imported_at = 1788033600;
	snprintf(source->parser_version, sizeof(source->parser_version), "e82");
	snprintf(source->content_hash, sizeof(source->content_hash), "abc123");
	snprintf(source->label, sizeof(source->label), "chat.log fixture");
	snprintf(price->name, sizeof(price->name), "Vibrant Sweat");
	price->market_mode = FIN_MARKET_UNIT;
	money_parse_ped("0.00130", &price->market_unit_uPED);
	context->timestamp = 1788033610;
	snprintf(context->source, sizeof(context->source), "chat.log fixture");
	context->provenance.source_id = 42;
	context->provenance.evidence = EVIDENCE_USER_OBSERVED;
	context->provenance.quality = DATA_COMPLETE;
}

/*
** Rôle: provenance_roundtrip — Vérifie unicité, liaison de provenance,
**       sauvegarde, relecture et clonage implicite des nouvelles collections.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 si toutes les propriétés survivent au round-trip.
** Effets: crée puis relit un fichier Finance temporaire.
** Invariants: aucune source dupliquée et aucun niveau de preuve n'est perdu.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_add_source_record(),
**            finance_book_destroy(), finance_book_initialize(),
**            finance_book_load(), finance_book_save(),
**            finance_record_market_sample_with_provenance(), provenance_fill().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_data_provenance.c -> provenance_roundtrip().
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: les collections sont libérées par finance_book_destroy().
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test séquentiel sur un fichier temporaire dédié.
** I/O: sauvegarde et relecture déléguées à Finance.
** Unités: identifiant entier, timestamp Unix et uPED.
** Performance: scénario constant avec une source et un market sample.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	provenance_roundtrip(void)
{
	t_finance_book	book;
	t_finance_book	loaded;
	t_source_record	source;
	t_finance_price	price;
	t_finance_market_context	context;
	int	ok;

	finance_book_initialize(&book, 0);
	finance_book_initialize(&loaded, 0);
	provenance_fill(&source, &price, &context);
	ok = finance_book_add_source_record(&book, &source);
	ok = ok && !finance_book_add_source_record(&book, &source);
	ok = ok && finance_record_market_sample_with_provenance(&book, &price,
			&context) && finance_book_save(&book, PROVENANCE_FILE);
	ok = ok && finance_book_load(&loaded, PROVENANCE_FILE);
	ok = ok && loaded.source_record_count == 1
		&& loaded.market_sample_count == 1;
	ok = ok && loaded.market_samples[0].provenance.source_id == 42;
	ok = ok && loaded.market_samples[0].provenance.evidence
		== EVIDENCE_USER_OBSERVED;
	ok = ok && loaded.market_samples[0].provenance.quality == DATA_COMPLETE
		&& strcmp(loaded.source_records[0].parser_version, "e82") == 0;
	finance_book_destroy(&loaded);
	finance_book_destroy(&book);
	return (ok);
}

/*
** Rôle: legacy_v5_defaults — Vérifie qu'une sauvegarde Finance v5 sans les
**       nouveaux champs est chargée avec une provenance UNKNOWN conservative.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 si le fichier v5 est lu et reste sans fausse provenance.
** Effets: écrit un petit fixture temporaire puis charge un registre Finance.
** Invariants: source_id=0, evidence=UNKNOWN et quality=UNKNOWN après migration.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize(), finance_book_load().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_data_provenance.c -> legacy_v5_defaults().
** Dépendances: appels externes/macros directs -> fclose(), fopen(), fprintf().
** Mémoire: les allocations chargées sont libérées par Finance.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test séquentiel sur un fichier temporaire dédié.
** I/O: crée le fixture v5 et le relit via le module de persistance.
** Unités: timestamp Unix et uPED.
** Performance: scénario constant de deux lignes.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	legacy_v5_defaults(void)
{
	t_finance_book	book;
	FILE		*stream;
	int		ok;

	stream = fopen(LEGACY_FILE, "wb");
	if (!stream)
		return (0);
	fprintf(stream, "meta;5;0.00000;;;;;;;;;;;;;\n");
	fprintf(stream, "market_sample;Legacy;123;3;0.00000;0;0.00000;"
		"0.00130;legacy;;;;;;;\n");
	fclose(stream);
	finance_book_initialize(&book, 0);
	ok = finance_book_load(&book, LEGACY_FILE) && book.market_sample_count == 1;
	ok = ok && book.market_samples[0].provenance.source_id == 0;
	ok = ok && book.market_samples[0].provenance.evidence == EVIDENCE_UNKNOWN;
	ok = ok && book.market_samples[0].provenance.quality == DATA_UNKNOWN;
	finance_book_destroy(&book);
	return (ok);
}

/*
** Rôle: main — Exécute les régressions de provenance E82 et nettoie leurs
**       fichiers temporaires quel que soit le résultat.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 si les deux scénarios réussissent, 1 sinon.
** Effets: supprime les fichiers temporaires et affiche le résultat sur stdout.
** Invariants: aucun fichier de données de test ne subsiste après exécution.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> legacy_v5_defaults(),
**            provenance_roundtrip().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_data_provenance.c -> main().
** Dépendances: appels externes/macros directs -> printf(), remove().
** Mémoire: aucune allocation/libération directe dans main.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: exécution séquentielle.
** I/O: nettoyage des fixtures et sortie du résultat.
** Unités: aucune unité métier supplémentaire.
** Performance: coût constant hors E/S des deux petits fichiers.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	int	ok;

	ok = provenance_roundtrip() && legacy_v5_defaults();
	(void)remove(PROVENANCE_FILE);
	(void)remove(LEGACY_FILE);
	if (!ok)
		return (1);
	printf("test_data_provenance: OK\n");
	return (0);
}
