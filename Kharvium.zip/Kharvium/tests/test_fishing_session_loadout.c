/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_session_loadout.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "app/app_fishing_session_loadout.h"
#include <string.h>

/*
** Rôle: seed_fishing_app — Prépare un montage actif minimal afin de vérifier
**       la capture immuable du loadout d'une session Fishing.
** Relations: memset(), snprintf().
** Appelants: check_session_snapshot_is_immutable(), check_non_fishing_clear().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> seed_fishing_app().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static void	seed_fishing_app(t_app *app)
{
	memset(app, 0, sizeof(*app));
	app->fishing_loadout_ready = 1;
	app->fishing_loadout.components[0].item_type_id = 1301;
	app->fishing_loadout.components[1].item_type_id = 1330;
	app->fishing_loadout_estimate.total_tt_per_attempt = 22800;
	app->fishing_loadout_estimate.quality = DATA_COMPLETE;
	app->fishing_loadout_estimate_ready = 1;
	snprintf(app->fishing_rod_name, sizeof(app->fishing_rod_name), "%s",
		"SET-FR1 Angling - River");
}

/*
** Rôle: check_session_snapshot_is_immutable — Vérifie qu'un changement du
**       montage courant après démarrage ne modifie pas le snapshot de session.
** Relations: seed_fishing_app(), app_fishing_session_loadout_capture().
** Appelants: main().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**    check_session_snapshot_is_immutable().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static int	check_session_snapshot_is_immutable(void)
{
	t_app	app;

	seed_fishing_app(&app);
	app_fishing_session_loadout_capture(&app, TRACKER_ACTIVITY_FISHING);
	ASSERT_TRUE(app.fishing_session_loadout_ready);
	ASSERT_I64_EQ(app.fishing_session_loadout.components[0].item_type_id, 1301);
	ASSERT_TRUE(strcmp(app.fishing_session_rod_name,
		"SET-FR1 Angling - River") == 0);
	ASSERT_TRUE(app.fishing_session_loadout_estimate_ready);
	ASSERT_I64_EQ(app.fishing_session_loadout_estimate.total_tt_per_attempt,
		22800);
	app.fishing_loadout.components[0].item_type_id = 9999;
	app.fishing_loadout_estimate.total_tt_per_attempt = 9999;
	snprintf(app.fishing_rod_name, sizeof(app.fishing_rod_name), "%s", "Other");
	ASSERT_I64_EQ(app.fishing_session_loadout.components[0].item_type_id, 1301);
	ASSERT_TRUE(strcmp(app.fishing_session_rod_name,
		"SET-FR1 Angling - River") == 0);
	ASSERT_I64_EQ(app.fishing_session_loadout_estimate.total_tt_per_attempt,
		22800);
	return (0);
}

/*
** Rôle: check_non_fishing_clear — Vérifie qu'une session Hunt n'hérite jamais
**       d'un ancien snapshot Fishing.
** Relations: seed_fishing_app(), app_fishing_session_loadout_capture().
** Appelants: main().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_non_fishing_clear().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static int	check_non_fishing_clear(void)
{
	t_app	app;

	seed_fishing_app(&app);
	app_fishing_session_loadout_capture(&app, TRACKER_ACTIVITY_FISHING);
	ASSERT_TRUE(app.fishing_session_loadout_ready);
	app_fishing_session_loadout_capture(&app, TRACKER_ACTIVITY_HUNT);
	ASSERT_TRUE(!app.fishing_session_loadout_ready);
	ASSERT_TRUE(!app.fishing_session_loadout_estimate_ready);
	ASSERT_TRUE(app.fishing_session_rod_name[0] == '\0');
	return (0);
}

/*
** Rôle: check_active_loadout_readiness — Vérifie qu'un simple flag interne
**       ne suffit pas sans nom de canne et qu'un montage nommé est accepté.
** Relations: app_fishing_loadout_is_ready(), memset(), snprintf().
** Appelants: main().
** Retour: 0 si les quatre états attendus sont respectés, sinon le test échoue.
** Effets: modifie uniquement la structure locale app.
** Invariants: NULL, flag absent ou nom vide restent non démarrables.
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_active_loadout_readiness().
** Dépendances: état Fishing de t_app.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: aucune.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static int	check_active_loadout_readiness(void)
{
	t_app	app;

	memset(&app, 0, sizeof(app));
	ASSERT_TRUE(!app_fishing_loadout_is_ready(NULL));
	ASSERT_TRUE(!app_fishing_loadout_is_ready(&app));
	app.fishing_loadout_ready = 1;
	ASSERT_TRUE(!app_fishing_loadout_is_ready(&app));
	snprintf(app.fishing_rod_name, sizeof(app.fishing_rod_name), "%s",
		"Baitfishing Rod");
	ASSERT_TRUE(app_fishing_loadout_is_ready(&app));
	return (0);
}

/*
** Rôle: main — Exécute les régressions du snapshot et du garde-fou Fishing.
** Relations: check_session_snapshot_is_immutable(), check_non_fishing_clear(),
**    check_active_loadout_readiness().
** Appelants: cible make test.
** Retour: 0 si toutes les régressions passent, sinon le test échoue.
** Effets: aucun état partagé persistant.
** Invariants: chaque cas repart d'un t_app local initialisé.
** Index: docs/FUNCTION_CALL_GRAPH.md -> main().
** Dépendances: API Fishing session/loadout du projet.
** Mémoire: aucune allocation dynamique directe.
** État partagé: aucun.
** Concurrence: non applicable au binaire de test séquentiel.
** I/O: uniquement les sorties du framework de test en cas d'échec.
** Unités: aucune.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	main(void)
{
	TEST_RUN(check_session_snapshot_is_immutable());
	TEST_RUN(check_non_fishing_clear());
	TEST_RUN(check_active_loadout_readiness());
	return (0);
}
