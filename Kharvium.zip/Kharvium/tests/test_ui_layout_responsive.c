/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ui_layout_responsive.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ui/ui_layout.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: rectangle_is_inside — Détermine si rectangle inside respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: root — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: rectangle — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: check_resolution().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_ui_layout_responsive.c -> rectangle_is_inside() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int rectangle_is_inside(t_rect root, t_rect rectangle)
{
	if (rectangle.w < 0 || rectangle.h < 0)
		return (0);
	if (rectangle.x < root.x || rectangle.y < root.y)
		return (0);
	if (rectangle.x + rectangle.w > root.x + root.w)
		return (0);
	return (rectangle.y + rectangle.h <= root.y + root.h);
}

/*
** Rôle: check_resolution — Vérifie resolution.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> rectangle_is_inside(),
**            ui_layout_calculate().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_ui_layout_responsive.c -> check_resolution() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int check_resolution(int width, int height)
{
	t_window	window;
	t_ui_layout	layout;

	memset(&window, 0, sizeof(window));
	window.width = width;
	window.height = height;
	ui_layout_calculate(&window, &layout);
	if (!rectangle_is_inside(layout.root, layout.topbar))
		return (1);
	if (!rectangle_is_inside(layout.root, layout.sidebar))
		return (1);
	if (!rectangle_is_inside(layout.root, layout.content))
		return (1);
	return (!rectangle_is_inside(layout.root, layout.footer));
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_resolution().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_ui_layout_responsive.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int main(void)
{
	if (check_resolution(160, 120) || check_resolution(320, 240))
		return (1);
	if (check_resolution(480, 360) || check_resolution(640, 480))
		return (1);
	if (check_resolution(800, 600) || check_resolution(1024, 768))
		return (1);
	if (check_resolution(1920, 1080) || check_resolution(3440, 1440))
		return (1);
	printf("test_ui_layout_responsive: OK\n");
	return (0);
}
