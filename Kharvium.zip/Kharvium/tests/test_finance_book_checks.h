/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_book_checks.h                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_FINANCE_BOOK_CHECKS_H
# define TEST_FINANCE_BOOK_CHECKS_H

/*
** Rôle: add_auction_sale — Ajoute auction vente.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_record_auction_sale(),
**            parse_test_ped_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_book_checks.h -> add_auction_sale() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	add_auction_sale(t_finance_book *book)
{
	t_finance_auction_sale	sale;

	memset(&sale, 0, sizeof(sale));
	snprintf(sale.item, sizeof(sale.item), "%s", "Test Item");
	sale.quantity = 2;
	sale.final_uPED = parse_test_ped_amount("6.0000");
	sale.fee_uPED = parse_test_ped_amount("0.5000");
	sale.status = FIN_AUCTION_SOLD;
	if (!finance_record_auction_sale(book, &sale))
		return (0);
	if (sale.cost_basis_uPED != parse_test_ped_amount("3.0000"))
		return (0);
	return (sale.profit_uPED == parse_test_ped_amount("2.5000"));
}

/*
** Rôle: check_summary — Vérifie synthèse.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_summary_build(),
**            parse_test_ped_amount().
** Appelants: main(), check_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_book_checks.h -> check_summary() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_summary(const t_finance_book *book)
{
	t_finance_summary	summary;

	finance_summary_build(book, &summary);
	if (summary.assets_uPED != parse_test_ped_amount("19000.0000"))
		return (0);
	if (summary.purchases_uPED != parse_test_ped_amount("15.0000"))
		return (0);
	if (summary.realized_profit_uPED != parse_test_ped_amount("6.5000"))
		return (0);
	if (summary.stock_cost_uPED != parse_test_ped_amount("6.0000"))
		return (0);
	if (summary.stock_market_uPED != parse_test_ped_amount("6.0000"))
		return (0);
	if (summary.cash_balance_uPED != parse_test_ped_amount("100.5000"))
		return (0);
	return (1);
}

/*
** Rôle: check_roundtrip — Vérifie roundtrip.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_summary(), finance_book_destroy(),
**            finance_book_initialize(), finance_book_load(),
**            finance_book_save(), platform_process_id().
** Appelants: main(), main(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_book_checks.h -> check_roundtrip() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> remove(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_roundtrip(t_finance_book *book)
{
	t_finance_book	loaded;
	char		path[256];
	int		pid;
	int		ok;

	pid = platform_process_id();
	snprintf(path, sizeof(path), "bin/tests/finance_%d.csv", pid);
	if (!finance_book_save(book, path))
		return (0);
	finance_book_initialize(&loaded, 0);
	ok = finance_book_load(&loaded, path);
	if (ok)
		ok = (loaded.stock_count == book->stock_count);
	if (ok)
		ok = check_summary(&loaded);
	finance_book_destroy(&loaded);
	(void)remove(path);
	return (ok);
}

/*
** Rôle: check_stackable_markup_rounding — Vérifie stackable markup
**       rounding.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize(), finance_book_stock_add(),
**            finance_summary_build(), parse_test_ped_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_book_checks.h -> check_stackable_markup_rounding()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_stackable_markup_rounding(void)
{
	t_finance_book	book;
	t_finance_stock	stock;
	t_finance_summary	summary;

	finance_book_initialize(&book, 0);
	memset(&stock, 0, sizeof(stock));
	snprintf(stock.item, sizeof(stock.item), "%s", "spool cell");
	stock.quantity = 100000;
	stock.tt_unit_uPED = parse_test_ped_amount("0.0001");
	stock.markup_mul_1e4 = 35000;
	stock.cost_known = 0;
	if (!finance_book_stock_add(&book, &stock))
		return (0);
	finance_summary_build(&book, &summary);
	finance_book_destroy(&book);
	return (summary.stock_market_uPED == parse_test_ped_amount("35.0000"));
}

#endif
