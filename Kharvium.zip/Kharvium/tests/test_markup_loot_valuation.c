/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_markup_loot_valuation.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "analytics/hunt_stats_core.h"
#include "common/money.h"
#include <string.h>

/*
** Rôle: markup_test_rule — Initialise une règle MU locale et sa base de test
**       sans accès fichier ni état global.
** Paramètre: db — base locale qui référencera la règle fournie.
** Paramètre: rule — stockage local de la règle initialisée.
** Paramètre: type — mode percent, tt_plus ou unit_value testé.
** Paramètre: value — valeur numérique connue affectée à la règle.
** Retour: Ne retourne rien; db référence rule après initialisation.
** Effets: modifie uniquement db et rule fournis par l'appelant.
** Invariants: le nom de test reste "Test Loot" et value_known vaut 1.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune fonction projet.
** Appelants: markup_test_modes(), markup_test_unknown().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_markup_loot_valuation.c -> markup_test_rule().
** Dépendances: appels externes/macros directs -> memset(), strcpy().
** Mémoire: aucune allocation/libération dynamique directe.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: réentrant pour des objets locaux indépendants.
** I/O: aucune primitive système/stdio appelée directement.
** Unités: valeur MU ou PED/unité selon le type fourni.
** Performance: aucune boucle; coût constant O(1).
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	markup_test_rule(t_markup_db *db, t_markup_rule *rule,
		t_markup_type type, double value)
{
	memset(rule, 0, sizeof(*rule));
	strcpy(rule->name, "Test Loot");
	rule->type = type;
	rule->value = value;
	rule->value_known = 1;
	db->items = rule;
	db->count = 1;
	db->cap = 1;
}

/*
** Rôle: markup_test_modes — Vérifie les calculs percent, tt_plus et
**       unit_value avec des quantités volontairement différentes.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 si toutes les assertions de valorisation réussissent.
** Effets: modifie uniquement des variables locales de test.
** Invariants: unit_value applique PED/unité x quantité; percent et tt_plus
**             ne multiplient pas leur règle par la quantité.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_stats_core_apply_markup_value(),
**            markup_test_rule(), money_from_ped_double().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_markup_loot_valuation.c -> markup_test_modes().
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération dynamique directe.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: test local sans état global mutable.
** I/O: diagnostics éventuels produits uniquement par les assertions.
** Unités: PED fixe, multiplicateur MU et quantité d'unités.
** Performance: aucune boucle; nombre constant de cas de test.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	markup_test_modes(void)
{
	t_markup_db	db;
	t_markup_rule	rule;
	t_money		value;

	markup_test_rule(&db, &rule, MARKUP_UNIT_VALUE, 0.25);
	value = hunt_stats_core_apply_markup_value(&db, "Test Loot", 0, 4);
	ASSERT_I64_EQ(value, money_from_ped_double(1.0));
	value = hunt_stats_core_apply_markup_value(&db, "Test Loot",
		money_from_ped_double(0.10), 3);
	ASSERT_I64_EQ(value, money_from_ped_double(0.75));
	markup_test_rule(&db, &rule, MARKUP_PERCENT, 1.10);
	value = hunt_stats_core_apply_markup_value(&db, "Test Loot",
		money_from_ped_double(2.0), 99);
	ASSERT_I64_EQ(value, money_from_ped_double(2.20));
	markup_test_rule(&db, &rule, MARKUP_TT_PLUS, 0.10);
	value = hunt_stats_core_apply_markup_value(&db, "Test Loot",
		money_from_ped_double(2.0), 99);
	ASSERT_I64_EQ(value, money_from_ped_double(2.10));
	return (0);
}

/*
** Rôle: markup_test_case_insensitive_names — Vérifie que les noms complets
**       de loot sont recherchés sans sensibilité à la casse ASCII.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 lorsque lookup et valorisation retrouvent la règle.
** Effets: modifie uniquement des variables locales de test.
** Invariants: seule la casse peut différer; aucun préfixe ou nom partiel ne
**             doit être assimilé à la règle "Test Loot".
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_stats_core_apply_markup_value(),
**            markup_database_get(), markup_test_rule(),
**            money_from_ped_double().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_markup_loot_valuation.c -> markup_test_case_insensitive_names().
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE().
** Mémoire: aucune allocation/libération dynamique directe.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: test local sans état global mutable.
** I/O: diagnostics éventuels produits uniquement par les assertions.
** Unités: PED fixe et comparaison de noms de LOOT_ITEM.
** Performance: base d'une entrée; coût constant pour ce test.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	markup_test_case_insensitive_names(void)
{
	t_markup_db		db;
	t_markup_rule	rule;
	t_markup_rule	found;
	t_money		value;

	markup_test_rule(&db, &rule, MARKUP_PERCENT, 1.10);
	ASSERT_TRUE(markup_database_get(&db, "test loot", &found) == 1);
	ASSERT_TRUE(markup_database_get(&db, "TEST LOOT", &found) == 1);
	ASSERT_TRUE(markup_database_get(&db, "Test Loo", &found) == 0);
	value = hunt_stats_core_apply_markup_value(&db, "tEsT LoOt",
		money_from_ped_double(2.0), 1);
	ASSERT_I64_EQ(value, money_from_ped_double(2.20));
	return (0);
}

/*
** Rôle: markup_test_unknown — Vérifie qu'une règle value=unknown préserve la
**       TT même lorsque le type configuré est unit_value.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 lorsque l'assertion de conservation TT réussit.
** Effets: modifie uniquement des variables locales de test.
** Invariants: value_known=0 ne fabrique jamais une valeur synthétique.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_stats_core_apply_markup_value(),
**            markup_test_rule(), money_from_ped_double().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_markup_loot_valuation.c -> markup_test_unknown().
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération dynamique directe.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: test local sans état global mutable.
** I/O: diagnostics éventuels produits uniquement par les assertions.
** Unités: PED fixe et quantité d'unités.
** Performance: aucune boucle; coût constant O(1).
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	markup_test_unknown(void)
{
	t_markup_db	db;
	t_markup_rule	rule;
	t_money		tt;

	markup_test_rule(&db, &rule, MARKUP_UNIT_VALUE, 9.0);
	rule.value_known = 0;
	tt = money_from_ped_double(0.12345);
	ASSERT_I64_EQ(hunt_stats_core_apply_markup_value(&db,
		"Test Loot", tt, 0), tt);
	return (0);
}

/*
** Rôle: main — Exécute les régressions E102 de valorisation et noms loot.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 lorsque tous les sous-tests réussissent.
** Effets: exécute uniquement les assertions des sous-tests locaux.
** Invariants: aucun prix de marché réel n'est figé par ce test.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_test_case_insensitive_names(),
**            markup_test_modes(), markup_test_unknown().
** Appelants: point d'entrée du binaire de test.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_markup_loot_valuation.c -> main().
** Dépendances: appels externes/macros directs -> ASSERT_TRUE().
** Mémoire: aucune allocation/libération dynamique directe.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: exécution séquentielle du binaire de test.
** I/O: diagnostics éventuels produits uniquement par les assertions.
** Unités: aucune conversion supplémentaire; sous-tests en PED/quantité.
** Performance: deux sous-tests de taille constante.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	ASSERT_TRUE(markup_test_modes() == 0);
	ASSERT_TRUE(markup_test_case_insensitive_names() == 0);
	ASSERT_TRUE(markup_test_unknown() == 0);
	return (0);
}
