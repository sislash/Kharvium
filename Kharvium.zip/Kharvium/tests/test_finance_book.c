/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_book.c                               +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_calculations.h"
#include "finance/finance_operations.h"
#include "finance/finance_persistence.h"
#include "platform/platform_file_system.h"

#include "common/money.h"
#include <stdio.h>
#include <string.h>

#include "test_finance_book_setup.h"
#include "test_finance_book_checks.h"

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> add_asset(), add_auction_sale(),
**            add_purchase(), add_test_sale(), check_roundtrip(),
**            check_stackable_markup_rounding(), check_summary(),
**            finance_book_destroy() (+2; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_book.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED, pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=10;
**              dépendances externes/macros=1. Le coût des fonctions appelées
**              peut dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_finance_book	book;

	finance_book_initialize(&book, parse_test_ped_amount("100.0000"));
	if (!add_asset(&book) || !add_purchase(&book))
		return (1);
	if (!add_test_sale(&book) || !add_auction_sale(&book))
		return (1);
	if (!check_summary(&book) || !check_roundtrip(&book))
		return (1);
	finance_book_destroy(&book);
	if (!check_stackable_markup_rounding())
		return (1);
	printf("test_finance_book: OK\n");
	return (0);
}
