/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_chart_data.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ui/hunt_chart_data.h"
#include "common/money.h"
#include "support/test_hunt_chart_support.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
** Rôle: setup_loot — Configure loot.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_from_ped_double().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_chart_data.c -> setup_loot() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void setup_loot(t_hunt_series *series)
{
	series->initialized = 1;
	series->bucket_sec = 60;
	series->loot_ev_count = 3;
	series->loot_ev_sec[0] = 0;
	series->loot_ev_sec[1] = 600;
	series->loot_ev_sec[2] = 3600;
	series->loot_ev_uPED[0] = money_from_ped_double(1.0);
	series->loot_ev_uPED[1] = money_from_ped_double(2.0);
	series->loot_ev_uPED[2] = money_from_ped_double(4.0);
	series->loot_ev_group_count[0] = 1;
	series->loot_ev_group_count[1] = 1;
	series->loot_ev_group_count[2] = 1;
}

/*
** Rôle: check_loot_modes — Vérifie loot modes.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : series, output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_hunt_chart_build_metric().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_chart_data.c -> check_loot_modes() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int check_loot_modes(t_hunt_series *series, t_hunt_chart_output *output)
{
	if (!test_hunt_chart_build_metric(
			series, HUNT_CHART_LOOT_PER_KILL, 0, output))
		return (1);
	if (output->count != 3 || output->values[1] != 2.0)
		return (1);
	if (!test_hunt_chart_build_metric(
			series, HUNT_CHART_CUMULATIVE_LOOT, 0, output))
		return (1);
	if (output->count != 3 || output->values[1] != 3.0
		|| output->values[2] != 7.0)
		return (1);
	return (0);
}

/*
** Rôle: check_range_filter — Vérifie plage filter.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : series, output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_hunt_chart_build_metric().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_chart_data.c -> check_range_filter() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int check_range_filter(t_hunt_series *series,
	t_hunt_chart_output *output)
{
	if (!test_hunt_chart_build_metric(
			series, HUNT_CHART_LOOT_PER_KILL, 15, output))
		return (1);
	if (output->count != 1 || output->x_seconds[0] != 3600
		|| output->values[0] != 4.0)
		return (1);
	if (!test_hunt_chart_build_metric(
			series, HUNT_CHART_CUMULATIVE_LOOT, 15, output))
		return (1);
	return (output->count != 1 || output->values[0] != 7.0);
}

/*
** Rôle: check_axes_and_buckets — Vérifie axes and buckets.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_chart_axis_maximum(),
**            hunt_chart_bucket_count_for_minutes().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_chart_data.c -> check_axes_and_buckets() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int check_axes_and_buckets(t_hunt_series *series)
{
	if (hunt_chart_bucket_count_for_minutes(series, 15) != 15)
		return (1);
	series->bucket_sec = 90;
	if (hunt_chart_bucket_count_for_minutes(series, 15) != 10)
		return (1);
	if (hunt_chart_axis_maximum(HUNT_CHART_HIT_RATE, 52.0) != 100.0)
		return (1);
	return (hunt_chart_axis_maximum(HUNT_CHART_CUMULATIVE_ROI, 50.0)
		< 110.0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_axes_and_buckets(),
**            check_loot_modes(), check_range_filter(), setup_loot().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_chart_data.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> calloc(), free(), memset(),
**              printf().
** Mémoire: opérations directes -> calloc(), free(); le transfert de
**          propriété reste défini par Retour/Effets et les contrats des
**          fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int main(void)
{
	t_test_hunt_chart_context	context;

	memset(&context, 0, sizeof(context));
	context.series = calloc(1, sizeof(*context.series));
	if (!context.series)
		return (1);
	context.output.values = context.values;
	context.output.x_seconds = context.x_seconds;
	context.output.group_counts = context.groups;
	context.output.kill_ids = context.kill_ids;
	context.output.has_kill = context.has_kill;
	setup_loot(context.series);
	if (check_loot_modes(context.series, &context.output)
		|| check_range_filter(context.series, &context.output)
		|| check_axes_and_buckets(context.series))
		return (free(context.series), 1);
	free(context.series);
	printf("test_hunt_chart_data: OK\n");
	return (0);
}
