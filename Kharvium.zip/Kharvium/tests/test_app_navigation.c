/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_app_navigation.c                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "app/app_navigation.h"
#include "support/test_app_navigation_support.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: history_pop_expect — Retire history expect dans la collection
**       concernée en respectant sa capacité, son ordre
**       et ses invariants de propriété.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: expected — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_history_pop().
** Appelants: check_history_sequence().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation.c -> history_pop_expect() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	history_pop_expect(t_app *app, t_page expected)
{
	t_page	target;

	if (!app_navigation_history_pop(app, app->page, &target)
		|| target != expected)
		return (0);
	app->page = target;
	return (1);
}

/*
** Rôle: check_history_sequence — Vérifie history sequence.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_history_can_back(),
**            app_navigation_history_push(), app_navigation_history_reset(),
**            history_pop_expect().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation.c -> check_history_sequence() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_history_sequence(void)
{
	t_app	app;

	memset(&app, 0, sizeof(app));
	app.page = PAGE_DASHBOARD;
	app_navigation_history_reset(&app);
	app_navigation_history_push(&app, PAGE_DASHBOARD);
	app.page = PAGE_FINANCE_INVENTORY;
	app_navigation_history_push(&app, app.page);
	app.page = PAGE_HUNT;
	app_navigation_history_push(&app, app.page);
	app.page = PAGE_CONFIG;
	app_navigation_history_push(&app, app.page);
	app.page = PAGE_HEALTH;
	if (!app_navigation_history_can_back(&app))
		return (0);
	if (!history_pop_expect(&app, PAGE_CONFIG)
		|| !history_pop_expect(&app, PAGE_HUNT)
		|| !history_pop_expect(&app, PAGE_FINANCE_INVENTORY)
		|| !history_pop_expect(&app, PAGE_DASHBOARD))
		return (0);
	return (!app_navigation_history_can_back(&app));
}

/*
** Rôle: check_history_duplicate — Vérifie history duplicate.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_history_push(),
**            app_navigation_history_reset().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation.c -> check_history_duplicate() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_history_duplicate(void)
{
	t_app	app;

	memset(&app, 0, sizeof(app));
	app.page = PAGE_DASHBOARD;
	app_navigation_history_reset(&app);
	app_navigation_history_push(&app, PAGE_DASHBOARD);
	app_navigation_history_push(&app, PAGE_DASHBOARD);
	return (app.nav_history_count == 1);
}

/*
** Rôle: check_modal_pages — Vérifie modale pages.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_page_is_tracker(),
**            app_navigation_page_uses_modal_frame().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation.c -> check_modal_pages() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_modal_pages(void)
{
	if (!app_navigation_page_uses_modal_frame(PAGE_GRAPH_LIVE))
		return (0);
	if (!app_navigation_page_uses_modal_frame(PAGE_CONFIG_WEAPONS))
		return (0);
	if (!app_navigation_page_uses_modal_frame(PAGE_CONFIG_MARKUP))
		return (0);
	if (app_navigation_page_uses_modal_frame(PAGE_HUNT))
		return (0);
	if (app_navigation_page_uses_modal_frame(PAGE_HOTKEYS))
		return (0);
	if (!app_navigation_page_is_tracker(PAGE_HUNT)
		|| !app_navigation_page_is_tracker(PAGE_GLOBAL_EVENTS)
		|| !app_navigation_page_is_tracker(PAGE_GRAPH_LIVE)
		|| !app_navigation_page_is_tracker(PAGE_SESSIONS))
		return (0);
	return (!app_navigation_page_is_tracker(PAGE_CONFIG));
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_back_target(),
**            app_navigation_page_for_cursor(), check_history_duplicate(),
**            check_history_sequence(), check_modal_pages(),
**            test_nav_check_all_pages_valid(), test_nav_check_back_routes(),
**            test_nav_check_cursor() (+1; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=9; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	if (!test_nav_check_finance_pages() || !test_nav_check_all_pages_valid())
		return (1);
	if (!test_nav_check_cursor(0, PAGE_DASHBOARD)
		|| !test_nav_check_cursor(1, PAGE_HUNT)
		|| !test_nav_check_cursor(2, PAGE_GLOBAL_EVENTS)
		|| !test_nav_check_cursor(3, PAGE_GRAPH_LIVE)
		|| !test_nav_check_cursor(4, PAGE_SESSIONS)
		|| !test_nav_check_cursor(5, PAGE_CONFIG)
		|| !test_nav_check_cursor(6, PAGE_HEALTH)
		|| !test_nav_check_cursor(7, PAGE_MAINTENANCE)
		|| !test_nav_check_cursor(8, PAGE_HELP))
		return (1);
	if (app_navigation_page_for_cursor(9, NULL))
		return (1);
	if (!test_nav_check_back_routes() || !check_modal_pages())
		return (1);
	if (!check_history_sequence() || !check_history_duplicate())
		return (1);
	if (app_navigation_back_target(PAGE_DASHBOARD, PAGE_HUNT, NULL))
		return (1);
	printf("test_app_navigation: OK\n");
	return (0);
}
