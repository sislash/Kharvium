/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_market_history.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_operations.h"
#include "finance/finance_persistence.h"
#include "common/money.h"
#include <stdio.h>
#include <string.h>

#define MARKET_HISTORY_FILE "tests/.tmp_market_history.csv"

/*
** Rôle: market_history_roundtrip — Vérifie qu’une cotation datée et sa
**       source survivent à une sauvegarde puis une relecture Finance.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 si prix courant et historique sont cohérents, 0 sinon.
** Effets: crée puis relit un fichier temporaire et libère les deux registres.
** Invariants: timestamp, source, valeur et mode du sample restent inchangés.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize(), finance_book_load(),
**            finance_book_save(), finance_record_market_sample().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_history.c -> market_history_roundtrip().
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: les collections dynamiques sont libérées par Finance.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test séquentiel utilisant un fichier temporaire dédié.
** I/O: sauvegarde et relecture déléguées au module de persistance Finance.
** Unités: timestamp Unix et uPED.
** Performance: scénario constant avec une seule observation de marché.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	market_history_roundtrip(void)
{
	t_finance_book	book;
	t_finance_book	loaded;
	t_finance_price	price;
	int			ok;

	finance_book_initialize(&book, 0);
	finance_book_initialize(&loaded, 0);
	memset(&price, 0, sizeof(price));
	snprintf(price.name, sizeof(price.name), "%s", "Vibrant Sweat");
	price.market_mode = FIN_MARKET_UNIT;
	money_parse_ped("0.00130", &price.market_unit_uPED);
	ok = finance_record_market_sample(&book, &price, 1788033600, "test");
	ok = ok && finance_book_save(&book, MARKET_HISTORY_FILE);
	ok = ok && finance_book_load(&loaded, MARKET_HISTORY_FILE);
	ok = ok && loaded.market_sample_count == 1;
	ok = ok && loaded.market_samples[0].timestamp == 1788033600;
	ok = ok && strcmp(loaded.market_samples[0].source, "test") == 0;
	ok = ok && loaded.market_samples[0].provenance.evidence == EVIDENCE_MANUAL;
	ok = ok && loaded.market_samples[0].provenance.quality == DATA_COMPLETE;
	finance_book_destroy(&loaded);
	finance_book_destroy(&book);
	return (ok);
}

/*
** Rôle: main — Exécute le test de persistance des observations de marché.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 si le round-trip réussit et 1 sinon.
** Effets: supprime le fichier temporaire avant de terminer.
** Invariants: aucun fichier de données de test ne subsiste après exécution.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> market_history_roundtrip().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_history.c -> main().
** Dépendances: appels externes/macros directs -> printf(), remove().
** Mémoire: aucune allocation/libération directe dans main.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: exécution séquentielle du test.
** I/O: supprime le fichier temporaire et écrit le résultat sur stdout.
** Unités: aucune unité supplémentaire.
** Performance: coût constant hors E/S du round-trip.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	int	ok;

	ok = market_history_roundtrip();
	(void)remove(MARKET_HISTORY_FILE);
	if (!ok)
		return (1);
	printf("test_finance_market_history: OK\n");
	return (0);
}
