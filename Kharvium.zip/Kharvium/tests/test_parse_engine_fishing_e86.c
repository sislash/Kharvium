/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_parse_engine_fishing_e86.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "app/app_state.h"
#include "common/string_operations.h"
#include "hunt/hunt_rules.h"
#include "io/hunt_csv.h"
#include "io/tracker_event_csv.h"
#include "parse/parse_engine.h"
#include "platform/platform_time.h"
#include "support/test_fishing_e86_support.h"
#include <stdio.h>
#include <string.h>

static const char	g_raw_fish[] =
	"2026-08-30 01:00:00 [System] [] You received Blue Snapper "
	"x (1) Value: 0.01 PED\n";
static const char	g_crafting[] =
	"2026-08-30 01:00:01 [System] [] You received Fish Oil x (1) "
	"Value: 0.01 PED\n"
	"2026-08-30 01:00:01 [System] [] You received Shrapnel x (50) "
	"Value: 0.005 PED\n";
static const char	g_family_oil[] =
	"2026-08-30 01:00:02 [System] [] You received Tuna Fish Oil x (1) "
	"Value: 0.01 PED\n"
	"2026-08-30 01:00:02 [System] [] You received Fish Scrap x (10) "
	"Value: 0.001 PED\n";
static const char	g_candidate[] =
	"2026-08-30 01:00:03 [System] [] You received Mystery Minnow "
	"x (1) Value: 0.01 PED\n";
static const char	g_skill[] =
	"2026-08-30 01:00:04 [System] [] You received Fish Scrap x (10) "
	"Value: 0.001 PED\n"
	"2026-08-30 01:00:04 [System] [] You have gained 0.1234 experience "
	"in your Angling skill\n";

static const t_e86_expected	g_expected_raw = {1, 1, 3, 0, 0, 0, 0, 1};
static const t_e86_expected	g_expected_craft = {0, 0, 0, 0, 0, 0, 0, 0};
static const t_e86_expected	g_expected_oil = {1, 2, 4, 0, 0, 0, 1, 0};
static const t_e86_expected	g_expected_candidate = {0, 0, 1, 0, 1, 0, 0, 0};
static const t_e86_expected	g_expected_skill = {1, 1, 4, 1, 0, 0, 1, 0};
static const t_e86_expected	g_expected_overflow = {1, 21, 23, 0, 0, 20, 1, 0};

/*
** Rôle: e86_write_log — Écrit un scénario Fishing synthétique sans toucher à
**       une donnée utilisateur.
** Paramètre: path — chemin temporaire détenu par le test.
** Paramètre: text — contenu chat.log complet du scénario.
** Retour: 1 si tout le texte est écrit, 0 sur erreur d'I/O.
** Effets: crée/remplace path puis ferme le flux.
** Invariants: aucun buffer n'est tronqué par cette fonction.
** Relations: aucune fonction projet appelée directement.
** Appelants: e86_run_case().
** Mémoire: aucune allocation dynamique.
** I/O: écriture stdio du fixture.
** Unités: octets.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_parse_engine_fishing_e86.c ->
** e86_write_log().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût local borné ou linéaire sur la collection parcourue.
*/
static int	e86_write_log(const char *path, const char *text)
{
	FILE	*file;
	size_t	length;

	file = fopen(path, "wb");
	if (!file)
		return (0);
	length = strlen(text);
	if (fwrite(text, 1, length, file) != length)
		return (fclose(file), 0);
	fclose(file);
	return (1);
}

/*
** Rôle: e86_make_paths — Construit les trois chemins temporaires d'un run et
**       le sidecar V4 associé au CSV V3.
** Paramètres: chat/hunt/events — buffers de 256 octets remplis par la fonction.
** Retour: 0 sur succès; les assertions signalent une dérivation impossible.
** Effets: écrit uniquement les buffers fournis.
** Invariants: chaque appel utilise un suffixe monotone distinct.
** Relations: platform_time_milliseconds(), tracker_event_csv_sibling_path().
** Appelants: e86_run_case().
** Mémoire: aucune allocation.
** I/O: aucune.
** Unités: millisecondes pour rendre le nom unique.
** Portabilité: séparateur du sidecar géré par l'API projet.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_parse_engine_fishing_e86.c ->
** e86_make_paths().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût local borné ou linéaire sur la collection parcourue.
*/
static int	e86_make_paths(char *chat, char *hunt, char *events)
{
	static unsigned long	sequence;
	unsigned long long	now;

	now = (unsigned long long)platform_time_milliseconds();
	sequence++;
	snprintf(chat, 256, "bin/tests/e86_%llu_%lu.log", now, sequence);
	snprintf(hunt, 256, "bin/tests/e86_%llu_%lu.csv", now, sequence);
	ASSERT_TRUE(tracker_event_csv_sibling_path(hunt, events, 256));
	return (0);
}

/*
** Rôle: e86_run_case — Exécute un replay Fishing complet puis compare les
**       journaux V3/V4 aux attentes du scénario.
** Paramètre: log — fixture chat à analyser.
** Paramètre: expected — compteurs attendus pour ce cas.
** Retour: 0 lorsque parsing, parentage et nettoyage passent.
** Effets: crée puis supprime chat, V3 et V4 temporaires.
** Invariants: le mode Fishing est fixé avant l'initialisation du parser.
** Relations: e86_make_paths(), e86_write_log(),
**            test_fishing_e86_collect_stats(),
**            parse_run_replay(), hunt_rules_initialize().
** Appelants: main().
** Mémoire: le parse engine reste propriétaire de ses buffers dynamiques.
** I/O: fixtures temporaires uniquement.
** Unités: nombres d'événements.
** Portabilité: C99, chemins dérivés par API projet.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_parse_engine_fishing_e86.c ->
** e86_run_case().
** Dépendances: fonctions projet/libc citées explicitement dans Relations.
** État partagé: aucun nouvel état global mutable introduit ici.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût borné ou linéaire sur la collection parcourue.
*/
static int	e86_run_case(const char *log, const t_e86_expected *expected)
{
	t_app_state	app;
	t_e86_stats	stats;
	char		chat[256];
	char		hunt[256];
	char		events[256];

	TEST_RUN(e86_make_paths(chat, hunt, events));
	(void)remove(chat);
	(void)remove(hunt);
	(void)remove(events);
	ASSERT_TRUE(e86_write_log(chat, log));
	memset(&app, 0, sizeof(app));
	hunt_rules_initialize(&app.parse.rules);
	hunt_rules_set_activity_mode(&app.parse.rules, TRACKER_ACTIVITY_FISHING);
	ASSERT_I64_EQ(parse_run_replay(&app, chat, hunt, NULL), 0);
	TEST_RUN(test_fishing_e86_collect_stats(hunt, events, &stats));
	TEST_RUN(test_fishing_e86_check_expected(&stats, expected));
	(void)remove(chat);
	(void)remove(hunt);
	(void)remove(events);
	return (0);
}

/*
** Rôle: main — Vérifie raw-fish-only, huiles, candidat inconnu, skill parenté
**       et groupe supérieur à l'ancienne limite de seize outputs.
** Retour: 0 lorsque toutes les régressions E86 passent.
** Effets: crée uniquement des fichiers temporaires sous bin/tests.
** Invariants: aucune huile seule ne confirme une catch et aucun inconnu seul
**             n'est promu comme poisson.
** Relations: e86_run_case().
** Appelants: runner de tests.
** Mémoire: buffer overflow local borné par snprintf.
** I/O: indirect via les scénarios de replay.
** Unités: événements et uPED fournis dans les fixtures.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_parse_engine_fishing_e86.c ->
** main().
** Dépendances: fonctions projet/libc citées explicitement dans Relations.
** État partagé: aucun nouvel état global mutable introduit ici.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût borné ou linéaire sur la collection parcourue.
*/
int	main(void)
{
	char	overflow[8192];
	int	index;
	size_t	used;

	TEST_RUN(e86_run_case(g_raw_fish, &g_expected_raw));
	TEST_RUN(e86_run_case(g_crafting, &g_expected_craft));
	TEST_RUN(e86_run_case(g_family_oil, &g_expected_oil));
	TEST_RUN(e86_run_case(g_candidate, &g_expected_candidate));
	TEST_RUN(e86_run_case(g_skill, &g_expected_skill));
	used = 0;
	index = 0;
	while (index++ < 20)
		used += (size_t)snprintf(overflow + used, sizeof(overflow) - used,
			"2026-08-30 01:00:05 [System] [] You received "
			"Mystery Minnow x (1) Value: 0.01 PED\n");
	snprintf(overflow + used, sizeof(overflow) - used,
		"2026-08-30 01:00:05 [System] [] You received Fish Scrap "
		"x (10) Value: 0.001 PED\n");
	TEST_RUN(e86_run_case(overflow, &g_expected_overflow));
	return (0);
}
