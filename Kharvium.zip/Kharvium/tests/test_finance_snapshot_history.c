/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_snapshot_history.c                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_persistence.h"
#include "finance/finance_snapshot.h"
#include "common/money.h"
#include "platform/platform_file_system.h"

#include <stdio.h>

/*
** Rôle: parse_test_ped_amount — Analyse test ped amount.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: main(), add_auction_sale(), check_stackable_markup_rounding(),
**            check_summary(), add_asset(), add_purchase() (+7; index complet
**            dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_snapshot_history.c -> parse_test_ped_amount() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static t_money	parse_test_ped_amount(const char *text)
{
	t_money	value;

	value = 0;
	if (!money_parse_ped(text, &value))
		return (0);
	return (value);
}

/*
** Rôle: build_history — Construit history.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_snapshot_upsert(),
**            parse_test_ped_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_snapshot_history.c -> build_history() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	build_history(t_finance_book *book)
{
	book->opening_cash_uPED = parse_test_ped_amount("100.00000");
	if (!finance_snapshot_upsert(book, 20680))
		return (0);
	book->opening_cash_uPED = parse_test_ped_amount("125.00000");
	if (!finance_snapshot_upsert(book, 20681))
		return (0);
	book->opening_cash_uPED = parse_test_ped_amount("150.00000");
	if (!finance_snapshot_upsert(book, 20682))
		return (0);
	book->opening_cash_uPED = parse_test_ped_amount("175.00000");
	if (!finance_snapshot_upsert(book, 20682))
		return (0);
	if (book->snapshot_count != 3)
		return (0);
	return (book->snapshots[2].ped_card_uPED
		== parse_test_ped_amount("175.00000"));
}

/*
** Rôle: check_reload — Recharge l’état associé à check.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize_new(), finance_book_load(),
**            finance_book_save(), parse_test_ped_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_snapshot_history.c -> check_reload() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_reload(t_finance_book *book, const char *path)
{
	t_finance_book	loaded;
	int		ok;

	if (!finance_book_save(book, path))
		return (0);
	finance_book_initialize_new(&loaded);
	ok = finance_book_load(&loaded, path);
	if (ok)
		ok = loaded.snapshot_count == 3;
	if (ok)
		ok = loaded.snapshots[0].day_key == 20680;
	if (ok)
		ok = loaded.snapshots[2].day_key == 20682;
	if (ok)
		ok =
			loaded.snapshots[2].ped_card_uPED
			== parse_test_ped_amount("175.00000");
	finance_book_destroy(&loaded);
	return (ok);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> build_history(), check_reload(),
**            finance_book_destroy(), finance_book_initialize_new(),
**            platform_process_id().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_snapshot_history.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf(), printf(),
**              remove(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf(), remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_finance_book	book;
	char		path[256];
	int		ok;

	finance_book_initialize_new(&book);
	ok = build_history(&book);
	snprintf(path, sizeof(path), "bin/tests/snapshot_history_%d.csv",
		platform_process_id());
	if (ok)
		ok = check_reload(&book, path);
	finance_book_destroy(&book);
	remove(path);
	if (!ok)
		return (fprintf(stderr, "FAIL snapshot history\n"), 1);
	printf("test_finance_snapshot_history: OK\n");
	return (0);
}
