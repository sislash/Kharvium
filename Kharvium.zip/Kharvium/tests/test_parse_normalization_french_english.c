/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_parse_normalization_french_english.c                    +:+ :+: :+: */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_util.h"

#include "hunt/hunt_rules.h"

/*
** Rôle: run_normalization_sequence — Exécute normalisation sequence.
** Paramètre: shot — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: loot — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_parse_line(), hunt_pending_pop(),
**            hunt_rules_initialize().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_normalization_french_english.c ->
**        run_normalization_sequence() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_STR_EQ(), ASSERT_TRUE(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	run_normalization_sequence(const char *shot, const char *loot)
{
	t_hunt_rules	r;
	t_hunt_event	ev;
	t_hunt_event	pending;
	int			ret;

	hunt_rules_initialize(&r);
	memset(&ev, 0, sizeof(ev));
	ret = hunt_parse_line(&r, shot, &ev);
	ASSERT_I64_EQ(ret, 0);
	ASSERT_STR_EQ(ev.type, "SHOT");

	memset(&ev, 0, sizeof(ev));
	ret = hunt_parse_line(&r, loot, &ev);
	ASSERT_I64_EQ(ret, 1);
	ASSERT_STR_EQ(ev.type, "LOOT_ITEM");
	ASSERT_STR_EQ(ev.name, "Animal Oil Residue");
	ASSERT_STR_EQ(ev.qty, "2");
	ASSERT_STR_EQ(ev.value, "0.0200");

	memset(&pending, 0, sizeof(pending));
	ASSERT_TRUE(hunt_pending_pop(&r, &pending));
	ASSERT_STR_EQ(pending.type, "KILL");
	ASSERT_STR_EQ(pending.name, "UNKNOWN");
	return (0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> run_normalization_sequence().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_normalization_french_english.c -> main() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	const char	*ts;
	char		shot_en[256];
	char		loot_en[512];
	char		shot_fr[256];
	char		loot_fr[512];

	ts = "2026-01-01 12:00:00";
	snprintf(shot_en, sizeof(shot_en),
			"%s You inflicted 10.0 points of damage.", ts);
	snprintf(loot_en, sizeof(loot_en),
		"%s You received Animal Oil Residue x (2) Value: 0.0200 PED.", ts);

	snprintf(shot_fr, sizeof(shot_fr),
		"%s Vous avez inflig\xC3\xA9 10.0 points de d\xC3\xA9g\xC3\xA2ts.", ts);
	snprintf(loot_fr, sizeof(loot_fr),
		"%s Vous avez re\xC3\xA7u Animal Oil Residue x (2) Valeur: 0,0200 PED.",
			ts);

	ASSERT_I64_EQ(run_normalization_sequence(shot_en, loot_en), 0);
	ASSERT_I64_EQ(run_normalization_sequence(shot_fr, loot_fr), 0);
	return (0);
}
