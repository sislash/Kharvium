/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_tracker_finance_import.c                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_activity.h"
#include "finance/finance_book.h"
#include "finance/finance_calculations.h"
#include "integration/tracker_finance.h"

#include "common/money.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: parse_test_ped_amount — Analyse test ped amount.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: main(), add_auction_sale(), check_stackable_markup_rounding(),
**            check_summary(), add_asset(), add_purchase() (+7; index complet
**            dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_finance_import.c -> parse_test_ped_amount() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static t_money	parse_test_ped_amount(const char *text)
{
	t_money	value;

	value = 0;
	if (!money_parse_ped(text, &value))
		return (0);
	return (value);
}

/*
** Rôle: seed_stats — Formate seed dans le buffer destination fourni, avec une
**       taille explicitement bornée par l’appelant.
** Paramètre: stats — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : stats.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> parse_test_ped_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_finance_import.c -> seed_stats() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED, pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	seed_stats(t_hunt_stats *stats)
{
	memset(stats, 0, sizeof(*stats));
	stats->data_lines_read = 42;
	stats->kills = 10;
	stats->shots = 120;
	stats->expense_used = parse_test_ped_amount("18.50000");
	stats->loot_tt_ped = parse_test_ped_amount("20.00000");
	stats->loot_total_mu_ped = parse_test_ped_amount("22.75000");
	stats->top_mobs_count = 1;
	snprintf(stats->top_mobs[0].name,
		sizeof(stats->top_mobs[0].name), "%s", "Atrox");
	stats->has_weapon = 1;
	snprintf(stats->weapon_name, sizeof(stats->weapon_name),
		"%s", "ArMatrix LR-35");
}

/*
** Rôle: check_draft — Vérifie draft.
** Paramètre: draft — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> parse_test_ped_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_finance_import.c -> check_draft() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_draft(const t_finance_activity *draft)
{
	if (draft->kind != FIN_ACTIVITY_HUNT
		|| draft->status != FIN_ACTIVITY_DRAFT)
		return (0);
	if (strcmp(draft->target, "Atrox") != 0
		|| strcmp(draft->setup, "ArMatrix LR-35") != 0)
		return (0);
	if (draft->direct_ped_uPED != parse_test_ped_amount("18.50000"))
		return (0);
	if (draft->loot_tt_uPED != parse_test_ped_amount("20.00000")
		|| draft->loot_market_uPED != parse_test_ped_amount("22.75000"))
		return (0);
	if (draft->tt_result_uPED != parse_test_ped_amount("1.50000"))
		return (0);
	return (draft->market_result_uPED == parse_test_ped_amount("4.25000"));
}

/*
** Rôle: check_commit — Valide et applique l’état associé à check.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: draft — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book, draft.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_activity_commit(),
**            finance_summary_build(), parse_test_ped_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_finance_import.c -> check_commit() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_commit(t_finance_book *book, t_finance_activity *draft)
{
	t_finance_summary	summary;

	if (!finance_activity_commit(book, draft, NULL))
		return (0);
	if (book->activity_count != 1 || book->stock_count != 0)
		return (0);
	finance_summary_build(book, &summary);
	if (summary.cash_balance_uPED != parse_test_ped_amount("81.50000"))
		return (0);
	return (book->activities[0].market_result_uPED
		== parse_test_ped_amount("4.25000"));
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_commit(), check_draft(),
**            finance_book_destroy(), finance_book_initialize(),
**            finance_book_is_empty(), parse_test_ped_amount(), seed_stats(),
**            tracker_finance_build_hunt_draft().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_finance_import.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf(), printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: PED, quantité.
** Performance: boucles while locales=0; appels projet directs=8; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_finance_book	book;
	t_finance_activity	draft;
	t_hunt_stats	stats;
	int		ok;

	seed_stats(&stats);
	finance_book_initialize(&book, parse_test_ped_amount("100.00000"));
	ok = tracker_finance_build_hunt_draft(&draft, &stats, "", 1234);
	ok = ok && check_draft(&draft);
	ok = ok && finance_book_is_empty(&book) == 0;
	ok = ok && book.activity_count == 0 && book.stock_count == 0;
	ok = ok && check_commit(&book, &draft);
	finance_book_destroy(&book);
	if (!ok)
		return (fprintf(stderr, "test_tracker_finance_import: FAIL\n"), 1);
	printf("test_tracker_finance_import: OK\n");
	return (0);
}
