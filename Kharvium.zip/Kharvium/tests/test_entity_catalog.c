/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_entity_catalog.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "catalog/catalog_loader.h"
#include "catalog/catalog_registry.h"
#include "core/entity_id.h"
#include <stdio.h>
#include <string.h>

#define BAD_ITEMS "tests/.tmp_catalog_bad_items.csv"
#define BAD_WORLDS "tests/.tmp_catalog_bad_worlds.csv"
#define CRLF_ITEMS "tests/.tmp_catalog_crlf_items.csv"

/*
** Rôle: catalog_packaged_data — Vérifie que les catalogues de référence
**       E83
**       sont réellement chargés depuis les fichiers data et résolus par ID.
** Paramètres: aucun.
** Retour: Retourne 1 si les items/mondes attendus sont accessibles.
** Effets: ouvre les deux CSV de référence puis détruit le registre
**         temporaire.
** Invariants: aucune valeur de prix ou donnée utilisateur n'est nécessaire.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> catalog_load_items_file(),
**            catalog_load_worlds_file(), catalog_registry_destroy(),
**            catalog_registry_find_item_by_id(),
**            catalog_registry_find_item_by_name(),
**            catalog_registry_find_world_by_id(),
**            catalog_registry_initialize().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_entity_catalog.c -> catalog_packaged_data().
** Dépendances: strcmp().
** Mémoire: les tableaux dynamiques sont libérés avant le retour.
** État partagé: aucun.
** Concurrence: test séquentiel.
** I/O: lecture des catalogues data/catalog.
** Unités: identifiants canoniques.
** Performance: petit jeu de référence constant.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	catalog_packaged_data(void)
{
	t_catalog_registry	registry;
	const t_catalog_world	*ancient;
	const t_catalog_item	*scrap;
	int			ok;

	catalog_registry_initialize(&registry);
	ok = catalog_load_items_file(&registry, "data/catalog/items.csv");
	ok = ok && catalog_load_worlds_file(&registry, "data/catalog/worlds.csv");
	scrap = catalog_registry_find_item_by_name(&registry, "Fish Scrap");
	ancient = catalog_registry_find_world_by_id(&registry, 2009);
	ok = ok && registry.item_count >= 8 && registry.world_count == 11;
	ok = ok && scrap && scrap->item_id == 1005;
	ok = ok && catalog_registry_find_item_by_id(&registry, 1001) != NULL;
	ok = ok && ancient && ancient->parent_world_id == 2003;
	ok = ok && catalog_registry_validate_world_links(&registry);
	catalog_registry_destroy(&registry);
	return (ok);
}

/*
** Rôle: catalog_write_invalid_fixtures — Construit deux petits catalogues
**       invalides pour tester unicité et parent absent.
** Paramètres: aucun.
** Retour: Retourne 1 si les deux fichiers temporaires sont créés.
** Effets: crée BAD_ITEMS et BAD_WORLDS.
** Invariants: les fixtures sont volontairement invalides mais syntaxiquement
**             lisibles par le chargeur.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: catalog_rejects_invalid().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_entity_catalog.c -> catalog_write_invalid_fixtures().
** Dépendances: fclose(), fopen(), fprintf().
** Mémoire: aucune allocation dynamique.
** État partagé: fichiers temporaires dédiés au test.
** Concurrence: test séquentiel.
** I/O: écriture de deux fixtures CSV.
** Unités: identifiants canoniques.
** Performance: coût constant.
** Portabilité: C99 stdio.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	catalog_write_invalid_fixtures(void)
{
	FILE	*stream;

	stream = fopen(BAD_ITEMS, "wb");
	if (!stream)
		return (0);
	fprintf(stream, "schema_version;entity_id;canonical_name;category\n");
	fprintf(stream, "1;1;Duplicate;RESOURCE\n1;1;Other;RESOURCE\n");
	fclose(stream);
	stream = fopen(BAD_WORLDS, "wb");
	if (!stream)
		return (0);
	fprintf(stream, "schema_version;entity_id;canonical_name;world_type;"
		"parent_world_id\n");
	fprintf(stream, "1;10;Child;SUBWORLD;99\n");
	fclose(stream);
	return (1);
}

/*
** Rôle: catalog_rejects_invalid — Vérifie qu'un chargement invalide
**       restaure
**       les compteurs et ne rend aucune entrée partielle visible.
** Paramètres: aucun.
** Retour: Retourne 1 si duplicate ID et parent absent sont tous deux rejetés.
** Effets: charge puis détruit un registre temporaire.
** Invariants: item_count et world_count restent zéro après chaque rejet.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> catalog_load_items_file(),
**            catalog_load_worlds_file(), catalog_registry_destroy(),
**            catalog_registry_initialize(), catalog_write_invalid_fixtures().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_entity_catalog.c -> catalog_rejects_invalid().
** Dépendances: aucune.
** Mémoire: les capacités éventuellement allouées sont libérées par
**          destroy.
** État partagé: fixtures temporaires du test.
** Concurrence: test séquentiel.
** I/O: lecture des fixtures invalides.
** Unités: nombre d'entrées.
** Performance: coût constant.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	catalog_rejects_invalid(void)
{
	t_catalog_registry	registry;
	int			ok;

	if (!catalog_write_invalid_fixtures())
		return (0);
	catalog_registry_initialize(&registry);
	ok = !catalog_load_items_file(&registry, BAD_ITEMS);
	ok = ok && registry.item_count == 0;
	ok = ok && !catalog_load_worlds_file(&registry, BAD_WORLDS);
	ok = ok && registry.world_count == 0;
	catalog_registry_destroy(&registry);
	return (ok);
}

/*
** Rôle: catalog_accepts_crlf — Vérifie que le chargeur normalise CRLF sans
**       modifier les champs canoniques du catalogue.
** Paramètres: aucun.
** Retour: Retourne 1 si un item écrit en CRLF est chargé exactement.
** Effets: crée et charge un petit fichier temporaire.
** Invariants: le nom canonique ne conserve aucun caractère CR ou LF.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> catalog_load_items_file(),
**            catalog_registry_destroy(), catalog_registry_initialize().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_entity_catalog.c -> catalog_accepts_crlf().
** Dépendances: fclose(), fopen(), fprintf(), strcmp().
** Mémoire: les items chargés sont libérés avant retour.
** État partagé: fixture temporaire dédiée.
** Concurrence: test séquentiel.
** I/O: écriture puis lecture d'un CSV CRLF.
** Unités: identifiant canonique.
** Performance: coût constant.
** Portabilité: teste explicitement la compatibilité CRLF/LF.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	catalog_accepts_crlf(void)
{
	t_catalog_registry	registry;
	FILE			*stream;
	int			ok;

	stream = fopen(CRLF_ITEMS, "wb");
	if (!stream)
		return (0);
	fprintf(stream, "schema_version;entity_id;canonical_name;category\r\n");
	fprintf(stream, "1;77;CRLF Item;RESOURCE\r\n");
	fclose(stream);
	catalog_registry_initialize(&registry);
	ok = catalog_load_items_file(&registry, CRLF_ITEMS);
	ok = ok && registry.item_count == 1;
	ok = ok && strcmp(registry.items[0].canonical_name, "CRLF Item") == 0;
	catalog_registry_destroy(&registry);
	return (ok);
}

/*
** Rôle: main — Exécute les régressions E83 sur les IDs et catalogues puis
**       nettoie les fixtures invalides temporaires.
** Paramètres: aucun.
** Retour: Retourne 0 si toutes les propriétés E83 sont vérifiées, 1 sinon.
** Effets: supprime les deux fichiers temporaires et écrit le résultat stdout.
** Invariants: UNKNOWN et INVALID ne deviennent jamais des IDs valides.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> catalog_packaged_data(),
**            catalog_rejects_invalid(), entity_id_is_valid().
** Appelants: aucun.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_entity_catalog.c -> main().
** Dépendances: printf(), remove().
** Mémoire: aucune allocation directe.
** État partagé: aucun après suppression des fixtures.
** Concurrence: exécution séquentielle.
** I/O: lecture catalogues, fixtures et sortie stdout.
** Unités: identifiants canoniques.
** Performance: coût constant sur les catalogues de référence.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	int	ok;

	ok = !entity_id_is_valid(ENTITY_ID_UNKNOWN);
	ok = ok && !entity_id_is_valid(ENTITY_ID_INVALID);
	ok = ok && entity_id_is_valid(1);
	ok = ok && catalog_packaged_data() && catalog_rejects_invalid();
	ok = ok && catalog_accepts_crlf();
	(void)remove(BAD_ITEMS);
	(void)remove(BAD_WORLDS);
	(void)remove(CRLF_ITEMS);
	if (!ok)
		return (1);
	printf("test_entity_catalog: OK\n");
	return (0);
}
