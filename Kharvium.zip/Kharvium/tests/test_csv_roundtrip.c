/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_csv_roundtrip.c                              +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_util.h"

#include "io/hunt_csv.h"

#include <stdlib.h>

static const t_hunt_csv_row_view	g_rows[] = {
	{.timestamp_unix = 1700000000, .type_evenement = "KILL",
		.cible = "Exarosaur", .quantite = 1, .valeur_uPED = 0,
		.a_valeur = 0, .id_kill = 42, .drapeaux = 3u, .brut = "raw kill"},
	{.timestamp_unix = 1700000000, .type_evenement = "LOOT_ITEM",
		.cible = "Animal Oil Residue", .quantite = 2, .valeur_uPED = 200,
		.a_valeur = 1, .id_kill = 42, .drapeaux = 3u,
		.brut = "raw,with,comma"},
	{.timestamp_unix = 1700000001, .type_evenement = "SHOT",
		.cible = "", .quantite = 1, .valeur_uPED = 0, .a_valeur = 0,
		.id_kill = 0, .drapeaux = 0u, .brut = ""}
};

/*
** Rôle: write_rows — Écrit lignes.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : f.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_ensure_header_v2(),
**            hunt_csv_write_v2().
** Appelants: test_hunt_loot_write_missing(), test_hunt_loot_write_partial(),
**            main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_roundtrip.c -> write_rows() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), fflush().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_rows.
** Concurrence: état global mutable détecté (g_rows); synchronisation externe
**              requise si plusieurs threads y accèdent simultanément.
** I/O: primitives système/stdio directes -> fflush().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	write_rows(FILE *f)
{
	int	index;

	ASSERT_TRUE(f != NULL);
	hunt_csv_ensure_header_v2(f);
	index = 0;
	while (index < 3)
	{
		ASSERT_I64_EQ(hunt_csv_write_v2(f, &g_rows[index]), 0);
		index++;
	}
	fflush(f);
	return (0);
}
/*
** Rôle: check_row — Vérifie ligne.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_parse_replay_rows_check(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_roundtrip.c -> check_row() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_STR_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_row(const t_hunt_csv_row_view *row, int count)
{
	if (count == 1)
	{
		ASSERT_I64_EQ(row->timestamp_unix, 1700000000);
		ASSERT_STR_EQ(row->type_evenement, "KILL");
		ASSERT_STR_EQ(row->cible, "Exarosaur");
		ASSERT_I64_EQ(row->quantite, 1);
		ASSERT_I64_EQ(row->valeur_uPED, 0);
		ASSERT_I64_EQ(row->id_kill, 42);
		ASSERT_I64_EQ(row->drapeaux, 3);
		ASSERT_STR_EQ(row->brut, "raw kill");
	}
	else if (count == 2)
	{
		ASSERT_STR_EQ(row->type_evenement, "LOOT_ITEM");
		ASSERT_STR_EQ(row->cible, "Animal Oil Residue");
		ASSERT_I64_EQ(row->quantite, 2);
		ASSERT_I64_EQ(row->valeur_uPED, 200);
		ASSERT_I64_EQ(row->id_kill, 42);
		ASSERT_STR_EQ(row->brut, "raw,with,comma");
	}
	else if (count == 3)
		ASSERT_STR_EQ(row->type_evenement, "SHOT");
	return (0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_row(),
**            hunt_csv_parse_row_inplace(), write_rows().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_roundtrip.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), fclose(), fgets(), rewind(), tmpfile().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), tmpfile().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=3; dépendances
**              externes/macros=6. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	FILE			*f;
	char			line[8192];
	t_hunt_csv_row_view	row;
	int			count;

	f = tmpfile();
	ASSERT_TRUE(f != NULL);
	ASSERT_I64_EQ(write_rows(f), 0);
	rewind(f);
	count = 0;
	while (fgets(line, sizeof(line), f))
	{
		if (!hunt_csv_parse_row_inplace(line, &row))
			continue ;
		count++;
		ASSERT_I64_EQ(check_row(&row, count), 0);
	}
	fclose(f);
	ASSERT_I64_EQ(count, 3);
	return (0);
}
