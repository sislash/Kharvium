/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_csv_data_module.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29 15:00:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/29 15:00:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "io/csv_data.h"
#include "io/csv_index.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

/*
** Rôle: fill_data — Compare fill data selon les règles de chaîne du module et
**       retourne le résultat sans modifier les entrées.
** Paramètre: data — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: rows — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : data, rows.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_round_trip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_data_module.c -> fill_data() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	fill_data(t_csv_data *data, t_csv_data_row *rows)
{
	memset(data, 0, sizeof(*data));
	memset(rows, 0, sizeof(*rows) * 3);
	rows[0].timestamp = 100;
	rows[0].event_type = "loot;\"rare\"";
	rows[0].value = 1.25;
	rows[1].timestamp = 200;
	rows[1].event_type = "cost";
	rows[1].value = 2.5;
	rows[1].hit_count_reset = 1;
	rows[2].timestamp = 300;
	rows[2].event_type = "loot";
	rows[2].value = 3.75;
	data->rows = rows;
	data->count = 3;
	data->capacity = 3;
}

/*
** Rôle: test_round_trip — Compare round trip selon les règles de chaîne du
**       module et retourne le résultat sans modifier les entrées.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_data_free(), csv_data_load(),
**            csv_data_save(), csv_load_options_default(),
**            csv_write_options_default(), fill_data().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_data_module.c -> test_round_trip() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fabs(), strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_round_trip(const char *path)
{
	t_csv_data			data;
	t_csv_data_row		rows[3];
	t_csv_write_options	write_options;
	t_csv_load_options	load_options;
	t_csv_data			*loaded;

	fill_data(&data, rows);
	csv_write_options_default(&write_options);
	write_options.delimiter = ';';
	write_options.fsync_on_close = 0;
	write_options.write_crc32_footer = 1;
	if (!csv_data_save(path, &data, &write_options, NULL))
		return (0);
	csv_load_options_default(&load_options);
	load_options.verify_crc32 = 1;
	loaded = csv_data_load(path, &load_options, NULL);
	if (!loaded || loaded->count != 3)
		return (csv_data_free(loaded), 0);
	if (strcmp(loaded->rows[0].event_type, "loot;\"rare\"") != 0)
		return (csv_data_free(loaded), 0);
	if (fabs(loaded->rows[2].value - 3.75) > 0.000001)
		return (csv_data_free(loaded), 0);
	csv_data_free(loaded);
	return (1);
}

/*
** Rôle: test_load_since — Charge since depuis la source fournie, contrôle le
**       format utile et ne renseigne la destination qu’avec des données
**       validées.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_data_free(), csv_data_load_since(),
**            csv_load_options_default().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_data_module.c -> test_load_since() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_load_since(const char *path)
{
	t_csv_load_options	options;
	t_csv_load_report	report;
	t_csv_data			*loaded;

	csv_load_options_default(&options);
	loaded = csv_data_load_since(path, 200, &options, &report);
	if (!loaded)
		return (0);
	if (loaded->count != 2 || report.loaded_rows != 2)
		return (csv_data_free(loaded), 0);
	if (loaded->rows[0].timestamp != 200)
		return (csv_data_free(loaded), 0);
	csv_data_free(loaded);
	return (1);
}

/*
** Rôle: test_indexed_load — Charge l’état associé à test indexed.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_data_free(),
**            csv_data_load_since_indexed(), csv_index_build(),
**            csv_index_options_default(), csv_load_options_default().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_data_module.c -> test_indexed_load() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_indexed_load(const char *path)
{
	t_csv_index_options	index_options;
	t_csv_index_report	index_report;
	t_csv_load_options	load_options;
	t_csv_load_report	load_report;
	t_csv_data			*loaded;

	csv_index_options_default(&index_options);
	index_options.stride_rows = 1;
	if (!csv_index_build(path, &index_options, &index_report))
		return (0);
	csv_load_options_default(&load_options);
	loaded = csv_data_load_since_indexed(path, 200, &load_options,
		&load_report);
	if (!loaded)
		return (0);
	if (loaded->count != 2 || loaded->rows[0].timestamp != 200)
		return (csv_data_free(loaded), 0);
	csv_data_free(loaded);
	return (1);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_index_remove(), test_indexed_load(),
**            test_load_since(), test_round_trip().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_data_module.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> printf(), remove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	const char	*path;

	path = "/tmp/kharvium_csv_data_module.csv";
	remove(path);
	csv_index_remove(path);
	if (!test_round_trip(path) || !test_load_since(path)
		|| !test_indexed_load(path))
		return (1);
	csv_index_remove(path);
	remove(path);
	printf("test_csv_data_module: OK\n");
	return (0);
}
