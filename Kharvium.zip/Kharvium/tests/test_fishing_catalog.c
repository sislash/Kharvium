/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_catalog.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "catalog/catalog_loader.h"
#include "catalog/catalog_registry.h"
#include <stdio.h>
#include <string.h>

#define BAD_OUTPUTS "tests/.tmp_fishing_outputs_bad.csv"

/*
** Rôle: load_catalogs — Charge les items, rôles Fishing et skills depuis les
**       données packagées utilisées par le parser de production.
** Paramètre: registry — registre vide détenu par le test.
** Retour: 1 lorsque les trois fichiers sont valides, 0 sinon.
** Effets: remplit les collections dynamiques du registre.
** Invariants: le catalogue output ne peut référencer qu'un item existant.
** Relations: catalog_load_items_file(), catalog_load_fishing_outputs_file(),
**            catalog_load_fishing_skills_file().
** Appelants: check_packaged_catalog(), check_invalid_mapping().
** Mémoire: les allocations restent la propriété de registry.
** I/O: lit trois CSV de data/catalog.
** Unités: IDs canoniques et rôles symboliques.
** Portabilité: C99, chemins relatifs du paquet de test.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_catalog.c ->
** load_catalogs().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût local borné ou linéaire sur la collection parcourue.
*/
static int	load_catalogs(t_catalog_registry *registry)
{
	if (!catalog_load_items_file(registry, "data/catalog/items.csv"))
		return (0);
	if (!catalog_load_fishing_outputs_file(registry,
			"data/catalog/fishing_outputs.csv"))
		return (0);
	return (catalog_load_fishing_skills_file(registry,
			"data/catalog/fishing_skills.csv"));
}

/*
** Rôle: check_packaged_catalog — Vérifie les classifications qui empêchent
**       les faux noms d'espèces et autorisent le raw-fish-only.
** Retour: 0 si les rôles et skills attendus sont exacts, 1 sinon.
** Effets: charge puis détruit un registre temporaire.
** Invariants: seuls les RAW_FISH peuvent devenir noms de prises.
** Relations: load_catalogs(), catalog_registry_find_fishing_output(),
**            catalog_registry_is_fishing_skill(), catalog_registry_destroy().
** Appelants: main().
** Mémoire: toutes les collections sont libérées avant retour.
** I/O: lecture des catalogues packagés.
** Unités: rôles Fishing.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_catalog.c ->
** check_packaged_catalog().
** Dépendances: fonctions projet/libc citées explicitement dans Relations.
** État partagé: aucun nouvel état global mutable introduit ici.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût borné ou linéaire sur la collection parcourue.
*/
static int	check_packaged_catalog(void)
{
	t_catalog_registry		registry;
	const t_catalog_fishing_output	*entry;

	catalog_registry_initialize(&registry);
	ASSERT_TRUE(load_catalogs(&registry));
	entry = catalog_registry_find_fishing_output(&registry, "Blue Snapper");
	ASSERT_TRUE(entry && entry->role == FISHING_OUTPUT_RAW_FISH);
	entry = catalog_registry_find_fishing_output(&registry, "Fish Scrap");
	ASSERT_TRUE(entry && entry->role == FISHING_OUTPUT_FISH_SCRAP);
	entry = catalog_registry_find_fishing_output(&registry, "Fish Oil");
	ASSERT_TRUE(entry && entry->role == FISHING_OUTPUT_GENERIC_FISH_OIL);
	entry = catalog_registry_find_fishing_output(&registry, "Tuna Fish Oil");
	ASSERT_TRUE(entry && entry->role == FISHING_OUTPUT_FAMILY_FISH_OIL);
	ASSERT_TRUE(catalog_registry_is_fishing_skill(&registry, "Angling"));
	ASSERT_TRUE(!catalog_registry_is_fishing_skill(&registry, "Provisioning"));
	catalog_registry_destroy(&registry);
	return (0);
}

/*
** Rôle: write_bad_mapping — Crée une définition Fishing qui référence un ID
**       canonique absent afin de tester le rollback du chargeur.
** Retour: 1 si la fixture est créée, 0 sinon.
** Effets: écrit BAD_OUTPUTS.
** Invariants: le CSV est syntaxiquement valide mais sémantiquement invalide.
** Relations: aucune fonction projet appelée directement.
** Appelants: check_invalid_mapping().
** Mémoire: aucune allocation dynamique.
** I/O: écriture d'une fixture temporaire.
** Unités: ID canonique.
** Portabilité: C99 stdio.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_catalog.c ->
** write_bad_mapping().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût local borné ou linéaire sur la collection parcourue.
*/
static int	write_bad_mapping(void)
{
	FILE	*file;

	file = fopen(BAD_OUTPUTS, "wb");
	if (!file)
		return (0);
	fprintf(file, "schema_version;item_type_id;canonical_name;role\n");
	fprintf(file, "1;999999;Missing Fish;RAW_FISH\n");
	fclose(file);
	return (1);
}

/*
** Rôle: check_invalid_mapping — Vérifie qu'un mapping vers un item absent est
**       rejeté sans laisser d'entrée Fishing partielle.
** Retour: 0 si le rejet/rollback est correct, 1 sinon.
** Effets: crée, charge puis supprime BAD_OUTPUTS.
** Invariants: fishing_output_count reste inchangé après l'échec.
** Relations: write_bad_mapping(), catalog_load_items_file(),
**            catalog_load_fishing_outputs_file(), catalog_registry_destroy().
** Appelants: main().
** Mémoire: le registre temporaire est toujours détruit.
** I/O: lecture/écriture d'une fixture de test.
** Unités: nombre d'entrées.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_catalog.c ->
** check_invalid_mapping().
** Dépendances: fonctions projet/libc citées explicitement dans Relations.
** État partagé: aucun nouvel état global mutable introduit ici.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût borné ou linéaire sur la collection parcourue.
*/
static int	check_invalid_mapping(void)
{
	t_catalog_registry	registry;

	ASSERT_TRUE(write_bad_mapping());
	catalog_registry_initialize(&registry);
	ASSERT_TRUE(catalog_load_items_file(&registry, "data/catalog/items.csv"));
	ASSERT_TRUE(!catalog_load_fishing_outputs_file(&registry, BAD_OUTPUTS));
	ASSERT_I64_EQ(registry.fishing_output_count, 0);
	catalog_registry_destroy(&registry);
	(void)remove(BAD_OUTPUTS);
	return (0);
}

/*
** Rôle: main — Exécute les régressions E86 du catalogue Fishing data-driven.
** Retour: 0 si les classifications et validations sont correctes.
** Effets: peut créer puis supprimer une fixture temporaire.
** Invariants: aucune heuristique de nom ne remplace le rôle du catalogue.
** Relations: check_packaged_catalog(), check_invalid_mapping().
** Appelants: runner de tests.
** Mémoire: aucune allocation directe.
** I/O: catalogues packagés et fixture locale.
** Unités: rôles et IDs.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_catalog.c -> main().
** Dépendances: fonctions projet/libc citées explicitement dans Relations.
** État partagé: aucun nouvel état global mutable introduit ici.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût borné ou linéaire sur la collection parcourue.
*/
int	main(void)
{
	TEST_RUN(check_packaged_catalog());
	TEST_RUN(check_invalid_mapping());
	return (0);
}
