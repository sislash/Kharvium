/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_loot_group_extreme.c                         +:+      :+:  :+: */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_util.h"

#include "io/hunt_csv.h"
#include "hunt/hunt_series.h"
#include "platform/platform_file_system.h"
#include "support/test_hunt_extreme_support.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
** Rôle: make_temporary_path — Construit ou résout le chemin utilisé par
**       make temporary.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_process_id().
** Appelants: main(), main(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_group_extreme.c -> make_temporary_path() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	make_temporary_path(char *out, size_t outsz)
{
	int	pid;

	if (!out || outsz < 32)
		return (0);
	pid = platform_process_id();
	snprintf(out, outsz, "bin/tests/tmp_loot_group_%d.csv", pid);
	return (1);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> make_temporary_path(),
**            test_hunt_extreme_verify(), test_hunt_extreme_write().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_group_extreme.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), remove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	char	path[512];

	ASSERT_TRUE(make_temporary_path(path, sizeof(path)));
	ASSERT_I64_EQ(test_hunt_extreme_write(path), 0);
	ASSERT_I64_EQ(test_hunt_extreme_verify(path), 0);
	(void)remove(path);
	return (0);
}
