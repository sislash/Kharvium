/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_rod_config.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "support/test_fishing_rod_config_support.h"
#include "config/fishing_rod_config.h"
#include "config/selected_fishing_rod.h"
#include <string.h>

#define TMP_INI "tests/.tmp_fishing_rods.ini"
#define TMP_SELECTED "tests/.tmp_selected_fishing_rod.txt"

/*
** Rôle: check_packaged_loadout — Vérifie le chargement d'un montage complet
**       et son application sans TT/coût inventé.
** Retour: 0 sur succès, 1 via ASSERT sur régression.
** Effets: charge puis libère catalogue/base temporaires.
** Invariants: les mesures TT du snapshot restent explicitement absentes.
** Relations: test_fishing_rod_load_config(), fishing_rod_database_find(),
**            fishing_rod_preset_apply(), test_fishing_rod_check_snapshot().
** Appelants: main().
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_packaged_loadout().
** Dépendances: fishing_rods.ini packagé.
** Mémoire: toute allocation est libérée avant retour.
** État partagé: aucun.
** Concurrence: test mono-thread.
** I/O: fichiers locaux packagés.
** Unités: IDs et drapeaux de mesure.
** Performance: linéaire sur catalogue/config.
** Portabilité: C99 Windows/Linux.
*/
static int	check_packaged_loadout(void)
{
	t_catalog_registry		registry;
	t_fishing_rod_database		database;
	const t_fishing_rod_preset	*preset;
	t_fishing_loadout_snapshot	snapshot;

	ASSERT_TRUE(test_fishing_rod_load_config(&registry, &database));
	ASSERT_I64_EQ(database.count, 24);
	ASSERT_I64_EQ(database.component_count, 117);
	ASSERT_I64_EQ(registry.fishing_gear_count, 115);
	ASSERT_I64_EQ(registry.fishing_ammo_count, 2);
	preset = fishing_rod_database_find(&database, "SET-FR1 Angling - River");
	ASSERT_TRUE(preset && preset->complete);
	ASSERT_TRUE(fishing_rod_preset_apply(&snapshot, preset, &registry));
	ASSERT_TRUE(!snapshot.components[0].has_tt_before);
	ASSERT_TRUE(!snapshot.ammo.has_quantity_before);
	ASSERT_TRUE(test_fishing_rod_check_snapshot(&snapshot) == 0);
	preset = fishing_rod_database_find(&database,
			"SET-FR1 Angling - Restricted");
	ASSERT_TRUE(preset && preset->complete && preset->ammo_id == 1008);
	test_fishing_rod_cleanup_config(&registry, &database);
	return (0);
}

/*
** Rôle: check_invalid_presets — Vérifie successivement absence de Lure,
**       mauvais slot Reel et ammo étrangère au Fishing.
** Retour: 0 si les trois erreurs sont rejetées, 1 sinon.
** Effets: délègue la création/suppression des fixtures.
** Invariants: aucun cas invalide ne devient un loadout complet.
** Relations: test_fishing_rod_invalid_rejected().
** Appelants: main().
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_invalid_presets().
** Dépendances: trois modes de fixture.
** Mémoire: aucune allocation directe.
** État partagé: aucun hors fixture temporaire.
** Concurrence: mono-thread.
** I/O: déléguée au helper.
** Unités: mode de test.
** Performance: trois chargements courts.
** Portabilité: C99 Windows/Linux.
*/
static int	check_invalid_presets(void)
{
	ASSERT_TRUE(test_fishing_rod_invalid_rejected(0) == 0);
	ASSERT_TRUE(test_fishing_rod_invalid_rejected(1) == 0);
	ASSERT_TRUE(test_fishing_rod_invalid_rejected(2) == 0);
	return (0);
}

/*
** Rôle: check_roundtrip — Vérifie qu'une base INI chargée peut être sauvée
**       puis rechargée sans perdre sa composition.
** Retour: 0 si presets et catalogue v2 survivent au roundtrip, 1 sinon.
** Effets: écrit puis supprime TMP_INI.
** Invariants: aucune donnée économique absente n'est ajoutée par save.
** Relations: test_fishing_rod_load_config(), fishing_rod_database_save(),
**            fishing_rod_database_load(), fishing_rod_database_find().
** Appelants: main().
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_roundtrip().
** Dépendances: sérialiseur fishing_rods.ini.
** Mémoire: bases/catalogue toujours libérés.
** État partagé: fichier temporaire.
** Concurrence: mono-thread.
** I/O: lecture/écriture INI locale.
** Unités: presets et composants v2.
** Performance: linéaire sur deux sections.
** Portabilité: C99 Windows/Linux.
*/
static int	check_roundtrip(void)
{
	t_catalog_registry	registry;
	t_fishing_rod_database	database;
	t_fishing_rod_database	reloaded;

	ASSERT_TRUE(test_fishing_rod_load_config(&registry, &database));
	memset(&reloaded, 0, sizeof(reloaded));
	ASSERT_TRUE(fishing_rod_database_save(&database, TMP_INI));
	ASSERT_TRUE(fishing_rod_database_load(&reloaded, TMP_INI, &registry));
	ASSERT_I64_EQ(reloaded.count, database.count);
	ASSERT_I64_EQ(reloaded.component_count, database.component_count);
	ASSERT_TRUE(fishing_rod_database_find(&reloaded,
			"Omegaton Abyss D-100 - Deep") != NULL);
	fishing_rod_database_free(&reloaded);
	test_fishing_rod_cleanup_config(&registry, &database);
	(void)remove(TMP_INI);
	return (0);
}

/*
** Rôle: check_selected_roundtrip — Vérifie la persistance indépendante du
**       nom de preset actif utilisée par le futur picker Fishing.
** Retour: 0 si le nom relu est strictement identique, 1 sinon.
** Effets: écrit puis supprime TMP_SELECTED.
** Invariants: seul le nom du preset est persisté dans le fichier de sélection.
** Relations: selected_fishing_rod_save(), selected_fishing_rod_load(),
**            strcmp(), remove().
** Appelants: main().
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_selected_roundtrip().
** Dépendances: stdio via module de sélection.
** Mémoire: buffer fixe uniquement.
** État partagé: fichier temporaire.
** Concurrence: mono-thread.
** I/O: lecture/écriture d'un nom.
** Unités: aucune.
** Performance: O(longueur du nom).
** Portabilité: C99 Windows/Linux.
*/
static int	check_selected_roundtrip(void)
{
	char	name[128];

	ASSERT_TRUE(selected_fishing_rod_save(TMP_SELECTED,
			"SET-FR1 Angling - River") == 0);
	ASSERT_TRUE(selected_fishing_rod_load(TMP_SELECTED, name,
			sizeof(name)) == 0);
	ASSERT_TRUE(strcmp(name, "SET-FR1 Angling - River") == 0);
	(void)remove(TMP_SELECTED);
	return (0);
}

/*
** Rôle: main — Exécute les régressions du catalogue INI de cannes E90.
** Retour: 0 si chargement, validation, save et sélection restent corrects.
** Effets: lance les tests et leurs fixtures temporaires.
** Invariants: aucune fixture n'est conservée après succès.
** Relations: check_packaged_loadout(), test_fishing_rod_direct_picker(),
**            check_roundtrip(), check_selected_roundtrip().
** Appelants: cible make test.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_rod_config.c -> main().
** Dépendances: macros TEST_RUN.
** Mémoire: aucune allocation directe.
** État partagé: aucun.
** Concurrence: mono-thread.
** I/O: déléguée aux sous-tests.
** Unités: nombre de sous-tests.
** Performance: bornée par quelques chargements de petits fichiers.
** Portabilité: C99 Windows/Linux.
*/
int	main(void)
{
	TEST_RUN(check_packaged_loadout());
	TEST_RUN(test_fishing_rod_direct_picker());
	TEST_RUN(check_invalid_presets());
	TEST_RUN(check_roundtrip());
	TEST_RUN(check_selected_roundtrip());
	return (0);
}
