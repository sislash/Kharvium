/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_loadout_cost.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "support/test_fishing_loadout_e88_support.h"
#include "test_util.h"

/*
** Rôle: check_packaged_gear — Valide le snapshot technique local E88.
** Relations: test_e88_load_catalog(), catalog_registry_find_fishing_gear(),
**            catalog_registry_find_fishing_ammo(), catalog_registry_destroy().
** Appelants: main().
** Mémoire: registre temporaire détruit.
** Invariants: aucun MU marchand n'est présent dans ces assertions.
** Retour: 0 si données attendues exactes.
** Effets: lecture catalogues locaux.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_loadout_cost.c ->
** check_packaged_gear().
** Dépendances: API catalogue E88.
** État partagé: aucun.
** Concurrence: mono-thread.
** I/O: CSV locaux.
** Unités: x100/cm/uPED5.
** Performance: coût borné.
** Portabilité: C99 Windows/Linux.
*/
static int	check_packaged_gear(void)
{
	t_catalog_registry		registry;
	const t_catalog_fishing_gear	*gear;
	const t_catalog_fishing_ammo	*ammo;

	catalog_registry_initialize(&registry);
	ASSERT_TRUE(test_e88_load_catalog(&registry));
	gear = catalog_registry_find_fishing_gear(&registry, 1301);
	ASSERT_TRUE(gear && gear->slot == FISHING_GEAR_SLOT_ROD);
	ASSERT_I64_EQ(gear->strength_x100, 100);
	ASSERT_I64_EQ(gear->ammo_burn, 1800);
	gear = catalog_registry_find_fishing_gear(&registry, 1331);
	ASSERT_TRUE(gear && gear->line_length_cm == 6000);
	gear = catalog_registry_find_fishing_gear(&registry, 1341);
	ASSERT_TRUE(gear && gear->lure_depth_cm == 1500);
	ASSERT_I64_EQ(gear->lure_quality_x100, 500);
	ammo = catalog_registry_find_fishing_ammo(&registry, 1008);
	ASSERT_TRUE(ammo && !ammo->tradeable);
	catalog_registry_destroy(&registry);
	return (0);
}

/*
** Rôle: check_measured_cost — Vérifie stats et coûts depuis mesures/bases.
** Relations: test_e88_build_measured_loadout(),
**            fishing_loadout_compute_stats(), fishing_loadout_calculate_cost().
** Appelants: main().
** Mémoire: registre temporaire détruit.
** Invariants: bases d'acquisition du test sont synthétiques et non persistées.
** Retour: 0 si résultats exacts.
** Effets: aucun état persistant.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_loadout_cost.c ->
** check_measured_cost().
** Dépendances: modèle loadout E88.
** État partagé: aucun.
** Concurrence: mono-thread.
** I/O: catalogues locaux.
** Unités: x100/cm/uPED5.
** Performance: coût borné.
** Portabilité: C99 Windows/Linux.
*/
static int	check_measured_cost(void)
{
	t_catalog_registry		registry;
	t_fishing_loadout_snapshot	loadout;
	t_fishing_loadout_cost		cost;

	catalog_registry_initialize(&registry);
	fishing_loadout_initialize(&loadout);
	ASSERT_TRUE(test_e88_load_catalog(&registry));
	ASSERT_TRUE(test_e88_build_measured_loadout(&loadout, &registry));
	ASSERT_TRUE(fishing_loadout_compute_stats(&loadout, &registry));
	ASSERT_I64_EQ(loadout.stats.strength_x100, 700);
	ASSERT_I64_EQ(loadout.stats.flexibility_x100, 700);
	ASSERT_I64_EQ(loadout.stats.reel_strength_x100, 1500);
	ASSERT_I64_EQ(loadout.stats.reel_speed_x100, 300);
	ASSERT_I64_EQ(loadout.stats.line_length_cm, 6000);
	ASSERT_I64_EQ(loadout.stats.lure_depth_cm, 1500);
	ASSERT_I64_EQ(loadout.stats.lure_quality_x100, 500);
	ASSERT_TRUE(fishing_loadout_calculate_cost(&loadout, &registry, &cost));
	ASSERT_I64_EQ(cost.total_tt_cost, 22800);
	ASSERT_I64_EQ(cost.total_cost_basis_consumed, 28800);
	ASSERT_I64_EQ(cost.tt_quality, DATA_COMPLETE);
	ASSERT_I64_EQ(cost.cost_basis_quality, DATA_COMPLETE);
	catalog_registry_destroy(&registry);
	return (0);
}

/*
** Rôle: check_restricted_spool — Valide TT d'usage et base cash zéro.
** Relations: test_e88_load_catalog(), fishing_loadout_set_ammo(),
**            fishing_loadout_set_ammo_basis(),
**            fishing_loadout_calculate_cost().
** Appelants: main().
** Mémoire: registre temporaire détruit.
** Invariants: aucune valeur marché n'est inventée pour Restricted Spool.
** Retour: 0 si TT=100, coût base=0 et qualités complètes.
** Effets: aucun état persistant.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_loadout_cost.c ->
** check_restricted_spool().
** Dépendances: modèle ammo E88.
** État partagé: aucun.
** Concurrence: mono-thread.
** I/O: catalogue local.
** Unités: uPED5.
** Performance: coût borné.
** Portabilité: C99 Windows/Linux.
*/
static int	check_restricted_spool(void)
{
	t_catalog_registry		registry;
	t_fishing_loadout_snapshot	loadout;
	t_fishing_loadout_cost		cost;
	const t_catalog_fishing_ammo	*ammo;

	catalog_registry_initialize(&registry);
	fishing_loadout_initialize(&loadout);
	ASSERT_TRUE(test_e88_load_catalog(&registry));
	ammo = catalog_registry_find_fishing_ammo(&registry, 1008);
	ASSERT_TRUE(ammo && !ammo->tradeable);
	ASSERT_TRUE(fishing_loadout_set_ammo(&loadout, ammo, 100, 90));
	ASSERT_TRUE(fishing_loadout_set_ammo_basis(&loadout, 100, 0));
	ASSERT_TRUE(fishing_loadout_calculate_cost(&loadout, &registry, &cost));
	ASSERT_I64_EQ(cost.ammo_tt_cost, 100);
	ASSERT_I64_EQ(cost.ammo_cost_basis_consumed, 0);
	ASSERT_I64_EQ(cost.tt_quality, DATA_COMPLETE);
	ASSERT_I64_EQ(cost.cost_basis_quality, DATA_COMPLETE);
	catalog_registry_destroy(&registry);
	return (0);
}

/*
** Rôle: check_partial_basis — Sépare TT mesuré et base d'acquisition absente.
** Relations: test_e88_load_catalog(), fishing_loadout_set_component(),
**            fishing_loadout_calculate_cost().
** Appelants: main().
** Mémoire: registre temporaire détruit.
** Invariants: aucun coût d'acquisition n'est inventé depuis le TT mesuré.
** Retour: 0 si TT complet et coût historique marqué partiel.
** Effets: aucun état persistant.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_loadout_cost.c ->
** check_partial_basis().
** Dépendances: modèle de qualité E82 et loadout E88.
** État partagé: aucun.
** Concurrence: mono-thread.
** I/O: catalogues locaux.
** Unités: uPED5.
** Performance: coût borné.
** Portabilité: C99 Windows/Linux.
*/
static int	check_partial_basis(void)
{
	t_catalog_registry		registry;
	t_fishing_loadout_snapshot	loadout;
	t_fishing_loadout_cost		cost;
	const t_catalog_fishing_gear	*gear;

	catalog_registry_initialize(&registry);
	fishing_loadout_initialize(&loadout);
	ASSERT_TRUE(test_e88_load_catalog(&registry));
	gear = catalog_registry_find_fishing_gear(&registry, 1301);
	ASSERT_TRUE(gear != NULL);
	ASSERT_TRUE(fishing_loadout_set_component(&loadout, gear,
			gear->max_tt, gear->max_tt - gear->decay_per_use));
	ASSERT_TRUE(fishing_loadout_calculate_cost(&loadout, &registry, &cost));
	ASSERT_I64_EQ(cost.total_tt_cost, gear->decay_per_use);
	ASSERT_I64_EQ(cost.total_cost_basis_consumed, 0);
	ASSERT_I64_EQ(cost.tt_quality, DATA_COMPLETE);
	ASSERT_I64_EQ(cost.cost_basis_quality, DATA_PARTIAL_COST);
	catalog_registry_destroy(&registry);
	return (0);
}

/*
** Rôle: main — Exécute les régressions loadout/coût Fishing E88.
** Relations: check_packaged_gear(), check_measured_cost(),
**            check_restricted_spool(), check_partial_basis().
** Appelants: runner Makefile.
** Mémoire: gérée par sous-tests.
** Invariants: aucune donnée de prix réelle créée.
** Retour: 0 si tous les tests passent.
** Effets: aucun artefact persistant.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_loadout_cost.c -> main().
** Dépendances: framework tests.
** État partagé: aucun.
** Concurrence: mono-thread.
** I/O: catalogues locaux.
** Unités: diverses.
** Performance: coût faible.
** Portabilité: C99 Windows/Linux.
*/
int	main(void)
{
	TEST_RUN(check_packaged_gear());
	TEST_RUN(check_measured_cost());
	TEST_RUN(check_restricted_spool());
	TEST_RUN(check_partial_basis());
	return (0);
}
