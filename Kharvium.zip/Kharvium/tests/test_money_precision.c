/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_money_precision.c                            +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_util.h"

#include "common/money.h"

#include <limits.h>
#include <math.h>

/*
** Rôle: check_parse_and_format — Formate l’état associé à check parsing
**       and.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_format_ped_4_decimals(),
**            money_format_ped_5_decimals(), money_parse_ped().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_money_precision.c -> check_parse_and_format() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_STR_EQ(), ASSERT_TRUE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_parse_and_format(void)
{
	t_money	v;
	char		buf[64];

	ASSERT_TRUE(money_parse_ped("1.23456", &v));
	ASSERT_I64_EQ(v, 123456);
	money_format_ped_4_decimals(buf, sizeof(buf), v);
	ASSERT_STR_EQ(buf, "1.2346");
	ASSERT_TRUE(money_parse_ped("0,00999", &v));
	ASSERT_I64_EQ(v, 999);
	money_format_ped_4_decimals(buf, sizeof(buf), v);
	ASSERT_STR_EQ(buf, "0.0100");
	ASSERT_TRUE(money_parse_ped("0.00001", &v));
	money_format_ped_5_decimals(buf, sizeof(buf), v);
	ASSERT_STR_EQ(buf, "0.00001");
	return (0);
}

/*
** Rôle: check_limits — Vérifie limits.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les limites des entiers sont traitées explicitement avant
**             tout dépassement.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_add(), money_from_ped_double(),
**            money_parse_ped(), money_subtract(), money_to_pec_rounded().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_money_precision.c -> check_limits() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED, PEC.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_limits(void)
{
	t_money	v;

	ASSERT_TRUE(!money_parse_ped("12.5 PED", &v));
	ASSERT_TRUE(!money_parse_ped(".", &v));
	ASSERT_TRUE(!money_parse_ped("92233720368547.75808", &v));
	ASSERT_TRUE(money_parse_ped("92233720368547.75807", &v));
	ASSERT_I64_EQ(v, INT64_MAX);
	ASSERT_TRUE(money_parse_ped("-92233720368547.75808", &v));
	ASSERT_I64_EQ(v, INT64_MIN);
	ASSERT_TRUE(!money_parse_ped("-92233720368547.75809", &v));
	ASSERT_I64_EQ(money_add(INT64_MAX, 1), INT64_MAX);
	ASSERT_I64_EQ(money_add(INT64_MIN, -1), INT64_MIN);
	ASSERT_I64_EQ(money_subtract(INT64_MIN, 1), INT64_MIN);
	ASSERT_I64_EQ(money_subtract(INT64_MAX, -1), INT64_MAX);
	ASSERT_I64_EQ(money_to_pec_rounded(INT64_MIN), -9223372036854776LL);
	ASSERT_I64_EQ(money_from_ped_double(INFINITY), 0);
	return (0);
}

/*
** Rôle: check_rounding_and_ratio — Vérifie rounding and ratio.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_apply_markup(),
**            money_to_pec_rounded(), ratio_parse_fixed_1e4().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_money_precision.c -> check_rounding_and_ratio() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PEC, pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_rounding_and_ratio(void)
{
	int64_t	ratio;

	ASSERT_I64_EQ(money_apply_markup(10000, 10250), 10250);
	ASSERT_I64_EQ(money_apply_markup(10000, 10000), 10000);
	ASSERT_I64_EQ(money_to_pec_rounded(499), 0);
	ASSERT_I64_EQ(money_to_pec_rounded(500), 1);
	ASSERT_I64_EQ(money_to_pec_rounded(1500), 2);
	ratio = 0;
	ASSERT_TRUE(ratio_parse_fixed_1e4("105.5000", &ratio));
	ASSERT_I64_EQ(ratio, 1055000);
	ASSERT_TRUE(!ratio_parse_fixed_1e4("105.5%", &ratio));
	ASSERT_TRUE(!ratio_parse_fixed_1e4("922337203685478", &ratio));
	return (0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_limits(),
**            check_parse_and_format(), check_rounding_and_ratio().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_money_precision.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	ASSERT_I64_EQ(check_parse_and_format(), 0);
	ASSERT_I64_EQ(check_limits(), 0);
	ASSERT_I64_EQ(check_rounding_and_ratio(), 0);
	return (0);
}
