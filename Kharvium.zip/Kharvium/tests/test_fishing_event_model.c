/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_event_model.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "fishing/fishing_event_model.h"
#include <string.h>

/*
** Rôle: main — Verrouille les libellés persistants des résultats Fishing E87.
** Retour: 0 lorsque chaque enum stable conserve son texte contractuel.
** Effets: aucun hors assertions.
** Invariants: UNKNOWN couvre aussi les valeurs hors domaine sans invention.
** Relations: appelle directement -> fishing_attempt_result_name().
** Appelants: runner de tests.
** Dépendances: strcmp(), macros d'assertion et modèle Fishing.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun état global mutable.
** Concurrence: test mono-thread et réentrant hors framework d'assertion.
** I/O: aucune.
** Unités: aucune.
** Performance: coût constant sur six valeurs enum.
** Portabilité: C99 portable Windows/Linux.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_event_model.c -> main().
*/
int	main(void)
{
	ASSERT_TRUE(strcmp(fishing_attempt_result_name(
			FISHING_ATTEMPT_CONFIRMED_CATCH), "CONFIRMED_CATCH") == 0);
	ASSERT_TRUE(strcmp(fishing_attempt_result_name(
			FISHING_ATTEMPT_NO_BITE), "NO_BITE") == 0);
	ASSERT_TRUE(strcmp(fishing_attempt_result_name(
			FISHING_ATTEMPT_FAILED_REEL), "FAILED_REEL") == 0);
	ASSERT_TRUE(strcmp(fishing_attempt_result_name(
			FISHING_ATTEMPT_CANCELLED), "CANCELLED") == 0);
	ASSERT_TRUE(strcmp(fishing_attempt_result_name(
			FISHING_ATTEMPT_INTERRUPTED), "INTERRUPTED") == 0);
	ASSERT_TRUE(strcmp(fishing_attempt_result_name(
			(t_fishing_attempt_result)99), "UNKNOWN") == 0);
	return (0);
}
