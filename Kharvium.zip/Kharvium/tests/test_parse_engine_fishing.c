/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_parse_engine_fishing.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "app/app_state.h"
#include "common/string_operations.h"
#include "hunt/hunt_rules.h"
#include "io/hunt_csv.h"
#include "parse/parse_engine.h"
#include "platform/platform_time.h"
#include <stdio.h>
#include <string.h>

typedef struct s_fishing_test_totals
{
	long	catches;
	long	items;
	t_uped	total;
} t_fishing_test_totals;

static const char	g_fishing_log[] =
	"2026-05-18 20:37:30 [System] [] You received Fish Oil x (1) "
	"Value: 0.01 PED\n"
	"2026-05-18 20:37:30 [System] [] You received Shrapnel x (55) "
	"Value: 0.0055 PED\n"
	"2026-08-27 18:47:05 [System] [] You received Snapjaw Tuna x (1) "
	"Value: 0.01 PED\n"
	"2026-08-27 18:47:05 [System] [] You received Fish Scrap x (295) "
	"Value: 0.0295 PED\n"
	"2026-08-27 18:47:38 [System] [] You received Fish Scrap x (473) "
	"Value: 0.0473 PED\n"
	"2026-08-27 18:47:38 [System] [] You have gained 0.3011 experience "
	"in your Angling skill\n"
	"2026-08-28 10:32:18 [System] [] You received Blue Snapper x (1) "
	"Value: 0.01 PED\n"
	"2026-08-28 10:32:18 [System] [] You received Fish Scrap x (280) "
	"Value: 0.028 PED\n"
	"2026-08-28 10:32:39 [System] [] You received Blue Snapper x (1) "
	"Value: 0.01 PED\n"
	"2026-08-28 10:32:39 [System] [] You received Fish Scrap x (130) "
	"Value: 0.013 PED\n"
	"2026-08-28 10:33:03 [System] [] You received Juvenile Calypsocod x (1) "
	"Value: 0.01 PED\n"
	"2026-08-28 10:33:03 [System] [] You received Fish Scrap x (249) "
	"Value: 0.0249 PED\n"
	"2026-08-28 10:33:03 [System] [] You have gained 0.4026 experience "
	"in your Fishing Rod Technology skill\n"
	"2026-08-28 10:33:39 [System] [] You received Young Calypso Salmon x (1) "
	"Value: 0.01 PED\n"
	"2026-08-28 10:33:39 [System] [] You received Fish Scrap x (336) "
	"Value: 0.0336 PED\n";

/*
** Rôle: write_log — Écrit le journal de régression pêche dans un fichier
**    temporaire de test.
** Retour: Retourne selon sa signature; aucun résultat implicite n’est produit.
** Effets: Modifie uniquement les objets de sortie ou l’état explicitement
**    passé.
** Invariants: Les pointeurs obligatoires sont contrôlés et les bornes restent
**    respectées.
** Relations: appelle directement -> fopen(), fwrite(), fclose().
** Appelants: main().
** Index: docs/FUNCTION_CALL_GRAPH.md -> tests/test_parse_engine_fishing.c ->
**    write_log().
** Dépendances: types et API déclarés par les en-têtes inclus dans ce module.
** Mémoire: aucune allocation dynamique directe; propriété conservée par
**    l’appelant.
** État partagé: aucun nouvel état global mutable; état porté par les structures
**    passées.
** Concurrence: réentrant hors objets partagés; le worker protège le changement
**    de mode.
** I/O: fichier temporaire de test via stdio.
** Unités: octets.
** Performance: coût borné; parcours linéaire seulement lorsque le corps itère
**    des loots.
** Portabilité: C99 portable; aucune dépendance C++ ni bibliothèque externe
**    ajoutée.
*/
static int	write_log(const char *path)
{
	FILE	*stream;

	stream = fopen(path, "wb");
	if (!stream)
		return (-1);
	fwrite(g_fishing_log, 1, strlen(g_fishing_log), stream);
	fclose(stream);
	return (0);
}

/*
** Rôle: make_paths — Construit des chemins de test uniques à partir de
**    l'horloge monotone.
** Retour: Retourne selon sa signature; aucun résultat implicite n’est produit.
** Effets: Modifie uniquement les objets de sortie ou l’état explicitement
**    passé.
** Invariants: Les pointeurs obligatoires sont contrôlés et les bornes restent
**    respectées.
** Relations: appelle directement -> platform_time_milliseconds(), snprintf().
** Appelants: main().
** Index: docs/FUNCTION_CALL_GRAPH.md -> tests/test_parse_engine_fishing.c ->
**    make_paths().
** Dépendances: types et API déclarés par les en-têtes inclus dans ce module.
** Mémoire: aucune allocation dynamique directe; propriété conservée par
**    l’appelant.
** État partagé: aucun nouvel état global mutable; état porté par les structures
**    passées.
** Concurrence: réentrant hors objets partagés; le worker protège le changement
**    de mode.
** I/O: aucune E/S directe.
** Unités: millisecondes.
** Performance: coût borné; parcours linéaire seulement lorsque le corps itère
**    des loots.
** Portabilité: C99 portable; aucune dépendance C++ ni bibliothèque externe
**    ajoutée.
*/
static void	make_paths(char *chat, size_t chat_size,
	char *csv, size_t csv_size)
{
	unsigned long long	now;

	now = (unsigned long long)platform_time_milliseconds();
	snprintf(chat, chat_size, "bin/tests/fishing_%llu.log", now);
	snprintf(csv, csv_size, "bin/tests/fishing_%llu.csv", now);
}

/*
** Rôle: check_csv_row — Valide une ligne CSV pêche et cumule prises, objets et
**    valeur TT.
** Retour: Retourne selon sa signature; aucun résultat implicite n’est produit.
** Effets: Modifie uniquement les objets de sortie ou l’état explicitement
**    passé.
** Invariants: Les pointeurs obligatoires sont contrôlés et les bornes restent
**    respectées.
** Relations: appelle directement -> strcmp(), ASSERT_TRUE().
** Appelants: check_csv().
** Index: docs/FUNCTION_CALL_GRAPH.md -> tests/test_parse_engine_fishing.c ->
**    check_csv_row().
** Dépendances: types et API déclarés par les en-têtes inclus dans ce module.
** Mémoire: aucune allocation dynamique directe; propriété conservée par
**    l’appelant.
** État partagé: aucun nouvel état global mutable; état porté par les structures
**    passées.
** Concurrence: réentrant hors objets partagés; le worker protège le changement
**    de mode.
** I/O: aucune E/S directe.
** Unités: uPED, quantité.
** Performance: coût borné; parcours linéaire seulement lorsque le corps itère
**    des loots.
** Portabilité: C99 portable; aucune dépendance C++ ni bibliothèque externe
**    ajoutée.
*/
static int	check_csv_row(t_hunt_csv_row_view *row,
	t_fishing_test_totals *totals)
{
	if (strcmp(row->type_evenement, "KILL_FISHING") == 0)
		totals->catches++;
	if (strcmp(row->type_evenement, "LOOT_ITEM") != 0)
		return (0);
	totals->items++;
	totals->total += row->valeur_uPED;
	ASSERT_TRUE(row->id_kill >= 1 && row->id_kill <= 6);
	ASSERT_TRUE(strcmp(row->cible, "Shrapnel") != 0);
	return (0);
}

/*
** Rôle: check_csv — Relit le CSV généré et vérifie 6 prises, 11 objets et 22630
**    uPED.
** Retour: Retourne selon sa signature; aucun résultat implicite n’est produit.
** Effets: Modifie uniquement les objets de sortie ou l’état explicitement
**    passé.
** Invariants: Les pointeurs obligatoires sont contrôlés et les bornes restent
**    respectées.
** Relations: appelle directement -> hunt_csv_parse_row_inplace(),
**    check_csv_row(), ASSERT_I64_EQ().
** Appelants: main().
** Index: docs/FUNCTION_CALL_GRAPH.md -> tests/test_parse_engine_fishing.c ->
**    check_csv().
** Dépendances: types et API déclarés par les en-têtes inclus dans ce module.
** Mémoire: aucune allocation dynamique directe; propriété conservée par
**    l’appelant.
** État partagé: aucun nouvel état global mutable; état porté par les structures
**    passées.
** Concurrence: réentrant hors objets partagés; le worker protège le changement
**    de mode.
** I/O: fichier temporaire de test via stdio.
** Unités: uPED, quantité.
** Performance: coût borné; parcours linéaire seulement lorsque le corps itère
**    des loots.
** Portabilité: C99 portable; aucune dépendance C++ ni bibliothèque externe
**    ajoutée.
*/
static int	check_csv(const char *path)
{
	FILE				*stream;
	char				line[8192];
	char				work[8192];
	t_hunt_csv_row_view	row;
	t_fishing_test_totals	totals;

	stream = fopen(path, "rb");
	ASSERT_TRUE(stream != NULL);
	memset(&totals, 0, sizeof(totals));
	while (fgets(line, sizeof(line), stream))
	{
		string_copy_safe(work, sizeof(work), line);
		if (hunt_csv_parse_row_inplace(work, &row))
			ASSERT_I64_EQ(check_csv_row(&row, &totals), 0);
	}
	fclose(stream);
	ASSERT_I64_EQ(totals.catches, 6);
	ASSERT_I64_EQ(totals.items, 11);
	ASSERT_I64_EQ(totals.total, 22630);
	return (0);
}

/*
** Rôle: main — Exécute la régression pêche complète du chat source vers le CSV
**    Tracker.
** Retour: Retourne 0 si toute la régression réussit; une assertion propage
**    l’échec.
** Effets: Modifie uniquement les objets de sortie ou l’état explicitement
**    passé.
** Invariants: Les pointeurs obligatoires sont contrôlés et les bornes restent
**    respectées.
** Relations: appelle directement -> write_log(), make_paths(),
**    parse_run_replay(), check_csv().
** Appelants: runner de tests.
** Index: docs/FUNCTION_CALL_GRAPH.md -> tests/test_parse_engine_fishing.c ->
**    main().
** Dépendances: types et API déclarés par les en-têtes inclus dans ce module.
** Mémoire: aucune allocation dynamique directe; propriété conservée par
**    l’appelant.
** État partagé: aucun nouvel état global mutable; état porté par les structures
**    passées.
** Concurrence: réentrant hors objets partagés; le worker protège le changement
**    de mode.
** I/O: aucune E/S directe.
** Unités: uPED, quantité.
** Performance: coût borné; parcours linéaire seulement lorsque le corps itère
**    des loots.
** Portabilité: C99 portable; aucune dépendance C++ ni bibliothèque externe
**    ajoutée.
*/
int	main(void)
{
	t_app_state	app;
	char		chat_path[256];
	char		csv_path[256];
	int			result;

	make_paths(chat_path, sizeof(chat_path), csv_path, sizeof(csv_path));
	ASSERT_I64_EQ(write_log(chat_path), 0);
	(void)remove(csv_path);
	memset(&app, 0, sizeof(app));
	hunt_rules_initialize(&app.parse.rules);
	hunt_rules_set_activity_mode(&app.parse.rules, TRACKER_ACTIVITY_FISHING);
	result = parse_run_replay(&app, chat_path, csv_path, NULL);
	ASSERT_I64_EQ(result, 0);
	ASSERT_I64_EQ(check_csv(csv_path), 0);
	(void)remove(chat_path);
	(void)remove(csv_path);
	return (0);
}
