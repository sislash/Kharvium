/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_sweat_no_fixed_price.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "hunt/hunt_rules.h"
#include <string.h>

/*
** Rôle: sweat_uses_logged_tt_value — Vérifie que le parseur ne transforme
**       plus Vibrant Sweat en prix de marché compilé et conserve une TT
**       nulle.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 lorsque le type, la quantité et la valeur sont corrects.
** Effets: initialise localement les règles de parsing et un événement.
** Invariants: une cotation de marché ne doit jamais remplacer la TT du log.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_parse_line(), hunt_rules_initialize().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_sweat_no_fixed_price.c -> sweat_uses_logged_tt_value().
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_STR_EQ(), memset().
** Mémoire: aucune allocation/libération directe dans le test.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test séquentiel et local.
** I/O: aucune E/S directe hors diagnostics des assertions.
** Unités: quantité et PED formaté sur quatre décimales.
** Performance: un seul événement de chat est analysé.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	sweat_uses_logged_tt_value(void)
{
	t_hunt_rules	rules;
	t_hunt_event	event;
	const char	*line;

	line = "2026-05-18 20:37:30 [System] [] "
		"You received Vibrant Sweat x (20) Value: 0 PED";
	hunt_rules_initialize(&rules);
	memset(&event, 0, sizeof(event));
	ASSERT_I64_EQ(hunt_parse_line(&rules, line, &event), 0);
	ASSERT_STR_EQ(event.type, "SWEAT");
	ASSERT_STR_EQ(event.name, "Vibrant Sweat");
	ASSERT_STR_EQ(event.qty, "20");
	ASSERT_STR_EQ(event.value, "0.0000");
	return (0);
}

/*
** Rôle: main — Exécute la régression interdisant tout prix Sweat figé.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat du scénario de régression.
** Effets: aucun au-delà des diagnostics éventuels du test.
** Invariants: le test échoue dès qu’une valeur marchande est réinjectée.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> sweat_uses_logged_tt_value().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_sweat_no_fixed_price.c -> main().
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: exécution séquentielle.
** I/O: aucune primitive système/stdio appelée directement.
** Unités: aucune unité supplémentaire.
** Performance: coût constant.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	return (sweat_uses_logged_tt_value());
}
