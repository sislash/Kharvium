/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_parse_engine_tracker_v4.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "support/test_tracker_e87_support.h"
#include "app/app_state.h"
#include "hunt/hunt_rules.h"
#include "io/hunt_csv.h"
#include "io/tracker_event_csv.h"
#include "parse/parse_engine.h"
#include "platform/platform_time.h"
#include <stdio.h>
#include <string.h>

static const char	g_log[] =
	"2026-08-28 10:32:18 [System] [] You received Blue Snapper x (1) "
	"Value: 0.01 PED\n"
	"2026-08-28 10:32:18 [System] [] You received Fish Scrap x (280) "
	"Value: 0.028 PED\n";

/*
** Rôle: make_paths — Crée des noms temporaires uniques et calcule le sidecar
**       V4 exactement comme le parse engine de production.
** Paramètre: chat — chemin du chat.log synthétique.
** Paramètre: hunt — chemin V3 historique temporaire.
** Paramètre: events — chemin V4 dérivé de hunt.
** Retour: 0 sur succès, 1 via assertion en cas d'échec.
** Effets: remplit uniquement les buffers fournis.
** Invariants: les trois chemins pointent dans bin/tests et ne touchent aucune
**             donnée utilisateur.
** Relations: appelle directement -> tracker_event_csv_sibling_path().
** Appelants: main().
** Mémoire: aucune allocation dynamique.
** I/O: aucune.
** Unités: millisecondes.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_engine_tracker_v4.c -> make_paths() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test directement utilisées par le
**            corps.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
static int	make_paths(char *chat, char *hunt, char *events)
{
	unsigned long long	now;

	now = (unsigned long long)platform_time_milliseconds();
	snprintf(chat, 256, "bin/tests/e85_live_%llu.log", now);
	snprintf(hunt, 256, "bin/tests/e85_live_%llu.csv", now);
	ASSERT_TRUE(tracker_event_csv_sibling_path(hunt, events, 256));
	return (0);
}

/*
** Rôle: write_log — Écrit le mini journal Fishing source utilisé pour tester
**       le double journal V3/V4 du parse engine.
** Paramètre: path — fichier chat temporaire.
** Retour: 0 sur succès, 1 si le fichier ne peut pas être créé/écrit.
** Effets: crée puis ferme path.
** Invariants: le contenu contient exactement une prise confirmée par Scrap.
** Relations: appelle directement -> aucune fonction projet.
** Appelants: main().
** Dépendances: fopen(), fwrite(), fclose().
** Mémoire: aucune allocation dynamique.
** I/O: écriture du fixture temporaire.
** Unités: octets.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_engine_tracker_v4.c -> write_log() (chemin complet dans
**        l’index).
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
static int	write_log(const char *path)
{
	FILE	*file;

	file = fopen(path, "wb");
	if (!file)
		return (1);
	if (fwrite(g_log, 1, strlen(g_log), file) != strlen(g_log))
		return (fclose(file), 1);
	fclose(file);
	return (0);
}

/*
** Rôle: check_sidecar — Vérifie que le parse engine a écrit une racine
**       FISHING puis deux LOOT_ITEM reliés au même parent V4.
** Paramètre: path — sidecar V4 créé pendant parse_run_replay().
** Retour: 0 lorsque activité, session et parentage sont cohérents.
** Effets: lit puis ferme le sidecar.
** Invariants: les enfants gardent envelope_id=1 tout en utilisant event_id
**             comme relation générique.
** Relations: appelle directement -> tracker_event_csv_parse_line().
** Appelants: main().
** Mémoire: aucune allocation dynamique.
** I/O: lecture du fixture V4.
** Unités: IDs et uPED.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_engine_tracker_v4.c -> check_sidecar() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test utilisées directement.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions.
*/
static int	check_sidecar(const char *path)
{
	t_tracker_event_record	row;
	char			line[4096];
	FILE			*file;
	int			count;
	int64_t			attempt_id;
	int64_t			catch_id;

	file = fopen(path, "rb");
	ASSERT_TRUE(file != NULL);
	count = 0;
	attempt_id = 0;
	catch_id = 0;
	while (fgets(line, sizeof(line), file))
	{
		if (!tracker_event_csv_parse_line(line, &row))
			continue ;
		count++;
		TEST_RUN(test_tracker_e87_runtime_row(&row, count, &attempt_id,
			&catch_id));
	}
	fclose(file);
	ASSERT_I64_EQ(count, 4);
	return (0);
}

/*
** Rôle: check_legacy_v3 — Confirme que la vue historique reste exactement
**       une enveloppe KILL_FISHING suivie de deux LOOT_ITEM.
** Paramètre: path — CSV V3 généré par le replay.
** Retour: 0 lorsque les trois lignes métier legacy sont préservées.
** Effets: lit puis ferme path.
** Invariants: E87 ne modifie pas le contrat V3 consommé par l'UI historique.
** Relations: appelle directement -> hunt_csv_parse_row_inplace().
** Appelants: main().
** Dépendances: stdio, strcmp(), parser CSV V3 et macros d'assertion.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun état global mutable.
** Concurrence: test mono-thread sur un fixture détenu localement.
** I/O: lecture du fixture V3 temporaire.
** Unités: lignes métier.
** Performance: parcours linéaire de trois lignes métier.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_parse_engine_tracker_v4.c ->
**        check_legacy_v3().
*/
static int	check_legacy_v3(const char *path)
{
	t_hunt_csv_row_view	row;
	char			line[4096];
	FILE			*file;
	int			count;

	file = fopen(path, "rb");
	ASSERT_TRUE(file != NULL);
	count = 0;
	while (fgets(line, sizeof(line), file))
	{
		if (!hunt_csv_parse_row_inplace(line, &row))
			continue ;
		count++;
		if (count == 1)
			ASSERT_TRUE(strcmp(row.type_evenement, "KILL_FISHING") == 0);
		if (count > 1)
			ASSERT_TRUE(strcmp(row.type_evenement, "LOOT_ITEM") == 0);
	}
	fclose(file);
	ASSERT_I64_EQ(count, 3);
	return (0);
}

/*
** Rôle: main — Exécute le vrai parse replay Fishing et valide que V3 et V4
**       sont produits ensemble sans changer la sémantique legacy existante.
** Retour: 0 lorsque la journalisation générique E85 est intégrée correctement.
** Effets: crée puis supprime trois fichiers temporaires.
** Invariants: le mode Fishing est fixé avant l'ouverture de la session.
** Relations: appelle directement -> check_sidecar(), hunt_rules_initialize(),
**            hunt_rules_set_activity_mode(), make_paths(), parse_run_replay(),
**            write_log().
** Appelants: aucun.
** Mémoire: aucune allocation dynamique directe.
** I/O: fixtures temporaires uniquement.
** Unités: identifiants persistants.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_engine_tracker_v4.c -> main() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test directement utilisées par le
**            corps.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
int	main(void)
{
	t_app_state	app;
	char		chat[256];
	char		hunt[256];
	char		events[256];

	TEST_RUN(make_paths(chat, hunt, events));
	(void)remove(chat);
	(void)remove(hunt);
	(void)remove(events);
	TEST_RUN(write_log(chat));
	memset(&app, 0, sizeof(app));
	hunt_rules_initialize(&app.parse.rules);
	hunt_rules_set_activity_mode(&app.parse.rules, TRACKER_ACTIVITY_FISHING);
	ASSERT_I64_EQ(parse_run_replay(&app, chat, hunt, NULL), 0);
	TEST_RUN(check_legacy_v3(hunt));
	TEST_RUN(check_sidecar(events));
	(void)remove(chat);
	(void)remove(hunt);
	(void)remove(events);
	return (0);
}
