/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_tracker_action_wiring.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "app/app_tracker_session_start.h"
#include "platform/app_paths.h"
#include "parse/parse_worker.h"
#include "src/app/app_picker_internal.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: test_missing_fishing_rod — vérifie que LIVE et REPLAY ouvrent le
**       picker Fishing au lieu de démarrer un worker sans canne valide.
** Paramètres: aucun paramètre explicite.
** Retour: 0 si les deux actions respectent le branchement central, 1 sinon.
** Effets: charge puis libère deux fois les catalogues temporaires du picker.
** Invariants: parse_worker.running reste faux pendant tout le scénario.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_fishing_rod_picker_close(),
**            app_paths_initialize(), app_state_initialize(),
**            app_tracker_start_live(), app_tracker_start_replay(),
**            hunt_rules_set_activity_mode(), parse_worker_is_running().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_action_wiring.c -> test_missing_fishing_rod().
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: catalogues du picker libérés avant chaque sortie de succès.
** État partagé: utilise uniquement l'état local core/app de ce test.
** Concurrence: aucun thread parser ne doit être démarré.
** I/O: lecture des catalogues Fishing locaux via le picker.
** Unités: aucune.
** Performance: O(taille des catalogues Fishing) deux fois.
** Portabilité: C99 Windows/Linux; aucune fenêtre native réelle requise.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_missing_fishing_rod(void)
{
	t_app_state	core;
	t_app		app;
	t_window	window;

	memset(&app, 0, sizeof(app));
	memset(&window, 0, sizeof(window));
	app_state_initialize(&core);
	app.core = &core;
	if (app_paths_initialize("./bin/kharvium") < 0)
		return (1);
	hunt_rules_set_activity_mode(&core.parse.rules, TRACKER_ACTIVITY_FISHING);
	app_tracker_start_live(&window, &app);
	if ((!app.fishing_rod_picker_open && !app.modal_open)
		|| parse_worker_is_running(&core))
		return (app_fishing_rod_picker_close(&app), 1);
	app_fishing_rod_picker_close(&app);
	app.modal_open = 0;
	app_tracker_start_replay(&window, &app);
	if ((!app.fishing_rod_picker_open && !app.modal_open)
		|| parse_worker_is_running(&core))
		return (app_fishing_rod_picker_close(&app), 1);
	app_fishing_rod_picker_close(&app);
	app_state_shutdown(&core);
	return (0);
}

/*
** Rôle: main — exécute la régression de branchement des actions de session.
** Paramètres: aucun paramètre explicite.
** Retour: 0 lorsque le garde-fou central LIVE/REPLAY est respecté, 1 sinon.
** Effets: écrit un diagnostic minimal sur stderr en cas d'échec.
** Invariants: un succès garantit que Fishing sans canne ne lance aucun parser.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_missing_fishing_rod().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_action_wiring.c -> main().
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation directe possédée par main.
** État partagé: aucun état global mutable introduit par ce test.
** Concurrence: aucun worker ne doit rester actif à la sortie.
** I/O: diagnostic stderr uniquement en cas d'échec.
** Unités: aucune.
** Performance: dominée par le chargement des catalogues Fishing.
** Portabilité: C99 portable Windows/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	if (test_missing_fishing_rod())
	{
		fprintf(stderr, "tracker action wiring failed\n");
		return (1);
	}
	return (0);
}
