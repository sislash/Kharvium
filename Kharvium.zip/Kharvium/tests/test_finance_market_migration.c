/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_market_migration.c                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_calculations.h"
#include "finance/finance_persistence.h"
#include "io/csv_format.h"
#include "common/money.h"
#include <stdio.h>
#include <string.h>

#define MARKET_MIGRATION_FILE "tests/.tmp_market_migration.csv"
#define FIN_FIELD_COUNT 16

/*
** Rôle: migration_ped — Convertit une valeur PED textuelle attendue par ce
**       test en représentation monétaire entière.
** Paramètre: text — montant PED décimal à convertir sans le modifier.
** Retour: Retourne le montant converti, ou 0 si le texte est invalide.
** Effets: n'effectue aucune E/S et ne modifie aucune donnée partagée.
** Invariants: utilise le même parseur monétaire fixe que le code Finance.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: check_market_migration().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_migration.c -> migration_ped() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static t_money	migration_ped(const char *text)
{
	t_money	value;

	value = 0;
	if (!money_parse_ped(text, &value))
		return (0);
	return (value);
}

/*
** Rôle: fill_legacy_price_fields — Prépare exactement les champs d'une ligne
**       price telle qu'elle était stockée avant la correction du mode 3.
** Paramètre: price — tableau de 16 champs déjà remis à zéro par l'appelant.
** Retour: Ne retourne rien.
** Effets: renseigne uniquement les indices nécessaires de la ligne CSV.
** Invariants: le prix 17 PED reste volontairement dans market_value et le
**             champ market_unit reste à zéro pour exercer la migration.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: write_legacy_market_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_migration.c -> fill_legacy_price_fields()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	fill_legacy_price_fields(const char **price)
{
	price[0] = "price";
	price[1] = "Bombardo";
	price[2] = "3";
	price[3] = "0.00000";
	price[4] = "0";
	price[5] = "0.00000";
	price[6] = "0.00000";
	price[7] = "3";
	price[8] = "17.00000";
	price[9] = "General";
	price[10] = "0";
}

/*
** Rôle: write_legacy_market_file — Écrit une sauvegarde minimale reproduisant
**       l'ancien stockage du mode numérique 3 avant FIN_MARKET_UNIT.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 si les deux lignes CSV sont écrites et fermées, 0 sinon.
** Effets: crée puis remplace MARKET_MIGRATION_FILE pendant le test.
** Invariants: market_unit reste à zéro et l'ancien prix 17 PED est placé dans
**             market_value afin d'exercer réellement la migration de lecture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_write_row_with_separator(),
**            fill_legacy_price_fields().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_migration.c -> write_legacy_market_file()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	write_legacy_market_file(void)
{
	const char	*meta[FIN_FIELD_COUNT];
	const char	*price[FIN_FIELD_COUNT];
	FILE		*stream;

	memset(meta, 0, sizeof(meta));
	memset(price, 0, sizeof(price));
	stream = fopen(MARKET_MIGRATION_FILE, "wb");
	if (!stream)
		return (0);
	meta[0] = "meta";
	meta[1] = "4";
	meta[2] = "0.00000";
	fill_legacy_price_fields(price);
	csv_write_row_with_separator(stream, meta, FIN_FIELD_COUNT, ';');
	csv_write_row_with_separator(stream, price, FIN_FIELD_COUNT, ';');
	return (fclose(stream) == 0);
}

/*
** Rôle: check_market_migration — Charge l'ancienne sauvegarde et vérifie que
**       la valeur devient un prix de marché unitaire courant exploitable.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 si mode, migration de champ et valorisation sont exacts.
** Effets: charge un registre Finance temporaire puis libère toutes ses données.
** Invariants: la valeur numérique 3 reste compatible sans conserver de notion
**             de prix immuable dans la structure chargée.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize(), finance_book_load(),
**            finance_price_market_total(), migration_ped().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_migration.c -> check_market_migration() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_market_migration(void)
{
	t_finance_book	book;
	int		ok;

	finance_book_initialize(&book, 0);
	ok = finance_book_load(&book, MARKET_MIGRATION_FILE);
	ok = ok && book.price_count == 1;
	ok = ok && book.prices[0].market_mode == FIN_MARKET_UNIT;
	ok = ok && book.prices[0].market_unit_uPED == migration_ped("17.00000");
	ok = ok && book.prices[0].market_value_uPED == 0;
	ok = ok && finance_price_market_total(&book.prices[0], 25)
		== migration_ped("425.00000");
	finance_book_destroy(&book);
	return (ok);
}

/*
** Rôle: main — Exécute le scénario de compatibilité du prix de marché courant.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 si la migration est correcte, 1 au premier échec.
** Effets: crée un fichier temporaire de test et le supprime avant de terminer.
** Invariants: aucun fichier de données utilisateur ne subsiste après le test.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_market_migration(),
**            write_legacy_market_file().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_market_migration.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> printf(), remove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	int	ok;

	ok = write_legacy_market_file();
	ok = ok && check_market_migration();
	(void)remove(MARKET_MIGRATION_FILE);
	if (!ok)
		return (1);
	printf("test_finance_market_migration: OK\n");
	return (0);
}
