/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_config_save_regression.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "src/ui/config_menu_modules.h"
#include "platform/file_system.h"

#include <stdio.h>
#include <string.h>
#if defined(_WIN32) || defined(_WIN64)
# include <direct.h>
#else
# include <unistd.h>
#endif

#define CONFIG_TEST_DIR "tests/tmp_config_save_regression"

/*
** Rôle: config_regression_weapon — sauvegarde une arme via le même chemin que
**       l’UI puis recharge weapons.ini pour vérifier la persistance réelle.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 si la base mémoire et le fichier rechargé contiennent
**         exactement l’arme de régression, sinon 0.
** Effets: modifie temporairement g_weapon_config et écrit weapons.ini dans le
**         répertoire de test courant.
** Invariants: le nom est unique; les coûts et MU saisis sont valides; toute
**             base chargée est libérée avant le retour.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_path_weapons_ini(),
**            weapon_config_save_selected(), weapon_database_free(),
**            weapon_database_load().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_config_save_regression.c -> config_regression_weapon() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), strcmp(),
**              strcpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_weapon_config.
** Concurrence: état global mutable détecté (g_weapon_config);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	config_regression_weapon(void)
{
	t_weapon_database	loaded;
	int					ok;

	memset(&g_weapon_config, 0, sizeof(g_weapon_config));
	strcpy(g_weapon_config.name, "Regression Weapon");
	strcpy(g_weapon_config.dpp, "2.5000");
	strcpy(g_weapon_config.ammo_shot, "0.0100");
	strcpy(g_weapon_config.decay_shot, "0.0200");
	strcpy(g_weapon_config.amp_ammo_shot, "0.0030");
	strcpy(g_weapon_config.amp_decay_shot, "0.0000");
	strcpy(g_weapon_config.markup_mu, "1.0000");
	strcpy(g_weapon_config.ammo_mu, "1.0000");
	strcpy(g_weapon_config.weapon_mu, "0");
	strcpy(g_weapon_config.amp_mu, "0");
	memset(&loaded, 0, sizeof(loaded));
	ok = weapon_config_save_selected(0, 1);
	ok = ok && g_weapon_config.db.count == 1;
	ok = ok && weapon_database_load(&loaded, app_path_weapons_ini());
	ok = ok && loaded.count == 1;
	ok = ok && !strcmp(loaded.items[0].name, "Regression Weapon");
	ok = ok && loaded.items[0].amp_ammo_shot > 0;
	weapon_database_free(&loaded);
	weapon_database_free(&g_weapon_config.db);
	return (ok);
}

/*
** Rôle: config_regression_markup — sauvegarde une règle MU via le chemin UI
**       puis recharge markup.ini afin de valider l’écriture persistante.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 si la règle sauvegardée est retrouvée avec son nom,
**         sinon 0.
** Effets: modifie temporairement g_config_markup et écrit markup.ini.
** Invariants: la base globale et la base rechargée sont libérées dans tous les
**             chemins qui atteignent la fin du scénario.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_path_markup_ini(),
**            config_markup_save_selected(), markup_database_free(),
**            markup_database_initialize(), markup_database_load().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_config_save_regression.c -> config_regression_markup() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), strcmp(),
**              strcpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_config_markup.
** Concurrence: état global mutable détecté (g_config_markup);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	config_regression_markup(void)
{
	t_markup_db	loaded;
	int			ok;

	memset(&g_config_markup, 0, sizeof(g_config_markup));
	markup_database_initialize(&g_config_markup.db);
	strcpy(g_config_markup.name, "Regression Unit Value");
	strcpy(g_config_markup.value, "0.25");
	g_config_markup.type = MARKUP_UNIT_VALUE;
	ok = config_markup_save_selected(0, 1);
	ok = ok && g_config_markup.db.count == 1;
	markup_database_initialize(&loaded);
	ok = ok && markup_database_load(&loaded, app_path_markup_ini()) == 0;
	ok = ok && loaded.count == 1;
	ok = ok && !strcmp(loaded.items[0].name, "Regression Unit Value");
	ok = ok && loaded.items[0].type == MARKUP_UNIT_VALUE;
	ok = ok && loaded.items[0].value_known == 1;
	ok = ok && loaded.items[0].value > 0.249
		&& loaded.items[0].value < 0.251;
	markup_database_free(&loaded);
	markup_database_free(&g_config_markup.db);
	return (ok);
}

/*
** Rôle: config_regression_remove_dir — supprime le répertoire temporaire une
**       fois les deux fichiers de persistance effacés.
** Paramètre: path — répertoire vide créé exclusivement par ce test.
** Retour: Ne retourne rien; l’échec de nettoyage n’altère pas le verdict sur
**         la persistance fonctionnelle.
** Effets: demande au système de supprimer un répertoire vide.
** Invariants: aucun fichier utilisateur réel n’est ciblé.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_config_save_regression.c -> config_regression_remove_dir()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> _rmdir(), else(), rmdir().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> rmdir().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	config_regression_remove_dir(const char *path)
{
#if defined(_WIN32) || defined(_WIN64)
	(void)_rmdir(path);
#else
	(void)rmdir(path);
#endif
}

/*
** Rôle: main — exécute de bout en bout les sauvegardes Weapon et Markup sans
**       script externe et restaure le répertoire de travail ensuite.
** Paramètres: aucun paramètre explicite.
** Retour: 0 si les deux persistance/relectures réussissent, sinon code 1..4.
** Effets: crée un sous-répertoire temporaire, change le cwd, écrit deux INI,
**         les supprime puis revient à la racine du projet.
** Invariants: aucune donnée utilisateur du projet n’est écrasée; tous les
**             chemins de test restent sous tests/tmp_config_save_regression.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> config_regression_markup(),
**            config_regression_remove_dir(), config_regression_weapon(),
**            file_system_change_directory(), file_system_ensure_directory().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_config_save_regression.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> puts(), remove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	int	ok_weapon;
	int	ok_markup;

	remove(CONFIG_TEST_DIR "/weapons.ini");
	remove(CONFIG_TEST_DIR "/markup.ini");
	if (file_system_ensure_directory(CONFIG_TEST_DIR) != 0)
		return (1);
	if (file_system_change_directory(CONFIG_TEST_DIR) != 0)
		return (2);
	ok_weapon = config_regression_weapon();
	ok_markup = config_regression_markup();
	remove("weapons.ini");
	remove("markup.ini");
	if (file_system_change_directory("../..") != 0)
		return (3);
	config_regression_remove_dir(CONFIG_TEST_DIR);
	if (!ok_weapon || !ok_markup)
		return (4);
	puts("test_config_save_regression: OK");
	return (0);
}
