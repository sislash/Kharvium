/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_benchmark_regression.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "app/app_benchmark.h"

#include <stdio.h>

#define BENCH_FIXTURE "tests/tmp_benchmark_regression.csv"

/*
** Rôle: benchmark_fixture_write_kill — écrit un kill synthétique complet avec
**       un tir et deux lignes de loot appartenant à la même enveloppe.
** Paramètre: file — flux temporaire ouvert en écriture et détenu par main.
** Paramètre: index — indice du kill; il détermine timestamp et KillID uniques.
** Retour: Ne retourne rien; les erreurs d’écriture sont détectées à la
**         fermeture et par l’exécution du benchmark.
** Effets: écrit quatre lignes CSV dans le fichier temporaire de régression.
** Invariants: un timestamp distinct est utilisé par kill; les deux objets de
**             loot réutilisent exactement le KillID de leur enveloppe.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: benchmark_fixture_write().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_benchmark_regression.c -> benchmark_fixture_write_kill()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	benchmark_fixture_write_kill(FILE *file, int index)
{
	long	timestamp;
	int		kill_id;

	timestamp = 1700000000L + index;
	kill_id = index + 1;
	fprintf(file, "%ld,SHOT,,1,0,0,0,shot\n", timestamp);
	fprintf(file, "%ld,KILL,Daikiba Mature,1,0,%d,2,kill\n",
		timestamp, kill_id);
	fprintf(file, "%ld,LOOT_ITEM,Animal Oil Residue,1,100,%d,3,loot\n",
		timestamp, kill_id);
	fprintf(file, "%ld,LOOT_ITEM,Animal Oil Residue,1,100,%d,3,loot\n",
		timestamp, kill_id);
}

/*
** Rôle: benchmark_fixture_write — crée une session déterministe de seize
**       enveloppes pour exercer deux reconstructions benchmark successives.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 si le fichier est intégralement écrit et fermé, sinon 0.
** Effets: crée BENCH_FIXTURE et remplace son contenu précédent éventuel.
** Invariants: seize kills ont seize timestamps distincts et seize KillID.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> benchmark_fixture_write_kill().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_benchmark_regression.c -> benchmark_fixture_write() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(), fputs().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	benchmark_fixture_write(void)
{
	FILE	*file;
	int		i;

	file = fopen(BENCH_FIXTURE, "wb");
	if (!file)
		return (0);
	fputs("timestamp_unix,event_type,target_or_item,qty,value_uPED5,", file);
	fputs("kill_id,flags,raw\n", file);
	i = 0;
	while (i < 16)
		benchmark_fixture_write_kill(file, i++);
	return (fclose(file) == 0);
}

/*
** Rôle: main — vérifie que le chemin CLI du benchmark accepte deux itérations
**       successives sans dépassement de pile ni incohérence de série.
** Paramètres: aucun paramètre explicite.
** Retour: 0 si génération et benchmark réussissent; une valeur non nulle
**         identifie une régression de fixture ou de benchmark.
** Effets: crée puis supprime le CSV, son index et son état d index.
** Invariants: app_benchmark_run_if_requested() doit retourner 0 pour un
**             benchmark explicitement demandé et entièrement valide.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_benchmark_run_if_requested(),
**            benchmark_fixture_write().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_benchmark_regression.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> puts(), remove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	char	*args[7];
	int		result;

	if (!benchmark_fixture_write())
		return (1);
	args[0] = "kharvium-test";
	args[1] = "--bench";
	args[2] = "--csv";
	args[3] = BENCH_FIXTURE;
	args[4] = "--iters";
	args[5] = "2";
	args[6] = NULL;
	result = app_benchmark_run_if_requested(6, args);
	remove(BENCH_FIXTURE);
	remove(BENCH_FIXTURE ".idx");
	remove(BENCH_FIXTURE ".idxstate");
	if (result != 0)
		return (2);
	puts("test_benchmark_regression: OK");
	return (0);
}
