/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_session_economics.c                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing/fishing_session_economics.h"
#include "io/tracker_event_csv.h"
#include "test_util.h"
#include <stdio.h>
#include <string.h>

#define E89_PATH "tests/tmp_fishing_session_e89.csv"

typedef struct s_e89_row
{
	int64_t		id;
	const char	*type;
	const char	*name;
	t_money		value;
	int			value_known;
}t_e89_row;

static const t_e89_row	g_e89_rows[] = {
	{1, "FISHING_ATTEMPT", "CONFIRMED_CATCH", 0, 1},
	{2, "FISHING_CATCH", "Test Fish A", 0, 1},
	{3, "LOOT_ITEM", "Fish Scrap", 1000, 1},
	{4, "FISHING_ATTEMPT", "CONFIRMED_CATCH", 0, 1},
	{5, "FISHING_CATCH", "Test Fish B", 0, 1},
	{6, "LOOT_ITEM", "Raw Fish", 500, 1},
	{7, "FISHING_SKILL", "Fishing", 0, 1}
};

static const t_fishing_loadout_cost	g_e89_cost = {
	.gear_tt_decay = 200,
	.ammo_tt_cost = 100,
	.total_tt_cost = 300,
	.gear_cost_basis_consumed = 300,
	.ammo_cost_basis_consumed = 150,
	.total_cost_basis_consumed = 450,
	.tt_quality = DATA_COMPLETE,
	.cost_basis_quality = DATA_COMPLETE
};

/*
** Rôle: e89_write — Écrit un événement V4 minimal pour la fixture de session.
** Relations: tracker_event_csv_write().
** Appelants: e89_fixture().
** Mémoire: aucune allocation.
** Invariants: IDs/session/type fournis sont déjà cohérents pour le test.
** Retour: 1 si la ligne est écrite, 0 sinon.
** Effets: ajoute une ligne dans file.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_session_economics.c ->
** e89_write().
** Dépendances: writer CSV V4.
** État partagé: aucun.
** Concurrence: mono-thread.
** I/O: écriture fichier test.
** Unités: IDs, quantité et uPED5.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static int	e89_write(FILE *file, const t_e89_row *input)
{
	t_tracker_event_record	row;

	memset(&row, 0, sizeof(row));
	row.timestamp_unix = 1000 + input->id;
	row.event_id = input->id;
	row.session_id = 7;
	row.activity_type = TRACKER_ACTIVITY_TYPE_FISHING;
	row.event_type = input->type;
	row.target_or_item = input->name;
	row.quantity = 1;
	row.value_uPED = input->value;
	if (input->value_known)
		row.flags = TRACKER_EVENT_FLAG_VALUE_KNOWN;
	row.raw = "fixture E89";
	return (tracker_event_csv_write(file, &row));
}

/*
** Rôle: e89_fixture — Construit deux prises Fishing V4 et une session parasite.
** Relations: e89_write(), tracker_event_csv_ensure_header().
** Appelants: check_complete(), check_partial_value().
** Mémoire: aucune allocation dynamique.
** Invariants: la session 7 contient deux attempts, catches et loot items.
** Retour: 1 si la fixture est entièrement écrite, 0 sinon.
** Effets: remplace E89_PATH.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_session_economics.c ->
** e89_fixture().
** Dépendances: stdio et writer V4.
** État partagé: fichier temporaire de test.
** Concurrence: mono-thread.
** I/O: création/écriture/fermeture CSV.
** Unités: uPED5.
** Performance: O(7 lignes).
** Portabilité: C99 Windows/Linux.
*/
static int	e89_fixture(void)
{
	FILE	*file;
	size_t	i;
	int	ok;

	file = fopen(E89_PATH, "w+b");
	if (!file)
		return (0);
	ok = tracker_event_csv_ensure_header(file);
	i = 0;
	while (ok && i < sizeof(g_e89_rows) / sizeof(g_e89_rows[0]))
	{
		ok = e89_write(file, &g_e89_rows[i]);
		i++;
	}
	if (fclose(file) != 0)
		ok = 0;
	return (ok);
}

/*
** Rôle: check_complete — Vérifie l'agrégation V4 et les résultats E89 complets.
** Relations: e89_fixture(), fishing_session_events_read_v4(),
**            fishing_session_economics_build().
** Appelants: main().
** Mémoire: structures locales seulement.
** Invariants: aucun prix marché ni coût non mesuré n'est introduit.
** Retour: 0 si toutes les assertions passent.
** Effets: lit puis supprime la fixture temporaire.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_session_economics.c ->
** check_complete().
** Dépendances: modèle E89.
** État partagé: E89_PATH.
** Concurrence: mono-thread.
** I/O: lecture/suppression fichier test.
** Unités: compteurs et uPED5.
** Performance: coût borné.
** Portabilité: C99 Windows/Linux.
*/
static int	check_complete(void)
{
	t_fishing_session_events		events;
	t_fishing_session_economics	economics;

	ASSERT_TRUE(e89_fixture());
	ASSERT_TRUE(fishing_session_events_read_v4(E89_PATH, 7, &events));
	ASSERT_I64_EQ(events.attempts, 2);
	ASSERT_I64_EQ(events.confirmed_attempts, 2);
	ASSERT_I64_EQ(events.catches, 2);
	ASSERT_I64_EQ(events.loot_rows, 2);
	ASSERT_I64_EQ(events.loot_tt, 1500);
	ASSERT_I64_EQ(events.loot_quality, DATA_COMPLETE);
	ASSERT_TRUE(fishing_session_economics_build(&events, &g_e89_cost,
			&economics));
	ASSERT_I64_EQ(economics.tt_net, 1200);
	ASSERT_I64_EQ(economics.cost_basis_net, 1050);
	ASSERT_I64_EQ(economics.tt_cost_per_attempt, 150);
	ASSERT_I64_EQ(economics.basis_cost_per_catch, 225);
	ASSERT_TRUE(economics.has_tt_result && economics.has_basis_result);
	remove(E89_PATH);
	return (0);
}

/*
** Rôle: check_partial_value — Vérifie qu'un loot V4 sans valeur bloque Net.
** Relations: e89_fixture(), fishing_session_events_read_v4(),
**            fishing_session_economics_build().
** Appelants: main().
** Mémoire: structures locales seulement.
** Invariants: une valeur manquante devient PARTIAL_VALUE et jamais zéro prouvé.
** Retour: 0 si le résultat financier reste indisponible comme attendu.
** Effets: réécrit une fixture dédiée puis la supprime.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_session_economics.c ->
** check_partial_value().
** Dépendances: CSV V4 et qualité E82.
** État partagé: E89_PATH.
** Concurrence: mono-thread.
** I/O: lecture/écriture/suppression fichier test.
** Unités: uPED5.
** Performance: coût borné.
** Portabilité: C99 Windows/Linux.
*/
static int	check_partial_value(void)
{
	t_fishing_session_events		events;
	t_fishing_session_economics	economics;
	t_e89_row					unknown;
	FILE				*file;

	ASSERT_TRUE(e89_fixture());
	file = fopen(E89_PATH, "ab");
	ASSERT_TRUE(file != NULL);
	unknown = (t_e89_row){8, "LOOT_ITEM", "Unknown Value", 0, 0};
	ASSERT_TRUE(e89_write(file, &unknown));
	ASSERT_TRUE(fclose(file) == 0);
	ASSERT_TRUE(fishing_session_events_read_v4(E89_PATH, 7, &events));
	ASSERT_TRUE(fishing_session_economics_build(&events, &g_e89_cost,
			&economics));
	ASSERT_I64_EQ(events.loot_quality, DATA_PARTIAL_VALUE);
	ASSERT_TRUE(!economics.has_tt_result);
	ASSERT_TRUE(!economics.has_basis_result);
	ASSERT_I64_EQ(economics.tt_result_quality, DATA_PARTIAL_VALUE);
	remove(E89_PATH);
	return (0);
}

/*
** Rôle: main — Exécute les régressions d'économie de session Fishing E89.
** Relations: check_complete(), check_partial_value().
** Appelants: runner Makefile.
** Mémoire: gérée par les sous-tests.
** Invariants: aucune donnée utilisateur persistante n'est conservée.
** Retour: 0 si toutes les régressions passent.
** Effets: crée temporairement E89_PATH pendant les sous-tests.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_session_economics.c ->
** main().
** Dépendances: framework test C.
** État partagé: aucun après nettoyage.
** Concurrence: mono-thread.
** I/O: via sous-tests.
** Unités: diverses.
** Performance: coût faible.
** Portabilité: C99 Windows/Linux.
*/
int	main(void)
{
	TEST_RUN(check_complete());
	TEST_RUN(check_partial_value());
	return (0);
}
