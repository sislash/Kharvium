/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_loadout_estimate.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "support/test_fishing_rod_config_support.h"
#include "config/fishing_rod_config.h"

/*
** Rôle: check_complete_estimate — Vérifie le total TT exact du montage River
**       dont les cinq decays et l'ammo burn sont connus dans le catalogue.
** Retour: 0 sur succès, sinon une macro ASSERT interrompt le test.
** Effets: charge puis libère la configuration Fishing packagée.
** Invariants: total = gear decay + ammo burn * TT unitaire, sans MU.
** Relations: test_fishing_rod_load_config(), fishing_rod_database_find(),
**            fishing_rod_preset_apply(),
**            fishing_loadout_estimate_tt_per_attempt().
** Appelants: main().
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_complete_estimate().
** Dépendances: catalogue Fishing packagé E110.
** Mémoire: toutes les allocations de fixture sont libérées.
** État partagé: aucun.
** Concurrence: test séquentiel.
** I/O: lecture des catalogues locaux par le helper de test.
** Unités: uPED5 par tentative.
** Performance: quelques recherches catalogue bornées.
** Portabilité: C99 Windows/Linux.
*/
static int	check_complete_estimate(void)
{
	t_catalog_registry		registry;
	t_fishing_rod_database		database;
	const t_fishing_rod_preset	*preset;
	t_fishing_loadout_snapshot	snapshot;
	t_fishing_loadout_estimate	estimate;

	ASSERT_TRUE(test_fishing_rod_load_config(&registry, &database));
	preset = fishing_rod_database_find(&database, "SET-FR1 Angling - River");
	ASSERT_TRUE(preset && fishing_rod_preset_apply(&snapshot, preset,
			&registry));
	ASSERT_TRUE(fishing_loadout_estimate_tt_per_attempt(&snapshot, &registry,
			&estimate));
	ASSERT_I64_EQ(estimate.gear_tt_per_attempt, 4800);
	ASSERT_I64_EQ(estimate.ammo_tt_per_attempt, 18000);
	ASSERT_I64_EQ(estimate.total_tt_per_attempt, 22800);
	ASSERT_TRUE(estimate.quality == DATA_COMPLETE);
	test_fishing_rod_cleanup_config(&registry, &database);
	return (0);
}

/*
** Rôle: check_partial_and_zero_estimates — Vérifie qu'une config incomplète
**       reste PARTIAL et que Baitfishing vaut exactement zéro sans ammo.
** Retour: 0 sur succès, sinon une macro ASSERT interrompt le test.
** Effets: charge puis libère la configuration Fishing packagée.
** Invariants: aucune donnée technique absente n'est remplacée par zéro.
** Relations: test_fishing_rod_load_config(), fishing_rod_database_find(),
**            fishing_rod_preset_apply(),
**            fishing_loadout_estimate_tt_per_attempt().
** Appelants: main().
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**    check_partial_and_zero_estimates().
** Dépendances: presets Restricted et Baitfishing du fichier packagé.
** Mémoire: toutes les allocations de fixture sont libérées.
** État partagé: aucun.
** Concurrence: test séquentiel.
** I/O: lecture des catalogues locaux par le helper de test.
** Unités: uPED5 par tentative.
** Performance: recherches catalogue bornées.
** Portabilité: C99 Windows/Linux.
*/
static int	check_partial_and_zero_estimates(void)
{
	t_catalog_registry		registry;
	t_fishing_rod_database		database;
	const t_fishing_rod_preset	*preset;
	t_fishing_loadout_snapshot	snapshot;
	t_fishing_loadout_estimate	estimate;

	ASSERT_TRUE(test_fishing_rod_load_config(&registry, &database));
	preset = fishing_rod_database_find(&database,
			"SET-FR1 Angling - Restricted");
	ASSERT_TRUE(preset && fishing_rod_preset_apply(&snapshot, preset,
			&registry));
	ASSERT_TRUE(fishing_loadout_estimate_tt_per_attempt(&snapshot, &registry,
			&estimate));
	ASSERT_TRUE(estimate.quality == DATA_PARTIAL_COST);
	preset = fishing_rod_database_find(&database, "Baitfishing - F2P");
	ASSERT_TRUE(preset && fishing_rod_preset_apply(&snapshot, preset,
			&registry));
	ASSERT_TRUE(fishing_loadout_estimate_tt_per_attempt(&snapshot, &registry,
			&estimate));
	ASSERT_I64_EQ(estimate.total_tt_per_attempt, 0);
	ASSERT_TRUE(estimate.quality == DATA_COMPLETE);
	test_fishing_rod_cleanup_config(&registry, &database);
	return (0);
}

/*
** Rôle: main — Exécute les régressions E110 du coût TT technique Fishing.
** Retour: 0 si les estimations complète, partielle et zéro sont correctes.
** Effets: exécute uniquement des fixtures locales de test.
** Invariants: aucun fichier temporaire n'est conservé après les tests.
** Relations: check_complete_estimate(), check_partial_and_zero_estimates().
** Appelants: cible make test.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_loadout_estimate.c ->
**    main().
** Dépendances: framework TEST_RUN.
** Mémoire: aucune allocation directe.
** État partagé: aucun.
** Concurrence: non applicable.
** I/O: sorties du framework de test uniquement en cas d'échec.
** Unités: nombre de sous-tests.
** Performance: deux chargements courts de catalogues locaux.
** Portabilité: C99 Windows/Linux.
*/
int	main(void)
{
	TEST_RUN(check_complete_estimate());
	TEST_RUN(check_partial_and_zero_estimates());
	return (0);
}
