/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_tracker_event_csv.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "io/tracker_event_csv.h"
#include "platform/platform_file_system.h"
#include "platform/platform_time.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: make_paths — Produit des chemins temporaires uniques pour vérifier le
**       nom sidecar normal et le cas hunt_log.csv standard.
** Paramètre: hunt — chemin Hunt de test à remplir.
** Paramètre: event — chemin V4 calculé par l'API testée.
** Retour: aucun.
** Effets: écrit les deux buffers fournis.
** Invariants: les buffers fixes du test restent bornés par snprintf/API.
** Relations: appelle directement -> tracker_event_csv_sibling_path().
** Appelants: main().
** Mémoire: aucune allocation dynamique.
** I/O: aucune.
** Unités: millisecondes dans le suffixe unique.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_event_csv.c -> make_paths() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test directement utilisées par le
**            corps.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
static int	make_paths(char *hunt, char *event)
{
	unsigned long long	now;

	now = (unsigned long long)platform_time_milliseconds();
	snprintf(hunt, 256, "bin/tests/e85_%llu.csv", now);
	ASSERT_TRUE(tracker_event_csv_sibling_path(hunt, event, 256));
	ASSERT_TRUE(strstr(event, ".tracker_events.csv") != NULL);
	return (0);
}

/*
** Rôle: write_fixture — Écrit deux événements V4 liés par parent_event_id
**       avec activité Fishing et valeurs fixed-point exactes.
** Paramètre: path — journal temporaire créé par le test.
** Retour: aucun; les assertions stoppent le test sur échec.
** Effets: crée puis ferme un fichier CSV V4.
** Invariants: event_id 41 est racine et 42 référence exactement 41.
** Relations: appelle directement -> tracker_event_csv_ensure_header(),
**            tracker_event_csv_write().
** Appelants: main().
** Mémoire: aucune allocation dynamique.
** I/O: écriture fichier temporaire.
** Unités: uPED et identifiants.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_event_csv.c -> write_fixture() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test directement utilisées par le
**            corps.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
static int	write_fixture(const char *path)
{
	t_tracker_event_record	row;
	FILE			*file;

	file = fopen(path, "wb+");
	ASSERT_TRUE(file != NULL);
	ASSERT_TRUE(tracker_event_csv_ensure_header(file));
	memset(&row, 0, sizeof(row));
	row = (t_tracker_event_record){1000, 41, 0, 7,
		TRACKER_ACTIVITY_TYPE_FISHING, "KILL_FISHING", "Blue Snapper",
		1, 0, 9, 2u, "raw root"};
	ASSERT_TRUE(tracker_event_csv_write(file, &row));
	row = (t_tracker_event_record){1000, 42, 41, 7,
		TRACKER_ACTIVITY_TYPE_FISHING, "LOOT_ITEM", "Fish Scrap",
		280, 2800, 9, 3u, "raw loot"};
	ASSERT_TRUE(tracker_event_csv_write(file, &row));
	fclose(file);
	return (0);
}

/*
** Rôle: check_fixture — Relit les lignes V4 et vérifie texte, activité,
**       parentage, envelope legacy et précision monétaire.
** Paramètre: path — journal créé par write_fixture().
** Retour: aucun; les assertions portent le verdict du test.
** Effets: ouvre et ferme le fichier en lecture.
** Invariants: seules les deux lignes de données doivent être acceptées.
** Relations: appelle directement -> tracker_event_csv_parse_line().
** Appelants: main().
** Mémoire: aucune allocation dynamique.
** I/O: lecture fichier temporaire.
** Unités: uPED et identifiants.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_event_csv.c -> check_fixture() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test directement utilisées par le
**            corps.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
static int	check_fixture(const char *path)
{
	t_tracker_event_record	row;
	char			line[4096];
	FILE			*file;
	int			count;

	file = fopen(path, "rb");
	ASSERT_TRUE(file != NULL);
	count = 0;
	while (fgets(line, sizeof(line), file))
	{
		if (!tracker_event_csv_parse_line(line, &row))
			continue ;
		count++;
		ASSERT_I64_EQ(row.session_id, 7);
		ASSERT_I64_EQ(row.activity_type, TRACKER_ACTIVITY_TYPE_FISHING);
		if (row.event_id == 42)
		{
			ASSERT_I64_EQ(row.parent_event_id, 41);
			ASSERT_I64_EQ(row.envelope_id, 9);
			ASSERT_I64_EQ(row.value_uPED, 2800);
		}
	}
	fclose(file);
	ASSERT_I64_EQ(count, 2);
	return (0);
}

/*
** Rôle: main — Vérifie round-trip V4, reprise des séquences et construction
**       du chemin standard `logs/tracker_events.csv`.
** Retour: 0 si toutes les assertions E85 passent.
** Effets: crée puis supprime un fichier temporaire.
** Invariants: aucun fichier utilisateur n'est consulté par ce test.
** Relations: appelle directement -> check_fixture(), make_paths(),
**            tracker_event_csv_sibling_path(), tracker_event_csv_tail_ids(),
**            write_fixture().
** Appelants: aucun.
** Mémoire: aucune allocation dynamique directe.
** I/O: fichiers temporaires du dossier bin/tests.
** Unités: identifiants persistants.
** Portabilité: vérifie aussi un chemin Windows synthétique.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_event_csv.c -> main() (chemin complet dans l’index).
** Dépendances: stdio/string et macros de test directement utilisées par le
**            corps.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
int	main(void)
{
	char	hunt[256];
	char	event[256];
	char	standard[256];
	int64_t	last_event;
	int64_t	last_session;

	TEST_RUN(make_paths(hunt, event));
	(void)remove(event);
	TEST_RUN(write_fixture(event));
	TEST_RUN(check_fixture(event));
	ASSERT_TRUE(tracker_event_csv_tail_ids(event, &last_event, &last_session));
	ASSERT_I64_EQ(last_event, 42);
	ASSERT_I64_EQ(last_session, 7);
	ASSERT_TRUE(tracker_event_csv_sibling_path("logs/hunt_log.csv",
			standard, sizeof(standard)));
	ASSERT_TRUE(strcmp(standard, "logs/tracker_events.csv") == 0);
	ASSERT_TRUE(tracker_event_csv_sibling_path("logs\\hunt_log.csv",
			standard, sizeof(standard)));
	ASSERT_TRUE(strcmp(standard, "logs\\tracker_events.csv") == 0);
	(void)remove(event);
	return (0);
}
