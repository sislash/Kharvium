/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_list_sort.c                          +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "app/finance_list_search.h"

#include <stdio.h>

/*
** Rôle: test_original — Calcule et retourne original à partir des paramètres
**       fournis sans modifier les entrées déclarées en lecture seule.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_finance_list_build_order(),
**            app_finance_list_order_position().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_list_sort.c -> test_original() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_original(void)
{
	const char	*items[4];
	int			order[4];
	int			count;

	items[0] = "Wool";
	items[1] = "Animal Oil";
	items[2] = "Basic Stone";
	items[3] = "ArMatrix";
	count = app_finance_list_build_order(
		&(t_finance_list_order_request){items, 4,
			FIN_LIST_SORT_ORIGINAL, order, 4});
	if (count != 4 || order[0] != 0 || order[1] != 1)
		return (0);
	if (order[2] != 2 || order[3] != 3)
		return (0);
	return (app_finance_list_order_position(order, 4, 2) == 2);
}

/*
** Rôle: test_sort_name_ascending — Trie nom ascending en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_finance_list_build_order(),
**            app_finance_list_order_position().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_list_sort.c -> test_sort_name_ascending() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_sort_name_ascending(void)
{
	const char	*items[5];
	int			order[5];
	int			count;

	items[0] = "Wool";
	items[1] = "animal Oil";
	items[2] = "Basic Stone";
	items[3] = "ArMatrix";
	items[4] = "animal Eye";
	count = app_finance_list_build_order(
		&(t_finance_list_order_request){items, 5,
			FIN_LIST_SORT_AZ, order, 5});
	if (count != 5)
		return (0);
	if (order[0] != 4 || order[1] != 1 || order[2] != 3)
		return (0);
	if (order[3] != 2 || order[4] != 0)
		return (0);
	return (app_finance_list_order_position(order, 5, 0) == 4);
}

/*
** Rôle: test_za_and_capacity — Calcule za et capacité à partir des entrées
**       courantes en respectant les unités, bornes et règles d’arrondi du
**       module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_finance_list_build_order(),
**            app_finance_list_order_position().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_list_sort.c -> test_za_and_capacity() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_za_and_capacity(void)
{
	const char	*items[5];
	int			order[3];
	int			count;

	items[0] = "Wool";
	items[1] = "Animal Oil";
	items[2] = "Basic Stone";
	items[3] = "ArMatrix";
	items[4] = "Animal Eye";
	count = app_finance_list_build_order(
		&(t_finance_list_order_request){items, 5,
			FIN_LIST_SORT_ZA, order, 3});
	if (count != 3)
		return (0);
	if (order[0] != 0 || order[1] != 2 || order[2] != 1)
		return (0);
	return (app_finance_list_order_position(order, 3, 4) == -1);
}

/*
** Rôle: test_search_sorted_view — Recherche sorted view dans la collection ou
**       la source disponible et retourne l’absence selon la convention
**       explicite du module.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les accès indexés sont bornés avant lecture ou écriture; les
**             montants persistants restent en représentation entière fixe,
**             sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_finance_list_build_order(),
**            app_finance_list_find().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_list_sort.c -> test_search_sorted_view() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_search_sorted_view(void)
{
	const char	*items[4];
	const char	*view[4];
	int			order[4];
	int			index;

	items[0] = "Wool";
	items[1] = "Animal Oil";
	items[2] = "Basic Stone";
	items[3] = "Animal Eye";
	app_finance_list_build_order(&(t_finance_list_order_request){items, 4,
		FIN_LIST_SORT_AZ, order, 4});
	index = 0;
	while (index < 4)
	{
		view[index] = items[order[index]];
		index++;
	}
	index = app_finance_list_find(view, 4, "animal", 0);
	if (index != 0 || order[index] != 3)
		return (0);
	index = app_finance_list_find(view, 4, "animal", index + 1);
	return (index == 1 && order[index] == 1);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_original(),
**            test_search_sorted_view(), test_sort_name_ascending(),
**            test_za_and_capacity().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_list_sort.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf(), printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	if (!test_original() || !test_sort_name_ascending()
		|| !test_za_and_capacity()
		|| !test_search_sorted_view())
	{
		fprintf(stderr, "test_finance_list_sort: FAIL\n");
		return (1);
	}
	printf("test_finance_list_sort: OK\n");
	return (0);
}
