/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_parse_engine_replay.c                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/17                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"

#include "io/hunt_csv.h"
#include "parse/parse_engine.h"
#include "hunt/hunt_rules.h"
#include "app/app_state.h"
#include "platform/platform_file_system.h"
#include "support/test_parse_replay_support.h"

#include "platform/platform_time.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: write_text_file — Écrit texte fichier.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_engine_replay.c -> write_text_file() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fwrite(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fwrite().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	write_text_file(const char *path, const char *text)
{
	FILE	*f;

	if (!path)
		return (-1);
	f = fopen(path, "wb");
	if (!f)
		return (-1);
	if (text && text[0])
		fwrite(text, 1, strlen(text), f);
	fclose(f);
	return (0);
}

/*
** Rôle: make_paths — Formate make paths dans le buffer destination fourni,
**       avec une taille explicitement bornée par l’appelant.
** Paramètre: chat — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: chatsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: csv — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: csvsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : chat, csv.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_process_id(),
**            platform_time_milliseconds().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_engine_replay.c -> make_paths() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: millisecondes.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	make_paths(char *chat, size_t chatsz, char *csv, size_t csvsz)
{
	int		pid;
	uint64_t	now;

	pid = platform_process_id();
	now = platform_time_milliseconds();
	snprintf(chat, chatsz, "bin/tests/tmp_chat_%d_%llu.log", pid,
			(unsigned long long)now);
	snprintf(csv, csvsz, "bin/tests/tmp_csv_%d_%llu.csv", pid,
			(unsigned long long)now);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_rules_initialize(), make_paths(),
**            parse_engine_set_player_name(), parse_run_replay(),
**            test_parse_replay_rows_check(), write_text_file().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_engine_replay.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(), memset(),
**              remove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_test_parse_replay_log.
** Concurrence: état global mutable détecté (g_test_parse_replay_log);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_app_state	app;
	char		chat_path[256];
	char		csv_path[256];
	int		rc;

	make_paths(chat_path, sizeof(chat_path), csv_path, sizeof(csv_path));
	ASSERT_I64_EQ(write_text_file(chat_path, g_test_parse_replay_log), 0);
	(void)remove(csv_path);
	memset(&app, 0, sizeof(app));
	hunt_rules_initialize(&app.parse.rules);
	parse_engine_set_player_name(&app, "Tester");
	rc = parse_run_replay(&app, chat_path, csv_path, NULL);
	ASSERT_I64_EQ(rc, 0);
	ASSERT_I64_EQ(test_parse_replay_rows_check(csv_path), 0);
	(void)remove(chat_path);
	(void)remove(csv_path);
	return (0);
}
