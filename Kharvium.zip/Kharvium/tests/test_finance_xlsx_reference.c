/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_xlsx_reference.c                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_calculations.h"
#include "finance/finance_recipe.h"

#include "common/money.h"
#include "support/test_fin_xlsx_recipe_support.h"
#include "support/test_fin_xlsx_seed_support.h"
#include <limits.h>
#include <stdio.h>
#include <string.h>

/*
** Rôle: check_stage_costs — Vérifie stage costs.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: recipe — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_recipe_stage_reference_cost(),
**            test_fin_xlsx_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_xlsx_reference.c -> check_stage_costs() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_stage_costs(const t_finance_book *book,
	const t_finance_recipe *recipe)
{
	if (finance_recipe_stage_reference_cost(book, &recipe->stages[0])
		!= test_fin_xlsx_amount("10.44840"))
		return (0);
	if (finance_recipe_stage_reference_cost(book, &recipe->stages[1])
		!= test_fin_xlsx_amount("25.17660"))
		return (0);
	if (finance_recipe_stage_reference_cost(book, &recipe->stages[2])
		!= test_fin_xlsx_amount("18.20954"))
		return (0);
	return (finance_recipe_stage_reference_cost(book, &recipe->stages[3])
		== test_fin_xlsx_amount("29.37808"));
}

/*
** Rôle: check_recipe_quote — Vérifie recette quote.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: recipe — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_recipe_quote(),
**            test_fin_xlsx_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_xlsx_reference.c -> check_recipe_quote() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_recipe_quote(const t_finance_book *book,
	const t_finance_recipe *recipe)
{
	t_finance_recipe_quote	quote;

	memset(&quote, 0, sizeof(quote));
	quote.requested_output_quantity = 25;
	if (!finance_recipe_quote(book, recipe, &quote))
		return (0);
	if (quote.batch_tt_uPED != test_fin_xlsx_amount("16.39000"))
		return (0);
	if (quote.batch_reference_uPED != test_fin_xlsx_amount("83.21262"))
		return (0);
	if (quote.requested_output_market_uPED
		!= test_fin_xlsx_amount("425.00000"))
		return (0);
	return (quote.theoretical_margin_uPED
		== test_fin_xlsx_amount("341.78738"));
}

/*
** Rôle: check_repayment_projection — Vérifie repayment projection.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_projection_build(),
**            test_fin_xlsx_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_xlsx_reference.c -> check_repayment_projection()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_repayment_projection(void)
{
	t_finance_projection	projection;

	memset(&projection, 0, sizeof(projection));
	projection.investment_uPED = test_fin_xlsx_amount("25300.00000");
	projection.cycle_cost_uPED = test_fin_xlsx_amount("339.00000");
	projection.yield_quantity = 25;
	projection.sale_unit_uPED = test_fin_xlsx_amount("17.00000");
	if (!finance_projection_build(&projection))
		return (0);
	if (projection.profit_cycle_uPED != test_fin_xlsx_amount("86.00000"))
		return (0);
	if (projection.cycles_to_repay != 295
		|| projection.units_to_repay != 7375)
		return (0);
	return (projection.working_capital_uPED
		== test_fin_xlsx_amount("100005.00000"));
}

/*
** Rôle: check_projection_limits — Vérifie projection limits.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les limites des entiers sont traitées
**             explicitement avant tout dépassement; les montants
**             persistants restent en représentation entière fixe, sans
**             dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_projection_build().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_xlsx_reference.c -> check_projection_limits() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_projection_limits(void)
{
	t_finance_projection	projection;

	memset(&projection, 0, sizeof(projection));
	projection.investment_uPED = INT64_MAX;
	projection.cycle_cost_uPED = 1;
	projection.yield_quantity = 2;
	projection.sale_unit_uPED = INT64_MAX;
	if (finance_projection_build(&projection))
		return (0);
	memset(&projection, 0, sizeof(projection));
	projection.investment_uPED = INT64_MAX;
	projection.cycle_cost_uPED = 1;
	projection.yield_quantity = 1;
	projection.sale_unit_uPED = 2;
	if (!finance_projection_build(&projection))
		return (0);
	return (projection.cycles_to_repay == 9223372036854775807LL);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_projection_limits(),
**            check_recipe_quote(), check_repayment_projection(),
**            check_stage_costs(), finance_book_add_recipe(),
**            finance_book_destroy(), finance_book_initialize(),
**            test_fin_xlsx_add_reference_prices() (+1; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_xlsx_reference.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=9; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_finance_book	book;
	t_finance_recipe	recipe;

	finance_book_initialize(&book, 0);
	if (!test_fin_xlsx_add_reference_prices(&book)
		|| !test_fin_xlsx_build_recipe(&recipe))
		return (1);
	if (!finance_book_add_recipe(&book, &recipe))
		return (1);
	if (!check_stage_costs(&book, &recipe)
		|| !check_recipe_quote(&book, &recipe))
		return (1);
	if (!check_repayment_projection() || !check_projection_limits())
		return (1);
	finance_book_destroy(&book);
	printf("test_finance_xlsx_reference: OK\n");
	return (0);
}
