/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_view_state.c                         +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "app/finance_view_state.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: set_inventory_state — Définit inventaire état.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: check_independent_pages(), check_reset().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_view_state.c -> set_inventory_state() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strcpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	set_inventory_state(t_app *app)
{
	app->finance_scroll = 210;
	app->finance_scroll2 = 90;
	app->finance_selected = 12;
	app->finance_selected2 = 4;
	app->finance_sort = 1;
	app->finance_sort2 = 2;
	app->finance_analysis_view = FIN_ANALYSIS_RUNS;
	strcpy(app->finance_search, "animal");
	strcpy(app->finance_search2, "oil");
}

/*
** Rôle: check_inventory_state — Vérifie inventaire état.
** Paramètre: app — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: check_independent_pages().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_view_state.c -> check_inventory_state() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_inventory_state(const t_app *app)
{
	if (app->finance_scroll != 210 || app->finance_scroll2 != 90)
		return (0);
	if (app->finance_selected != 12 || app->finance_selected2 != 4)
		return (0);
	if (app->finance_sort != 1 || app->finance_sort2 != 2)
		return (0);
	if (strcmp(app->finance_search, "animal") != 0)
		return (0);
	return (strcmp(app->finance_search2, "oil") == 0);
}

/*
** Rôle: check_independent_pages — Vérifie independent pages.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_inventory_state(),
**            finance_view_state_capture(), finance_view_state_reset_all(),
**            finance_view_state_restore(), set_inventory_state().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_view_state.c -> check_independent_pages() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), strcmp(),
**              strcpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_independent_pages(void)
{
	t_app	app;

	memset(&app, 0, sizeof(app));
	finance_view_state_reset_all(&app);
	set_inventory_state(&app);
	finance_view_state_capture(&app, PAGE_FINANCE_INVENTORY);
	app.finance_scroll = 7;
	app.finance_selected = 2;
	app.finance_analysis_view = FIN_ANALYSIS_CAPITAL;
	strcpy(app.finance_search, "run");
	finance_view_state_capture(&app, PAGE_FINANCE_ANALYSIS);
	finance_view_state_restore(&app, PAGE_FINANCE_INVENTORY);
	if (!check_inventory_state(&app))
		return (0);
	finance_view_state_restore(&app, PAGE_FINANCE_ANALYSIS);
	if (app.finance_scroll != 7 || app.finance_selected != 2)
		return (0);
	if (app.finance_analysis_view != FIN_ANALYSIS_CAPITAL)
		return (0);
	return (strcmp(app.finance_search, "run") == 0);
}

/*
** Rôle: check_reset — Réinitialise l’état associé à check.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_view_state_capture(),
**            finance_view_state_reset_all(), finance_view_state_restore(),
**            set_inventory_state().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_view_state.c -> check_reset() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_reset(void)
{
	t_app	app;

	memset(&app, 0, sizeof(app));
	set_inventory_state(&app);
	finance_view_state_capture(&app, PAGE_FINANCE_INVENTORY);
	finance_view_state_reset_all(&app);
	finance_view_state_restore(&app, PAGE_FINANCE_INVENTORY);
	return (app.finance_scroll == 0 && app.finance_selected == 0
		&& app.finance_search[0] == '\0' && app.finance_sort == 0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_independent_pages(),
**            check_reset().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_view_state.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	if (!check_independent_pages() || !check_reset())
		return (1);
	printf("test_finance_view_state: OK\n");
	return (0);
}
