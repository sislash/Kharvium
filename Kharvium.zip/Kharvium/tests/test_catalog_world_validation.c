/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_catalog_world_validation.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "catalog/catalog_registry.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: world_fill — Prépare une définition monde minimale afin de tester le
**       graphe de parentage sans dépendre des fichiers CSV.
** Paramètre: world — structure destination initialisée complètement.
** Paramètre: id — identifiant canonique du monde.
** Paramètre: parent_id — parent canonique ou UNKNOWN.
** Paramètre: name — nom canonique unique du monde.
** Retour: Ne retourne rien.
** Effets: écrase la structure world fournie.
** Invariants: world_type reste TEST et n'intervient pas dans le graphe.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: world_cycle_rejected(), world_missing_parent_rejected().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_catalog_world_validation.c -> world_fill().
** Dépendances: memset(), snprintf().
** Mémoire: aucune allocation dynamique.
** État partagé: aucun.
** Concurrence: réentrant.
** I/O: aucune.
** Unités: identifiants canoniques.
** Performance: O(1).
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	world_fill(t_catalog_world *world, t_entity_id id,
	t_entity_id parent_id, const char *name)
{
	memset(world, 0, sizeof(*world));
	world->world_id = id;
	world->parent_world_id = parent_id;
	snprintf(world->canonical_name, sizeof(world->canonical_name), "%s", name);
	snprintf(world->world_type, sizeof(world->world_type), "TEST");
}

/*
** Rôle: world_cycle_rejected — Construit deux parents circulaires et vérifie
**       que la validation globale refuse ce graphe.
** Paramètres: aucun.
** Retour: Retourne 1 uniquement si le cycle est détecté.
** Effets: alloue puis détruit un petit registre temporaire.
** Invariants: l'ajout local autorise l'ordre arbitraire, la validation finale
**             est responsable de détecter le cycle.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> catalog_registry_add_world(),
**            catalog_registry_destroy(), catalog_registry_initialize(),
**            catalog_registry_validate_world_links(), world_fill().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_catalog_world_validation.c -> world_cycle_rejected().
** Dépendances: aucune.
** Mémoire: libération déléguée à catalog_registry_destroy().
** État partagé: aucun.
** Concurrence: test séquentiel.
** I/O: aucune.
** Unités: identifiants canoniques.
** Performance: scénario constant de deux mondes.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	world_cycle_rejected(void)
{
	t_catalog_registry	registry;
	t_catalog_world		a;
	t_catalog_world		b;
	int			ok;

	catalog_registry_initialize(&registry);
	world_fill(&a, 3001, 3002, "Cycle A");
	world_fill(&b, 3002, 3001, "Cycle B");
	ok = catalog_registry_add_world(&registry, &a);
	ok = ok && catalog_registry_add_world(&registry, &b);
	ok = ok && !catalog_registry_validate_world_links(&registry);
	catalog_registry_destroy(&registry);
	return (ok);
}

/*
** Rôle: world_missing_parent_rejected — Vérifie qu'un parent positif absent
**       rend aussi le catalogue global invalide.
** Paramètres: aucun.
** Retour: Retourne 1 si le parent inexistant est rejeté.
** Effets: alloue puis détruit un registre temporaire.
** Invariants: UNKNOWN zéro reste le seul parent racine implicite.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> catalog_registry_add_world(),
**            catalog_registry_destroy(), catalog_registry_initialize(),
**            catalog_registry_validate_world_links(), world_fill().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_catalog_world_validation.c -> world_missing_parent_rejected().
** Dépendances: aucune.
** Mémoire: libération déléguée à catalog_registry_destroy().
** État partagé: aucun.
** Concurrence: test séquentiel.
** I/O: aucune.
** Unités: identifiants canoniques.
** Performance: scénario constant d'un monde.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	world_missing_parent_rejected(void)
{
	t_catalog_registry	registry;
	t_catalog_world		world;
	int			ok;

	catalog_registry_initialize(&registry);
	world_fill(&world, 3010, 3999, "Orphan");
	ok = catalog_registry_add_world(&registry, &world);
	ok = ok && !catalog_registry_validate_world_links(&registry);
	catalog_registry_destroy(&registry);
	return (ok);
}

/*
** Rôle: main — Exécute les deux protections de graphe monde introduites E83.
** Paramètres: aucun.
** Retour: Retourne 0 si cycle et parent absent sont refusés, 1 sinon.
** Effets: écrit uniquement le résultat du test sur stdout.
** Invariants: aucune fixture ni allocation ne subsiste après les scénarios.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> world_cycle_rejected(),
**            world_missing_parent_rejected().
** Appelants: aucun.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_catalog_world_validation.c -> main().
** Dépendances: printf().
** Mémoire: aucune allocation directe.
** État partagé: aucun.
** Concurrence: exécution séquentielle.
** I/O: sortie stdout uniquement.
** Unités: aucune supplémentaire.
** Performance: coût constant.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	if (!world_cycle_rejected() || !world_missing_parent_rejected())
		return (1);
	printf("test_catalog_world_validation: OK\n");
	return (0);
}
