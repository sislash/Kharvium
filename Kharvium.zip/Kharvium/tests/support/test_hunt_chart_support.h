/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_chart_support.h                          +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_HUNT_CHART_SUPPORT_H
# define TEST_HUNT_CHART_SUPPORT_H

# include "ui/hunt_chart_data.h"

typedef struct s_test_hunt_chart_context
{
	t_hunt_series		*series;
	t_hunt_chart_output	output;
	double			values[HS_MAX_POINTS];
	int			x_seconds[HS_MAX_POINTS];
	int			groups[HS_MAX_POINTS];
	int64_t			kill_ids[HS_MAX_POINTS];
	unsigned char		has_kill[HS_MAX_POINTS];
}t_test_hunt_chart_context;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_chart_build_metric — Construit graphique metric à partir
**       des paramètres fournis et initialise tous les champs requis avant
**       qu’ils soient lus par une autre opération.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: metric — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: range_minutes — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : series, output.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_chart_build_metric().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_chart_build_metric(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_chart_build_metric(t_hunt_series *series,
		t_hunt_chart_metric metric, int range_minutes,
		t_hunt_chart_output *output);

#endif
