/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_tracker_e87_support.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_tracker_e87_support.h"
#include "../test_util.h"
#include <string.h>

/*
** Rôle: test_runtime_attempt — Vérifie la racine ATTEMPT runtime E87.
** Paramètres: row — événement V4; attempt_id — identité racine produite.
** Retour: 0 lorsque type, résultat, flags et parent sont conformes.
** Effets: renseigne attempt_id; les autres données restent inchangées.
** Invariants: une catch prouve seulement CONFIRMED_CATCH, jamais un coût.
** Relations: appelle directement -> strcmp() et macros d'assertion.
** Appelants: test_tracker_e87_runtime_row().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_runtime_attempt().
** Dépendances: modèle Tracker V4, string.h et framework de test.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun état global mutable.
** Concurrence: réentrant pour des paramètres distincts.
** I/O: aucune.
** Unités: event_id persistant.
** Performance: coût constant.
** Portabilité: C99 portable Windows/Linux.
*/
static int	test_runtime_attempt(const t_tracker_event_record *row,
	int64_t *attempt_id)
{
	ASSERT_TRUE(strcmp(row->event_type, "FISHING_ATTEMPT") == 0);
	ASSERT_TRUE(strcmp(row->target_or_item, "CONFIRMED_CATCH") == 0);
	ASSERT_TRUE((row->flags & TRACKER_EVENT_FLAG_INFERRED) != 0);
	ASSERT_TRUE((row->flags & TRACKER_EVENT_FLAG_PARTIAL_CONTEXT) != 0);
	ASSERT_I64_EQ(row->parent_event_id, 0);
	*attempt_id = row->event_id;
	return (0);
}

/*
** Rôle: test_runtime_catch — Vérifie CATCH comme enfant de la tentative.
** Paramètres: row — catch V4; attempt_id — parent; catch_id — sortie.
** Retour: 0 si type, flag partiel et relation parent sont conformes.
** Effets: renseigne catch_id uniquement.
** Invariants: la catch est le parent sémantique des futurs enfants.
** Relations: appelle directement -> strcmp() et macros d'assertion.
** Appelants: test_tracker_e87_runtime_row().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_runtime_catch().
** Dépendances: modèle Tracker V4, string.h et framework de test.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun état global mutable.
** Concurrence: réentrant pour des paramètres distincts.
** I/O: aucune.
** Unités: event_id persistant.
** Performance: coût constant.
** Portabilité: C99 portable Windows/Linux.
*/
static int	test_runtime_catch(const t_tracker_event_record *row,
	int64_t attempt_id, int64_t *catch_id)
{
	ASSERT_TRUE(strcmp(row->event_type, "FISHING_CATCH") == 0);
	ASSERT_TRUE((row->flags & TRACKER_EVENT_FLAG_PARTIAL_CONTEXT) != 0);
	ASSERT_I64_EQ(row->parent_event_id, attempt_id);
	*catch_id = row->event_id;
	return (0);
}

/*
** Rôle: test_tracker_e87_runtime_row — Valide une ligne Fishing V4 runtime.
** Paramètres: row/count — ligne et rang; attempt_id/catch_id — liens suivis.
** Retour: 0 lorsque la hiérarchie E87 reste cohérente.
** Effets: délègue la mise à jour des IDs racines aux helpers dédiés.
** Invariants: aucun KILL_FISHING neuf n'est accepté en V4.
** Relations: test_runtime_attempt(), test_runtime_catch(), strcmp().
** Appelants: test_parse_engine_tracker_v4.c::check_sidecar().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_tracker_e87_runtime_row().
** Dépendances: modèle Tracker V4 et framework d'assertion.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun état global mutable.
** Concurrence: réentrant pour des états de test distincts.
** I/O: aucune.
** Unités: rang de ligne et event/envelope IDs.
** Performance: coût constant par ligne.
** Portabilité: C99 portable Windows/Linux.
*/
int	test_tracker_e87_runtime_row(const t_tracker_event_record *row,
	int count, int64_t *attempt_id, int64_t *catch_id)
{
	ASSERT_I64_EQ(row->session_id, 1);
	ASSERT_I64_EQ(row->activity_type, TRACKER_ACTIVITY_TYPE_FISHING);
	ASSERT_TRUE(strcmp(row->event_type, "KILL_FISHING") != 0);
	if (count == 1)
		return (test_runtime_attempt(row, attempt_id));
	if (count == 2)
		return (test_runtime_catch(row, *attempt_id, catch_id));
	ASSERT_TRUE(*catch_id > 0);
	ASSERT_I64_EQ(row->parent_event_id, *catch_id);
	ASSERT_I64_EQ(row->envelope_id, 1);
	return (0);
}

/*
** Rôle: test_migration_attempt — Vérifie la tentative issue du V3 legacy.
** Paramètre: row — événement ATTEMPT migré consulté en lecture seule.
** Retour: 0 si résultat, flags d'inférence/legacy et parent sont conformes.
** Effets: aucun hors assertions.
** Invariants: la migration n'efface jamais sa provenance legacy.
** Relations: appelle directement -> strcmp() et macros d'assertion.
** Appelants: test_tracker_e87_migration_row().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_migration_attempt().
** Dépendances: modèle Tracker V4, string.h et framework de test.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun état global mutable.
** Concurrence: réentrant.
** I/O: aucune.
** Unités: aucune.
** Performance: coût constant.
** Portabilité: C99 portable Windows/Linux.
*/
static int	test_migration_attempt(const t_tracker_event_record *row)
{
	ASSERT_TRUE(strcmp(row->event_type, "FISHING_ATTEMPT") == 0);
	ASSERT_TRUE(strcmp(row->target_or_item, "CONFIRMED_CATCH") == 0);
	ASSERT_TRUE((row->flags & TRACKER_EVENT_FLAG_INFERRED) != 0);
	ASSERT_TRUE((row->flags & TRACKER_EVENT_FLAG_PARTIAL_CONTEXT) != 0);
	ASSERT_TRUE((row->flags & TRACKER_EVENT_FLAG_LEGACY_SOURCE) != 0);
	ASSERT_I64_EQ(row->parent_event_id, 0);
	return (0);
}

/*
** Rôle: test_tracker_e87_migration_row — Valide les lignes V4 migrées.
** Paramètres: row — événement migré; count — rang attendu dans le fixture.
** Retour: 0 lorsque Hunting et Fishing conservent leurs relations prévues.
** Effets: aucun hors assertions.
** Invariants: KILL_FISHING V3 devient ATTEMPT puis CATCH en V4.
** Relations: test_migration_attempt(), strcmp() et macros d'assertion.
** Appelants: test_tracker_event_migration.c::check_v4().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_tracker_e87_migration_row().
** Dépendances: modèle Tracker V4 et framework de test.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun état global mutable.
** Concurrence: réentrant pour des lignes distinctes.
** I/O: aucune.
** Unités: rang, event_id et envelope_id.
** Performance: coût constant par ligne.
** Portabilité: C99 portable Windows/Linux.
*/
int	test_tracker_e87_migration_row(const t_tracker_event_record *row,
	int count)
{
	ASSERT_I64_EQ(row->event_id, count);
	ASSERT_I64_EQ(row->session_id, 1);
	ASSERT_TRUE(strcmp(row->event_type, "KILL_FISHING") != 0);
	if (count == 2)
		ASSERT_I64_EQ(row->parent_event_id, 1);
	if (count == 3)
		return (test_migration_attempt(row));
	if (count == 4)
	{
		ASSERT_TRUE(strcmp(row->event_type, "FISHING_CATCH") == 0);
		ASSERT_TRUE((row->flags & TRACKER_EVENT_FLAG_LEGACY_SOURCE) != 0);
		ASSERT_I64_EQ(row->parent_event_id, 3);
	}
	if (count == 5)
		ASSERT_I64_EQ(row->parent_event_id, 4);
	if (count >= 3)
		ASSERT_I64_EQ(row->activity_type, TRACKER_ACTIVITY_TYPE_FISHING);
	return (0);
}
