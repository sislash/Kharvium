/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_manager_seed_support.h                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_FIN_MANAGER_SEED_SUPPORT_H
# define TEST_FIN_MANAGER_SEED_SUPPORT_H

# include "finance/finance_book.h"
# include "common/money.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_manager_amount — Met à jour fin manager montant en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_manager_amount().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_manager_amount(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	test_fin_manager_amount(const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_manager_add_price — Ajoute fin manager prix dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: tt — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: market — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_manager_add_price().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_manager_add_price(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		test_fin_manager_add_price(t_finance_book *book, const char *name,
			const char *tt, const char *market);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_manager_seed_stock — Met à jour fin manager seed stock en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_manager_seed_stock().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_manager_seed_stock(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		test_fin_manager_seed_stock(t_finance_book *book);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_manager_add_recipe — Ajoute fin manager recette dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_manager_add_recipe().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_manager_add_recipe(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		test_fin_manager_add_recipe(t_finance_book *book);

#endif
