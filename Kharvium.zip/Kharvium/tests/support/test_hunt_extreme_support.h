/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_extreme_support.h                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_HUNT_EXTREME_SUPPORT_H
# define TEST_HUNT_EXTREME_SUPPORT_H

# include "hunt/hunt_series.h"

typedef struct s_test_hunt_extreme_context
{
	t_hunt_series			*series;
	t_hunt_series_range_request	range;
	t_hunt_series_loot_request	request;
	t_hunt_series_output		output;
	double				values[HS_MAX_POINTS];
	int				x_seconds[HS_MAX_POINTS];
	int				groups[HS_MAX_POINTS];
	int64_t				kill_ids[HS_MAX_POINTS];
}t_test_hunt_extreme_context;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_extreme_write — Écrit l’état associé à test chasse
**       extreme.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_extreme_write().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_extreme_write(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_extreme_write(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_extreme_verify — Vérifie extreme en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_extreme_verify().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_extreme_verify(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_extreme_verify(const char *path);

#endif
