/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_csv_persistence_totals_support.c              :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_csv_persistence_support.h"

#include "io/hunt_csv.h"
#include "common/string_operations.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: lower_ascii — Compare lower ascii selon les règles de chaîne du
**       module et retourne le résultat sans modifier les entrées.
** Paramètre: c — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type char; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: contains_ci().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_totals_support.c -> lower_ascii() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static char	lower_ascii(char c)
{
	if (c >= 'A' && c <= 'Z')
		return ((char)(c - 'A' + 'a'));
	return (c);
}

/*
** Rôle: contains_ci — Détermine si ci respecte la condition indiquée par le
**       nom de la fonction, sans modifier l’état consulté.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: token — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> lower_ascii().
** Appelants: is_expense_type().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_totals_support.c -> contains_ci() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	contains_ci(const char *text, const char *token)
{
	size_t	i;
	size_t	j;

	if (!text || !token || !token[0])
		return (0);
	i = 0;
	while (text[i])
	{
		j = 0;
		while (token[j] && text[i + j]
			&& lower_ascii(text[i + j]) == lower_ascii(token[j]))
			j++;
		if (!token[j])
			return (1);
		i++;
	}
	return (0);
}

/*
** Rôle: is_loot_type — Détermine si loot type.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_csv_calculate_totals().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_totals_support.c -> is_loot_type() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	is_loot_type(const char *type)
{
	if (!type)
		return (0);
	return (strcmp(type, "SWEAT") == 0
		|| strncmp(type, "LOOT", 4) == 0
		|| strncmp(type, "RECEIVED", 8) == 0);
}

/*
** Rôle: is_expense_type — Détermine si expense type.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> contains_ci().
** Appelants: test_csv_calculate_totals().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_totals_support.c -> is_expense_type() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	is_expense_type(const char *type)
{
	if (!type)
		return (0);
	return (strcmp(type, "SPEND") == 0 || strcmp(type, "AMMO") == 0
		|| strcmp(type, "DECAY") == 0 || strcmp(type, "REPAIR") == 0
		|| contains_ci(type, "SPEND") || contains_ci(type, "AMMO")
		|| contains_ci(type, "DECAY") || contains_ci(type, "REPAIR"));
}

/*
** Rôle: test_csv_calculate_totals — Calcule totals à partir des entrées
**       fournies en respectant les unités, les bornes et les règles
**       d’arrondi propres au module.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: totals — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : totals.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_parse_row_inplace(),
**            is_expense_type(), is_loot_type(), string_copy_safe().
** Appelants: test_csv_legacy_rewrite(), test_csv_money_migration(),
**            test_csv_rewrite_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_totals_support.c ->
**        test_csv_calculate_totals() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fgets(), fopen(),
**              memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: uPED.
** Performance: boucles while locales=1; appels projet directs=4; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_csv_calculate_totals(const char *path, t_test_csv_totals *totals)
{
	FILE				*f;
	char				line[8192];
	char				work[8192];
	t_hunt_csv_row_view	row;

	if (!path || !totals)
		return (0);
	memset(totals, 0, sizeof(*totals));
	f = fopen(path, "rb");
	if (!f)
		return (0);
	while (fgets(line, sizeof(line), f))
	{
		string_copy_safe(work, sizeof(work), line);
		if (!hunt_csv_parse_row_inplace(work, &row))
			continue ;
		totals->rows++;
		if (is_loot_type(row.type_evenement))
			totals->loot += (long long)row.valeur_uPED;
		else if (is_expense_type(row.type_evenement))
			totals->expense += (long long)row.valeur_uPED;
	}
	return (fclose(f), 1);
}
