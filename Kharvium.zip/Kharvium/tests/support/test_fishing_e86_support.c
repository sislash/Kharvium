/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_e86_support.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_fishing_e86_support.h"
#include "../test_util.h"
#include "common/string_operations.h"
#include "io/hunt_csv.h"
#include "io/tracker_event_csv.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: fishing_e86_collect_v3 — Compte racines et loots du CSV legacy.
** Paramètre: path — journal V3 produit par le replay.
** Paramètre: stats — compteurs accumulés par le support de test.
** Retour: 0 si le fichier est lisible, 1 via assertion sinon.
** Effets: lit path et modifie catches/loot.
** Invariants: les lignes invalides ne contribuent pas aux compteurs.
** Relations: hunt_csv_parse_row_inplace(), string_copy_safe().
** Appelants: test_fishing_e86_collect_stats().
** Mémoire: buffers locaux uniquement.
** I/O: lecture V3.
** Unités: nombre d'événements.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_e86_support.c ->
** fishing_e86_collect_v3().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût local borné ou linéaire sur la collection parcourue.
*/
static int	fishing_e86_collect_v3(const char *path, t_e86_stats *stats)
{
	t_hunt_csv_row_view	row;
	char			line[4096];
	char			work[4096];
	FILE			*file;

	file = fopen(path, "rb");
	ASSERT_TRUE(file != NULL);
	while (fgets(line, sizeof(line), file))
	{
		string_copy_safe(work, sizeof(work), line);
		if (hunt_csv_parse_row_inplace(work, &row))
		{
			stats->catches += strcmp(row.type_evenement,
					"KILL_FISHING") == 0;
			stats->loot += strcmp(row.type_evenement, "LOOT_ITEM") == 0;
		}
	}
	fclose(file);
	return (0);
}

/*
** Rôle: fishing_e86_update_v4 — Applique une ligne V4 valide aux compteurs
**       de classification et de parentage E86.
** Paramètre: event — événement générique déjà parsé.
** Paramètre: stats — compteurs à mettre à jour.
** Retour: aucun.
** Effets: modifie uniquement stats.
** Invariants: unknown_loot exige un parent positif.
** Relations: strcmp(), strstr().
** Appelants: fishing_e86_collect_v4().
** Mémoire: aucune allocation.
** I/O: aucune.
** Unités: nombre d'événements.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_e86_support.c ->
** fishing_e86_update_v4().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût local borné ou linéaire sur la collection parcourue.
*/
static void	fishing_e86_update_v4(const t_tracker_event_record *event,
	t_e86_stats *stats)
{
	stats->events++;
	if (strcmp(event->event_type, "FISHING_SKILL") == 0)
	{
		stats->skills++;
		stats->parented_skills += event->parent_event_id > 0;
	}
	if (strcmp(event->event_type, "FISHING_CANDIDATE") == 0)
		stats->candidates++;
	if (strcmp(event->event_type, "LOOT_ITEM") == 0
		&& strcmp(event->target_or_item, "Mystery Minnow") == 0)
		stats->unknown_loot += event->parent_event_id > 0;
	if (strcmp(event->event_type, "FISHING_CATCH") != 0)
		return ;
	stats->neutral_roots += strstr(event->target_or_item,
			"no raw fish") != NULL;
	stats->raw_roots += strcmp(event->target_or_item, "Blue Snapper") == 0;
	stats->oil_roots += strstr(event->target_or_item, "Oil") != NULL;
}

/*
** Rôle: fishing_e86_collect_v4 — Compte skills, candidats, liens et racines
**       du journal générique E85/E86.
** Paramètre: path — sidecar V4 produit par le replay.
** Paramètre: stats — compteurs accumulés.
** Retour: 0 si le fichier est lisible, 1 via assertion sinon.
** Effets: lit path et met à jour les dimensions E86.
** Invariants: les lignes V4 invalides sont ignorées sans inventer de données.
** Relations: tracker_event_csv_parse_line(), fishing_e86_update_v4().
** Appelants: test_fishing_e86_collect_stats().
** Mémoire: buffer local uniquement.
** I/O: lecture V4.
** Unités: nombres et identifiants parent.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_e86_support.c ->
** fishing_e86_collect_v4().
** Dépendances: fonctions projet/libc citées explicitement dans Relations.
** État partagé: aucun nouvel état global mutable introduit ici.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût borné ou linéaire sur la collection parcourue.
*/
static int	fishing_e86_collect_v4(const char *path, t_e86_stats *stats)
{
	t_tracker_event_record	event;
	char			line[4096];
	FILE			*file;

	file = fopen(path, "rb");
	ASSERT_TRUE(file != NULL);
	while (fgets(line, sizeof(line), file))
	{
		if (tracker_event_csv_parse_line(line, &event))
			fishing_e86_update_v4(&event, stats);
	}
	fclose(file);
	return (0);
}

/*
** Rôle: test_fishing_e86_collect_stats — Relit les deux journaux produits par
**       un scénario Fishing et consolide les compteurs de validation.
** Paramètre: hunt/events — chemins V3 et V4.
** Paramètre: stats — destination remise à zéro avant lecture.
** Retour: 0 sur succès, 1 via assertion si une source est illisible.
** Effets: lit les deux fichiers et modifie stats.
** Invariants: aucune donnée utilisateur n'est écrite par ce support.
** Relations: fishing_e86_collect_v3(), fishing_e86_collect_v4().
** Appelants: test_parse_engine_fishing_e86.c -> e86_run_case().
** Mémoire: aucune allocation dynamique.
** I/O: lecture V3/V4.
** Unités: nombres d'événements.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_e86_support.c ->
** test_fishing_e86_collect_stats().
** Dépendances: fonctions projet/libc citées explicitement dans Relations.
** État partagé: aucun nouvel état global mutable introduit ici.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût borné ou linéaire sur la collection parcourue.
*/
int	test_fishing_e86_collect_stats(const char *hunt, const char *events,
	t_e86_stats *stats)
{
	memset(stats, 0, sizeof(*stats));
	TEST_RUN(fishing_e86_collect_v3(hunt, stats));
	TEST_RUN(fishing_e86_collect_v4(events, stats));
	return (0);
}

/*
** Rôle: test_fishing_e86_check_expected — Compare les compteurs réels aux
**       attentes d'un scénario sans dupliquer les assertions dans le runner.
** Paramètre: stats — résultats observés.
** Paramètre: expected — résultats attendus.
** Retour: 0 si toutes les dimensions correspondent.
** Effets: écrit uniquement un diagnostic de test en cas d'échec.
** Invariants: aucune huile ne peut être un nom de racine Fishing.
** Relations: macros ASSERT_I64_EQ().
** Appelants: test_parse_engine_fishing_e86.c -> e86_run_case().
** Mémoire: aucune allocation.
** I/O: diagnostic stderr uniquement en cas d'échec.
** Unités: nombres d'événements.
** Portabilité: C99 portable.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_e86_support.c ->
** test_fishing_e86_check_expected().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** Performance: coût local borné ou linéaire sur la collection parcourue.
*/
int	test_fishing_e86_check_expected(const t_e86_stats *stats,
	const t_e86_expected *expected)
{
	ASSERT_I64_EQ(stats->catches, expected->catches);
	ASSERT_I64_EQ(stats->loot, expected->loot);
	ASSERT_I64_EQ(stats->events, expected->events);
	ASSERT_I64_EQ(stats->skills, expected->skills);
	ASSERT_I64_EQ(stats->parented_skills, expected->skills);
	ASSERT_I64_EQ(stats->candidates, expected->candidates);
	ASSERT_I64_EQ(stats->unknown_loot, expected->unknown_loot);
	ASSERT_I64_EQ(stats->neutral_roots, expected->neutral_roots);
	ASSERT_I64_EQ(stats->raw_roots, expected->raw_roots);
	ASSERT_I64_EQ(stats->oil_roots, 0);
	return (0);
}
