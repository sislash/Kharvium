/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_extreme_support.c                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_hunt_extreme_support.h"
#include "../test_util.h"
#include "hunt/hunt_series.h"
#include "io/hunt_csv.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
** Rôle: ped_to_uped — Convertit vers PED uPED en appliquant les
**       validations, bornes et effets explicitement définis
**       par ce module.
** Paramètre: ped — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: extreme_check().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_extreme_support.c -> ped_to_uped() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int64_t	ped_to_uped(double ped)
{
	double	scaled;

	scaled = ped * (double)MONEY_UPED_PER_PED;
	if (scaled >= 0.0)
		return ((int64_t)(scaled + 0.5));
	return ((int64_t)(scaled - 0.5));
}

static const t_hunt_csv_row_view	g_extreme_kill = {
	.timestamp_unix = 1700000000, .type_evenement = "KILL", .cible = "Mob",
	.quantite = 1, .valeur_uPED = 0, .a_valeur = 0, .id_kill = 1,
	.drapeaux = 2u, .brut = "You killed Mob."
};

static const t_hunt_csv_row_view	g_extreme_loot = {
	.timestamp_unix = 1700000000, .type_evenement = "LOOT_ITEM",
	.cible = "Animal Oil Residue", .quantite = 1, .valeur_uPED = 1000,
	.a_valeur = 1, .id_kill = 1, .drapeaux = 3u,
	.brut = "You received Animal Oil Residue"
};

/*
** Rôle: test_hunt_extreme_write — Écrit l’état associé à test chasse
**       extreme.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_ensure_header_v2(),
**            hunt_csv_write_v2().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_extreme_support.c -> test_hunt_extreme_write() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), fclose(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_extreme_kill,
**               g_extreme_loot.
** Concurrence: état global mutable détecté (g_extreme_kill, g_extreme_loot);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_extreme_write(const char *path)
{
	FILE	*stream;
	int		index;

	stream = fopen(path, "wb");
	ASSERT_TRUE(stream != NULL);
	hunt_csv_ensure_header_v2(stream);
	ASSERT_I64_EQ(hunt_csv_write_v2(stream, &g_extreme_kill), 0);
	index = 0;
	while (index++ < 5000)
		ASSERT_I64_EQ(hunt_csv_write_v2(stream, &g_extreme_loot), 0);
	return (fclose(stream));
}
/*
** Rôle: extreme_build — Construit l’état associé à extreme.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_build_loot(),
**            hunt_series_rebuild_range(), hunt_series_reset(),
**            hunt_series_sanity_check().
** Appelants: test_hunt_extreme_verify().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_extreme_support.c -> extreme_build() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_TRUE(), calloc(),
**              memset().
** Mémoire: opérations directes -> calloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	extreme_build(t_test_hunt_extreme_context *context,
		const char *path)
{
	context->series = (t_hunt_series *)calloc(1, sizeof(*context->series));
	ASSERT_TRUE(context->series != NULL);
	hunt_series_reset(context->series, 0, 60);
	context->range = (t_hunt_series_range_request){path, 0, -1, 60};
	ASSERT_TRUE(hunt_series_rebuild_range(context->series, &context->range));
	ASSERT_TRUE(hunt_series_sanity_check(context->series));
	context->request = (t_hunt_series_loot_request){context->series, 0, 0};
	memset(&context->output, 0, sizeof(context->output));
	context->output.values = context->values;
	context->output.x_seconds = context->x_seconds;
	context->output.group_counts = context->groups;
	context->output.kill_ids = context->kill_ids;
	return (hunt_series_build_loot(&context->request, &context->output));
}

/*
** Rôle: extreme_check — Vérifie extreme en contrôlant ses préconditions, ses
**       bornes et les invariants nécessaires avant toute utilisation
**       ultérieure.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> ped_to_uped().
** Appelants: test_hunt_extreme_verify().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_extreme_support.c -> extreme_check() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	extreme_check(const t_test_hunt_extreme_context *context)
{
	ASSERT_I64_EQ(context->output.count, 1);
	ASSERT_I64_EQ(context->groups[0], 5000);
	ASSERT_I64_EQ(context->kill_ids[0], 1);
	ASSERT_I64_EQ(ped_to_uped(context->values[0]), (int64_t)(5000 * 1000));
	return (0);
}

/*
** Rôle: test_hunt_extreme_verify — Vérifie extreme en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> extreme_build(), extreme_check().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_extreme_support.c -> test_hunt_extreme_verify() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), free(), memset().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_extreme_verify(const char *path)
{
	t_test_hunt_extreme_context	context;

	memset(&context, 0, sizeof(context));
	ASSERT_TRUE(extreme_build(&context, path));
	ASSERT_I64_EQ(extreme_check(&context), 0);
	free(context.series);
	return (0);
}
