/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_csv_persistence_file_support.c                :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_csv_persistence_support.h"

#include "common/string_operations.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: copy_stream — Copie stream.
** Paramètre: in — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: out — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : in,
**         out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_csv_file_copy().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_file_support.c -> copy_stream() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fread(), fwrite().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fread(), fwrite().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	copy_stream(FILE *in, FILE *out)
{
	char	buf[8192];
	size_t	n;

	n = fread(buf, 1, sizeof(buf), in);
	while (n > 0)
	{
		if (fwrite(buf, 1, n, out) != n)
			return (0);
		if (n < sizeof(buf))
			return (1);
		n = fread(buf, 1, sizeof(buf), in);
	}
	return (1);
}

/*
** Rôle: test_csv_file_copy — Copie l’état associé à test CSV fichier.
** Paramètre: src — source consultée pour produire le résultat sans en
**            modifier la signification.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> copy_stream().
** Appelants: test_csv_rewrite_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_file_support.c -> test_csv_file_copy() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_csv_file_copy(const char *src, const char *dst)
{
	FILE	*in;
	FILE	*out;
	int		ok;

	if (!src || !dst)
		return (-1);
	in = fopen(src, "rb");
	if (!in)
		return (-1);
	out = fopen(dst, "wb");
	if (!out)
		return (fclose(in), -1);
	ok = copy_stream(in, out);
	fclose(out);
	fclose(in);
	if (!ok)
		return (-1);
	return (0);
}

/*
** Rôle: test_csv_read_first_line — Lit first ligne depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_trim_line_end().
** Appelants: test_csv_clear_roundtrip(), test_csv_money_migration(),
**            test_csv_rewrite_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_file_support.c -> test_csv_read_first_line()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fgets(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_csv_read_first_line(const char *path, char *out, size_t cap)
{
	FILE	*f;

	if (!path || !out || cap == 0)
		return (0);
	out[0] = '\0';
	f = fopen(path, "rb");
	if (!f)
		return (0);
	if (!fgets(out, (int)cap, f))
		return (fclose(f), 0);
	fclose(f);
	string_trim_line_end(out);
	return (1);
}

/*
** Rôle: test_csv_write_text_file — Écrit texte vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_csv_clear_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_file_support.c -> test_csv_write_text_file()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fwrite(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fwrite().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_csv_write_text_file(const char *path, const char *text)
{
	FILE	*f;

	if (!path)
		return (-1);
	f = fopen(path, "wb");
	if (!f)
		return (-1);
	if (text && text[0])
		fwrite(text, 1, strlen(text), f);
	fclose(f);
	return (0);
}

/*
** Rôle: test_csv_write_legacy — Écrit legacy vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_csv_legacy_rewrite(), test_csv_money_migration().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_file_support.c -> test_csv_write_legacy()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_csv_write_legacy(const char *path)
{
	FILE	*f;

	f = fopen(path, "wb");
	if (!f)
		return (-1);
	fprintf(f, "timestamp_unix;event_type;target_or_item;qty;value_uPED;raw\n");
	fprintf(f, "1700000000;LOOT_ITEM;Animal Oil Residue;2;200;raw\n");
	fprintf(f, "1700000001;KILL;Exarosaur;1;0;42;raw kill\n");
	return (fclose(f), 0);
}
