/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_manager_capital_support.c                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_fin_manager_capital_support.h"
#include "test_fin_manager_seed_support.h"
#include "finance/finance_capital.h"
#include "finance/finance_equipment.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: check_equipment_events — Vérifie équipement événements.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_equipment_enhancer_break(),
**            finance_equipment_repair(), test_fin_manager_amount().
** Appelants: test_fin_manager_check_capital().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_manager_capital_support.c -> check_equipment_events()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_equipment_events(t_finance_book *book)
{
	t_finance_enhancer_break_input	broken;

	if (!finance_equipment_repair(book, "Test Rifle",
			test_fin_manager_amount("1.00000"), 210))
		return (0);
	memset(&broken, 0, sizeof(broken));
	broken.timestamp = 220;
	snprintf(broken.equipment, sizeof(broken.equipment), "%s", "Test Rifle");
	snprintf(broken.enhancer, sizeof(broken.enhancer), "%s", "Damage Enhancer");
	broken.enhancer_tt_uPED = test_fin_manager_amount("0.10000");
	broken.acquisition_cost_uPED = test_fin_manager_amount("0.15000");
	return (finance_equipment_enhancer_break(book, &broken));
}

/*
** Rôle: check_capital_flow — Vérifie capital flow.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_deposit_record(),
**            finance_withdrawal_commit(), finance_withdrawal_request(),
**            test_fin_manager_amount().
** Appelants: test_fin_manager_check_capital().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_manager_capital_support.c -> check_capital_flow() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_capital_flow(t_finance_book *book)
{
	t_finance_deposit	deposit;
	t_finance_withdrawal	withdrawal;
	size_t			index;

	memset(&deposit, 0, sizeof(deposit));
	deposit.timestamp = 300;
	snprintf(deposit.currency, sizeof(deposit.currency), "%s", "EUR");
	deposit.ped_credited_uPED = test_fin_manager_amount("500.00000");
	deposit.mode = FIN_DEPOSIT_ACTUAL_PED;
	if (!finance_deposit_record(book, &deposit, &index))
		return (0);
	memset(&withdrawal, 0, sizeof(withdrawal));
	withdrawal.requested_at = 400;
	withdrawal.requested_uPED = test_fin_manager_amount("1000.00000");
	if (!finance_withdrawal_request(book, &withdrawal, &index))
		return (0);
	return (finance_withdrawal_commit(book, index, 410));
}

/*
** Rôle: test_fin_manager_check_capital — Vérifie fin manager capital en
**       contrôlant ses préconditions, ses bornes et les invariants
**       nécessaires avant toute utilisation ultérieure.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_capital_flow(),
**            check_equipment_events().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_manager_capital_support.c ->
**        test_fin_manager_check_capital() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_manager_check_capital(t_finance_book *book)
{
	return (check_equipment_events(book) && check_capital_flow(book));
}
