/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_xlsx_recipe_support.h                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_FIN_XLSX_RECIPE_SUPPORT_H
# define TEST_FIN_XLSX_RECIPE_SUPPORT_H

# include "finance/finance_recipe.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_xlsx_build_recipe — Construit fin xlsx recette à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_xlsx_build_recipe().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_xlsx_build_recipe(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_fin_xlsx_build_recipe(t_finance_recipe *recipe);

#endif
