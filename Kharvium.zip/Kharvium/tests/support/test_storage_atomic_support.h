/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_storage_atomic_support.h                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_STORAGE_ATOMIC_SUPPORT_H
# define TEST_STORAGE_ATOMIC_SUPPORT_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_storage_write_temp — Écrit temp vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_storage_write_temp().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_storage_write_temp(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_storage_write_temp(const char *path, const char *text);

#endif
