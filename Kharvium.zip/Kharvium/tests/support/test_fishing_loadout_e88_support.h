/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_loadout_e88_support.h                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_FISHING_LOADOUT_E88_SUPPORT_H
# define TEST_FISHING_LOADOUT_E88_SUPPORT_H

# include "catalog/catalog_loader.h"
# include "fishing/fishing_loadout.h"

int	test_e88_load_catalog(t_catalog_registry *registry);
int	test_e88_build_measured_loadout(t_fishing_loadout_snapshot *snapshot,
		const t_catalog_registry *registry);

#endif
