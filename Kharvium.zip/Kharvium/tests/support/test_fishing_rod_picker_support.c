/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_rod_picker_support.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_fishing_rod_config_support.h"
#include "../test_util.h"
#include <string.h>

/*
** Rôle: test_fishing_rod_direct_picker — Vérifie que le picker E107 expose
**       une seule ligne par vraie canne et conserve un montage par défaut.
** Retour: 0 si les 23 Rods et le défaut SET-FR1 sont corrects, 1 sinon.
** Effets: charge puis libère les catalogues de test packagés.
** Invariants: SET-FR1 est unique et son défaut reste le montage River.
** Relations: test_fishing_rod_load_config(),
**            fishing_rod_database_collect_default_rods(),
**            fishing_rod_database_default_for_rod().
** Appelants: test_fishing_rod_config.c -> main().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_rod_direct_picker().
** Dépendances: fishing_rods.ini packagé E107.
** Mémoire: tableau fixe; allocations de config libérées avant retour.
** État partagé: aucun.
** Concurrence: test mono-thread.
** I/O: lecture des catalogues locaux packagés.
** Unités: nombre de cannes.
** Performance: O(nombre de presets).
** Portabilité: C99 Windows/Linux.
*/
int	test_fishing_rod_direct_picker(void)
{
	t_catalog_registry		registry;
	t_fishing_rod_database		database;
	const t_fishing_rod_preset	*rods[32];
	const t_fishing_rod_preset	*preset;
	size_t				count;

	ASSERT_TRUE(test_fishing_rod_load_config(&registry, &database));
	count = fishing_rod_database_collect_default_rods(&database, rods, 32);
	ASSERT_I64_EQ(count, 23);
	ASSERT_TRUE(strcmp(rods[0]->rod_name, "Baitfishing Rod") == 0);
	preset = fishing_rod_database_default_for_rod(&database,
			"SET-FR1 Angling Rod (L)");
	ASSERT_TRUE(preset != NULL);
	ASSERT_TRUE(strcmp(preset->name, "SET-FR1 Angling - River") == 0);
	test_fishing_rod_cleanup_config(&registry, &database);
	return (0);
}
