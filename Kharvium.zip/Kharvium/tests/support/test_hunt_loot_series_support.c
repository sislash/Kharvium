/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_loot_series_support.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_hunt_loot_group_support.h"
#include "../test_util.h"

#include <stdlib.h>
#include <string.h>

/*
** Rôle: setup_output — Configure output.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_hunt_loot_context_init().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_series_support.c -> setup_output() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	setup_output(t_test_hunt_loot_context *ctx)
{
	ctx->request.series = ctx->series;
	ctx->request.last_minutes = 0;
	ctx->request.cumulative = 0;
	ctx->output.values = ctx->values;
	ctx->output.x_seconds = ctx->x;
	ctx->output.group_counts = ctx->group_counts;
	ctx->output.kill_ids = ctx->kill_ids;
	ctx->output.has_kill = ctx->has_kill;
}

/*
** Rôle: test_hunt_loot_context_init — Initialise les données nécessaires à
**       test chasse loot context.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_build_loot(),
**            hunt_series_rebuild_range(), hunt_series_reset(),
**            hunt_series_sanity_check(), setup_output().
** Appelants: test_hunt_loot_missing_kill_id(), test_hunt_loot_baseline().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_series_support.c -> test_hunt_loot_context_init()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> calloc(), free(), memset().
** Mémoire: opérations directes -> calloc(), free(); le transfert de
**          propriété reste défini par Retour/Effets et les contrats des
**          fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_loot_context_init(t_test_hunt_loot_context *ctx,
		const char *csv_path)
{
	t_hunt_series_range_request	range;

	memset(ctx, 0, sizeof(*ctx));
	ctx->series = (t_hunt_series *)calloc(1, sizeof(*ctx->series));
	if (!ctx->series)
		return (0);
	hunt_series_reset(ctx->series, 0, 60);
	range.csv_path = csv_path;
	range.start_line = 0;
	range.end_line = -1;
	range.bucket_sec = 60;
	if (!hunt_series_rebuild_range(ctx->series, &range)
		|| !hunt_series_sanity_check(ctx->series))
		return (free(ctx->series), ctx->series = NULL, 0);
	setup_output(ctx);
	return (hunt_series_build_loot(&ctx->request, &ctx->output));
}

/*
** Rôle: check_baseline_values — Vérifie baseline valeurs.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_hunt_loot_baseline().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_series_support.c -> check_baseline_values() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_baseline_values(t_test_hunt_loot_context *ctx)
{
	ASSERT_I64_EQ(ctx->output.count, 2);
	ASSERT_I64_EQ(ctx->group_counts[0], 2);
	ASSERT_I64_EQ(ctx->group_counts[1], 1);
	ASSERT_I64_EQ(ctx->kill_ids[0], 1);
	ASSERT_I64_EQ(ctx->kill_ids[1], 2);
	ASSERT_I64_EQ(ctx->has_kill[0], 1);
	ASSERT_I64_EQ(ctx->has_kill[1], 1);
	ASSERT_I64_EQ((long long)(ctx->values[0]
			* (double)MONEY_UPED_PER_PED + 0.5), 62500);
	ASSERT_I64_EQ((long long)(ctx->values[1]
			* (double)MONEY_UPED_PER_PED + 0.5), 10000);
	return (0);
}

/*
** Rôle: check_baseline_markers — Vérifie baseline markers.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_markers_build_loot().
** Appelants: test_hunt_loot_baseline().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_series_support.c -> check_baseline_markers() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_baseline_markers(t_test_hunt_loot_context *ctx)
{
	t_hunt_marker_build	build;

	memset(&build, 0, sizeof(build));
	build.loot_values = ctx->values;
	build.group_counts = ctx->group_counts;
	build.has_kill = ctx->has_kill;
	build.count = ctx->output.count;
	build.output = ctx->markers;
	build.output_capacity = 16;
	build.output_count = &ctx->marker_count;
	ASSERT_TRUE(hunt_markers_build_loot(&build));
	ASSERT_I64_EQ(ctx->marker_count, 4);
	ASSERT_I64_EQ(ctx->markers[0].kind, HUNT_MARKER_KILL);
	ASSERT_I64_EQ(ctx->markers[1].kind, HUNT_MARKER_LOOT);
	ASSERT_I64_EQ(ctx->markers[1].group_count, 2);
	ASSERT_I64_EQ(ctx->markers[2].kind, HUNT_MARKER_KILL);
	ASSERT_I64_EQ(ctx->markers[3].kind, HUNT_MARKER_LOOT);
	ASSERT_I64_EQ(ctx->markers[3].group_count, 1);
	return (0);
}

/*
** Rôle: test_hunt_loot_baseline — Calcule et retourne loot baseline à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_baseline_markers(),
**            check_baseline_values(), test_hunt_loot_context_init().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_series_support.c -> test_hunt_loot_baseline()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_loot_baseline(void)
{
	t_test_hunt_loot_context	ctx;

	ASSERT_TRUE(test_hunt_loot_context_init(
			&ctx, "tests/fixtures/baseline_hunt_log.csv"));
	ASSERT_I64_EQ(check_baseline_values(&ctx), 0);
	ASSERT_I64_EQ(check_baseline_markers(&ctx), 0);
	free(ctx.series);
	return (0);
}
