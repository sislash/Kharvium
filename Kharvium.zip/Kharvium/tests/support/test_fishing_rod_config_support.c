/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_rod_config_support.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_fishing_rod_config_support.h"
#include "test_fishing_loadout_e88_support.h"
#include "../test_util.h"
#include <stdio.h>
#include <string.h>

#define TMP_INI "tests/.tmp_fishing_rods.ini"

/*
** Rôle: test_fishing_rod_load_config — Charge les catalogues Fishing
**       packagés puis
**       fishing_rods.ini pour les tests d'intégration E90.
** Retour: 1 si catalogue et INI chargent, 0 sinon.
** Effets: remplit registry et database appartenant à l'appelant.
** Invariants: aucun réseau ni prix marché n'intervient dans la fixture.
** Relations: catalog_registry_initialize(), test_e88_load_catalog(),
**            fishing_rod_database_load().
** Appelants: check_packaged_loadout(), check_roundtrip().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_rod_load_config().
** Dépendances: catalogues locaux E88 et nouveau chargeur INI.
** Mémoire: allocations détenues par registry/database jusqu'au cleanup.
** État partagé: aucun.
** Concurrence: tests mono-thread.
** I/O: CSV et INI packagés.
** Unités: noms/IDs canoniques.
** Performance: linéaire sur les petits fichiers de fixture.
** Portabilité: C99 Windows/Linux.
*/
int	test_fishing_rod_load_config(t_catalog_registry *registry,
	t_fishing_rod_database *database)
{
	catalog_registry_initialize(registry);
	memset(database, 0, sizeof(*database));
	if (!test_e88_load_catalog(registry))
		return (0);
	return (fishing_rod_database_load(database, "fishing_rods.ini", registry));
}

/*
** Rôle: test_fishing_rod_cleanup_config — Libère les deux propriétaires
**       dynamiques
**       créés par test_fishing_rod_load_config().
** Retour: aucun.
** Effets: libère base INI puis registres catalogues.
** Invariants: peut être appelé après un chargement réussi.
** Relations: fishing_rod_database_free(), catalog_registry_destroy().
** Appelants: check_packaged_loadout(), check_roundtrip().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_rod_cleanup_config().
** Dépendances: destructeurs des modules testés.
** Mémoire: libère toutes les allocations détenues par les deux structures.
** État partagé: aucun.
** Concurrence: tests mono-thread.
** I/O: aucune.
** Unités: aucune.
** Performance: O(nombre d'entrées allouées).
** Portabilité: C99 Windows/Linux.
*/
void	test_fishing_rod_cleanup_config(t_catalog_registry *registry,
	t_fishing_rod_database *database)
{
	fishing_rod_database_free(database);
	catalog_registry_destroy(registry);
}

/*
** Rôle: test_fishing_rod_check_snapshot — Vérifie que le preset SET-FR1
**       installe bien
**       les cinq composants et l'ammo attendus dans le snapshot runtime.
** Retour: 0 si tous les IDs/stats sont exacts, 1 via ASSERT sinon.
** Effets: aucun.
** Invariants: l'ordre components reste Rod/Reel/Blank/Line/Lure.
** Relations: macros ASSERT de la suite de tests.
** Appelants: check_packaged_loadout().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_rod_check_snapshot().
** Dépendances: modèle t_fishing_loadout_snapshot E88.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: IDs, stats x100 et cm.
** Performance: O(1).
** Portabilité: C99.
*/
int	test_fishing_rod_check_snapshot(const t_fishing_loadout_snapshot *snapshot)
{
	ASSERT_I64_EQ(snapshot->components[0].item_type_id, 1301);
	ASSERT_I64_EQ(snapshot->components[1].item_type_id, 1311);
	ASSERT_I64_EQ(snapshot->components[2].item_type_id, 1321);
	ASSERT_I64_EQ(snapshot->components[3].item_type_id, 1331);
	ASSERT_I64_EQ(snapshot->components[4].item_type_id, 1341);
	ASSERT_I64_EQ(snapshot->ammo.item_type_id, 1007);
	ASSERT_I64_EQ(snapshot->stats.strength_x100, 700);
	ASSERT_I64_EQ(snapshot->stats.flexibility_x100, 700);
	ASSERT_I64_EQ(snapshot->stats.reel_strength_x100, 1500);
	ASSERT_I64_EQ(snapshot->stats.reel_speed_x100, 300);
	ASSERT_I64_EQ(snapshot->stats.line_length_cm, 6000);
	ASSERT_I64_EQ(snapshot->stats.lure_depth_cm, 1500);
	return (0);
}

/*
** Rôle: test_fishing_rod_write_invalid_ini — Crée un preset volontairement
**       invalide selon le
**       mode demandé pour tester les garde-fous de slot/ammo/complétude.
** Retour: 1 si la fixture est écrite, 0 sinon.
** Effets: remplace TMP_INI.
** Invariants: mode 0 omet Lure; mode 1 met une Line en Reel; mode 2
**             utilise une ammo non Fishing.
** Relations: fopen(), fprintf(), fclose().
** Appelants: check_invalid_presets().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_rod_write_invalid_ini().
** Dépendances: stdio C.
** Mémoire: aucune.
** État partagé: fichier temporaire unique du test.
** Concurrence: test mono-thread.
** I/O: écriture fixture INI.
** Unités: aucune.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	test_fishing_rod_write_invalid_ini(int mode)
{
	FILE	*file;

	file = fopen(TMP_INI, "wb");
	if (!file)
		return (0);
	fprintf(file, "[LOADOUT:Bad]\nrod=SET-FR1 Angling Rod (L)\n");
	if (mode == 1)
		fprintf(file, "reel=SL-100x Fishing Line (L)\n");
	else
		fprintf(file, "reel=Adu Darcia SpinReeler A-05 (L)\n");
	fprintf(file, "blank=Adu Darcia Ultralight Fishing Blank C-01 (L)\n");
	fprintf(file, "line=SL-100x Fishing Line (L)\n");
	if (mode != 0)
		fprintf(file, "lure=Teal \"Caly River\" Spinner (L)\n");
	if (mode == 2)
		fprintf(file, "ammo=Universal Ammo\n");
	else
		fprintf(file, "ammo=Spool Cell\n");
	return (fclose(file) == 0);
}

/*
** Rôle: test_fishing_rod_invalid_rejected — Charge une fixture invalide et
**       vérifie le
**       rollback transactionnel complet de la base.
** Retour: 0 si le mode est rejeté sans entrée partielle, 1 sinon.
** Effets: crée/supprime TMP_INI et alloue temporairement des catalogues.
** Invariants: database.count vaut zéro après l'échec du chargeur.
** Relations: test_fishing_rod_write_invalid_ini(), test_e88_load_catalog(),
**            fishing_rod_database_load(), test_fishing_rod_cleanup_config().
** Appelants: check_invalid_presets().
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_rod_invalid_rejected().
** Dépendances: validateur INI Fishing.
** Mémoire: toutes les allocations sont libérées.
** État partagé: fichier de test temporaire.
** Concurrence: mono-thread.
** I/O: CSV locaux et TMP_INI.
** Unités: nombre de presets.
** Performance: linéaire sur petit fixture.
** Portabilité: C99 Windows/Linux.
*/
int	test_fishing_rod_invalid_rejected(int mode)
{
	t_catalog_registry	registry;
	t_fishing_rod_database	database;

	ASSERT_TRUE(test_fishing_rod_write_invalid_ini(mode));
	catalog_registry_initialize(&registry);
	memset(&database, 0, sizeof(database));
	ASSERT_TRUE(test_e88_load_catalog(&registry));
	ASSERT_TRUE(!fishing_rod_database_load(&database, TMP_INI, &registry));
	ASSERT_I64_EQ(database.count, 0);
	test_fishing_rod_cleanup_config(&registry, &database);
	(void)remove(TMP_INI);
	return (0);
}
