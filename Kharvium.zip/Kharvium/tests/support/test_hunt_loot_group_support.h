/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_loot_group_support.h                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_HUNT_LOOT_GROUP_SUPPORT_H
# define TEST_HUNT_LOOT_GROUP_SUPPORT_H

# include "hunt/hunt_series.h"
# include "hunt/hunt_markers.h"

typedef struct s_test_hunt_loot_context
{
	t_hunt_series			*series;
	t_hunt_series_loot_request	request;
	t_hunt_series_output		output;
	double				values[HS_MAX_POINTS];
	int				x[HS_MAX_POINTS];
	int				group_counts[HS_MAX_POINTS];
	int64_t				kill_ids[HS_MAX_POINTS];
	unsigned char			has_kill[HS_MAX_POINTS];
	t_hunt_marker			markers[16];
	int				marker_count;
} t_test_hunt_loot_context;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_loot_context_init — Initialise les données nécessaires à
**       test chasse loot context.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_loot_context_init().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_loot_context_init(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_loot_context_init(t_test_hunt_loot_context *ctx,
		const char *csv_path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_loot_baseline — Met à jour loot baseline en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_loot_baseline().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_loot_baseline(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_loot_baseline(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_loot_missing_kill_id — Met à jour loot missing kill id en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement une gestion de mémoire dynamique; effectue
**         directement des E/S fichier ou une modification de chemin.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_loot_missing_kill_id().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_loot_missing_kill_id(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_loot_missing_kill_id(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_loot_envelope_details — Met à jour loot enveloppe details
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_loot_envelope_details().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_loot_envelope_details(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_loot_envelope_details(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_loot_unvalued_items — Construit ou traite les objets
**       appartenant à test chasse loot unvalued.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_loot_unvalued_items().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_loot_unvalued_items(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_loot_unvalued_items(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_loot_marker_format — Formate l’état associé à test chasse
**       loot marker.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_loot_marker_format().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_loot_marker_format(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_loot_marker_format(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_loot_write_missing — Écrit loot missing vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_loot_write_missing().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_loot_write_missing(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_loot_write_missing(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_loot_write_partial — Écrit loot partial vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_loot_write_partial().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_loot_write_partial(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_loot_write_partial(const char *path);

#endif
