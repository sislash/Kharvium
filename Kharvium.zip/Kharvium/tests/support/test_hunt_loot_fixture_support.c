/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_loot_fixture_support.c                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_hunt_loot_group_support.h"
#include "../test_util.h"

#include "io/hunt_csv.h"

#include <stdio.h>

static const t_hunt_csv_row_view	g_missing_rows[] = {
	{.timestamp_unix = 1700000000, .type_evenement = "KILL",
		.cible = "Exarosaur", .quantite = 1, .valeur_uPED = 0,
		.a_valeur = 0, .id_kill = 42, .drapeaux = 2u, .brut = "raw kill"},
	{.timestamp_unix = 1700000000, .type_evenement = "LOOT_ITEM",
		.cible = "Animal Oil Residue", .quantite = 2, .valeur_uPED = 10000,
		.a_valeur = 1, .id_kill = 0, .drapeaux = 3u, .brut = "raw loot a"},
	{.timestamp_unix = 1700000000, .type_evenement = "LOOT_ITEM",
		.cible = "Muscle Oil", .quantite = 1, .valeur_uPED = 20000,
		.a_valeur = 1, .id_kill = 0, .drapeaux = 3u, .brut = "raw loot b"}
};

static const t_hunt_csv_row_view	g_partial_rows[] = {
	{.timestamp_unix = 1700000100, .type_evenement = "KILL",
		.cible = "Berycled", .quantite = 1, .valeur_uPED = 0,
		.a_valeur = 0, .id_kill = 7, .drapeaux = 2u, .brut = "raw kill"},
	{.timestamp_unix = 1700000100, .type_evenement = "LOOT_ITEM",
		.cible = "Animal Oil Residue", .quantite = 2, .valeur_uPED = 15000,
		.a_valeur = 1, .id_kill = 7, .drapeaux = 3u, .brut = "raw loot a"},
	{.timestamp_unix = 1700000101, .type_evenement = "LOOT_ITEM",
		.cible = "Unknown Fragment", .quantite = 1, .valeur_uPED = 0,
		.a_valeur = 0, .id_kill = 7, .drapeaux = 2u, .brut = "raw loot b"}
};
/*
** Rôle: write_rows — Écrit lignes.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: rows — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_ensure_header_v2(),
**            hunt_csv_write_v2().
** Appelants: test_hunt_loot_write_missing(), test_hunt_loot_write_partial(),
**            main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_fixture_support.c -> write_rows() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	write_rows(const char *path, const t_hunt_csv_row_view *rows,
		int count)
{
	FILE	*f;
	int		i;

	f = fopen(path, "wb");
	if (!f)
		return (-1);
	hunt_csv_ensure_header_v2(f);
	i = 0;
	while (i < count)
	{
		if (hunt_csv_write_v2(f, &rows[i]) != 0)
			return (fclose(f), -1);
		i++;
	}
	return (fclose(f), 0);
}

/*
** Rôle: test_hunt_loot_write_missing — Écrit loot missing vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> write_rows().
** Appelants: test_hunt_loot_missing_kill_id().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_fixture_support.c -> test_hunt_loot_write_missing()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_missing_rows.
** Concurrence: état global mutable détecté (g_missing_rows); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_loot_write_missing(const char *path)
{
	return (write_rows(path, g_missing_rows,
			(int)(sizeof(g_missing_rows) / sizeof(g_missing_rows[0]))));
}

/*
** Rôle: test_hunt_loot_write_partial — Écrit loot partial vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> write_rows().
** Appelants: test_hunt_loot_unvalued_items().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_fixture_support.c -> test_hunt_loot_write_partial()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_partial_rows.
** Concurrence: état global mutable détecté (g_partial_rows); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_loot_write_partial(const char *path)
{
	return (write_rows(path, g_partial_rows,
			(int)(sizeof(g_partial_rows) / sizeof(g_partial_rows[0]))));
}
