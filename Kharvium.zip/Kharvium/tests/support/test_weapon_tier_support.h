/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_weapon_tier_support.h                         +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_WEAPON_TIER_SUPPORT_H
# define TEST_WEAPON_TIER_SUPPORT_H

# include "config/weapon_config.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_weapon_write_profile — Écrit profile vers la destination prévue
**       en respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_weapon_write_profile().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_weapon_write_profile(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_weapon_write_profile(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_weapon_check_finance_bridge — Vérifie bridge en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: database — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : database.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_weapon_check_finance_bridge().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_weapon_check_finance_bridge(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_weapon_check_finance_bridge(t_weapon_database *database);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_weapon_check_database — Vérifie database en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: database — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_weapon_check_database().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_weapon_check_database(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_weapon_check_database(const t_weapon_database *database);

#endif
