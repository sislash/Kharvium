/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_eviction_support.c                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_hunt_eviction_support.h"
#include "../test_util.h"
#include "hunt/hunt_series.h"
#include "io/hunt_csv.h"

#include <stdio.h>
#include <stdlib.h>

static const t_hunt_csv_row_view	g_eviction_rows[] = {
	{.type_evenement = "KILL", .cible = "Mob", .quantite = 1,
		.valeur_uPED = 0, .a_valeur = 0, .drapeaux = 2u,
		.brut = "You killed Mob."},
	{.type_evenement = "LOOT_ITEM", .cible = "Animal Oil Residue",
		.quantite = 1, .valeur_uPED = 1, .a_valeur = 1, .drapeaux = 3u,
		.brut = "You received Animal Oil Residue"}
};

/*
** Rôle: test_hunt_eviction_write — Écrit l’état associé à test chasse
**       eviction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: total — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_ensure_header_v2(),
**            hunt_csv_write_v2().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_eviction_support.c -> test_hunt_eviction_write() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), fclose(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_eviction_rows.
** Concurrence: état global mutable détecté (g_eviction_rows);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_eviction_write(const char *path, int total)
{
	FILE			*stream;
	t_hunt_csv_row_view	row;
	int			index;

	stream = fopen(path, "wb");
	ASSERT_TRUE(stream != NULL);
	hunt_csv_ensure_header_v2(stream);
	index = 0;
	while (index < total)
	{
		row = g_eviction_rows[0];
		row.timestamp_unix = 1700000000LL + index;
		row.id_kill = index + 1;
		ASSERT_I64_EQ(hunt_csv_write_v2(stream, &row), 0);
		row = g_eviction_rows[1];
		row.timestamp_unix = 1700000000LL + index;
		row.id_kill = index + 1;
		ASSERT_I64_EQ(hunt_csv_write_v2(stream, &row), 0);
		index++;
	}
	return (fclose(stream));
}
/*
** Rôle: assert_contiguous — Calcule et retourne assert contiguous à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: seconds — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: verify_event_windows().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_eviction_support.c -> assert_contiguous() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	assert_contiguous(const int *seconds, int count)
{
	int	index;

	if (!seconds || count <= 1)
		return (0);
	index = 1;
	while (index < count)
	{
		ASSERT_I64_EQ(seconds[index], seconds[index - 1] + 1);
		index++;
	}
	return (0);
}

/*
** Rôle: verify_event_windows — Vérifie événement Win32.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: total — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> assert_contiguous().
** Appelants: test_hunt_eviction_verify().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_eviction_support.c -> verify_event_windows() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	verify_event_windows(t_hunt_series *series, int total)
{
	int	first_second;
	int	last_second;
	int64_t	first_kill;
	int64_t	last_kill;

	ASSERT_TRUE(series->kill_ev_count > 0 && series->loot_ev_count > 0);
	ASSERT_TRUE(series->kill_ev_count <= HS_MAX_EVENTS);
	ASSERT_TRUE(series->loot_ev_count <= HS_MAX_EVENTS);
	last_second = series->kill_ev_sec[series->kill_ev_count - 1];
	ASSERT_I64_EQ(last_second, total - 1);
	ASSERT_I64_EQ(assert_contiguous(series->kill_ev_sec,
			series->kill_ev_count), 0);
	first_second = series->kill_ev_sec[0];
	ASSERT_I64_EQ(first_second, last_second - (series->kill_ev_count - 1));
	last_kill = series->loot_ev_kill_id[series->loot_ev_count - 1];
	first_kill = series->loot_ev_kill_id[0];
	ASSERT_I64_EQ(last_kill, (int64_t)total);
	ASSERT_I64_EQ(first_kill, (int64_t)(total - series->loot_ev_count + 1));
	return (assert_contiguous(series->loot_ev_sec, series->loot_ev_count));
}

/*
** Rôle: verify_loot_flags — Vérifie loot flags.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les accès indexés sont bornés avant lecture ou écriture; un
**             kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_hunt_eviction_verify().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_eviction_support.c -> verify_loot_flags() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	verify_loot_flags(const t_hunt_series *series)
{
	int	index;

	index = 0;
	while (index < series->loot_ev_count)
	{
		ASSERT_I64_EQ(series->loot_ev_group_count[index], 1);
		ASSERT_I64_EQ(series->loot_ev_has_kill[index], 1);
		index++;
	}
	return (0);
}

/*
** Rôle: test_hunt_eviction_verify — Vérifie eviction en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: total — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_rebuild_range(),
**            hunt_series_reset(), hunt_series_sanity_check(),
**            verify_event_windows(), verify_loot_flags().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_eviction_support.c -> test_hunt_eviction_verify() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), calloc(), free().
** Mémoire: opérations directes -> calloc(), free(); le transfert de
**          propriété reste défini par Retour/Effets et les contrats des
**          fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_eviction_verify(const char *path, int total)
{
	t_hunt_series			*series;
	t_hunt_series_range_request	range;

	series = (t_hunt_series *)calloc(1, sizeof(*series));
	ASSERT_TRUE(series != NULL);
	hunt_series_reset(series, 0, 60);
	range = (t_hunt_series_range_request){path, 0, -1, 60};
	ASSERT_TRUE(hunt_series_rebuild_range(series, &range));
	ASSERT_TRUE(hunt_series_sanity_check(series));
	ASSERT_I64_EQ(verify_event_windows(series, total), 0);
	ASSERT_I64_EQ(verify_loot_flags(series), 0);
	free(series);
	return (0);
}
