/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_chart_support.c                          +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_hunt_chart_support.h"

/*
** Rôle: test_hunt_chart_build_metric — Construit graphique metric à partir
**       des paramètres fournis et initialise tous les champs requis avant
**       qu’ils soient lus par une autre opération.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: metric — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: range_minutes — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : series, output.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_chart_build_data().
** Appelants: check_loot_modes(), check_range_filter().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_chart_support.c -> test_hunt_chart_build_metric() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_chart_build_metric(t_hunt_series *series,
		t_hunt_chart_metric metric, int range_minutes,
		t_hunt_chart_output *output)
{
	t_hunt_chart_request	request;

	request.series = series;
	request.stats = NULL;
	request.metric = metric;
	request.range_minutes = range_minutes;
	return (hunt_chart_build_data(&request, output));
}
