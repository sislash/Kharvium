/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_activity_support.h                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_FIN_ACTIVITY_SUPPORT_H
# define TEST_FIN_ACTIVITY_SUPPORT_H

# include "finance/finance_activity.h"
# include "finance/finance_book.h"

# include "common/money.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_activity_amount — Met à jour fin activité montant en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_activity_amount().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_activity_amount(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	test_fin_activity_amount(const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_activity_add_price — Ajoute fin activité prix dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: tt — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: market — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_activity_add_price().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_activity_add_price(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		test_fin_activity_add_price(t_finance_book *book, const char *name,
			const char *tt, const char *market);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_activity_seed_stock — Met à jour fin activité seed stock en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_activity_seed_stock().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_activity_seed_stock(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		test_fin_activity_seed_stock(t_finance_book *book);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_activity_seed_equipment — Met à jour fin activité seed
**       équipement en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_activity_seed_equipment().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_activity_seed_equipment(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		test_fin_activity_seed_equipment(t_finance_book *book);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_activity_build_run — Exécute l’état associé à test fin
**       activité build.
** Paramètre: run — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Paramètre: target — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: location — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : run.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_activity_build_run().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_activity_build_run(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		test_fin_activity_build_run(t_finance_activity *run, int64_t timestamp,
			const char *target, const char *location);

#endif
