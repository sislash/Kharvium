/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_manager_seed_support.c                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_fin_manager_seed_support.h"
#include "finance/finance_recipe.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: test_fin_manager_amount — Formate fin manager montant dans le buffer
**       destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: check_capital_flow(), check_equipment_events(),
**            test_fin_manager_add_price(), test_fin_manager_seed_stock(),
**            check_activity(), check_production() (+2; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_manager_seed_support.c -> test_fin_manager_amount()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_money	test_fin_manager_amount(const char *text)
{
	t_money	value;

	value = 0;
	if (!money_parse_ped(text, &value))
		return (0);
	return (value);
}

/*
** Rôle: test_fin_manager_add_price — Ajoute fin manager prix dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: tt — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: market — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_add_price(),
**            test_fin_manager_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_manager_seed_support.c -> test_fin_manager_add_price()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_manager_add_price(t_finance_book *book, const char *name,
		const char *tt, const char *market)
{
	t_finance_price	value;

	memset(&value, 0, sizeof(value));
	snprintf(value.name, sizeof(value.name), "%s", name);
	value.tt_unit_uPED = test_fin_manager_amount(tt);
	value.market_mode = FIN_MARKET_UNIT;
	value.market_unit_uPED = test_fin_manager_amount(market);
	return (finance_book_add_price(book, &value));
}

/*
** Rôle: test_fin_manager_seed_stock — Formate fin manager seed stock dans le
**       buffer destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_stock_add(),
**            test_fin_manager_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_manager_seed_support.c -> test_fin_manager_seed_stock()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_manager_seed_stock(t_finance_book *book)
{
	t_finance_stock	stock;

	memset(&stock, 0, sizeof(stock));
	snprintf(stock.item, sizeof(stock.item), "%s", "Component A");
	stock.quantity = 10;
	stock.cost_known = 1;
	stock.cost_total_uPED = test_fin_manager_amount("15.00000");
	stock.tt_unit_uPED = test_fin_manager_amount("1.00000");
	return (finance_book_stock_add(book, &stock));
}

/*
** Rôle: test_fin_manager_add_recipe — Ajoute fin manager recette dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_add_recipe(),
**            finance_recipe_add_item(), finance_recipe_add_stage(),
**            finance_recipe_initialize().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_manager_seed_support.c -> test_fin_manager_add_recipe()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_manager_add_recipe(t_finance_book *book)
{
	t_finance_recipe_setup	setup;
	t_finance_recipe_item	item;
	t_finance_recipe	recipe;

	memset(&setup, 0, sizeof(setup));
	setup.name = "Simple Craft";
	setup.kind = FIN_RECIPE_CRAFT;
	setup.product_item = "Craft Output";
	setup.reference_output_quantity = 4;
	if (!finance_recipe_initialize(&recipe, &setup)
		|| !finance_recipe_add_stage(&recipe, "Stage 1"))
		return (0);
	memset(&item, 0, sizeof(item));
	snprintf(item.name, sizeof(item.name), "%s", "Component A");
	item.quantity = 2;
	if (!finance_recipe_add_item(&recipe, 0, &item))
		return (0);
	return (finance_book_add_recipe(book, &recipe));
}
