/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_xlsx_seed_support.c                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_fin_xlsx_seed_support.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: test_fin_xlsx_amount — Formate fin xlsx montant dans le buffer
**       destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: add_fertilizer(), add_fruit(), add_price(),
**            check_recipe_quote(), check_repayment_projection(),
**            check_stage_costs().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_xlsx_seed_support.c -> test_fin_xlsx_amount() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_money	test_fin_xlsx_amount(const char *text)
{
	t_money	value;

	value = 0;
	if (!money_parse_ped(text, &value))
		return (0);
	return (value);
}

/*
** Rôle: add_price — Ajoute prix.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: tt — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: markup — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_add_price(),
**            test_fin_xlsx_amount().
** Appelants: test_fin_xlsx_add_reference_prices().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_xlsx_seed_support.c -> add_price() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	add_price(t_finance_book *book, const char *name,
		const char *tt, int64_t markup)
{
	t_finance_price	price;

	memset(&price, 0, sizeof(price));
	snprintf(price.name, sizeof(price.name), "%s", name);
	price.kind = FIN_PRICE_COMPONENT;
	price.market_mode = FIN_MARKET_PERCENT;
	price.tt_unit_uPED = test_fin_xlsx_amount(tt);
	price.markup_mul_1e4 = markup;
	return (finance_book_add_price(book, &price));
}

/*
** Rôle: add_fertilizer — Ajoute fertilizer.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_add_price(),
**            test_fin_xlsx_amount().
** Appelants: test_fin_xlsx_add_reference_prices().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_xlsx_seed_support.c -> add_fertilizer() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	add_fertilizer(t_finance_book *book)
{
	t_finance_price	price;

	memset(&price, 0, sizeof(price));
	snprintf(price.name, sizeof(price.name), "%s", "Basic Fertilizer");
	price.kind = FIN_PRICE_COMPONENT;
	price.market_mode = FIN_MARKET_UNIT;
	price.tt_unit_uPED = test_fin_xlsx_amount("0.0200");
	price.market_value_uPED = 0;
	price.craft_unit_uPED = test_fin_xlsx_amount("0.0201");
	return (finance_book_add_price(book, &price));
}

/*
** Rôle: add_fruit — Ajoute fruit.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_add_price(),
**            test_fin_xlsx_amount().
** Appelants: test_fin_xlsx_add_reference_prices().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_xlsx_seed_support.c -> add_fruit() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	add_fruit(t_finance_book *book)
{
	t_finance_price	price;

	memset(&price, 0, sizeof(price));
	snprintf(price.name, sizeof(price.name), "%s", "Bombardo Transgen");
	price.kind = FIN_PRICE_FRUIT;
	price.market_mode = FIN_MARKET_UNIT;
	price.tt_unit_uPED = test_fin_xlsx_amount("0.0001");
	price.market_unit_uPED = test_fin_xlsx_amount("17.0000");
	return (finance_book_add_price(book, &price));
}

/*
** Rôle: test_fin_xlsx_add_reference_prices — Ajoute fin xlsx référence prix
**       dans la collection concernée en respectant sa capacité, son ordre
**       logique et la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> add_fertilizer(), add_fruit(),
**            add_price().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_xlsx_seed_support.c ->
**        test_fin_xlsx_add_reference_prices() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_xlsx_add_reference_prices(t_finance_book *book)
{
	if (!add_fertilizer(book))
		return (0);
	if (!add_price(book, "Dianthus Crystal", "0.6000", 18639))
		return (0);
	if (!add_price(book, "Light Liquid", "0.8400", 20107))
		return (0);
	if (!add_price(book, "Energized Crystal Cell", "0.6000", 10255))
		return (0);
	if (!add_price(book, "DNA Fragment A", "1.0000", 34828))
		return (0);
	if (!add_price(book, "DNA Fragment B", "2.0000", 119730))
		return (0);
	if (!add_price(book, "DNA Fragment C", "2.5600", 62394))
		return (0);
	if (!add_price(book, "DNA Fragment D", "3.1500", 82540))
		return (0);
	return (add_fruit(book));
}
