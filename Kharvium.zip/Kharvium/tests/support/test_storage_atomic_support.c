/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_storage_atomic_support.c                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_storage_atomic_support.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: test_storage_write_temp — Écrit temp vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_commit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_storage_atomic_support.c -> test_storage_write_temp() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fwrite(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fwrite().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_storage_write_temp(const char *path, const char *text)
{
	FILE	*stream;

	stream = fopen(path, "wb");
	if (!stream)
		return (0);
	if (text && text[0])
		fwrite(text, 1, strlen(text), stream);
	return (fclose(stream) == 0);
}
