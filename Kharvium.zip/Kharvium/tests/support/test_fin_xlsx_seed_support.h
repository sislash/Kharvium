/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_xlsx_seed_support.h                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_FIN_XLSX_SEED_SUPPORT_H
# define TEST_FIN_XLSX_SEED_SUPPORT_H

# include "finance/finance_book.h"
# include "common/money.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_xlsx_amount — Met à jour fin xlsx montant en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_xlsx_amount().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_xlsx_amount(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	test_fin_xlsx_amount(const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_xlsx_add_reference_prices — Ajoute fin xlsx référence prix
**       dans la collection concernée en respectant sa capacité, son ordre
**       logique et la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_xlsx_add_reference_prices().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_xlsx_add_reference_prices(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		test_fin_xlsx_add_reference_prices(t_finance_book *book);

#endif
