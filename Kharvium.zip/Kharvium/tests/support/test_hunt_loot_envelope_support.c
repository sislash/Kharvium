/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_loot_envelope_support.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_hunt_loot_group_support.h"
#include "../test_util.h"

#include "io/hunt_csv.h"
#include "platform/platform_file_system.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: test_hunt_loot_envelope_details — Formate loot enveloppe details dans
**       le buffer destination fourni, avec une taille explicitement bornée
**       par l’appelant.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_collect_loot_envelope().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_envelope_support.c ->
**        test_hunt_loot_envelope_details() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_STR_EQ(), ASSERT_TRUE(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_loot_envelope_details(void)
{
	t_hunt_csv_loot_envelope	envelope;
	t_hunt_csv_loot_line		items[8];

	memset(&envelope, 0, sizeof(envelope));
	memset(items, 0, sizeof(items));
	ASSERT_TRUE(hunt_csv_collect_loot_envelope(&(t_hunt_csv_loot_query){
			.csv_path = "tests/fixtures/baseline_hunt_log.csv",
			.timestamp_unix = 1700000001, .kill_id = 1,
			.lines = items, .line_capacity = 8}, &envelope));
	ASSERT_I64_EQ(envelope.kill_id, 1);
	ASSERT_STR_EQ(envelope.creature, "Daikiba Mature");
	ASSERT_I64_EQ(envelope.item_count, 2);
	ASSERT_I64_EQ(envelope.stored_item_count, 2);
	ASSERT_I64_EQ(envelope.total_uPED, 62500);
	ASSERT_I64_EQ(envelope.truncated, 0);
	ASSERT_STR_EQ(items[0].cible, "Animal Oil Residue");
	ASSERT_STR_EQ(items[1].cible, "Muscle Oil");
	return (0);
}

/*
** Rôle: check_unvalued_envelope — Vérifie unvalued enveloppe.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_collect_loot_envelope().
** Appelants: test_hunt_loot_unvalued_items().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_envelope_support.c -> check_unvalued_envelope()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_STR_EQ(), ASSERT_TRUE(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_unvalued_envelope(const char *path)
{
	t_hunt_csv_loot_envelope	envelope;
	t_hunt_csv_loot_line		items[4];

	memset(&envelope, 0, sizeof(envelope));
	memset(items, 0, sizeof(items));
	ASSERT_TRUE(hunt_csv_collect_loot_envelope(&(t_hunt_csv_loot_query){
			.csv_path = path, .timestamp_unix = 1700000100, .kill_id = 7,
			.lines = items, .line_capacity = 4}, &envelope));
	ASSERT_I64_EQ(envelope.item_count, 2);
	ASSERT_I64_EQ(envelope.stored_item_count, 2);
	ASSERT_I64_EQ(envelope.items_without_value, 1);
	ASSERT_I64_EQ(envelope.total_uPED, 15000);
	ASSERT_I64_EQ(items[0].has_value, 1);
	ASSERT_I64_EQ(items[1].has_value, 0);
	ASSERT_STR_EQ(items[1].cible, "Unknown Fragment");
	return (0);
}

/*
** Rôle: test_hunt_loot_unvalued_items — Construit ou traite les objets
**       appartenant à test chasse loot unvalued.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_unvalued_envelope(),
**            platform_process_id(), test_hunt_loot_write_partial().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_envelope_support.c ->
**        test_hunt_loot_unvalued_items() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(), remove(),
**              snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_loot_unvalued_items(void)
{
	char	path[256];
	int		pid;

	pid = platform_process_id();
	snprintf(path, sizeof(path), "bin/tests/tmp_%d_partial_value.csv", pid);
	ASSERT_I64_EQ(test_hunt_loot_write_partial(path), 0);
	ASSERT_I64_EQ(check_unvalued_envelope(path), 0);
	(void)remove(path);
	return (0);
}

/*
** Rôle: test_hunt_loot_marker_format — Formate l’état associé à test chasse
**       loot marker.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_markers_format_text().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_envelope_support.c -> test_hunt_loot_marker_format()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_STR_EQ(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_loot_marker_format(void)
{
	t_hunt_marker	marker;
	char			text[64];

	memset(&marker, 0, sizeof(marker));
	marker.kind = HUNT_MARKER_LOOT;
	marker.value = 1.2345;
	marker.group_count = 3;
	ASSERT_I64_EQ(hunt_markers_format_text(&marker, text, sizeof(text)), 1);
	ASSERT_STR_EQ(text, "1.23 x3");
	memset(&marker, 0, sizeof(marker));
	marker.kind = HUNT_MARKER_KILL;
	ASSERT_I64_EQ(hunt_markers_format_text(&marker, text, sizeof(text)), 1);
	ASSERT_STR_EQ(text, "K");
	return (0);
}
