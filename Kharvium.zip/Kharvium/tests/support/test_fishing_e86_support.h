/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_e86_support.h                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_FISHING_E86_SUPPORT_H
# define TEST_FISHING_E86_SUPPORT_H

typedef struct s_e86_stats
{
	long	catches;
	long	loot;
	long	events;
	long	skills;
	long	parented_skills;
	long	candidates;
	long	unknown_loot;
	long	neutral_roots;
	long	raw_roots;
	long	oil_roots;
}   t_e86_stats;

typedef struct s_e86_expected
{
	long	catches;
	long	loot;
	long	events;
	long	skills;
	long	candidates;
	long	unknown_loot;
	long	neutral_roots;
	long	raw_roots;
}   t_e86_expected;

int	test_fishing_e86_collect_stats(const char *hunt, const char *events,
		t_e86_stats *stats);
int	test_fishing_e86_check_expected(const t_e86_stats *stats,
		const t_e86_expected *expected);

#endif
