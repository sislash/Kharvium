/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_app_navigation_support.c                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_app_navigation_support.h"

static const int	g_back_routes[][3] = {
	{PAGE_GRAPH_LIVE, PAGE_HELP, PAGE_HUNT},
	{PAGE_CONFIG_WEAPONS, PAGE_HUNT, PAGE_CONFIG},
	{PAGE_CONFIG_MARKUP, PAGE_HUNT, PAGE_CONFIG},
	{PAGE_HOTKEYS, PAGE_HUNT, PAGE_CONFIG},
	{PAGE_HUNT, PAGE_GLOBAL_EVENTS, PAGE_DASHBOARD},
	{PAGE_GLOBAL_EVENTS, PAGE_HUNT, PAGE_DASHBOARD},
	{PAGE_SESSIONS, PAGE_HUNT, PAGE_DASHBOARD},
	{PAGE_CONFIG, PAGE_HUNT, PAGE_DASHBOARD},
	{PAGE_HEALTH, PAGE_HUNT, PAGE_HUNT},
	{PAGE_MAINTENANCE, PAGE_CONFIG, PAGE_CONFIG},
	{PAGE_HELP, PAGE_GLOBAL_EVENTS, PAGE_GLOBAL_EVENTS}
};

/*
** Rôle: test_nav_check_finance_pages — Vérifie nav pages en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_cursor_for_page().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation_support.c -> test_nav_check_finance_pages()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_nav_check_finance_pages(void)
{
	int	page;

	page = PAGE_DASHBOARD;
	while (page <= PAGE_FINANCE_ANALYSIS)
	{
		if (app_navigation_cursor_for_page((t_page)page) != 0)
			return (0);
		page++;
	}
	return (1);
}

/*
** Rôle: test_nav_check_cursor — Vérifie nav curseur en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: cursor — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: expected — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_page_for_cursor().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation_support.c -> test_nav_check_cursor() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_nav_check_cursor(int cursor, t_page expected)
{
	t_page	page;

	page = PAGE_DASHBOARD;
	if (!app_navigation_page_for_cursor(cursor, &page))
		return (0);
	return (page == expected);
}

/*
** Rôle: check_back — Vérifie back.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: previous — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: expected — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_back_target().
** Appelants: test_nav_check_back_routes().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation_support.c -> check_back() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_back(t_page page, t_page previous, t_page expected)
{
	t_page	target;

	target = PAGE_DASHBOARD;
	if (!app_navigation_back_target(page, previous, &target))
		return (0);
	return (target == expected);
}

/*
** Rôle: test_nav_check_all_pages_valid — Vérifie si nav check all pages
**       possède l’état valide attendu avant de poursuivre l’opération.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_page_is_valid().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation_support.c -> test_nav_check_all_pages_valid()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_nav_check_all_pages_valid(void)
{
	int	page;

	page = PAGE_DASHBOARD;
	while (page <= PAGE_HEALTH)
	{
		if (!app_navigation_page_is_valid((t_page)page))
			return (0);
		page++;
	}
	if (app_navigation_page_is_valid((t_page)-1))
		return (0);
	return (!app_navigation_page_is_valid((t_page)(PAGE_HEALTH + 1)));
}

/*
** Rôle: test_nav_check_back_routes — Vérifie nav retour routes en contrôlant
**       ses préconditions, ses bornes et les invariants nécessaires avant
**       toute utilisation ultérieure.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_back().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_navigation_support.c -> test_nav_check_back_routes()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_back_routes.
** Concurrence: état global mutable détecté (g_back_routes); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_nav_check_back_routes(void)
{
	int	page;
	int	index;

	page = PAGE_FINANCE_WALLET;
	while (page <= PAGE_FINANCE_ANALYSIS)
	{
		if (!check_back((t_page)page, PAGE_HUNT, PAGE_DASHBOARD))
			return (0);
		page++;
	}
	index = 0;
	while (index < (int)(sizeof(g_back_routes) / sizeof(g_back_routes[0])))
	{
		if (!check_back((t_page)g_back_routes[index][0],
				(t_page)g_back_routes[index][1],
				(t_page)g_back_routes[index][2]))
			return (0);
		index++;
	}
	return (1);
}
