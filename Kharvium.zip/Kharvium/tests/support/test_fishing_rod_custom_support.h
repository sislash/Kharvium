/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_rod_custom_support.h                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_FISHING_ROD_CUSTOM_SUPPORT_H
# define TEST_FISHING_ROD_CUSTOM_SUPPORT_H

# include "config/fishing_rod_config.h"

int	test_fishing_custom_set_named(t_fishing_rod_preset *preset,
		const t_fishing_rod_database *database,
		const t_catalog_registry *catalog, const char *name);
int	test_fishing_custom_build_standard(t_fishing_rod_preset *preset,
		const t_fishing_rod_database *database,
		const t_catalog_registry *catalog);

#endif
