/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_app_navigation_support.h                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_APP_NAVIGATION_SUPPORT_H
# define TEST_APP_NAVIGATION_SUPPORT_H

# include "app/app_navigation.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_nav_check_finance_pages — Vérifie nav pages en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_nav_check_finance_pages().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_nav_check_finance_pages(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_nav_check_finance_pages(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_nav_check_cursor — Vérifie nav curseur en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: cursor — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: expected — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_nav_check_cursor().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_nav_check_cursor(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_nav_check_cursor(int cursor, t_page expected);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_nav_check_all_pages_valid — Vérifie si nav check all pages
**       possède l’état valide attendu avant de poursuivre l’opération.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_nav_check_all_pages_valid().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_nav_check_all_pages_valid(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_nav_check_all_pages_valid(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_nav_check_back_routes — Vérifie nav retour routes en contrôlant
**       ses préconditions, ses bornes et les invariants nécessaires avant
**       toute utilisation ultérieure.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: test_nav_check_back_routes().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_nav_check_back_routes(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_nav_check_back_routes(void);

#endif
