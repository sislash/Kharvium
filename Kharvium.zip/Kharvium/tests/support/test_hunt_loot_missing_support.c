/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_loot_missing_support.c                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_hunt_loot_group_support.h"
#include "../test_util.h"

#include "platform/platform_file_system.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
** Rôle: check_missing_values — Vérifie missing valeurs.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_hunt_loot_missing_kill_id().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_missing_support.c -> check_missing_values() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_missing_values(t_test_hunt_loot_context *ctx)
{
	double	scaled;

	ASSERT_I64_EQ(ctx->output.count, 1);
	ASSERT_I64_EQ(ctx->group_counts[0], 2);
	ASSERT_I64_EQ(ctx->kill_ids[0], 0);
	ASSERT_I64_EQ(ctx->has_kill[0], 1);
	scaled = ctx->values[0] * (double)MONEY_UPED_PER_PED;
	ASSERT_I64_EQ((long long)(scaled + 0.5), 30000);
	return (0);
}

/*
** Rôle: check_missing_markers — Vérifie missing markers.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_markers_build_loot().
** Appelants: test_hunt_loot_missing_kill_id().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_missing_support.c -> check_missing_markers() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_missing_markers(t_test_hunt_loot_context *ctx)
{
	t_hunt_marker_build	build;

	memset(&build, 0, sizeof(build));
	build.loot_values = ctx->values;
	build.group_counts = ctx->group_counts;
	build.has_kill = ctx->has_kill;
	build.count = ctx->output.count;
	build.output = ctx->markers;
	build.output_capacity = 16;
	build.output_count = &ctx->marker_count;
	ASSERT_TRUE(hunt_markers_build_loot(&build));
	ASSERT_I64_EQ(ctx->marker_count, 2);
	ASSERT_I64_EQ(ctx->markers[0].kind, HUNT_MARKER_KILL);
	ASSERT_I64_EQ(ctx->markers[1].kind, HUNT_MARKER_LOOT);
	ASSERT_I64_EQ(ctx->markers[1].group_count, 2);
	return (0);
}

/*
** Rôle: test_hunt_loot_missing_kill_id — Formate loot missing kill id dans le
**       buffer destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement une gestion de mémoire dynamique; effectue
**         directement des E/S fichier ou une modification de chemin.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_missing_markers(),
**            check_missing_values(), platform_process_id(),
**            test_hunt_loot_context_init(), test_hunt_loot_write_missing().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_loot_missing_support.c ->
**        test_hunt_loot_missing_kill_id() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), free(), remove(), snprintf().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_loot_missing_kill_id(void)
{
	t_test_hunt_loot_context	ctx;
	char				path[256];
	int				pid;

	pid = platform_process_id();
	snprintf(path, sizeof(path), "bin/tests/tmp_%d_missing_kid.csv", pid);
	ASSERT_I64_EQ(test_hunt_loot_write_missing(path), 0);
	ASSERT_TRUE(test_hunt_loot_context_init(&ctx, path));
	ASSERT_I64_EQ(check_missing_values(&ctx), 0);
	ASSERT_I64_EQ(check_missing_markers(&ctx), 0);
	free(ctx.series);
	(void)remove(path);
	return (0);
}
