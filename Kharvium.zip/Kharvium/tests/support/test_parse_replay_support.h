/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_parse_replay_support.h                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_PARSE_REPLAY_SUPPORT_H
# define TEST_PARSE_REPLAY_SUPPORT_H

extern const char	g_test_parse_replay_log[];
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_parse_replay_rows_check — Vérifie REPLAY lignes en contrôlant
**       ses préconditions, ses bornes et les invariants nécessaires avant
**       toute utilisation ultérieure.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_parse_replay_rows_check().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_parse_replay_rows_check(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			test_parse_replay_rows_check(const char *csv_path);

#endif
