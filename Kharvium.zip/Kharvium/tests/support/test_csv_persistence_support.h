/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_csv_persistence_support.h                     :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_CSV_PERSISTENCE_SUPPORT_H
# define TEST_CSV_PERSISTENCE_SUPPORT_H

# include <stddef.h>

typedef struct s_test_csv_totals
{
	long long	rows;
	long long	loot;
	long long	expense;
} t_test_csv_totals;

typedef struct s_test_csv_paths
{
	int		pid;
	char	src[256];
	char	dst[256];
	char	path[256];
	char	backup[320];
	char	header[256];
} t_test_csv_paths;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_file_copy — Copie l’état associé à test CSV fichier.
** Paramètre: src — source consultée pour produire le résultat sans en
**            modifier la signification.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_file_copy().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_file_copy(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_csv_file_copy(const char *src, const char *dst);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_read_first_line — Lit first ligne depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_read_first_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_read_first_line(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_csv_read_first_line(const char *path, char *out, size_t cap);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_write_text_file — Écrit texte vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_write_text_file().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_write_text_file(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_csv_write_text_file(const char *path, const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_write_legacy — Écrit legacy vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_write_legacy().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_write_legacy(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_csv_write_legacy(const char *path);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_calculate_totals — Calcule totals à partir des entrées
**       fournies en respectant les unités, les bornes et les règles
**       d’arrondi propres au module.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: totals — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : totals.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_calculate_totals().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_calculate_totals(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_csv_calculate_totals(const char *path, t_test_csv_totals *totals);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_paths_init — Initialise les données nécessaires à test CSV
**       chemins.
** Paramètre: paths — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : paths.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_paths_init().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_paths_init(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	test_csv_paths_init(t_test_csv_paths *paths);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_rewrite_roundtrip — Met à jour rewrite roundtrip en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : p.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_rewrite_roundtrip().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_rewrite_roundtrip(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_csv_rewrite_roundtrip(t_test_csv_paths *paths);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_clear_roundtrip — Réinitialise roundtrip en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : p.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_clear_roundtrip().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_clear_roundtrip(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_csv_clear_roundtrip(t_test_csv_paths *paths);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_legacy_rewrite — Met à jour legacy rewrite en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : p.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_legacy_rewrite().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_legacy_rewrite(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_csv_legacy_rewrite(t_test_csv_paths *paths);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_csv_money_migration — Met à jour migration en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : p.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: test_csv_money_migration().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_csv_money_migration(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_csv_money_migration(t_test_csv_paths *paths);

#endif
