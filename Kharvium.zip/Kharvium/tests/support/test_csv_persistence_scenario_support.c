/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_csv_persistence_scenario_support.c            :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_csv_persistence_support.h"
#include "../test_util.h"

#include "io/hunt_csv.h"
#include "io/csv_persistence.h"
#include "platform/platform_file_system.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: test_csv_paths_init — Initialise les données nécessaires à test CSV
**       chemins.
** Paramètre: paths — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : paths.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_process_id().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_scenario_support.c -> test_csv_paths_init()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	test_csv_paths_init(t_test_csv_paths *paths)
{
	memset(paths, 0, sizeof(*paths));
	paths->pid = platform_process_id();
}

/*
** Rôle: test_csv_rewrite_roundtrip — Formate rewrite roundtrip dans le buffer
**       destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : p.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_persistence_rewrite_hunt_atomic(),
**            test_csv_calculate_totals(), test_csv_file_copy(),
**            test_csv_read_first_line().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_scenario_support.c ->
**        test_csv_rewrite_roundtrip() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), remove(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_csv_rewrite_roundtrip(t_test_csv_paths *p)
{
	t_test_csv_totals	a;
	t_test_csv_totals	b;

	snprintf(p->src, sizeof(p->src), "bin/tests/tmp_%d_src.csv", p->pid);
	snprintf(p->dst, sizeof(p->dst), "bin/tests/tmp_%d_dst.csv", p->pid);
	ASSERT_I64_EQ(test_csv_file_copy(
			"tests/fixtures/baseline_hunt_log.csv", p->src), 0);
	ASSERT_I64_EQ(csv_persistence_rewrite_hunt_atomic(p->src, p->dst), 0);
	ASSERT_TRUE(test_csv_calculate_totals(p->src, &a));
	ASSERT_TRUE(test_csv_calculate_totals(p->dst, &b));
	ASSERT_I64_EQ(a.rows, b.rows);
	ASSERT_I64_EQ(b.loot, a.loot * 10);
	ASSERT_I64_EQ(b.expense, a.expense * 10);
	ASSERT_TRUE(test_csv_read_first_line(p->dst, p->header, sizeof(p->header)));
	(void)remove(p->src);
	(void)remove(p->dst);
	return (0);
}

/*
** Rôle: test_csv_clear_roundtrip — Réinitialise roundtrip en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : p.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_persistence_clear_hunt_atomic(),
**            test_csv_read_first_line(), test_csv_write_text_file().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_scenario_support.c ->
**        test_csv_clear_roundtrip() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), remove(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_csv_clear_roundtrip(t_test_csv_paths *p)
{
	snprintf(p->path, sizeof(p->path), "bin/tests/tmp_%d_clear.csv", p->pid);
	ASSERT_I64_EQ(test_csv_write_text_file(p->path, "junk\n"), 0);
	ASSERT_I64_EQ(csv_persistence_clear_hunt_atomic(p->path), 0);
	ASSERT_TRUE(test_csv_read_first_line(
			p->path, p->header, sizeof(p->header)));
	(void)remove(p->path);
	return (0);
}

/*
** Rôle: test_csv_legacy_rewrite — Formate legacy rewrite dans le buffer
**       destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : p.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_persistence_rewrite_hunt_atomic(),
**            test_csv_calculate_totals(), test_csv_write_legacy().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_scenario_support.c ->
**        test_csv_legacy_rewrite() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), remove(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_csv_legacy_rewrite(t_test_csv_paths *p)
{
	t_test_csv_totals	totals;

	snprintf(p->src, sizeof(p->src), "bin/tests/tmp_%d_legacy.csv", p->pid);
	snprintf(p->dst, sizeof(p->dst),
		"bin/tests/tmp_%d_legacy_norm.csv", p->pid);
	ASSERT_I64_EQ(test_csv_write_legacy(p->src), 0);
	ASSERT_I64_EQ(csv_persistence_rewrite_hunt_atomic(p->src, p->dst), 0);
	ASSERT_TRUE(test_csv_calculate_totals(p->dst, &totals));
	ASSERT_I64_EQ(totals.rows, 2);
	ASSERT_I64_EQ(totals.loot, 2000);
	(void)remove(p->src);
	(void)remove(p->dst);
	return (0);
}

/*
** Rôle: test_csv_money_migration — Formate migration dans le buffer
**       destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : p.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_migrate_money_scale(),
**            test_csv_calculate_totals(), test_csv_read_first_line(),
**            test_csv_write_legacy().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence_scenario_support.c ->
**        test_csv_money_migration() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), remove(), snprintf(), strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_csv_money_migration(t_test_csv_paths *p)
{
	t_test_csv_totals	totals;

	snprintf(p->path, sizeof(p->path), "bin/tests/tmp_%d_migrate.csv", p->pid);
	snprintf(p->backup, sizeof(p->backup), "%s.money-v2.bak", p->path);
	ASSERT_I64_EQ(test_csv_write_legacy(p->path), 0);
	ASSERT_TRUE(hunt_csv_migrate_money_scale(p->path));
	ASSERT_TRUE(test_csv_read_first_line(
			p->path, p->header, sizeof(p->header)));
	ASSERT_TRUE(test_csv_calculate_totals(p->path, &totals));
	ASSERT_I64_EQ(totals.rows, 2);
	ASSERT_I64_EQ(totals.loot, 2000);
	ASSERT_TRUE(test_csv_read_first_line(
			p->backup, p->header, sizeof(p->header)));
	ASSERT_TRUE(strstr(p->header, "value_uPED") != NULL);
	ASSERT_TRUE(strstr(p->header, "value_uPED5") == NULL);
	(void)remove(p->path);
	(void)remove(p->backup);
	return (0);
}
