/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_xlsx_recipe_support.c                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_fin_xlsx_recipe_support.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: add_item — Ajoute objet.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: stage — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: quantity — quantité d’unités à traiter; les préconditions du
**            module encadrent les valeurs invalides.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_recipe_add_item().
** Appelants: test_fin_xlsx_build_recipe().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_xlsx_recipe_support.c -> add_item() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	add_item(t_finance_recipe *recipe, size_t stage,
		const char *name, int64_t quantity)
{
	t_finance_recipe_item	item;

	memset(&item, 0, sizeof(item));
	snprintf(item.name, sizeof(item.name), "%s", name);
	item.quantity = quantity;
	return (finance_recipe_add_item(recipe, stage, &item));
}

/*
** Rôle: add_stages — Ajoute stages.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_recipe_add_stage().
** Appelants: test_fin_xlsx_build_recipe().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_xlsx_recipe_support.c -> add_stages() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	add_stages(t_finance_recipe *recipe)
{
	return (finance_recipe_add_stage(recipe, "Etape 1")
		&& finance_recipe_add_stage(recipe, "Etape 2")
		&& finance_recipe_add_stage(recipe, "Etape 3")
		&& finance_recipe_add_stage(recipe, "Etape 4"));
}

/*
** Rôle: test_fin_xlsx_build_recipe — Construit fin xlsx recette à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: recipe — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : recipe.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> add_item(), add_stages(),
**            finance_recipe_initialize().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_xlsx_recipe_support.c -> test_fin_xlsx_build_recipe()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_xlsx_build_recipe(t_finance_recipe *recipe)
{
	t_finance_recipe_setup	setup;

	memset(&setup, 0, sizeof(setup));
	setup.name = "Culture Bombardo XLSX";
	setup.kind = FIN_RECIPE_CULTURE;
	setup.product_item = "Bombardo Transgen";
	setup.reference_output_quantity = 25;
	if (!finance_recipe_initialize(recipe, &setup) || !add_stages(recipe))
		return (0);
	if (!add_item(recipe, 0, "Basic Fertilizer", 50)
		|| !add_item(recipe, 0, "DNA Fragment A", 3))
		return (0);
	if (!add_item(recipe, 1, "Basic Fertilizer", 10)
		|| !add_item(recipe, 1, "Energized Crystal Cell", 2)
		|| !add_item(recipe, 1, "DNA Fragment B", 1))
		return (0);
	if (!add_item(recipe, 2, "Basic Fertilizer", 10)
		|| !add_item(recipe, 2, "Dianthus Crystal", 2)
		|| !add_item(recipe, 2, "DNA Fragment C", 1))
		return (0);
	return (add_item(recipe, 3, "Basic Fertilizer", 10)
		&& add_item(recipe, 3, "Light Liquid", 2)
		&& add_item(recipe, 3, "DNA Fragment D", 1));
}
