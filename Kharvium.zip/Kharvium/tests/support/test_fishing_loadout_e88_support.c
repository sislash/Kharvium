/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_loadout_e88_support.c                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_fishing_loadout_e88_support.h"

/*
** Rôle: test_e88_load_catalog — Charge items, gear et ammo du fixture E88.
** Relations: catalog_load_items_file(), catalog_load_fishing_gear_file(),
**            catalog_load_fishing_ammo_file().
** Appelants: tests Fishing loadout E88.
** Mémoire: allocations détenues par registry.
** Invariants: aucun accès réseau; uniquement data/catalog local.
** Retour: 1 si les trois catalogues chargent, 0 sinon.
** Effets: remplit registry.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
** test_fishing_loadout_e88_support.c -> test_e88_load_catalog().
** Dépendances: chargeurs data-driven.
** État partagé: aucun.
** Concurrence: tests mono-thread.
** I/O: CSV locaux.
** Unités: diverses.
** Performance: O(taille catalogues).
** Portabilité: C99 Windows/Linux.
*/
int	test_e88_load_catalog(t_catalog_registry *registry)
{
	if (!catalog_load_items_file(registry, "data/catalog/items.csv"))
		return (0);
	if (!catalog_load_fishing_gear_file(registry,
			"data/catalog/fishing_gear.csv"))
		return (0);
	return (catalog_load_fishing_ammo_file(registry,
			"data/catalog/fishing_ammo.csv"));
}

/*
** Rôle: test_e88_add_component — Ajoute mesure + base synthétique à 150 %.
** Relations: catalog_registry_find_fishing_gear(),
**            fishing_loadout_set_component(),
**            fishing_loadout_set_component_basis().
** Appelants: test_e88_build_measured_loadout().
** Mémoire: aucune.
** Invariants: 150 % sert uniquement à tester l'arithmétique, jamais au produit.
** Retour: 1 si composant ajouté, 0 sinon.
** Effets: modifie snapshot.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
** test_fishing_loadout_e88_support.c -> test_e88_add_component().
** Dépendances: API E88.
** État partagé: snapshot de test.
** Concurrence: mono-thread.
** I/O: aucune.
** Unités: uPED5.
** Performance: recherche catalogue bornée.
** Portabilité: C99.
*/
static int	test_e88_add_component(t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *registry, t_entity_id id, t_money after)
{
	const t_catalog_fishing_gear	*gear;
	t_money				cost;

	gear = catalog_registry_find_fishing_gear(registry, id);
	if (!gear || gear->max_tt <= 0 || gear->decay_per_use < 0)
		return (0);
	if (!fishing_loadout_set_component(snapshot, gear, gear->max_tt, after))
		return (0);
	cost = gear->max_tt + gear->max_tt / 2;
	return (fishing_loadout_set_component_basis(snapshot, gear->slot,
			gear->max_tt, cost));
}

/*
** Rôle: test_e88_build_measured_loadout — Construit le fixture complet E88.
** Relations: test_e88_add_component(), catalog_registry_find_fishing_ammo(),
**            fishing_loadout_set_ammo(), fishing_loadout_set_ammo_basis().
** Appelants: test_fishing_loadout_cost.c.
** Mémoire: aucune.
** Invariants: after = max_tt - decay technique attendu pour ce fixture.
** Retour: 1 si toutes les mesures/bases sont installées, 0 sinon.
** Effets: modifie snapshot.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
** test_fishing_loadout_e88_support.c -> test_e88_build_measured_loadout().
** Dépendances: catalogue local E88.
** État partagé: snapshot de test.
** Concurrence: mono-thread.
** I/O: aucune.
** Unités: uPED5 et cellules.
** Performance: coût borné.
** Portabilité: C99 Windows/Linux.
*/
int	test_e88_build_measured_loadout(t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *registry)
{
	const t_catalog_fishing_ammo	*ammo;

	if (!test_e88_add_component(snapshot, registry, 1301, 198000)
		|| !test_e88_add_component(snapshot, registry, 1311, 2199120)
		|| !test_e88_add_component(snapshot, registry, 1321, 399680))
		return (0);
	if (!test_e88_add_component(snapshot, registry, 1331, 3398640)
		|| !test_e88_add_component(snapshot, registry, 1341, 599760))
		return (0);
	ammo = catalog_registry_find_fishing_ammo(registry, 1007);
	if (!ammo || !fishing_loadout_set_ammo(snapshot, ammo, 5000, 3200))
		return (0);
	return (fishing_loadout_set_ammo_basis(snapshot, 10000, 120000));
}
