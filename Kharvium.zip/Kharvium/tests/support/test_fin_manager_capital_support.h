/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_manager_capital_support.h                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_FIN_MANAGER_CAPITAL_SUPPORT_H
# define TEST_FIN_MANAGER_CAPITAL_SUPPORT_H

# include "finance/finance_book.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_fin_manager_check_capital — Vérifie fin manager capital en
**       contrôlant ses préconditions, ses bornes et les invariants
**       nécessaires avant toute utilisation ultérieure.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_fin_manager_check_capital().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_fin_manager_check_capital(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_fin_manager_check_capital(t_finance_book *book);

#endif
