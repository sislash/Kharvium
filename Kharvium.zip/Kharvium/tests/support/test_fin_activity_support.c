/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fin_activity_support.c                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_fin_activity_support.h"
#include "finance/finance_equipment.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: test_fin_activity_amount — Formate fin activité montant dans le
**       buffer destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: test_fin_activity_add_price(), test_fin_activity_build_run(),
**            test_fin_activity_seed_equipment(),
**            test_fin_activity_seed_stock(), check_aggregate(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_activity_support.c -> test_fin_activity_amount() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_money	test_fin_activity_amount(const char *text)
{
	t_money	value;

	value = 0;
	if (!money_parse_ped(text, &value))
		return (0);
	return (value);
}

/*
** Rôle: test_fin_activity_add_price — Ajoute fin activité prix dans la
**       collection concernée en respectant sa capacité, son ordre logique et
**       la propriété de ses éléments.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: tt — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: market — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_add_price(),
**            test_fin_activity_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_activity_support.c -> test_fin_activity_add_price()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_activity_add_price(t_finance_book *book, const char *name,
		const char *tt, const char *market)
{
	t_finance_price	price;

	memset(&price, 0, sizeof(price));
	snprintf(price.name, sizeof(price.name), "%s", name);
	price.tt_unit_uPED = test_fin_activity_amount(tt);
	price.market_mode = FIN_MARKET_UNIT;
	price.market_unit_uPED = test_fin_activity_amount(market);
	return (finance_book_add_price(book, &price));
}

/*
** Rôle: test_fin_activity_seed_stock — Formate fin activité seed stock dans
**       le buffer destination fourni, avec une taille explicitement bornée
**       par l’appelant.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_stock_add(),
**            test_fin_activity_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_activity_support.c -> test_fin_activity_seed_stock()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_activity_seed_stock(t_finance_book *book)
{
	t_finance_stock	stock;

	memset(&stock, 0, sizeof(stock));
	snprintf(stock.item, sizeof(stock.item), "%s", "Universal Ammo");
	stock.quantity = 20;
	stock.cost_known = 1;
	stock.cost_total_uPED = test_fin_activity_amount("30.00000");
	stock.tt_unit_uPED = test_fin_activity_amount("1.00000");
	return (finance_book_stock_add(book, &stock));
}

/*
** Rôle: test_fin_activity_seed_equipment — Formate fin activité seed
**       équipement dans le buffer destination fourni, avec une taille
**       explicitement bornée par l’appelant.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_equipment_register(),
**            test_fin_activity_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_activity_support.c -> test_fin_activity_seed_equipment()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_activity_seed_equipment(t_finance_book *book)
{
	t_finance_equipment	equipment;

	memset(&equipment, 0, sizeof(equipment));
	snprintf(equipment.name, sizeof(equipment.name), "%s", "ArMatrix LR-35");
	equipment.tt_current_uPED = test_fin_activity_amount("50.00000");
	equipment.repairable = 1;
	return (finance_equipment_register(book, &equipment));
}

/*
** Rôle: test_fin_activity_build_run — Exécute l’état associé à test fin
**       activité build.
** Paramètre: run — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Paramètre: target — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: location — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : run.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_activity_add_consumable_kind(),
**            finance_activity_add_decay_kind(), finance_activity_add_loot(),
**            finance_activity_initialize(), finance_activity_set_details(),
**            finance_activity_set_setup(), test_fin_activity_amount().
** Appelants: commit_runs().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_fin_activity_support.c -> test_fin_activity_build_run()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=7; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_fin_activity_build_run(t_finance_activity *run, int64_t timestamp,
		const char *target, const char *location)
{
	finance_activity_initialize(run, FIN_ACTIVITY_HUNT, timestamp);
	finance_activity_set_details(run, "Atrox run", target, location);
	finance_activity_set_setup(run, "ArMatrix LR-35 + A105");
	run->direct_ped_uPED = test_fin_activity_amount("2.00000");
	if (!finance_activity_add_consumable_kind(run, "Universal Ammo", 2,
			FIN_ACTIVITY_INPUT_AMMO))
		return (0);
	if (!finance_activity_add_decay_kind(run, "ArMatrix LR-35",
			test_fin_activity_amount("1.00000"), FIN_ACTIVITY_DECAY_WEAPON))
		return (0);
	return (finance_activity_add_loot(run, "Animal Oil", 3));
}
