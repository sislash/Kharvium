/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_long_support.c                           +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_hunt_long_support.h"
#include "../test_util.h"
#include "hunt/hunt_series.h"
#include "io/csv_index.h"
#include "io/hunt_csv.h"
#include "platform/platform_file_system.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const t_hunt_csv_row_view	g_shot_row = {
	.type_evenement = "SHOT", .cible = "", .quantite = 1,
	.valeur_uPED = 0, .a_valeur = 0, .id_kill = 0, .drapeaux = 0u,
	.brut = "You inflicted 1.0 points of damage"
};

static const t_hunt_csv_row_view	g_kill_rows[] = {
	{.type_evenement = "KILL", .cible = "Daikiba Mature", .quantite = 1,
		.valeur_uPED = 0, .a_valeur = 0, .drapeaux = 2u,
		.brut = "You killed Daikiba Mature."},
	{.type_evenement = "LOOT_ITEM", .cible = "Animal Oil Residue",
		.quantite = 1, .valeur_uPED = 100, .a_valeur = 1, .drapeaux = 3u,
		.brut = "You received Animal Oil Residue"},
	{.type_evenement = "LOOT_ITEM", .cible = "Animal Oil Residue",
		.quantite = 1, .valeur_uPED = 100, .a_valeur = 1, .drapeaux = 3u,
		.brut = "You received Animal Oil Residue"},
	{.type_evenement = "AMMO", .cible = "Weapon", .quantite = 1,
		.valeur_uPED = 200, .a_valeur = 1, .id_kill = 0, .drapeaux = 1u,
		.brut = "AMMO"},
	{.type_evenement = "DECAY", .cible = "Weapon", .quantite = 1,
		.valeur_uPED = 150, .a_valeur = 1, .id_kill = 0, .drapeaux = 1u,
		.brut = "DECAY"}
};

/*
** Rôle: write_shots — Écrit shots.
** Paramètre: stream — flux de fichier déjà ouvert dont le cycle de vie
**            reste celui prévu par l’appelant.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : stream.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_write_v2().
** Appelants: test_hunt_long_write_csv().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_long_support.c -> write_shots() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_shot_row.
** Concurrence: état global mutable détecté (g_shot_row); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	write_shots(FILE *stream, int64_t timestamp)
{
	t_hunt_csv_row_view	row;
	int			index;

	row = g_shot_row;
	row.timestamp_unix = timestamp;
	index = 0;
	while (index++ < 3)
		ASSERT_I64_EQ(hunt_csv_write_v2(stream, &row), 0);
	return (0);
}

/*
** Rôle: write_kill_rows — Écrit kill lignes.
** Paramètre: stream — flux de fichier déjà ouvert dont le cycle de vie
**            reste celui prévu par l’appelant.
** Paramètre: timestamp — horodatage associé à l’événement ou à la
**            transition d’état.
** Paramètre: kill_id — identifiant stable servant à retrouver ou associer
**            l’élément.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : stream.
** Invariants: les accès indexés sont bornés avant lecture ou écriture; un
**             kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_write_v2().
** Appelants: test_hunt_long_write_csv().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_long_support.c -> write_kill_rows() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_kill_rows.
** Concurrence: état global mutable détecté (g_kill_rows); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	write_kill_rows(FILE *stream, int64_t timestamp, int64_t kill_id)
{
	t_hunt_csv_row_view	row;
	int			index;

	index = 0;
	while (index < 5)
	{
		row = g_kill_rows[index];
		row.timestamp_unix = timestamp;
		if (index < 3)
			row.id_kill = kill_id;
		ASSERT_I64_EQ(hunt_csv_write_v2(stream, &row), 0);
		index++;
	}
	return (0);
}
/*
** Rôle: test_hunt_long_write_csv — Écrit long vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: kills — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_ensure_header_v2(),
**            write_kill_rows(), write_shots().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_long_support.c -> test_hunt_long_write_csv() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), fclose(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=3; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_long_write_csv(const char *path, int kills)
{
	FILE		*stream;
	int		index;
	int64_t		timestamp;

	stream = fopen(path, "wb");
	ASSERT_TRUE(stream != NULL);
	hunt_csv_ensure_header_v2(stream);
	index = 0;
	while (index < kills)
	{
		timestamp = 1700000000LL + index;
		ASSERT_I64_EQ(write_shots(stream, timestamp), 0);
		ASSERT_I64_EQ(write_kill_rows(stream, timestamp, index + 1), 0);
		index++;
	}
	ASSERT_I64_EQ(fclose(stream), 0);
	return (0);
}

/*
** Rôle: verify_index — Vérifie index.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: start_line — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_index_build(),
**            csv_index_lookup_row_offset(), csv_index_options_default().
** Appelants: test_hunt_long_verify().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_long_support.c -> verify_index() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_TRUE(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	verify_index(const char *path, long start_line)
{
	t_csv_index_options	opt;
	t_csv_index_checkpoint	checkpoint;
	t_csv_index_row_query	query;

	csv_index_options_default(&opt);
	opt.stride_rows = 1024;
	ASSERT_TRUE(csv_index_build(path, &opt, NULL));
	memset(&checkpoint, 0, sizeof(checkpoint));
	query.csv_path = path;
	query.row_index = (unsigned long long)start_line;
	ASSERT_TRUE(csv_index_lookup_row_offset(&query, &checkpoint, NULL));
	ASSERT_TRUE(checkpoint.byte_offset > 0);
	ASSERT_TRUE((long)checkpoint.row_index <= start_line);
	return (0);
}

/*
** Rôle: test_hunt_long_verify — Vérifie long en contrôlant ses préconditions,
**       ses bornes et les invariants nécessaires avant toute utilisation
**       ultérieure.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: kills_total — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_rebuild_range(),
**            hunt_series_reset(), hunt_series_sanity_check(),
**            verify_index().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_hunt_long_support.c -> test_hunt_long_verify() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), calloc(), free().
** Mémoire: opérations directes -> calloc(), free(); le transfert de
**          propriété reste défini par Retour/Effets et les contrats des
**          fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_hunt_long_verify(const char *path, int kills_total)
{
	t_hunt_series			*series;
	t_hunt_series_range_request	range;
	long				start_line;
	long				kills_range;

	start_line = 4000L * 8L;
	ASSERT_I64_EQ(verify_index(path, start_line), 0);
	series = (t_hunt_series *)calloc(1, sizeof(*series));
	ASSERT_TRUE(series != NULL);
	hunt_series_reset(series, 0, 60);
	range.csv_path = path;
	range.start_line = start_line;
	range.end_line = -1;
	range.bucket_sec = 60;
	ASSERT_TRUE(hunt_series_rebuild_range(series, &range));
	ASSERT_TRUE(hunt_series_sanity_check(series));
	kills_range = kills_total - 4000;
	ASSERT_I64_EQ(series->core.kills_total, kills_range);
	ASSERT_I64_EQ(series->core.shots_total, kills_range * 3);
	ASSERT_I64_EQ(series->core.hits_total, kills_range * 3);
	ASSERT_I64_EQ(series->core.loot_total_uPED, kills_range * 200);
	ASSERT_I64_EQ(series->core.expense_total_uPED, kills_range * 350);
	free(series);
	return (0);
}
