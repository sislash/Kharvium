/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_hunt_eviction_support.h                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#ifndef TEST_HUNT_EVICTION_SUPPORT_H
# define TEST_HUNT_EVICTION_SUPPORT_H

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_eviction_write — Écrit l’état associé à test chasse
**       eviction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: total — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_eviction_write().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_eviction_write(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_eviction_write(const char *path, int total);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: test_hunt_eviction_verify — Vérifie eviction en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: total — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement une gestion de mémoire dynamique.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: test_hunt_eviction_verify().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                test_hunt_eviction_verify(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	test_hunt_eviction_verify(const char *path, int total);

#endif
