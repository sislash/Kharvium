/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_rod_config_support.h                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_FISHING_ROD_CONFIG_SUPPORT_H
# define TEST_FISHING_ROD_CONFIG_SUPPORT_H

# include "catalog/catalog_registry.h"
# include "config/fishing_rod_config.h"

int	test_fishing_rod_load_config(t_catalog_registry *registry,
		t_fishing_rod_database *database);
void	test_fishing_rod_cleanup_config(t_catalog_registry *registry,
		t_fishing_rod_database *database);
int	test_fishing_rod_check_snapshot(
		const t_fishing_loadout_snapshot *snapshot);
int	test_fishing_rod_write_invalid_ini(int mode);
int	test_fishing_rod_invalid_rejected(int mode);
int	test_fishing_rod_direct_picker(void);

#endif
