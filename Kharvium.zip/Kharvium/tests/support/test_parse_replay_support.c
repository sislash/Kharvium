/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_parse_replay_support.c                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_parse_replay_support.h"
#include "../test_util.h"
#include "common/string_operations.h"
#include "io/hunt_csv.h"

#include <stdio.h>

const char	g_test_parse_replay_log[] =
	"2026-01-01 12:00:00 You inflicted 10.0 points of damage.\n"
	"2026-01-01 12:00:01 You killed Daikiba Mature.\n"
	"2026-01-01 12:00:01 You received Animal Oil Residue x (10) "
	"Value: 0.1250 PED\n"
	"2026-01-01 12:00:01 You received Muscle Oil x (1) Value: 0.5000 PED.\n"
	"2026-01-01 12:00:05 Vous avez infligÃ© 10.0 points de dÃ©gÃ¢ts.\n"
	"2026-01-01 12:00:06 Vous avez tu\xC3\xA9 Exarosaur.\n"
	"2026-01-01 12:00:06 Vous avez recu Animal Oil Residue x (2) "
	"Valeur: 0,0200 PED.\n"
	"2026-01-01 12:00:10 You killed Berycled Young.\n"
	"2026-01-01 12:00:10 You killed Berycled Young.\n"
	"2026-01-01 12:00:10 You received Animal Hide x (1) Value: 0.0100 PED.\n"
	"2026-01-01 12:00:11 You killed Daikiba Young.\n"
	"2026-01-01 12:00:11 You received Muscle Oil x (1) Value: 0.0200 PED.\n"
	"2026-01-01 12:00:11 You received Animal Oil Residue x (3) "
	"Value: 0.0300 PED.\n";

/*
** Rôle: check_row — Vérifie ligne.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_parse_replay_rows_check(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_replay_support.c -> check_row() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_row(const t_hunt_csv_row_view *row, int count)
{
	if (count == 1 || count == 5)
		return (strcmp(row->type_evenement, "SHOT") == 0 && row->id_kill == 0);
	if (count == 2)
		return (strcmp(row->type_evenement, "KILL") == 0
			&& strcmp(row->cible, "Daikiba Mature") == 0 && row->id_kill == 1);
	if (count == 3)
		return (strcmp(row->cible, "Animal Oil Residue") == 0
			&& row->quantite == 10 && row->valeur_uPED == 12500
			&& row->id_kill == 1 && row->drapeaux == 3);
	if (count == 4)
		return (strcmp(row->cible, "Muscle Oil") == 0
			&& row->valeur_uPED == 50000 && row->id_kill == 1);
	if (count == 6)
		return (strcmp(row->cible, "Exarosaur") == 0 && row->id_kill == 2);
	if (count == 7)
		return (row->quantite == 2 && row->valeur_uPED == 2000
			&& row->id_kill == 2 && row->drapeaux == 3);
	if (count == 8 || count == 9)
		return (row->id_kill == 3);
	return (row->id_kill == 4);
}

/*
** Rôle: test_parse_replay_rows_check — Vérifie REPLAY lignes en contrôlant
**       ses préconditions, ses bornes et les invariants nécessaires avant
**       toute utilisation ultérieure.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_row(),
**            hunt_csv_parse_row_inplace(), string_copy_safe().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_parse_replay_support.c -> test_parse_replay_rows_check()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ(),
**              ASSERT_TRUE(), fclose(), fgets(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=3; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_parse_replay_rows_check(const char *csv_path)
{
	FILE			*stream;
	char			line[8192];
	char			work[8192];
	t_hunt_csv_row_view	row;
	int			count;

	stream = fopen(csv_path, "rb");
	ASSERT_TRUE(stream != NULL);
	count = 0;
	while (fgets(line, sizeof(line), stream))
	{
		string_copy_safe(work, sizeof(work), line);
		if (!hunt_csv_parse_row_inplace(work, &row))
			continue ;
		count++;
		ASSERT_TRUE(check_row(&row, count));
	}
	fclose(stream);
	ASSERT_I64_EQ(count, 12);
	return (0);
}
