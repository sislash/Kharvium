/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_rod_custom_support.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_fishing_rod_custom_support.h"

/*
** Rôle: test_fishing_custom_set_named — Cherche un composant v2 par nom puis
**       l'applique au draft avec validation canonique.
** Relations: fishing_rod_database_find_component(),
**            fishing_rod_preset_set_component().
** Appelants: test_fishing_custom_build_standard(), tests E91.
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> test_fishing_custom_set_named().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
int	test_fishing_custom_set_named(t_fishing_rod_preset *preset,
	const t_fishing_rod_database *database, const t_catalog_registry *catalog,
	const char *name)
{
	const t_fishing_rod_component	*component;

	component = fishing_rod_database_find_component(database, name);
	if (!component)
		return (0);
	return (fishing_rod_preset_set_component(preset, component, catalog));
}

/*
** Rôle: test_fishing_custom_build_standard — Construit un montage standard
**       complet depuis les composants du fishing_rods.ini v2.
** Relations: fishing_rod_preset_initialize(), test_fishing_custom_set_named().
** Appelants: tests E91.
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**    test_fishing_custom_build_standard().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
int	test_fishing_custom_build_standard(t_fishing_rod_preset *preset,
	const t_fishing_rod_database *database, const t_catalog_registry *catalog)
{
	fishing_rod_preset_initialize(preset, FISHING_ROD_CUSTOM_NAME);
	if (!test_fishing_custom_set_named(preset, database, catalog,
			"SET-FR1 Angling Rod (L)"))
		return (0);
	if (!test_fishing_custom_set_named(preset, database, catalog,
			"Adu Darcia SpinReeler A-05 (L)"))
		return (0);
	if (!test_fishing_custom_set_named(preset, database, catalog,
			"Adu Darcia Ultralight Fishing Blank C-01 (L)"))
		return (0);
	if (!test_fishing_custom_set_named(preset, database, catalog,
			"SL-100x Fishing Line (L)"))
		return (0);
	if (!test_fishing_custom_set_named(preset, database, catalog,
			"Teal \"Caly River\" Spinner (L)"))
		return (0);
	return (test_fishing_custom_set_named(preset, database, catalog,
			"Spool Cell"));
}
