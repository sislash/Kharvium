/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_tracker_e87_support.h                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_TRACKER_E87_SUPPORT_H
# define TEST_TRACKER_E87_SUPPORT_H

# include "core/tracker_event.h"
# include <stdint.h>

int	test_tracker_e87_runtime_row(const t_tracker_event_record *row,
			int count, int64_t *attempt_id, int64_t *catch_id);
int	test_tracker_e87_migration_row(const t_tracker_event_record *row,
			int count);

#endif
