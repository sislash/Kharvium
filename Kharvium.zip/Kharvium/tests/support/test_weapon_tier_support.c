/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_weapon_tier_support.c                         +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_weapon_tier_support.h"
#include "common/money.h"
#include "common/string_operations.h"
#include "finance/finance_book.h"
#include "finance/finance_equipment.h"
#include "integration/tracker_finance.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: test_weapon_write_profile — Écrit profile vers la destination prévue
**       en respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: run_weapon_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_weapon_tier_support.c -> test_weapon_write_profile() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_weapon_write_profile(const char *path)
{
	FILE	*stream;

	stream = fopen(path, "wb");
	if (!stream)
		return (0);
	fprintf(stream, "[Test Rifle]\n");
	fprintf(stream, "dpp=3.0000\nammo_shot=0.10000\ndecay_shot=0.01000\n");
	fprintf(stream, "weapon_mu=1.25\ntier=10.00\n");
	fprintf(stream, "enhancer1=Damage Enhancer 1\nenhancer1_tt=0.10000\n");
	fprintf(stream, "enhancer1_cost=0.25000\nenhancer1_mu=2.50\n");
	fprintf(stream, "enhancer1_breaks=7\n");
	fprintf(stream, "enhancer10=Economy Enhancer 10\nenhancer10_tt=0.20000\n");
	fprintf(stream, "enhancer10_cost=0.30000\nenhancer10_mu=1.50\n");
	fprintf(stream, "enhancer10_breaks=2\n");
	return (fclose(stream) == 0);
}

/*
** Rôle: test_weapon_check_finance_bridge — Vérifie bridge en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: database — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : database.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize_new(), finance_equipment_register(),
**            money_parse_ped(), string_copy_bounded(),
**            tracker_finance_enhancer_break().
** Appelants: run_weapon_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_weapon_tier_support.c -> test_weapon_check_finance_bridge()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_weapon_check_finance_bridge(t_weapon_database *database)
{
	t_finance_book		book;
	t_finance_equipment	equipment;
	t_money			loss;
	t_money			shrapnel;
	int			valid;

	if (!database || database->count != 1)
		return (0);
	finance_book_initialize_new(&book);
	memset(&equipment, 0, sizeof(equipment));
	string_copy_bounded(equipment.name, database->items[0].name,
		sizeof(equipment.name));
	equipment.tt_current_uPED = 1000000;
	equipment.repairable = 1;
	valid = finance_equipment_register(&book, &equipment);
	valid = valid && tracker_finance_enhancer_break(&book,
		&database->items[0], 0, 1234);
	valid = valid && money_parse_ped("0.15000", &loss);
	valid = valid && money_parse_ped("0.10000", &shrapnel);
	valid = valid && book.equipment_event_count == 1;
	valid = valid && book.equipment_events[0].book_loss_uPED == loss;
	valid = valid && book.equipment_events[0].shrapnel_return_uPED == shrapnel;
	valid = valid && database->items[0].enhancers[0].break_count == 8;
	finance_book_destroy(&book);
	return (valid);
}

/*
** Rôle: check_slot — Vérifie slot.
** Paramètre: slot — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: expected — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_weapon_check_database().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_weapon_tier_support.c -> check_slot() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_slot(const t_enhancer_slot *slot,
		const t_enhancer_slot *expected)
{
	return (slot->installed && strcmp(slot->name, expected->name) == 0
		&& slot->tt_uPED == expected->tt_uPED
		&& slot->acquisition_cost_uPED == expected->acquisition_cost_uPED
		&& slot->markup_mu_1e4 == expected->markup_mu_1e4
		&& slot->break_count == expected->break_count);
}

/*
** Rôle: fill_expected_slot — Calcule et retourne fill expected slot à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: slot — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : slot.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped(),
**            string_copy_bounded().
** Appelants: test_weapon_check_database().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_weapon_tier_support.c -> fill_expected_slot() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	fill_expected_slot(t_enhancer_slot *slot, int index)
{
	memset(slot, 0, sizeof(*slot));
	slot->installed = 1;
	if (index == 0)
	{
		string_copy_bounded(slot->name, "Damage Enhancer 1",
			sizeof(slot->name));
		slot->markup_mu_1e4 = 25000;
		slot->break_count = 7;
		return (money_parse_ped("0.10000", &slot->tt_uPED)
			&& money_parse_ped("0.25000", &slot->acquisition_cost_uPED));
	}
	string_copy_bounded(slot->name, "Economy Enhancer 10",
		sizeof(slot->name));
	slot->markup_mu_1e4 = 15000;
	slot->break_count = 2;
	return (money_parse_ped("0.20000", &slot->tt_uPED)
		&& money_parse_ped("0.30000", &slot->acquisition_cost_uPED));
}

/*
** Rôle: test_weapon_check_database — Vérifie database en contrôlant ses
**       préconditions, ses bornes et les invariants nécessaires avant toute
**       utilisation ultérieure.
** Paramètre: database — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_slot(), fill_expected_slot(),
**            weapon_database_find().
** Appelants: run_weapon_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_weapon_tier_support.c -> test_weapon_check_database() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	test_weapon_check_database(const t_weapon_database *database)
{
	const t_weapon_stats	*weapon;
	t_enhancer_slot		expected[2];

	if (!database || database->player_name[0] != '\0' || database->count != 1)
		return (0);
	weapon = weapon_database_find(database, "Test Rifle");
	if (!weapon || weapon->tier_x100 != 1000)
		return (0);
	if (!fill_expected_slot(&expected[0], 0)
		|| !fill_expected_slot(&expected[1], 9))
		return (0);
	if (!check_slot(&weapon->enhancers[0], &expected[0]))
		return (0);
	return (check_slot(&weapon->enhancers[9], &expected[1]));
}
