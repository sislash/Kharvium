/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_manager_features.c                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_activity.h"
#include "finance/finance_book.h"
#include "finance/finance_calculations.h"
#include "finance/finance_capital.h"
#include "finance/finance_equipment.h"
#include "finance/finance_persistence.h"
#include "finance/finance_production.h"
#include "finance/finance_recipe.h"
#include "finance/finance_snapshot.h"
#include "platform/platform_file_system.h"

#include "common/money.h"
#include "support/test_fin_manager_capital_support.h"
#include "support/test_fin_manager_seed_support.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: check_production — Vérifie production.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_find_stock(),
**            finance_production_execute_next(),
**            finance_production_finalize(), finance_production_start(),
**            test_fin_manager_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_manager_features.c -> check_production() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_production(t_finance_book *book)
{
	t_finance_stock	*stock;
	size_t		index;

	if (!finance_production_start(book, "Simple Craft", 100, &index))
		return (0);
	if (!finance_production_execute_next(book, index))
		return (0);
	if (book->productions[index].book_cost_uPED
		!= test_fin_manager_amount("3.00000"))
		return (0);
	if (!finance_production_finalize(book, index, 110, 4))
		return (0);
	stock = finance_book_find_stock(book, "Craft Output");
	if (!stock || stock->quantity != 4)
		return (0);
	return (stock->cost_total_uPED == test_fin_manager_amount("3.00000"));
}

/*
** Rôle: register_equipment — Formate register équipement dans le buffer
**       destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_equipment_register(),
**            test_fin_manager_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_manager_features.c -> register_equipment() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	register_equipment(t_finance_book *book)
{
	t_finance_equipment	value;

	memset(&value, 0, sizeof(value));
	snprintf(value.name, sizeof(value.name), "%s", "Test Rifle");
	snprintf(value.catalog_item, sizeof(value.catalog_item), "%s",
		"Test Rifle");
	value.tt_current_uPED = test_fin_manager_amount("50.00000");
	value.repairable = 1;
	return (finance_equipment_register(book, &value));
}

/*
** Rôle: check_activity — Vérifie activité.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_activity_add_consumable(),
**            finance_activity_add_decay(), finance_activity_add_loot(),
**            finance_activity_commit(), finance_activity_initialize(),
**            test_fin_manager_amount().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_manager_features.c -> check_activity() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_activity(t_finance_book *book)
{
	t_finance_activity	activity;
	size_t			index;

	finance_activity_initialize(&activity, FIN_ACTIVITY_HUNT, 200);
	activity.direct_ped_uPED = test_fin_manager_amount("5.00000");
	if (!finance_activity_add_consumable(&activity, "Component A", 2))
		return (0);
	if (!finance_activity_add_decay(&activity, "Test Rifle",
		test_fin_manager_amount("1.00000")))
		return (0);
	if (!finance_activity_add_loot(&activity, "Loot Item", 2))
		return (0);
	if (!finance_activity_commit(book, &activity, &index))
		return (0);
	if (book->activities[index].cycle_tt_uPED
		!= test_fin_manager_amount("8.00000"))
		return (0);
	if (book->activities[index].book_cost_uPED
		!= test_fin_manager_amount("9.00000"))
		return (0);
	if (book->activities[index].loot_market_uPED
		!= test_fin_manager_amount("6.00000"))
		return (0);
	return (book->equipment[0].tt_current_uPED
		== test_fin_manager_amount("49.00000"));
}

/*
** Rôle: check_roundtrip — Vérifie roundtrip.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize(), finance_book_load(),
**            finance_book_save(), finance_snapshot_upsert(),
**            platform_process_id().
** Appelants: main(), main(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_manager_features.c -> check_roundtrip() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_roundtrip(t_finance_book *book)
{
	t_finance_book	loaded;
	char		path[256];
	int		ok;

	snprintf(path, sizeof(path), "bin/tests/finance_v3_%d.csv",
		platform_process_id());
	if (!finance_snapshot_upsert(book, 20260827))
		return (0);
	if (!finance_book_save(book, path))
		return (0);
	finance_book_initialize(&loaded, 0);
	ok = finance_book_load(&loaded, path);
	if (ok)
		ok = loaded.recipe_count == 1 && loaded.production_count == 1;
	if (ok)
		ok = loaded.recipes[0].stage_count == 1;
	if (ok)
		ok = loaded.deposit_count == 1 && loaded.withdrawal_count == 1;
	if (ok)
		ok = loaded.equipment_count == 1 && loaded.equipment_event_count == 3;
	if (ok)
		ok = loaded.activity_count == 1 && loaded.snapshot_count == 1;
	finance_book_destroy(&loaded);
	return (ok);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_activity(), check_production(),
**            check_roundtrip(), finance_book_destroy(),
**            finance_book_initialize(), register_equipment(),
**            test_fin_manager_add_price(), test_fin_manager_add_recipe()
**            (+3; index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_manager_features.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf(), printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=11;
**              dépendances externes/macros=2. Le coût des fonctions appelées
**              peut dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_finance_book	book;

	finance_book_initialize(&book, test_fin_manager_amount("1000.00000"));
	if (!test_fin_manager_add_price(
			&book, "Component A", "1.00000", "1.20000")
		|| !test_fin_manager_add_price(
			&book, "Craft Output", "0.50000", "1.00000")
		|| !test_fin_manager_add_price(
			&book, "Loot Item", "2.00000", "3.00000"))
		return (fprintf(stderr, "FAIL prices\n"), 1);
	if (!test_fin_manager_seed_stock(&book)
		|| !test_fin_manager_add_recipe(&book) || !check_production(&book))
		return (fprintf(stderr, "FAIL production\n"), 1);
	if (!register_equipment(&book) || !check_activity(&book))
		return (fprintf(stderr, "FAIL activity\n"), 1);
	if (!test_fin_manager_check_capital(&book))
		return (fprintf(stderr, "FAIL capital/equipment\n"), 1);
	if (!check_roundtrip(&book))
		return (fprintf(stderr, "FAIL roundtrip\n"), 1);
	finance_book_destroy(&book);
	printf("test_finance_manager_features: OK\n");
	return (0);
}
