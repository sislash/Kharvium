/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_util.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   Minimal test helpers (no external deps).                                 */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_UTIL_H
# define TEST_UTIL_H

# include <stdio.h>
# include <string.h>

# if defined(__GNUC__) || defined(__clang__)
#  define TEST_ATTR_UNUSED __attribute__((unused))
# else
#  define TEST_ATTR_UNUSED
# endif

/*
** Rôle: test_fail_at — Formate fail at dans le buffer destination fourni,
**       avec une taille explicitement bornée par l’appelant.
** Paramètre: file — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: msg — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int TEST_ATTR_UNUSED; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_i64_eq(), test_str_eq(), test_true().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère test_util.h
**        -> test_fail_at() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	TEST_ATTR_UNUSED test_fail_at(
						const char *file, int line, const char *msg)
{
	fprintf(stderr, "[TEST] FAIL %s:%d: %s\n", file, line, msg);
	return (1);
}

/*
** Rôle: test_true — Formate true dans le buffer destination fourni, avec une
**       taille explicitement bornée par l’appelant.
** Paramètre: file — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: cond — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: expr — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int TEST_ATTR_UNUSED; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_fail_at().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère test_util.h
**        -> test_true() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	TEST_ATTR_UNUSED test_true(
						const char *file, int line, int cond,
						const char *expr)
{
	char	buf[256];
	if (!cond)
	{

		snprintf(buf, sizeof(buf), "assert_true(%s)", expr);
		return (test_fail_at(file, line, buf));
	}
	return (0);
}

/*
** Rôle: test_i64_eq — Formate i64 eq dans le buffer destination fourni, avec
**       une taille explicitement bornée par l’appelant.
** Paramètre: file — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: a — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: b — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int TEST_ATTR_UNUSED; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_fail_at().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère test_util.h
**        -> test_i64_eq() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	TEST_ATTR_UNUSED test_i64_eq(
						const char *file, int line,
						long long a, long long b)
{
	char	buf[256];
	if (a != b)
	{

		snprintf(buf, sizeof(buf), "assert_i64_eq: %lld != %lld", a, b);
		return (test_fail_at(file, line, buf));
	}
	return (0);
}

/*
** Rôle: strings_equal_null_safe — Compare strings null safe en appliquant
**       les validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: a — objet source consulté en lecture seule par cette fonction.
** Paramètre: b — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int TEST_ATTR_UNUSED; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_str_eq().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère test_util.h
**        -> strings_equal_null_safe() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	TEST_ATTR_UNUSED strings_equal_null_safe(const char *a,
	const char *b)
{
	if (!a)
		a = "";
	if (!b)
		b = "";
	return (strcmp(a, b) == 0);
}

/*
** Rôle: test_str_eq — Formate str eq dans le buffer destination fourni, avec
**       une taille explicitement bornée par l’appelant.
** Paramètre: file — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: a — objet source consulté en lecture seule par cette fonction.
** Paramètre: b — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int TEST_ATTR_UNUSED; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> strings_equal_null_safe(),
**            test_fail_at().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère test_util.h
**        -> test_str_eq() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	TEST_ATTR_UNUSED test_str_eq(
						const char *file, int line,
						const char *a, const char *b)
{
	const char	*sa;
	const char	*sb;

	char	buf[256];
	if (!strings_equal_null_safe(a, b))
	{

		sa = a;
		sb = b;
		if (!sa)
			sa = "(null)";
		if (!sb)
			sb = "(null)";
		snprintf(buf, sizeof(buf), "assert_str_eq: '%s' != '%s'", sa, sb);
		return (test_fail_at(file, line, buf));
	}
	return (0);
}

# define TEST_RUN(E) if (E) return (1)
# define ASSERT_TRUE(C) TEST_RUN(test_true(__FILE__, __LINE__, (C), #C))
# define ASSERT_I64_EQ(A, B) TEST_RUN(test_i64_eq(__FILE__, __LINE__, (A), (B)))
# define ASSERT_STR_EQ(A, B) TEST_RUN(test_str_eq(__FILE__, __LINE__, (A), (B)))

#endif
