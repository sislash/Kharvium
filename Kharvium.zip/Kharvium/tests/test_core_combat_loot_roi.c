/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_core_combat_loot_roi.c                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "test_util.h"

#include "core/core_loot_aggregate.h"
#include "core/core_roi.h"
#include "core/core_session.h"

#include "common/money.h"
#include <limits.h>

/*
** Rôle: test_combat_segment — Calcule et retourne combat segment à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_session_on_kill(),
**            core_session_on_shot(), core_session_reset().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_core_combat_loot_roi.c -> test_combat_segment() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_combat_segment(void)
{
	t_core_session	s;
	long		seg_shots;
	long		seg_hits;

	core_session_reset(&s);
	core_session_on_shot(&s, 1);
	core_session_on_shot(&s, 0);
	core_session_on_shot(&s, 1);
	core_session_on_kill(&s, &seg_shots, &seg_hits);
	ASSERT_I64_EQ(seg_shots, 3);
	ASSERT_I64_EQ(seg_hits, 2);
	core_session_on_shot(&s, 1);
	core_session_on_kill(&s, &seg_shots, &seg_hits);
	ASSERT_I64_EQ(seg_shots, 1);
	ASSERT_I64_EQ(seg_hits, 1);
	return (0);
}

/*
** Rôle: test_loot_merge_rules — Calcule et retourne loot merge rules à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_loot_should_merge().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_core_combat_loot_roi.c -> test_loot_merge_rules() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_TRUE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_loot_merge_rules(void)
{
	ASSERT_TRUE(core_loot_should_merge(100, 7, 101, 7) == 1);
	ASSERT_TRUE(core_loot_should_merge(100, 7, 100, 8) == 0);
	ASSERT_TRUE(core_loot_should_merge(100, 0, 100, 0) == 1);
	ASSERT_TRUE(core_loot_should_merge(100, 0, 101, 0) == 0);
	ASSERT_TRUE(core_loot_should_merge(100, 7, 100, 0) == 0);
	return (0);
}

/*
** Rôle: test_money_clamp — Borne l’état associé à test montant.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les limites des entiers sont traitées explicitement avant
**             tout dépassement.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_money_add_clamped(),
**            core_money_multiply_long_clamped().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_core_combat_loot_roi.c -> test_money_clamp() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_money_clamp(void)
{
	t_money	v;

	v = core_money_add_clamped((t_money)INT64_MAX - 10, 50);
	ASSERT_I64_EQ(v, (t_money)INT64_MAX);
	v = core_money_add_clamped((t_money)INT64_MIN + 10, -50);
	ASSERT_I64_EQ(v, (t_money)INT64_MIN);

	v = core_money_multiply_long_clamped((t_money)123, 10);
	ASSERT_I64_EQ(v, 1230);
	v = core_money_multiply_long_clamped((t_money)INT64_MAX / 2, 3);
	ASSERT_I64_EQ(v, (t_money)INT64_MAX);
	return (0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_combat_segment(),
**            test_loot_merge_rules(), test_money_clamp().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_core_combat_loot_roi.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_STR_EQ(),
**              ASSERT_TRUE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	ASSERT_STR_EQ("ok", "ok");
	ASSERT_TRUE(test_combat_segment() == 0);
	ASSERT_TRUE(test_loot_merge_rules() == 0);
	ASSERT_TRUE(test_money_clamp() == 0);
	return (0);
}
