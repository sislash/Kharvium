/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_csv_persistence.c                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/17                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "support/test_csv_persistence_support.h"

/*
** Rôle: check_v2_header — Vérifie v2 header.
** Paramètre: header — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence.c -> check_v2_header() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ASSERT_STR_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_v2_header(const char *header)
{
	ASSERT_STR_EQ(header,
		"timestamp_unix,event_type,target_or_item,qty,value_uPED5,"
		"kill_id,flags,raw");
	return (0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_v2_header(),
**            test_csv_clear_roundtrip(), test_csv_legacy_rewrite(),
**            test_csv_money_migration(), test_csv_paths_init(),
**            test_csv_rewrite_roundtrip().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_persistence.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> ASSERT_I64_EQ().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_test_csv_paths	paths;

	test_csv_paths_init(&paths);
	ASSERT_I64_EQ(test_csv_rewrite_roundtrip(&paths), 0);
	ASSERT_I64_EQ(check_v2_header(paths.header), 0);
	ASSERT_I64_EQ(test_csv_clear_roundtrip(&paths), 0);
	ASSERT_I64_EQ(check_v2_header(paths.header), 0);
	ASSERT_I64_EQ(test_csv_legacy_rewrite(&paths), 0);
	ASSERT_I64_EQ(test_csv_money_migration(&paths), 0);
	return (0);
}
