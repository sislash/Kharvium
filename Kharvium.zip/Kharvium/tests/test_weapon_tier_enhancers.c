/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_weapon_tier_enhancers.c                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config/weapon_config.h"
#include "finance/finance_book.h"
#include "finance/finance_equipment.h"
#include "integration/tracker_finance.h"
#include "common/money.h"
#include "support/test_weapon_tier_support.h"
#include "platform/platform_file_system.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: run_weapon_roundtrip — Exécute arme roundtrip.
** Paramètre: input — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_weapon_check_database(),
**            test_weapon_check_finance_bridge(),
**            test_weapon_write_profile(), weapon_database_free(),
**            weapon_database_load(), weapon_database_save().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_weapon_tier_enhancers.c -> run_weapon_roundtrip() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	run_weapon_roundtrip(const char *input, const char *output)
{
	t_weapon_database	first;
	t_weapon_database	second;
	int			ok;

	memset(&first, 0, sizeof(first));
	memset(&second, 0, sizeof(second));
	ok = test_weapon_write_profile(input);
	ok = ok && weapon_database_load(&first, input);
	ok = ok && test_weapon_check_database(&first);
	ok = ok && test_weapon_check_finance_bridge(&first);
	if (ok)
		first.items[0].enhancers[0].break_count = 7;
	ok = ok && weapon_database_save(&first, output);
	ok = ok && weapon_database_load(&second, output);
	ok = ok && test_weapon_check_database(&second);
	weapon_database_free(&second);
	weapon_database_free(&first);
	return (ok);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_process_id(),
**            run_weapon_roundtrip().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_weapon_tier_enhancers.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf(), printf(),
**              remove(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf(), remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	char	input[256];
	char	output[256];
	int	ok;

	snprintf(input, sizeof(input), "bin/tests/weapon_%d.ini",
		platform_process_id());
	snprintf(output, sizeof(output), "bin/tests/weapon_%d_out.ini",
		platform_process_id());
	ok = run_weapon_roundtrip(input, output);
	(void)remove(input);
	(void)remove(output);
	if (!ok)
		return (fprintf(stderr, "test_weapon_tier_enhancers: FAIL\n"), 1);
	printf("test_weapon_tier_enhancers: OK\n");
	return (0);
}
