/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_invariants.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_calculations.h"
#include "finance/finance_capital.h"
#include "common/money.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: ped — Convertit le texte PED fourni en représentation monétaire
**       entière du projet et retourne zéro si le montant ne peut pas être
**       analysé.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: check_deposit_lifecycle(), check_stock_cost_conservation(),
**            check_withdrawal_lifecycle(), check_market_unit_quantity(),
**            check_market_unit_stock_value(), check_percent_and_plus().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_invariants.c -> ped() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static t_money	ped(const char *text)
{
	t_money	value;

	value = 0;
	if (!money_parse_ped(text, &value))
		return (0);
	return (value);
}

/*
** Rôle: check_stock_cost_conservation — Vérifie stock cost conservation.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; les montants persistants restent en représentation
**             entière fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize(), finance_book_stock_add(),
**            finance_book_stock_take(), money_add(), ped().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_invariants.c -> check_stock_cost_conservation()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=1; appels projet directs=6; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_stock_cost_conservation(void)
{
	t_finance_book	book;
	t_finance_stock	stock;
	t_money		cost;
	t_money		total;
	int		index;

	finance_book_initialize(&book, 0);
	memset(&stock, 0, sizeof(stock));
	snprintf(stock.item, sizeof(stock.item), "%s", "Ore");
	stock.quantity = 3;
	stock.cost_total_uPED = ped("1.00000");
	stock.cost_known = 1;
	if (!finance_book_stock_add(&book, &stock))
		return (finance_book_destroy(&book), 0);
	total = 0;
	index = 0;
	while (index++ < 3 && finance_book_stock_take(&book, "Ore", 1, &cost))
		total = money_add(total, cost);
	finance_book_destroy(&book);
	return (index == 4 && total == ped("1.00000"));
}

/*
** Rôle: check_deposit_lifecycle — Vérifie dépôt lifecycle.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize(), finance_deposit_cancel(),
**            finance_deposit_record(), finance_summary_build(), ped().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_invariants.c -> check_deposit_lifecycle() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, fiat/EUR.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_deposit_lifecycle(void)
{
	t_finance_book	book;
	t_finance_deposit	deposit;
	t_finance_summary	summary;
	size_t		index;
	int		ok;

	finance_book_initialize(&book, 0);
	memset(&deposit, 0, sizeof(deposit));
	snprintf(deposit.currency, sizeof(deposit.currency), "%s", "EUR");
	deposit.gross_fiat_x1e4 = 1000000;
	deposit.fee_fiat_x1e4 = 50000;
	deposit.ped_per_currency_uPED = ped("10.00000");
	deposit.mode = FIN_DEPOSIT_RATE;
	ok = finance_deposit_record(&book, &deposit, &index);
	finance_summary_build(&book, &summary);
	ok = ok && summary.cash_balance_uPED == ped("950.00000");
	ok = ok && finance_deposit_cancel(&book, index);
	finance_summary_build(&book, &summary);
	ok = ok && summary.cash_balance_uPED == 0;
	finance_book_destroy(&book);
	return (ok);
}

/*
** Rôle: check_withdrawal_lifecycle — Vérifie retrait lifecycle.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize(), finance_summary_build(),
**            finance_withdrawal_commit(), finance_withdrawal_receive(),
**            finance_withdrawal_request(), ped().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_invariants.c -> check_withdrawal_lifecycle() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, fiat/EUR.
** Performance: boucles while locales=0; appels projet directs=7; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_withdrawal_lifecycle(void)
{
	t_finance_book	book;
	t_finance_withdrawal	value;
	t_finance_summary	summary;
	size_t		index;
	int		ok;

	finance_book_initialize(&book, ped("2000.00000"));
	memset(&value, 0, sizeof(value));
	value.requested_uPED = ped("1000.00000");
	value.mindark_fee_uPED = ped("100.00000");
	ok = finance_withdrawal_request(&book, &value, &index);
	finance_summary_build(&book, &summary);
	ok = ok && summary.capital_rce_adjusted_uPED == ped("2000.00000");
	ok = ok && finance_withdrawal_commit(&book, index, 10);
	value.received_fiat_x1e4 = 900000;
	snprintf(value.currency, sizeof(value.currency), "%s", "EUR");
	ok = ok && finance_withdrawal_receive(&book, index, &value);
	finance_summary_build(&book, &summary);
	ok = ok && summary.withdrawal_received_uPED == ped("900.00000");
	ok = ok && summary.capital_rce_adjusted_uPED == ped("1900.00000");
	finance_book_destroy(&book);
	return (ok);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_deposit_lifecycle(),
**            check_stock_cost_conservation(), check_withdrawal_lifecycle().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_invariants.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	if (!check_stock_cost_conservation() || !check_deposit_lifecycle())
		return (1);
	if (!check_withdrawal_lifecycle())
		return (1);
	printf("test_finance_accounting_invariants: OK\n");
	return (0);
}
