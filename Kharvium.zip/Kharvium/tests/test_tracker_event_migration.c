/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_tracker_event_migration.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "support/test_tracker_e87_support.h"
#include "io/hunt_csv.h"
#include "io/tracker_event_csv.h"
#include "platform/platform_time.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: make_paths — Construit les deux fichiers temporaires utilisés pour
**       la migration Hunt V3 vers Tracker V4.
** Paramètre: hunt — destination du chemin source V3.
** Paramètre: events — destination du chemin V4.
** Retour: aucun.
** Effets: remplit les buffers bornés.
** Invariants: les noms sont uniques pour l'exécution courante.
** Relations: appelle directement -> tracker_event_csv_sibling_path().
** Appelants: main().
** Mémoire: aucune allocation.
** I/O: aucune.
** Unités: millisecondes.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_event_migration.c -> make_paths() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test directement utilisées par le
**            corps.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
static int	make_paths(char *hunt, char *events)
{
	unsigned long long	now;

	now = (unsigned long long)platform_time_milliseconds();
	snprintf(hunt, 256, "bin/tests/e85_migrate_%llu.csv", now);
	ASSERT_TRUE(tracker_event_csv_sibling_path(hunt, events, 256));
	return (0);
}

/*
** Rôle: write_v3 — Génère un petit historique V3 contenant une enveloppe
**       Hunting puis une enveloppe Fishing, chacune avec un loot enfant.
** Paramètre: path — destination V3 temporaire.
** Retour: aucun; échec géré par assertions.
** Effets: écrit quatre lignes historiques après l'en-tête V3.
** Invariants: les kill_id 10/11 sont les seules clés parent disponibles.
** Relations: appelle directement -> hunt_csv_ensure_header_v3(),
**            hunt_csv_write_v2().
** Appelants: main().
** Mémoire: aucune allocation.
** I/O: écriture fichier temporaire.
** Unités: uPED et kill_id.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_event_migration.c -> write_v3() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test directement utilisées par le
**            corps.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
static int	write_v3(const char *path)
{
	FILE	*file;

	file = fopen(path, "wb+");
	ASSERT_TRUE(file != NULL);
	hunt_csv_ensure_header_v3(file);
	ASSERT_TRUE(hunt_csv_write_v2(file, &(t_hunt_csv_row_view){100,
		"KILL", "Atrox", 1, 0, 0, 10, 2u, "hunt root"}) == 0);
	ASSERT_TRUE(hunt_csv_write_v2(file, &(t_hunt_csv_row_view){100,
		"LOOT_ITEM", "Shrapnel", 50, 500, 1, 10, 3u, "hunt loot"}) == 0);
	ASSERT_TRUE(hunt_csv_write_v2(file, &(t_hunt_csv_row_view){200,
		"KILL_FISHING", "Blue Snapper", 1, 0, 0, 11, 2u,
		"fish root"}) == 0);
	ASSERT_TRUE(hunt_csv_write_v2(file, &(t_hunt_csv_row_view){200,
		"LOOT_ITEM", "Fish Scrap", 280, 2800, 1, 11, 3u,
		"fish loot"}) == 0);
	fclose(file);
	return (0);
}

/*
** Rôle: check_v4 — Vérifie que la migration conserve envelope_id et relie
**       chaque loot au véritable event_id de sa racine avec la bonne activité.
** Paramètre: path — fichier V4 migré.
** Retour: aucun; les assertions vérifient quatre événements ordonnés.
** Effets: lit puis ferme le fichier.
** Invariants: tous les événements migrés appartiennent à la session legacy 1.
** Relations: appelle directement -> tracker_event_csv_parse_line().
** Appelants: main().
** Mémoire: aucune allocation.
** I/O: lecture du sidecar migré.
** Unités: identifiants et uPED.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_event_migration.c -> check_v4() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test utilisées directement.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions.
*/
static int	check_v4(const char *path)
{
	t_tracker_event_record	row;
	char			line[4096];
	FILE			*file;
	int			count;

	file = fopen(path, "rb");
	ASSERT_TRUE(file != NULL);
	count = 0;
	while (fgets(line, sizeof(line), file))
	{
		if (!tracker_event_csv_parse_line(line, &row))
			continue ;
		count++;
		TEST_RUN(test_tracker_e87_migration_row(&row, count));
	}
	fclose(file);
	ASSERT_I64_EQ(count, 5);
	return (0);
}

/*
** Rôle: main — Exécute la migration atomique V3→V4 et contrôle que la source
**       V3 reste encore lisible après l'opération.
** Retour: 0 lorsque migration, parentage et compatibilité réussissent.
** Effets: crée et supprime deux fichiers temporaires.
** Invariants: aucune donnée du projet ou utilisateur réel n'est modifiée.
** Relations: appelle directement -> check_v4(), hunt_csv_parse_row_inplace(),
**            make_paths(), tracker_event_csv_migrate_v3(), write_v3().
** Appelants: aucun.
** Mémoire: aucune allocation dynamique directe.
** I/O: fichiers temporaires bin/tests.
** Unités: identifiants persistants.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_tracker_event_migration.c -> main() (chemin complet dans
**        l’index).
** Dépendances: stdio/string et macros de test directement utilisées par le
**            corps.
** État partagé: aucun symbole global mutable référencé directement.
** Concurrence: test mono-thread; fixtures temporaires détenus par ce processus.
** Performance: fixture borné; coût dominé par les I/O et assertions du test.
*/
int	main(void)
{
	t_hunt_csv_row_view	row;
	char			hunt[256];
	char			events[256];
	char			line[4096];
	FILE			*file;

	TEST_RUN(make_paths(hunt, events));
	(void)remove(hunt);
	(void)remove(events);
	TEST_RUN(write_v3(hunt));
	ASSERT_TRUE(tracker_event_csv_migrate_v3(hunt, events));
	TEST_RUN(check_v4(events));
	file = fopen(hunt, "rb");
	ASSERT_TRUE(file != NULL);
	ASSERT_TRUE(fgets(line, sizeof(line), file) != NULL);
	ASSERT_TRUE(fgets(line, sizeof(line), file) != NULL);
	ASSERT_TRUE(hunt_csv_parse_row_inplace(line, &row));
	ASSERT_I64_EQ(row.id_kill, 10);
	fclose(file);
	(void)remove(hunt);
	(void)remove(events);
	return (0);
}
