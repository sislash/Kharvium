/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_canonical_refs.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_operations.h"
#include "finance/finance_persistence.h"
#include "common/money.h"
#include <stdio.h>
#include <string.h>

#define REF_FILE "tests/.tmp_finance_refs.csv"
#define LEGACY_REF_FILE "tests/.tmp_finance_refs_v6.csv"

/*
** Rôle: canonical_add_market — Ajoute un prix Fish Scrap lié au catalogue et
**       une observation Calypso afin de tester les deux références canoniques.
** Paramètre: book — registre Finance modifié par l'opération.
** Retour: Retourne 1 si prix et observation sont enregistrés, 0 sinon.
** Effets: ajoute un prix courant et un market sample.
** Invariants: item_type_id=1005 et world_id=2001 restent distincts du texte.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement ->
**            finance_record_market_sample_with_provenance().
** Appelants: canonical_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_canonical_refs.c -> canonical_add_market().
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: allocations éventuelles déléguées au finance_book.
** État partagé: aucun.
** Concurrence: test séquentiel.
** I/O: aucune E/S directe.
** Unités: identifiants canoniques et timestamp Unix.
** Performance: O(1) amorti.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	canonical_add_market(t_finance_book *book)
{
	t_finance_price		price;
	t_finance_market_context	context;

	memset(&price, 0, sizeof(price));
	memset(&context, 0, sizeof(context));
	snprintf(price.name, sizeof(price.name), "Fish Scrap");
	price.item_type_id = 1005;
	price.market_mode = FIN_MARKET_UNIT;
	money_parse_ped("0.00020", &price.market_unit_uPED);
	context.timestamp = 1788033600;
	context.world_id = 2001;
	context.provenance.evidence = EVIDENCE_MANUAL;
	context.provenance.quality = DATA_COMPLETE;
	return (finance_record_market_sample_with_provenance(book, &price,
			&context));
}

/*
** Rôle: canonical_add_trade — Vérifie la propagation d'un item_type_id depuis
**       un achat vers le stock puis vers une vente qui partait avec UNKNOWN.
** Paramètre: book — registre Finance modifié par achats, stock et vente.
** Retour: Retourne 1 si la propagation et les opérations réussissent.
** Effets: ajoute un achat, un stock puis une vente partielle.
** Invariants: le stock Baitfish et la vente finale conservent l'ID 1004.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_record_purchase(),
**            finance_record_sale().
** Appelants: canonical_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_canonical_refs.c -> canonical_add_trade().
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: allocations éventuelles déléguées au finance_book.
** État partagé: aucun.
** Concurrence: test séquentiel.
** I/O: aucune E/S directe.
** Unités: quantité, uPED et identifiant canonique.
** Performance: scénario constant.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	canonical_add_trade(t_finance_book *book)
{
	t_finance_purchase	purchase;
	t_finance_sale		sale;

	memset(&purchase, 0, sizeof(purchase));
	memset(&sale, 0, sizeof(sale));
	purchase.timestamp = 1788033610;
	purchase.item_type_id = 1004;
	purchase.quantity = 10;
	money_parse_ped("0.00001", &purchase.tt_unit_uPED);
	money_parse_ped("1.00000", &purchase.total_uPED);
	snprintf(purchase.item, sizeof(purchase.item), "Baitfish");
	if (!finance_record_purchase(book, &purchase))
		return (0);
	sale.timestamp = 1788033620;
	sale.quantity = 2;
	money_parse_ped("0.30000", &sale.revenue_uPED);
	snprintf(sale.item, sizeof(sale.item), "Baitfish");
	return (finance_record_sale(book, &sale)
		&& sale.item_type_id == 1004);
}

/*
** Rôle: canonical_add_activity — Ajoute une activité dont le monde, le
**       consommable et le loot portent leurs références canoniques E84.
** Paramètre: book — registre Finance recevant l'activité.
** Retour: Retourne le résultat de finance_book_add_activity().
** Effets: ajoute une activité complète minimale.
** Invariants: les noms humains restent présents en parallèle des IDs.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_add_activity().
** Appelants: canonical_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_canonical_refs.c -> canonical_add_activity().
** Dépendances: appels externes/macros directs -> memset(), snprintf().
** Mémoire: allocation éventuelle déléguée au finance_book.
** État partagé: aucun.
** Concurrence: test séquentiel.
** I/O: aucune E/S directe.
** Unités: identifiants canoniques et quantités.
** Performance: O(1) amorti.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	canonical_add_activity(t_finance_book *book)
{
	t_finance_activity	activity;

	memset(&activity, 0, sizeof(activity));
	activity.id = 77;
	activity.world_id = 2001;
	activity.consumable_count = 1;
	activity.consumables[0].item_type_id = 1007;
	activity.consumables[0].quantity = 50;
	snprintf(activity.consumables[0].item,
		sizeof(activity.consumables[0].item), "Spool Cell");
	activity.loot_count = 1;
	activity.loot[0].item_type_id = 1005;
	activity.loot[0].quantity = 250;
	snprintf(activity.loot[0].item,
		sizeof(activity.loot[0].item), "Fish Scrap");
	snprintf(activity.location, sizeof(activity.location), "Calypso");
	return (finance_book_add_activity(book, &activity));
}

/*
** Rôle: canonical_roundtrip — Vérifie que Finance v7 sauvegarde puis relit
**       les références items/mondes sans perdre les textes historiques.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 1 si toutes les références survivent au round-trip.
** Effets: crée, sauvegarde et recharge un registre temporaire.
** Invariants: les IDs positifs restent identiques après persistance.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> canonical_add_activity(),
**            canonical_add_market(), canonical_add_trade(),
**            finance_book_destroy(), finance_book_initialize(),
**            finance_book_load(), finance_book_save().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_canonical_refs.c -> canonical_roundtrip().
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: toutes les collections sont libérées par finance_book_destroy().
** État partagé: aucun.
** Concurrence: test séquentiel sur un fichier dédié.
** I/O: persistance Finance sur fixture temporaire.
** Unités: identifiants canoniques, uPED et quantités.
** Performance: scénario constant.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	canonical_roundtrip(void)
{
	t_finance_book	book;
	t_finance_book	loaded;
	int			ok;

	finance_book_initialize(&book, 0);
	finance_book_initialize(&loaded, 0);
	ok = canonical_add_market(&book) && canonical_add_trade(&book);
	ok = ok && canonical_add_activity(&book);
	ok = ok && finance_book_save(&book, REF_FILE);
	ok = ok && finance_book_load(&loaded, REF_FILE);
	ok = ok && loaded.price_count == 1 && loaded.prices[0].item_type_id == 1005;
	ok = ok && loaded.market_sample_count == 1;
	ok = ok && loaded.market_samples[0].item_type_id == 1005;
	ok = ok && loaded.market_samples[0].world_id == 2001;
	ok = ok && loaded.stock_count == 1 && loaded.stocks[0].item_type_id == 1004;
	ok = ok && loaded.sale_count == 1 && loaded.sales[0].item_type_id == 1004;
	ok = ok && loaded.activity_count == 1;
	ok = ok && loaded.activities[0].world_id == 2001;
	ok = ok && loaded.activities[0].consumables[0].item_type_id == 1007;
	ok = ok && loaded.activities[0].loot[0].item_type_id == 1005;
	finance_book_destroy(&loaded);
	finance_book_destroy(&book);
	return (ok);
}

/*
** Rôle: main — Exécute les régressions de migration canonique E84 et nettoie
**       les fixtures temporaires quel que soit le résultat.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 en cas de succès complet, 1 sinon.
** Effets: supprime les fixtures et écrit le statut du test sur stdout.
** Invariants: aucun fichier temporaire ne subsiste après l'exécution normale.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> canonical_roundtrip().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_canonical_refs.c -> main().
** Dépendances: appels externes/macros directs -> printf(), remove().
** Mémoire: aucune allocation directe.
** État partagé: aucun.
** Concurrence: exécution séquentielle.
** I/O: nettoyage des fixtures et sortie stdout.
** Unités: aucune unité métier supplémentaire.
** Performance: coût constant hors petites E/S de test.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	int	ok;

	ok = canonical_roundtrip();
	(void)remove(REF_FILE);
	(void)remove(LEGACY_REF_FILE);
	if (!ok)
		return (1);
	printf("test_finance_canonical_refs: OK\n");
	return (0);
}
