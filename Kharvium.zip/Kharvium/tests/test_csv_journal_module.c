/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_csv_journal_module.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29 16:30:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/29 16:30:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "io/csv_data.h"
#include "io/csv_index.h"
#include "platform/file_system.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: prepare_snapshot — Prépare snapshot.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_data_save().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_journal_module.c -> prepare_snapshot() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	prepare_snapshot(const char *path)
{
	t_csv_data		data;
	t_csv_data_row	row;

	memset(&data, 0, sizeof(data));
	memset(&row, 0, sizeof(row));
	row.timestamp = 100;
	row.event_type = "snapshot";
	row.value = 1.0;
	data.rows = &row;
	data.count = 1;
	data.capacity = 1;
	return (csv_data_save(path, &data, NULL, NULL));
}

/*
** Rôle: append_journal — Ajoute journal.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_journal_append_data_row(),
**            csv_journal_options_default().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_journal_module.c -> append_journal() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	append_journal(const char *path)
{
	t_csv_data_row		row;
	t_csv_journal_options	options;
	t_csv_journal_report	report;

	memset(&row, 0, sizeof(row));
	csv_journal_options_default(&options);
	options.journal_index_stride_rows = 1;
	row.timestamp = 200;
	row.event_type = "loot";
	row.value = 2.0;
	if (!csv_journal_append_data_row(path, &row, &options, &report))
		return (0);
	row.timestamp = 300;
	row.event_type = "cost";
	row.value = 3.0;
	return (csv_journal_append_data_row(path, &row, &options, &report));
}

/*
** Rôle: verify_load — Charge l’état associé à verify.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_data_free(),
**            csv_journal_load_since(), csv_load_options_default().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_journal_module.c -> verify_load() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	verify_load(const char *path)
{
	t_csv_data		*data;
	t_csv_load_options	options;

	csv_load_options_default(&options);
	data = csv_journal_load_since(path, 200, &options, NULL);
	if (!data)
		return (0);
	if (data->count != 2 || data->rows[0].timestamp != 200)
		return (csv_data_free(data), 0);
	csv_data_free(data);
	return (1);
}

/*
** Rôle: verify_rotate — Vérifie rotate.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_data_free(), csv_data_load(),
**            csv_journal_rotate_if_needed(),
**            csv_journal_rotate_options_default(),
**            file_system_file_exists().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_journal_module.c -> verify_rotate() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	verify_rotate(const char *path)
{
	t_csv_journal_rotate_options	rotate;
	t_csv_journal_rotation_request	request;
	t_csv_journal_rotate_report	report;
	t_csv_data			*data;

	csv_journal_rotate_options_default(&rotate);
	rotate.max_journal_bytes = 0;
	rotate.max_journal_rows = 2;
	rotate.archive_old_journal = 0;
	rotate.index_stride_rows = 1;
	memset(&request, 0, sizeof(request));
	request.base_csv = path;
	request.rotate_options = &rotate;
	if (!csv_journal_rotate_if_needed(&request, &report) || !report.rotated)
		return (0);
	if (file_system_file_exists("/tmp/kharvium_journal.csv.journal"))
		return (0);
	data = csv_data_load(path, NULL, NULL);
	if (!data || data->count != 3)
		return (csv_data_free(data), 0);
	return (csv_data_free(data), 1);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> append_journal(), csv_index_remove(),
**            prepare_snapshot(), verify_load(), verify_rotate().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_csv_journal_module.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> printf(), remove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	const char	*path;

	path = "/tmp/kharvium_journal.csv";
	remove(path);
	remove("/tmp/kharvium_journal.csv.journal");
	csv_index_remove(path);
	csv_index_remove("/tmp/kharvium_journal.csv.journal");
	if (!prepare_snapshot(path) || !append_journal(path)
		|| !verify_load(path) || !verify_rotate(path))
		return (1);
	csv_index_remove(path);
	remove(path);
	printf("test_csv_journal_module: OK\n");
	return (0);
}
