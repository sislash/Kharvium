/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_activity_analysis.c                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_activity.h"
#include "finance/finance_analysis.h"
#include "finance/finance_book.h"
#include "finance/finance_equipment.h"
#include "finance/finance_persistence.h"
#include "platform/platform_file_system.h"

#include "common/money.h"
#include "support/test_fin_activity_support.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: commit_runs — Valide et applique runs.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_activity_commit(),
**            test_fin_activity_build_run().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_activity_analysis.c -> commit_runs() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	commit_runs(t_finance_book *book)
{
	t_finance_activity	run;

	if (!test_fin_activity_build_run(&run, 1000, "Atrox", "Camp Icarus"))
		return (0);
	if (!finance_activity_commit(book, &run, NULL))
		return (0);
	if (!test_fin_activity_build_run(&run, 2000, "Atrox", "Fort Ithaca"))
		return (0);
	if (!finance_activity_commit(book, &run, NULL))
		return (0);
	return (1);
}

/*
** Rôle: check_aggregate — Vérifie aggregate.
** Paramètre: agg — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> test_fin_activity_amount().
** Appelants: check_analysis().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_activity_analysis.c -> check_aggregate() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_aggregate(const t_finance_activity_aggregate *agg,
	size_t count)
{
	if (!agg || agg->run_count != count)
		return (0);
	if (agg->input_tt_uPED[FIN_ACTIVITY_INPUT_AMMO]
		!= test_fin_activity_amount("4.00000"))
		return (0);
	if (agg->input_book_uPED[FIN_ACTIVITY_INPUT_AMMO]
		!= test_fin_activity_amount("6.00000"))
		return (0);
	if (agg->decay_uPED[FIN_ACTIVITY_DECAY_WEAPON]
		!= test_fin_activity_amount("2.00000"))
		return (0);
	if (agg->cycle_tt_uPED != test_fin_activity_amount("10.00000"))
		return (0);
	return (agg->loot_market_uPED == test_fin_activity_amount("18.00000"));
}

/*
** Rôle: check_analysis — Vérifie analyse.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_aggregate(),
**            finance_analysis_latest(), finance_analysis_period(),
**            finance_analysis_recent(), finance_analysis_tag().
** Appelants: check_roundtrip(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_activity_analysis.c -> check_analysis() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_analysis(const t_finance_book *book)
{
	t_finance_activity_aggregate	agg;
	const t_finance_activity	*latest;

	if (!finance_analysis_recent(book,
			&(t_finance_recent_request){10, {1, FIN_ACTIVITY_HUNT}}, &agg))
		return (0);
	if (!check_aggregate(&agg, 2))
		return (0);
	if (!finance_analysis_period(book,
			&(t_finance_period_request){0, 3000, {0, FIN_ACTIVITY_OTHER}},
			&agg))
		return (0);
	if (!check_aggregate(&agg, 2))
		return (0);
	if (!finance_analysis_tag(book, FIN_ACTIVITY_TAG_TARGET, "Atrox", &agg))
		return (0);
	if (!check_aggregate(&agg, 2))
		return (0);
	if (!finance_analysis_tag(book, FIN_ACTIVITY_TAG_LOCATION,
			"Camp Icarus", &agg) || agg.run_count != 1)
		return (0);
	latest = finance_analysis_latest(book);
	if (!latest || strcmp(latest->location, "Fort Ithaca") != 0)
		return (0);
	return (strcmp(latest->setup, "ArMatrix LR-35 + A105") == 0);
}

/*
** Rôle: check_roundtrip — Vérifie roundtrip.
** Paramètre: book — registre Finance contenant les écritures et agrégats
**            métier.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : book.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_analysis(),
**            finance_book_destroy(), finance_book_initialize_new(),
**            finance_book_load(), finance_book_save(),
**            platform_process_id().
** Appelants: main(), main(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_activity_analysis.c -> check_roundtrip() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> remove(), snprintf(),
**              strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	check_roundtrip(t_finance_book *book)
{
	t_finance_book	loaded;
	char		path[256];
	int		ok;

	snprintf(path, sizeof(path), "bin/tests/finance_f17_%d.csv",
		platform_process_id());
	if (!finance_book_save(book, path))
		return (0);
	finance_book_initialize_new(&loaded);
	ok = finance_book_load(&loaded, path);
	if (ok)
		ok = loaded.activity_count == 2;
	if (ok)
		ok = strcmp(loaded.activities[0].target, "Atrox") == 0;
	if (ok)
		ok = loaded.activities[0].consumables[0].kind
			== FIN_ACTIVITY_INPUT_AMMO;
	if (ok)
		ok = loaded.activities[0].decays[0].kind
			== FIN_ACTIVITY_DECAY_WEAPON;
	if (ok)
		ok = check_analysis(&loaded);
	finance_book_destroy(&loaded);
	(void)remove(path);
	return (ok);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les montants persistants restent en
**             représentation entière fixe, sans dépendre d’un prix supposé
**             immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> check_analysis(), check_roundtrip(),
**            commit_runs(), finance_book_destroy(),
**            finance_book_initialize(), test_fin_activity_add_price(),
**            test_fin_activity_amount(), test_fin_activity_seed_equipment()
**            (+1; index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_finance_activity_analysis.c -> main() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf(), printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=9; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_finance_book	book;
	int		ok;

	finance_book_initialize(&book, test_fin_activity_amount("1000.00000"));
	ok = test_fin_activity_add_price(&book, "Universal Ammo",
		"1.00000", "1.00000");
	ok = ok && test_fin_activity_add_price(&book, "Animal Oil",
		"2.00000", "3.00000");
	ok = ok && test_fin_activity_seed_stock(&book);
	ok = ok && test_fin_activity_seed_equipment(&book);
	ok = ok && commit_runs(&book) && check_analysis(&book);
	ok = ok && check_roundtrip(&book);
	finance_book_destroy(&book);
	if (!ok)
		return (fprintf(stderr, "test_finance_activity_analysis: FAIL\n"), 1);
	printf("test_finance_activity_analysis: OK\n");
	return (0);
}
