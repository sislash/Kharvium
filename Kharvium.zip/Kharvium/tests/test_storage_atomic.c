/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_storage_atomic.c                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/27                               #+#    #+#             */
/*   Updated: 2026/08/27                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "storage/atomic_file.h"
#include "support/test_storage_atomic_support.h"
#include "platform/platform_file_system.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: read_matches — Lit matches.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: expected — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: test_commit(), test_failed_replace_keeps_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_storage_atomic.c -> read_matches() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fgets(), fopen(),
**              memset(), strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	read_matches(const char *path, const char *expected)
{
	FILE	*stream;
	char	buffer[64];

	stream = fopen(path, "rb");
	if (!stream)
		return (0);
	memset(buffer, 0, sizeof(buffer));
	if (!fgets(buffer, sizeof(buffer), stream))
	{
		fclose(stream);
		return (0);
	}
	fclose(stream);
	return (strcmp(buffer, expected) == 0);
}

/*
** Rôle: test_temp_paths — Formate temp paths dans le buffer destination
**       fourni, avec une taille explicitement bornée par l’appelant.
** Paramètre: destination — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> storage_temp_path().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_storage_atomic.c -> test_temp_paths() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_temp_paths(const char *destination)
{
	char	first[512];
	char	second[512];

	if (!storage_temp_path(first, sizeof(first), destination))
		return (0);
	if (!storage_temp_path(second, sizeof(second), destination))
		return (0);
	if (strcmp(first, second) == 0)
		return (0);
	if (strstr(first, destination) != first)
		return (0);
	return (1);
}

/*
** Rôle: test_commit — Valide et applique l’état associé à test.
** Paramètre: destination — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> read_matches(), storage_discard_temp(),
**            storage_replace_temp(), storage_temp_path(),
**            test_storage_write_temp().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_storage_atomic.c -> test_commit() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_commit(const char *destination)
{
	char	tmp_path[512];

	if (!storage_temp_path(tmp_path, sizeof(tmp_path), destination))
		return (0);
	if (!test_storage_write_temp(tmp_path, "atomic-storage-ok\n"))
	{
		storage_discard_temp(tmp_path);
		return (0);
	}
	if (!storage_replace_temp(tmp_path, destination))
		return (0);
	if (!read_matches(destination, "atomic-storage-ok\n"))
		return (0);
	return (1);
}

/*
** Rôle: test_failed_replace_keeps_file — Formate failed replace keeps dans le
**       buffer destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: destination — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> read_matches(), storage_discard_temp(),
**            storage_replace_temp(), storage_temp_path().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_storage_atomic.c -> test_failed_replace_keeps_file() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	test_failed_replace_keeps_file(const char *destination)
{
	char	missing[512];

	if (!storage_temp_path(missing, sizeof(missing), destination))
		return (0);
	storage_discard_temp(missing);
	if (storage_replace_temp(missing, destination))
		return (0);
	if (!read_matches(destination, "atomic-storage-ok\n"))
		return (0);
	return (1);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_process_id(), test_commit(),
**            test_failed_replace_keeps_file(), test_temp_paths().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_storage_atomic.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> printf(), remove(),
**              snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	char	destination[256];
	int		pid;

	pid = platform_process_id();
	snprintf(destination, sizeof(destination),
		"bin/tests/storage_atomic_%d.txt", pid);
	if (!test_temp_paths(destination))
		return (1);
	if (!test_commit(destination))
		return (1);
	if (!test_failed_replace_keeps_file(destination))
		return (1);
	(void)remove(destination);
	printf("test_storage_atomic: OK\n");
	return (0);
}
