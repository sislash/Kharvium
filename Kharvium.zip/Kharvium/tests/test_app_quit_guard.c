/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_app_quit_guard.c                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "app/app_quit_guard.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: expect_state — Consulte ou prépare l’état nécessaire à expect.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: expected — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : app.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_quit_guard_state().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_quit_guard.c -> expect_state() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	expect_state(t_app *app, t_app_quit_guard expected,
	const char *name)
{
	if (app_quit_guard_state(app) == expected)
		return (1);
	fprintf(stderr, "[quit_guard] FAIL: %s\n", name);
	return (0);
}

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> expect_state().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        test_app_quit_guard.c -> main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), printf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_app	app;

	memset(&app, 0, sizeof(app));
	if (!expect_state(&app, APP_QUIT_SAFE, "clean"))
		return (1);
	app.finance_activity_draft_active = 1;
	if (!expect_state(&app, APP_QUIT_ACTIVITY_DRAFT, "draft"))
		return (1);
	app.finance_form = FIN_FORM_PURCHASE;
	if (!expect_state(&app, APP_QUIT_FINANCE_FORM, "form"))
		return (1);
	app.finance_dirty = 1;
	if (!expect_state(&app, APP_QUIT_UNSAVED_FINANCE, "unsaved"))
		return (1);
	printf("[quit_guard] OK\n");
	return (0);
}
