/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_fishing_rod_custom.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "test_util.h"
#include "support/test_fishing_rod_config_support.h"
#include "support/test_fishing_rod_custom_support.h"
#include "config/fishing_rod_config.h"
#include <string.h>

#define TMP_CUSTOM_INI "tests/.tmp_fishing_custom.ini"

/*
** Rôle: check_custom_roundtrip — Vérifie construction, sauvegarde, recharge
**       et application du preset personnalisé E91.
** Relations: test_fishing_rod_load_config(),
**            test_fishing_custom_build_standard(),
**            fishing_rod_database_upsert_preset(), fishing_rod_database_save().
** Appelants: main().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_custom_roundtrip().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static int	check_custom_roundtrip(void)
{
	t_catalog_registry	registry;
	t_fishing_rod_database	database;
	t_fishing_rod_database	reloaded;
	t_fishing_rod_preset	preset;
	t_fishing_loadout_snapshot snapshot;

	ASSERT_TRUE(test_fishing_rod_load_config(&registry, &database));
	ASSERT_TRUE(test_fishing_custom_build_standard(&preset, &database,
			&registry));
	ASSERT_TRUE(preset.complete);
	ASSERT_TRUE(fishing_rod_database_upsert_preset(&database, &preset,
			&registry));
	ASSERT_TRUE(fishing_rod_database_save(&database, TMP_CUSTOM_INI));
	fishing_rod_database_initialize(&reloaded);
	ASSERT_TRUE(fishing_rod_database_load(&reloaded, TMP_CUSTOM_INI,
			&registry));
	ASSERT_TRUE(fishing_rod_preset_apply(&snapshot,
			fishing_rod_database_find(&reloaded, FISHING_ROD_CUSTOM_NAME),
			&registry));
	ASSERT_I64_EQ(snapshot.components[0].item_type_id, 1301);
	fishing_rod_database_free(&reloaded);
	test_fishing_rod_cleanup_config(&registry, &database);
	(void)remove(TMP_CUSTOM_INI);
	return (0);
}

/*
** Rôle: check_custom_upsert — Vérifie qu'une seconde sauvegarde du draft
**       personnalisé remplace l'entrée au lieu de créer un doublon.
** Relations: test_fishing_custom_build_standard(),
**            fishing_rod_database_upsert_preset().
** Appelants: main().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_custom_upsert().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static int	check_custom_upsert(void)
{
	t_catalog_registry	registry;
	t_fishing_rod_database	database;
	t_fishing_rod_preset	preset;
	size_t			before;

	ASSERT_TRUE(test_fishing_rod_load_config(&registry, &database));
	ASSERT_TRUE(test_fishing_custom_build_standard(&preset, &database,
			&registry));
	before = database.count;
	ASSERT_TRUE(fishing_rod_database_upsert_preset(&database, &preset,
			&registry));
	ASSERT_I64_EQ(database.count, before + 1);
	ASSERT_TRUE(fishing_rod_database_upsert_preset(&database, &preset,
			&registry));
	ASSERT_I64_EQ(database.count, before + 1);
	test_fishing_rod_cleanup_config(&registry, &database);
	return (0);
}

/*
** Rôle: check_baitfishing_cleanup — Vérifie qu'un changement de canne par
**       le configurateur recharge son preset par défaut et ne conserve jamais
**       les accessoires incompatibles de la canne précédente.
** Relations: fishing_rod_database_find_component(),
**            fishing_rod_preset_set_rod_default().
** Appelants: main().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_baitfishing_cleanup().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static int	check_baitfishing_cleanup(void)
{
	t_catalog_registry	registry;
	t_fishing_rod_database	database;
	t_fishing_rod_preset	preset;
	const t_fishing_rod_component	*rod;

	ASSERT_TRUE(test_fishing_rod_load_config(&registry, &database));
	ASSERT_TRUE(test_fishing_custom_build_standard(&preset, &database,
			&registry));
	rod = fishing_rod_database_find_component(&database, "Baitfishing Rod");
	ASSERT_TRUE(rod != NULL);
	ASSERT_TRUE(fishing_rod_preset_set_rod_default(&preset, &database, rod,
			&registry));
	ASSERT_TRUE(preset.complete);
	ASSERT_TRUE(strcmp(preset.name, FISHING_ROD_CUSTOM_NAME) == 0);
	ASSERT_TRUE(preset.reel_name[0] == '\0' && preset.blank_name[0] == '\0');
	ASSERT_TRUE(preset.line_name[0] == '\0' && preset.lure_name[0] == '\0');
	ASSERT_TRUE(preset.ammo_name[0] == '\0');
	test_fishing_rod_cleanup_config(&registry, &database);
	return (0);
}

/*
** Rôle: check_component_filter — Vérifie que le catalogue v2 peut alimenter
**       une liste UI filtrée par slot sans mélange de types.
** Relations: fishing_rod_database_collect_components().
** Appelants: main().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> check_component_filter().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static int	check_component_filter(void)
{
	t_catalog_registry	registry;
	t_fishing_rod_database	database;
	const t_fishing_rod_component *items[64];
	size_t			count;

	ASSERT_TRUE(test_fishing_rod_load_config(&registry, &database));
	count = fishing_rod_database_collect_components(&database,
			FISHING_GEAR_SLOT_ROD, items, 64);
	ASSERT_I64_EQ(count, 23);
	ASSERT_TRUE(items[0]->slot == FISHING_GEAR_SLOT_ROD);
	count = fishing_rod_database_collect_components(&database, -1, items, 64);
	ASSERT_I64_EQ(count, 2);
	ASSERT_TRUE(items[0]->kind == FISHING_ROD_COMPONENT_AMMO);
	test_fishing_rod_cleanup_config(&registry, &database);
	return (0);
}

/*
** Rôle: main — Exécute les régressions du configurateur Fishing E91.
** Relations: check_custom_roundtrip(), check_custom_upsert(),
**            check_baitfishing_cleanup(), check_component_filter().
** Appelants: cible make test.
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> main().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
int	main(void)
{
	TEST_RUN(check_custom_roundtrip());
	TEST_RUN(check_custom_upsert());
	TEST_RUN(check_baitfishing_cleanup());
	TEST_RUN(check_component_filter());
	return (0);
}
