/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_finance_canonical_refs_legacy.c               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29 23:30:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "finance/finance_book.h"
#include "finance/finance_persistence.h"

#include <stdio.h>

#define LEGACY_REF_FILE "tests/.tmp_finance_canonical_refs_v6.dat"

/*
** Rôle: main — Vérifie qu’une sauvegarde Finance v6 sans champs canoniques
**       reste lisible et migre vers UNKNOWN sans correspondance inventée.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne 0 si la migration conservative réussit, 1 sinon.
** Effets: crée, charge puis supprime un petit fixture Finance v6.
** Invariants: aucun item_type_id n’est déduit uniquement depuis le nom texte.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_book_destroy(),
**            finance_book_initialize(), finance_book_load().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md.
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**            fprintf(), printf(), remove().
** Mémoire: toutes les allocations du book sont libérées avant retour.
** État partagé: aucun.
** Concurrence: test séquentiel.
** I/O: fixture Finance temporaire et sortie stdout.
** Unités: identifiant canonique.
** Performance: scénario constant.
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(void)
{
	t_finance_book	book;
	FILE			*stream;
	int			ok;

	stream = fopen(LEGACY_REF_FILE, "wb");
	if (!stream)
		return (1);
	fprintf(stream, "meta;6;0.00000;;;;;;;;;;;;;\n");
	fprintf(stream, "price;Fish Scrap;3;0.00010;0;0.00020;0.00000;3;"
		"0.00000;Fishing;0;;;;;\n");
	fclose(stream);
	finance_book_initialize(&book, 0);
	ok = finance_book_load(&book, LEGACY_REF_FILE);
	ok = ok && book.price_count == 1;
	ok = ok && book.prices[0].item_type_id == ENTITY_ID_UNKNOWN;
	finance_book_destroy(&book);
	remove(LEGACY_REF_FILE);
	if (!ok)
		return (1);
	printf("test_finance_canonical_refs_legacy: OK\n");
	return (0);
}
