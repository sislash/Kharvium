/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_modal_confirm_keyboard.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main_modules.h"

/*
** Rôle: modal_confirm_keyboard — Traite les touches de navigation,
**       validation et annulation de la modale de
**       confirmation, met à jour son résultat et
**       la ferme lorsque le choix est final.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_modal_close().
** Appelants: modal_confirm_render().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_modal_confirm_keyboard.c -> modal_confirm_keyboard() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	modal_confirm_keyboard(t_modal_frame_context *ctx)
{
	if (ctx->w->key_up || ctx->w->key_down || ctx->w->key_tab)
		ctx->app->modal_selected = !ctx->app->modal_selected;
	if (ctx->w->key_escape)
		ctx->app->modal_result = -1;
	else if (ctx->w->key_enter && ctx->app->modal_selected == 0)
		ctx->app->modal_result = 1;
	else if (ctx->w->key_enter)
		ctx->app->modal_result = -1;
	if (ctx->app->modal_result == 0)
		return (0);
	app_modal_close(ctx->app);
	return (1);
}

/*
** Rôle: modal_confirm_content — Construit ou rend le contenu de modale
**       confirm.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> ui_draw_lines_in_rectangle(),
**            ui_draw_text_fit().
** Appelants: modal_confirm_render().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_modal_confirm_keyboard.c -> modal_confirm_content() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	modal_confirm_content(t_modal_frame_context *ctx)
{
	ui_draw_lines_in_rectangle(ctx->w, (t_rect){ctx->panel.x + 16,
		ctx->panel.y + 44, ctx->panel.w - 32, ctx->panel.h - 134},
		(t_ui_line_view){ctx->app->modal_lines, ctx->app->modal_n, 14,
			ctx->ui->theme->text2, 0});
	ui_draw_text_fit(ctx->w, (t_rect){ctx->panel.x + 16,
		ctx->panel.y + ctx->panel.h - 88, ctx->panel.w - 32, 18},
		LOCALIZE("Cette action demande une confirmation explicite.",
			"This action requires explicit confirmation."),
		ctx->ui->theme->warn);
	ctx->primary = (t_rect){ctx->panel.x + 16,
		ctx->panel.y + ctx->panel.h - 44, (ctx->panel.w - 32) / 2 - 6, 30};
	ctx->secondary = (t_rect){ctx->primary.x + ctx->primary.w + 12,
		ctx->primary.y, ctx->primary.w, ctx->primary.h};
}

/*
** Rôle: modal_confirm_render — Rend l’état associé à modale confirm.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_modal_close(),
**            modal_confirm_content(), modal_confirm_keyboard(), ui_btn().
** Appelants: app_modal_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_modal_confirm_keyboard.c -> modal_confirm_render() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	modal_confirm_render(t_modal_frame_context *ctx)
{
	if (modal_confirm_keyboard(ctx))
		return (0);
	modal_confirm_content(ctx);
	if (ui_btn(&(t_btn){ctx->w, ctx->ui, ctx->primary,
			LOCALIZE("Confirmer", "Confirm"), UI_BTN_PRIMARY, 1}))
		ctx->app->modal_result = 1;
	else if (ui_btn(&(t_btn){ctx->w, ctx->ui, ctx->secondary,
			LOCALIZE("Annuler", "Cancel"), UI_BTN_SECONDARY, 1}))
		ctx->app->modal_result = -1;
	if (ctx->app->modal_result == 0)
		return (1);
	app_modal_close(ctx->app);
	return (0);
}

/*
** Rôle: modal_creature_content — Construit ou rend le contenu de modale
**       creature.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> selected_creature_name_is_set(),
**            selected_creature_sanitize(), ui_draw_text_fit(), ui_input().
** Appelants: modal_creature_render().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_modal_confirm_keyboard.c -> modal_creature_content() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	modal_creature_content(t_modal_frame_context *ctx)
{
	ui_draw_text_fit(ctx->w, (t_rect){ctx->panel.x + 16,
		ctx->panel.y + 44, ctx->panel.w - 32, 18},
		ctx->app->modal_lines[0], ctx->ui->theme->text);
	ui_draw_text_fit(ctx->w, (t_rect){ctx->panel.x + 16,
		ctx->panel.y + 66, ctx->panel.w - 32, 18},
		ctx->app->modal_lines[1], ctx->ui->theme->text2);
	ctx->input = (t_rect){ctx->panel.x + 16, ctx->panel.y + 92,
		ctx->panel.w - 32, 28};
	(void)ui_input(&(t_in){ctx->w, ctx->ui, ctx->input,
		ctx->app->creature_input, (int)sizeof(ctx->app->creature_input),
		&ctx->app->creature_focus_id, 1});
	snprintf(ctx->temporary, sizeof(ctx->temporary), "%s",
		ctx->app->creature_input);
	selected_creature_sanitize(ctx->temporary);
	ctx->valid = selected_creature_name_is_set(ctx->temporary);
}

/*
** Rôle: modal_creature_buttons — Gère les boutons et leurs actions pour
**       modale creature.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> ui_btn(), ui_draw_rectangle_border(),
**            ui_draw_text_fit().
** Appelants: modal_creature_finish().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_modal_confirm_keyboard.c -> modal_creature_buttons() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	modal_creature_buttons(t_modal_frame_context *ctx)
{
	ctx->primary = (t_rect){ctx->panel.x + 16,
		ctx->panel.y + ctx->panel.h - 44, (ctx->panel.w - 32) / 2 - 6, 30};
	ctx->secondary = (t_rect){ctx->primary.x + ctx->primary.w + 12,
		ctx->primary.y, ctx->primary.w, ctx->primary.h};
	if (ui_btn(&(t_btn){ctx->w, ctx->ui, ctx->primary,
			LOCALIZE("Valider", "Confirm"), UI_BTN_PRIMARY, ctx->valid}))
		ctx->app->modal_result = 1;
	else if (ui_btn(&(t_btn){ctx->w, ctx->ui, ctx->secondary,
			LOCALIZE("Annuler", "Cancel"), UI_BTN_SECONDARY, 1}))
		ctx->app->modal_result = -1;
	if (!ctx->valid)
	{
		ui_draw_text_fit(ctx->w, (t_rect){ctx->panel.x + 16,
			ctx->primary.y - 18, ctx->panel.w - 32, 16},
			LOCALIZE("* Champ obligatoire (non vide).",
				"* Required field (non-empty)."), ctx->ui->theme->warn);
		ui_draw_rectangle_border(ctx->w, ctx->input, ctx->ui->theme->danger);
	}
}
