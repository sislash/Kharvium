/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_topbar_finance_reload.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main_modules.h"

/*
** Rôle: topbar_finance_reload — Recharge l’état associé à topbar finance.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: enabled — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_finance_request_reload(), ui_btn(),
**            window_measure_text_width_role().
** Appelants: topbar_finance_actions().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_topbar_finance_reload.c -> topbar_finance_reload() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	topbar_finance_reload(t_topbar_context *ctx, int enabled)
{
	const char	*label;
	int			width;

	label = LOCALIZE("Recharger", "Reload");
	width = window_measure_text_width_role(ctx->w, label,
		WINDOW_FONT_BUTTON) + 24;
	if (ctx->w->width < 760)
	{
		label = LOCALIZE("Rech.", "Reload");
		width = 62;
	}
	ctx->x -= width;
	if (ui_btn(&(t_btn){ctx->w, ctx->ui,
			(t_rect){ctx->x, ctx->button_y, width, ctx->button_h}, label,
			UI_BTN_SECONDARY, enabled}))
		app_finance_request_reload(ctx->app);
	ctx->x -= ctx->gap;
}

/*
** Rôle: topbar_finance_save — Sauvegarde l’état associé à topbar finance.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: enabled — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_finance_save(), ui_btn(),
**            window_measure_text_width_role().
** Appelants: topbar_finance_actions().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_topbar_finance_reload.c -> topbar_finance_save() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	topbar_finance_save(t_topbar_context *ctx, int enabled)
{
	const char	*label;
	int			width;

	label = LOCALIZE("Sauvegarder", "Save");
	width = window_measure_text_width_role(ctx->w, label,
		WINDOW_FONT_BUTTON) + 24;
	if (ctx->w->width < 760)
	{
		label = LOCALIZE("Sauv.", "Save");
		width = 62;
	}
	ctx->x -= width;
	if (ui_btn(&(t_btn){ctx->w, ctx->ui,
			(t_rect){ctx->x, ctx->button_y, width, ctx->button_h}, label,
			UI_BTN_PRIMARY, enabled}))
		(void)app_finance_save(ctx->app);
	ctx->x -= ctx->gap;
}

/*
** Rôle: topbar_finance_status — Détermine ou formate l’état courant de
**       topbar finance.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> ui_badge(),
**            window_measure_text_width_role().
** Appelants: topbar_finance_actions().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_topbar_finance_reload.c -> topbar_finance_status() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	topbar_finance_status(t_topbar_context *ctx)
{
	const char	*label;
	unsigned int	color;
	int			width;

	if (ctx->w->width < 760)
		return ;
	label = LOCALIZE("AUTO-SAVE OK", "AUTO-SAVE OK");
	color = ctx->ui->theme->success;
	if (ctx->app->finance_dirty)
	{
		label = LOCALIZE("NON SAUVEGARDE", "UNSAVED");
		color = ctx->ui->theme->danger;
	}
	width = window_measure_text_width_role(ctx->w, label,
		WINDOW_FONT_BUTTON) + 20;
	ctx->x -= width;
	ui_badge(&(t_badge){ctx->w, ctx->ui,
		(t_rect){ctx->x, ctx->button_y, width, ctx->button_h}, label, color});
}

/*
** Rôle: topbar_finance_actions — Gère les actions utilisateur ou métier de
**       topbar finance.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> topbar_finance_reload(),
**            topbar_finance_save(), topbar_finance_status().
** Appelants: app_draw_top_bar().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_topbar_finance_reload.c -> topbar_finance_actions() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	topbar_finance_actions(t_topbar_context *ctx)
{
	int	enabled;

	enabled = (ctx->app->finance_form == FIN_FORM_NONE);
	topbar_finance_reload(ctx, enabled);
	topbar_finance_save(ctx, enabled);
	topbar_finance_status(ctx);
}

