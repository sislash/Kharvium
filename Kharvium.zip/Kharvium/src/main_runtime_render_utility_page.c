/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_runtime_render_utility_page.c                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main_modules.h"

/*
** Rôle: runtime_render_utility_page — Rend runtime utility page dans le
**       contexte graphique courant en respectant la géométrie, le clipping
**       et l’état des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> config_page_render(),
**            help_page_render(), hotkeys_page_render(),
**            maintenance_page_render(), system_health_page_render().
** Appelants: runtime_render_content().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_utility_page.c -> runtime_render_utility_page()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	runtime_render_utility_page(t_app_runtime *runtime)
{
	if (runtime->app.page == PAGE_CONFIG)
		config_page_render(&runtime->window, &runtime->ui,
			&runtime->app, runtime->content);
	else if (runtime->app.page == PAGE_HOTKEYS)
		hotkeys_page_render(&runtime->window, &runtime->ui,
			&runtime->app, runtime->content);
	else if (runtime->app.page == PAGE_MAINTENANCE)
		maintenance_page_render(&runtime->window, &runtime->ui,
			&runtime->app, runtime->content);
	else if (runtime->app.page == PAGE_HELP)
		help_page_render(&runtime->window, &runtime->ui,
			&runtime->app, runtime->content);
	else if (runtime->app.page == PAGE_HEALTH)
		system_health_page_render(&runtime->window, &runtime->ui,
			&runtime->app, runtime->content);
	else
		return (0);
	return (1);
}

/*
** Rôle: runtime_render_content — Rend runtime contenu dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> finance_dashboard_page_render(),
**            runtime_render_finance_detail(), runtime_render_finance_page(),
**            runtime_render_tracker_page(), runtime_render_utility_page().
** Appelants: runtime_render_standard_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_utility_page.c -> runtime_render_content()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	runtime_render_content(t_app_runtime *runtime)
{
	if (runtime_render_finance_page(runtime))
		return ;
	if (runtime_render_finance_detail(runtime))
		return ;
	if (runtime_render_tracker_page(runtime))
		return ;
	if (runtime_render_utility_page(runtime))
		return ;
	runtime->app.page = PAGE_DASHBOARD;
	runtime->app.nav_cursor = 0;
	finance_dashboard_page_render(&runtime->window, &runtime->ui,
		&runtime->app, runtime->content);
}

/*
** Rôle: runtime_render_dialogs — Rend runtime dialogs dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_modal_frame(),
**            app_modal_process_result(), app_session_picker_close(),
**            app_session_picker_render(), app_weapon_picker_close(),
**            app_weapon_picker_render().
** Appelants: runtime_render_standard_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_utility_page.c -> runtime_render_dialogs()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	runtime_render_dialogs(t_app_runtime *runtime)
{
	if (runtime->window.key_escape && runtime->app.weapon_picker_open)
		app_weapon_picker_close(&runtime->app);
	app_weapon_picker_render(&runtime->window, &runtime->ui,
		&runtime->app, runtime->content);
	if (runtime->window.key_escape
		&& runtime->app.fishing_rod_picker_open)
		app_fishing_rod_picker_close(&runtime->app);
	app_fishing_rod_picker_render(&runtime->window, &runtime->ui,
		&runtime->app, runtime->content);
	if (runtime->window.key_escape && runtime->app.session_picker_open)
		app_session_picker_close(&runtime->app);
	app_session_picker_render(&runtime->window, &runtime->ui,
		&runtime->app, runtime->content);
	(void)app_modal_frame(&runtime->window, &runtime->ui,
		&runtime->app, runtime->content);
	app_modal_process_result(&runtime->window, &runtime->app);
}

/*
** Rôle: runtime_lock_inputs — Lit ou prépare les entrées de exécution lock.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_swallow_inputs().
** Appelants: runtime_render_standard_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_utility_page.c -> runtime_lock_inputs() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	runtime_lock_inputs(t_app_runtime *runtime)
{
	runtime->locked = (runtime->app.modal_open
		|| runtime->app.weapon_picker_open
		|| runtime->app.fishing_rod_picker_open
		|| runtime->app.session_picker_open);
	if (!runtime->locked)
		return ;
	runtime->snapshot = runtime->window;
	app_swallow_inputs(&runtime->window);
}

/*
** Rôle: runtime_render_standard_frame — Rend runtime standard frame dans le
**       contexte graphique courant en respectant la géométrie, le clipping
**       et l’état des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_draw_top_bar(),
**            app_modal_page_frame_render(),
**            app_navigation_page_uses_modal_frame(),
**            app_sidebar_navigation_render(), runtime_lock_inputs(),
**            runtime_prepare_chrome(), runtime_render_content(),
**            runtime_render_dialogs().
** Appelants: runtime_render_ui().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_utility_page.c ->
**        runtime_render_standard_frame() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=8; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	runtime_render_standard_frame(t_app_runtime *runtime)
{
	runtime_lock_inputs(runtime);
	runtime_prepare_chrome(runtime);
	app_sidebar_navigation_render(&runtime->window, &runtime->ui,
		&runtime->layout, &runtime->app);
	app_draw_top_bar(&runtime->window, &runtime->ui,
		&runtime->layout, &runtime->app);
	runtime->modal = app_navigation_page_uses_modal_frame(runtime->app.page);
	if (!runtime->modal)
		runtime_render_content(runtime);
	if (runtime->locked)
		runtime->window = runtime->snapshot;
	if (!runtime->modal)
		runtime_render_dialogs(runtime);
	else
		app_modal_page_frame_render(&runtime->window, &runtime->ui,
			&runtime->app);
}
