/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_font_roles.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/31                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_font_points — Retourne la taille typographique native
**       du rôle.
** Paramètre: role — rôle SMALL/BODY/BUTTON/TITLE demandé par l'interface.
** Retour: taille en points GDI, toujours strictement positive.
** Effets: aucun.
** Invariants: un rôle inconnu retombe sur la taille BODY.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_create_ui_font().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_font.c -> windows_font_points().
** Dépendances: aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: fonction réentrante.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: points typographiques.
** Performance: coût constant.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_font_points(t_window_font_role role)
{
	if (role == WINDOW_FONT_SMALL)
		return (8);
	if (role == WINDOW_FONT_TITLE)
		return (13);
	return (9);
}

/*
** Rôle: windows_font_weight — Retourne la graisse GDI associée au rôle UI.
** Paramètre: role — rôle typographique demandé.
** Retour: constante de poids GDI.
** Effets: aucun.
** Invariants: BODY et SMALL utilisent un poids normal.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_create_ui_font().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_font.c -> windows_font_weight().
** Dépendances: macros GDI FW_*.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: fonction réentrante.
** I/O: aucune.
** Unités: aucune.
** Performance: coût constant.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_font_weight(t_window_font_role role)
{
	if (role == WINDOW_FONT_TITLE)
		return (FW_BOLD);
	if (role == WINDOW_FONT_BUTTON)
		return (FW_SEMIBOLD);
	return (FW_NORMAL);
}

/*
** Rôle: windows_create_font_named — Crée une police GDI au nom et rôle
**       donnés.
** Paramètre: hdc — contexte graphique utilisé pour convertir les points
**            en pixels.
** Paramètre: role — rôle typographique centralisé de l'interface.
** Paramètre: name — famille installée à demander à GDI.
** Retour: handle HFONT ou NULL si GDI refuse la création.
** Effets: crée une ressource GDI possédée par le backend appelant.
** Invariants: aucun fichier de police n'est embarqué ni chargé par le projet.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_font_points(),
**            windows_font_weight().
** Appelants: windows_create_ui_font().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_font.c -> windows_create_font_named().
** Dépendances: CreateFontA(), GetDeviceCaps(), MulDiv().
** Mémoire: ressource HFONT native à libérer avec DeleteObject().
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend du HDC fourni.
** I/O: aucun fichier ouvert directement.
** Unités: points et pixels.
** Performance: création ponctuelle au démarrage.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static HFONT	windows_create_font_named(HDC hdc, t_window_font_role role,
	const char *name)
{
	int	pixel_height;

	pixel_height = -MulDiv(windows_font_points(role),
		GetDeviceCaps(hdc, LOGPIXELSY), 72);
	return (CreateFontA(pixel_height, 0, 0, 0, windows_font_weight(role),
		0, 0, 0, DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
		CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, name));
}

/*
** Rôle: windows_create_ui_font — Crée une police native pour un rôle UI.
** Paramètre: device — HDC valide utilisé uniquement pendant
**            l'initialisation.
** Paramètre: role — SMALL, BODY, BUTTON ou TITLE.
** Retour: HFONT créé ou police système de secours pour BODY.
** Effets: crée une ressource GDI lorsque la famille demandée est disponible.
** Invariants: privilégie Segoe UI puis Arial; aucune dépendance externe.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_create_font_named().
** Appelants: windows_initialize_graphics().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_font.c -> windows_create_ui_font().
** Dépendances: GetStockObject().
** Mémoire: la police créée est possédée par t_windows_backend.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: initialisation locale au backend.
** I/O: aucun fichier ouvert directement.
** Unités: aucune unité métier.
** Performance: exécuté quatre fois au démarrage.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
HFONT	windows_create_ui_font(HDC device, t_window_font_role role)
{
	HFONT	font;

	if (!device)
		return (NULL);
	font = windows_create_font_named(device, role, "Segoe UI");
	if (!font)
		font = windows_create_font_named(device, role, "Arial");
	if (!font && role == WINDOW_FONT_BODY)
		font = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
	return (font);
}

/*
** Rôle: windows_font_for_role — Résout le handle réellement utilisé au
**       rendu.
** Paramètre: backend — backend Win32 initialisé.
** Paramètre: role — rôle demandé par le widget.
** Retour: police du rôle, sinon BODY, sinon NULL.
** Effets: aucun.
** Invariants: un rôle hors plage est traité comme BODY.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_draw_text(), window_measure_text_width_role(),
**            window_measure_text_height_role().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_font.c -> windows_font_for_role().
** Dépendances: aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: lecture seule du backend.
** I/O: aucune.
** Unités: aucune.
** Performance: coût constant.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
HFONT	windows_font_for_role(t_windows_backend *backend,
	t_window_font_role role)
{
	if (!backend)
		return (NULL);
	if (role < WINDOW_FONT_BODY || role >= WINDOW_FONT_ROLE_COUNT)
		role = WINDOW_FONT_BODY;
	if (backend->fonts[role])
		return (backend->fonts[role]);
	if (backend->fonts[WINDOW_FONT_BODY])
		return (backend->fonts[WINDOW_FONT_BODY]);
	return (NULL);
}

# endif
