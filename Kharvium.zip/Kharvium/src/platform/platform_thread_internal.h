/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_thread_internal.h                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PLATFORM_THREAD_INTERNAL_H
# define PLATFORM_THREAD_INTERNAL_H

# include "platform/platform_thread.h"

typedef struct s_th_ctx
{
	t_platform_thread_fn	fn;
	void				*arg;
} 	t_th_ctx;

#endif
