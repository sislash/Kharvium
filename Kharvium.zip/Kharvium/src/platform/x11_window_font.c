/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_font.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef _WIN32

#  include "x11_window_backend_internal.h"

/*
** Rôle: x11_font_for_role — Résout la police réellement utilisée au rendu.
** Paramètre: backend — backend X11 initialisé.
** Paramètre: role — rôle typographique demandé par le widget.
** Retour: police du rôle, sinon BODY, sinon NULL.
** Effets: aucun.
** Invariants: tout rôle hors plage est ramené sur BODY.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_draw_text(), window_measure_text_width_role(),
**            window_measure_text_height_role().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_draw.c -> x11_font_for_role().
** Dépendances: aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: lecture seule du backend.
** I/O: aucune.
** Unités: aucune.
** Performance: coût constant.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
XFontStruct	*x11_font_for_role(t_x11_backend *backend,
	t_window_font_role role)
{
	if (!backend)
		return (NULL);
	if (role < WINDOW_FONT_BODY || role >= WINDOW_FONT_ROLE_COUNT)
		role = WINDOW_FONT_BODY;
	if (backend->fonts[role])
		return (backend->fonts[role]);
	return (backend->fonts[WINDOW_FONT_BODY]);
}

/*
** Rôle: window_measure_text_width — Calcule la largeur nécessaire à fenêtre
**       measure texte.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: finance_capital_chart_dates(), ui_chart_render_time_label(),
**            ui_chart_render_left_padding(), ui_chart_hover_box(),
**            ui_chart_x_axis_measure(), ui_chart_x_axis_tick() (+3; index
**            complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_draw.c -> window_measure_text_width() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> XTextWidth(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_measure_text_width_role(t_window *w, const char *text,
	t_window_font_role role)
{
	t_x11_backend	*backend;
	XFontStruct		*font;

	if (!w || !text)
		return (0);
	backend = (t_x11_backend *)w->backend_1;
	font = x11_font_for_role(backend, role);
	if (font)
		return (XTextWidth(font, text, (int)strlen(text)));
	return ((int)strlen(text) * 8);
}

int	window_measure_text_width(t_window *w, const char *text)
{
	return (window_measure_text_width_role(w, text, WINDOW_FONT_BODY));
}

/*
** Rôle: window_measure_text_height — Calcule la hauteur nécessaire à
**       fenêtre measure texte.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: tracker_clip_text_draw(), draw_item(), ui_chrome_text_area(),
**            ui_draw_text_fit(), ui_text_vertical_center(), ui_btn() (+6;
**            index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_draw.c -> window_measure_text_height() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_measure_text_height_role(t_window *w, t_window_font_role role)
{
	t_x11_backend	*backend;
	XFontStruct		*font;

	if (!w)
		return (16);
	backend = (t_x11_backend *)w->backend_1;
	font = x11_font_for_role(backend, role);
	if (font)
		return (font->ascent + font->descent);
	return (16);
}

int	window_measure_text_height(t_window *w)
{
	return (window_measure_text_height_role(w, WINDOW_FONT_BODY));
}

# endif
