/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_path.c                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/platform_file_system.h"

#include <stdlib.h>
#include <string.h>

#if defined(_WIN32) || defined(_WIN64)
# include <windows.h>
# include <io.h>
#else
# include <unistd.h>

extern ssize_t	readlink(const char *path, char *buf, size_t bufsiz);
#endif

/*
** Rôle: platform_path_separator — Localise ou traite le séparateur utilisé
**       par platform chemin.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type char; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: chat_log_build_default_path(), file_system_join_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_path.c -> platform_path_separator() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
char	platform_path_separator(void)
{
#if defined(_WIN32) || defined(_WIN64)
	return ('\\');
#else
	return ('/');
#endif
}

/*
** Rôle: get_env_home — Retourne env home.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: platform_home_directory().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_path.c -> get_env_home() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> getenv().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static const char	*get_env_home(void)
{
	const char	*home;

	home = getenv("HOME");
	if (home && home[0])
		return (home);
	home = getenv("USERPROFILE");
	if (home && home[0])
		return (home);
	return (NULL);
}

/*
** Rôle: platform_home_directory — Calcule et retourne home répertoire à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> get_env_home().
** Appelants: chat_log_build_default_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_path.c -> platform_home_directory() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
const char	*platform_home_directory(void)
{
	return (get_env_home());
}

/*
** Rôle: platform_path_exists — Calcule et retourne chemin exists à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: chat_log_try_path(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_path.c -> platform_path_exists() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> _access(), access().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_path_exists(const char *path)
{
	if (!path || !*path)
		return (0);
#if defined(_WIN32) || defined(_WIN64)
	return (_access(path, 0) == 0);
#else
	return (access(path, F_OK) == 0);
#endif
}

/*
** Rôle: platform_replace_file — Calcule et retourne replace à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Paramètre: tmp_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: dst_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: storage_replace_temp().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_path.c -> platform_replace_file() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> MoveFileExA(), rename().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> rename().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_replace_file(const char *tmp_path, const char *dst_path)
{
	if (!tmp_path || !dst_path)
		return (0);
#if defined(_WIN32) || defined(_WIN64)
	if (MoveFileExA(tmp_path, dst_path, MOVEFILE_REPLACE_EXISTING
			| MOVEFILE_WRITE_THROUGH) != 0)
		return (1);
	return (0);
#else
	return (rename(tmp_path, dst_path) == 0);
#endif
}
