/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   chat_log_available.c                              +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/chat_log_path.h"
#include "platform/file_system.h"
#include "common/string_operations.h"

/*
** Rôle: chat_log_is_available — Détermine si chat log available respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_size — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> chat_log_build_path(),
**            file_system_file_exists(), string_copy_fits().
** Appelants: help_draw_chat(), topbar_draw_left_text().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        chat_log_available.c -> chat_log_is_available() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	chat_log_is_available(char *out, size_t out_size)
{
	if (!out || out_size == 0)
		return (0);
	out[0] = '\0';
	if (chat_log_build_path(out, out_size) != 0)
	{
		if (!string_copy_fits(out, out_size, "chat.log"))
			return (0);
	}
	return (file_system_file_exists(out));
}
