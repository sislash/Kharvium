/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths_fishing_asset.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "app_paths_internal.h"
#include "platform/file_system.h"

/*
** Rôle: app_paths_copy_fishing_asset — Copie fishing_rods.ini depuis les
**       assets packagés vers le répertoire writable uniquement s'il manque.
** Retour: aucun.
** Effets: peut copier le fichier de presets Fishing par défaut.
** Invariants: un fichier utilisateur existant n'est jamais écrasé.
** Relations: app_path_fishing_rods_ini(), file_system_file_exists(),
**            file_system_join_path(), file_system_copy_file().
** Appelants: app_paths_copy_default_assets().
** Index: docs/FUNCTION_CALL_GRAPH.md -> app_paths_copy_fishing_asset().
** Dépendances: système de fichiers portable du projet.
** Mémoire: buffer source fixe sur la pile, aucune allocation.
** État partagé: lit les chemins app_paths déjà initialisés.
** Concurrence: bootstrap mono-thread attendu.
** I/O: test d'existence puis copie de fichier locale.
** Unités: chemin de fichier.
** Performance: O(taille du fichier lors de la première copie).
** Portabilité: C99 Windows/Linux via backend file_system.
*/
void	app_paths_copy_fishing_asset(t_app_paths_init_context *context)
{
	if (file_system_file_exists(app_path_fishing_rods_ini()))
		return ;
	if (file_system_join_path(context->source, sizeof(context->source),
			context->assets_root, APP_FILE_FISHING_RODS_INI) != 0)
		return ;
	if (file_system_file_exists(context->source))
		(void)file_system_copy_file(context->source,
			app_path_fishing_rods_ini());
}
