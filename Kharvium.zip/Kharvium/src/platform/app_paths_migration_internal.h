/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths_migration_internal.h                     +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 13:30:00 by tracker_loot       #+#    #+#            */
/*   Updated: 2026/08/28 13:30:00 by tracker_loot      ###   ########.fr      */
/*                                                                            */
/* ************************************************************************** */

#ifndef APP_PATHS_MIGRATION_INTERNAL_H
# define APP_PATHS_MIGRATION_INTERNAL_H

# include <stddef.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_paths_directory_has_required_assets — Détermine si paths
**       répertoire required actifs respecte la condition attendue, sans
**       modifier les données consultées.
** Paramètre: directory — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_paths_directory_has_required_assets().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_paths_directory_has_required_assets(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		app_paths_directory_has_required_assets(const char *directory);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_paths_migrate_legacy_data — Migre paths legacy data en
**       appliquant les validations, bornes
**       et effets explicitement définis par
**       ce module.
** Paramètre: root — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_paths_migrate_legacy_data().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_paths_migrate_legacy_data(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_paths_migrate_legacy_data(const char *root);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_paths_copy_weapon_asset — Copie paths actif en préservant la
**       propriété des ressources, les compteurs et la cohérence de la
**       destination.
** Paramètre: assets_root — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: destination — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_paths_copy_weapon_asset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_paths_copy_weapon_asset(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		app_paths_copy_weapon_asset(const char *assets_root,
			const char *destination);

#endif
