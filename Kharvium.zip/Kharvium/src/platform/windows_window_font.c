/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_font.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/31                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: window_measure_text_width_role — Mesure la largeur native réelle.
** Paramètre: w — fenêtre Win32 propriétaire du backend.
** Paramètre: text — texte à mesurer.
** Paramètre: role — rôle typographique réellement utilisé au dessin.
** Retour: largeur en pixels; 0 pour une entrée invalide.
** Effets: sélectionne temporairement la police dans le HDC.
** Invariants: mesure et rendu utilisent exactement le même HFONT.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_font_for_role().
** Appelants: window_measure_text_width(), UI typographique.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_font.c -> window_measure_text_width_role().
** Dépendances: GetDC(), GetTextExtentPoint32A(), ReleaseDC(), SelectObject().
** Mémoire: aucune allocation dynamique.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend du HDC de la fenêtre.
** I/O: aucune.
** Unités: pixels.
** Performance: mesure native bornée par la longueur du texte.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_measure_text_width_role(t_window *w, const char *text,
	t_window_font_role role)
{
	t_windows_backend	*backend;
	HDC				dc;
	HFONT			old_font;
	SIZE				size;

	if (!w || !text)
		return (0);
	backend = (t_windows_backend *)w->backend_1;
	if (!backend || !backend->hwnd)
		return ((int)strlen(text) * 8);
	dc = backend->back_dc;
	if (!dc)
		dc = GetDC(backend->hwnd);
	old_font = (HFONT)SelectObject(dc, windows_font_for_role(backend, role));
	if (!GetTextExtentPoint32A(dc, text, (int)strlen(text), &size))
		size.cx = (LONG)strlen(text) * 8;
	if (old_font)
		SelectObject(dc, old_font);
	if (!backend->back_dc)
		ReleaseDC(backend->hwnd, dc);
	return ((int)size.cx);
}

/*
** Rôle: window_measure_text_width — Mesure le texte BODY avec le backend natif.
** Paramètre: w — fenêtre ciblée.
** Paramètre: text — texte à mesurer.
** Retour: largeur réelle en pixels.
** Effets: délègue à la mesure typographique BODY.
** Invariants: aucune estimation UI n'est utilisée lorsque le backend existe.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_measure_text_width_role().
** Appelants: compatibilité des widgets BODY existants.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_font.c -> window_measure_text_width().
** Dépendances: aucune directe.
** Mémoire: aucune.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend de la fonction appelée.
** I/O: aucune.
** Unités: pixels.
** Performance: celle de la mesure native appelée.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_measure_text_width(t_window *w, const char *text)
{
	return (window_measure_text_width_role(w, text, WINDOW_FONT_BODY));
}

/*
** Rôle: window_measure_text_height_role — Mesure la hauteur native réelle.
** Paramètre: w — fenêtre Win32 propriétaire du backend.
** Paramètre: role — rôle typographique réellement utilisé au dessin.
** Retour: hauteur de ligne en pixels.
** Effets: sélectionne temporairement la police dans le HDC.
** Invariants: la métrique provient du même HFONT que le rendu.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_font_for_role().
** Appelants: window_measure_text_height(), UI typographique.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_font.c -> window_measure_text_height_role().
** Dépendances: GetDC(), GetTextMetricsA(), ReleaseDC(), SelectObject().
** Mémoire: aucune allocation dynamique.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend du HDC de la fenêtre.
** I/O: aucune.
** Unités: pixels.
** Performance: coût constant du backend GDI.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_measure_text_height_role(t_window *w, t_window_font_role role)
{
	t_windows_backend	*backend;
	HDC				dc;
	HFONT			old_font;
	TEXTMETRICA		metrics;

	if (!w)
		return (16);
	backend = (t_windows_backend *)w->backend_1;
	if (!backend || !backend->hwnd)
		return (16);
	dc = backend->back_dc;
	if (!dc)
		dc = GetDC(backend->hwnd);
	old_font = (HFONT)SelectObject(dc, windows_font_for_role(backend, role));
	if (!GetTextMetricsA(dc, &metrics))
		metrics.tmHeight = 16;
	if (old_font)
		SelectObject(dc, old_font);
	if (!backend->back_dc)
		ReleaseDC(backend->hwnd, dc);
	return ((int)metrics.tmHeight);
}

/*
** Rôle: window_measure_text_height — Mesure la hauteur BODY native.
** Paramètre: w — fenêtre ciblée.
** Retour: hauteur de ligne BODY en pixels.
** Effets: délègue à la mesure typographique centralisée.
** Invariants: valeur cohérente avec window_draw_text().
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_measure_text_height_role().
** Appelants: compatibilité des widgets BODY existants.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_font.c -> window_measure_text_height().
** Dépendances: aucune directe.
** Mémoire: aucune.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend de la fonction appelée.
** I/O: aucune.
** Unités: pixels.
** Performance: celle de la mesure native appelée.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_measure_text_height(t_window *w)
{
	return (window_measure_text_height_role(w, WINDOW_FONT_BODY));
}

# endif
