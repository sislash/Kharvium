/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths_state.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "app_paths_internal.h"

static t_app_paths_state	g_paths = {
	.initialized = 0,
	.root = ".",
	.assets_root = ".",
	.logs_dir = "logs",
	.hunt_csv = APP_FILE_HUNT_CSV,
	.session_offset = APP_FILE_SESSION_OFFSET,
	.session_range = APP_FILE_SESSION_RANGE,
	.selected_weapon = APP_FILE_SELECTED_WEAPON,
	.selected_fishing_rod = APP_FILE_SELECTED_FISHING_ROD,
	.selected_creature = APP_FILE_SELECTED_CREATURE,
	.weapons_ini = APP_FILE_WEAPONS_INI,
	.fishing_rods_ini = APP_FILE_FISHING_RODS_INI,
	.options_cfg = APP_FILE_OPTIONS_CONFIG,
	.session_statistics_csv = APP_FILE_SESSION_STATISTICS_CSV,
	.global_events_csv = APP_FILE_GLOBAL_EVENTS_CSV,
	.markup_ini = APP_FILE_MARKUP_INI,
	.finance_book = APP_FILE_FINANCE_BOOK,
	.parser_debug_log = "logs/parser_debug.log",
	.hotkeys_log = APP_FILE_HOTKEYS_LOG
};

/*
** Rôle: app_paths_state — Consulte ou prépare l’état nécessaire à
**       application chemins.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_paths_initialize(), app_path_global_events_csv(),
**            app_path_markup_ini(), app_path_options_config(),
**            app_path_session_statistics_csv(), app_path_weapons_ini() (+13;
**            index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_state.c -> app_paths_state() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_paths.
** Concurrence: état global mutable détecté (g_paths); synchronisation
**              externe requise si plusieurs threads y accèdent
**              simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_app_paths_state	*app_paths_state(void)
{
	return (&g_paths);
}
