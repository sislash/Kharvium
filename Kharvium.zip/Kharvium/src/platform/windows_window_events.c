/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_events.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_message_handler — Calcule et retourne message handler à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: hwnd — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: message — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: wparam — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: lparam — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type LRESULT CALLBACK; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_handle_content_event(),
**            windows_handle_keyboard_event(),
**            windows_handle_pointer_event(), windows_handle_system_event().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_events.c -> windows_message_handler() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> DefWindowProc(),
**              GetWindowLongPtr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
LRESULT CALLBACK	windows_message_handler(HWND hwnd, UINT message,
	WPARAM wparam, LPARAM lparam)
{
	t_windows_message_context	context;
	LRESULT				result;

	context.hwnd = hwnd;
	context.message = message;
	context.wparam = wparam;
	context.lparam = lparam;
	context.window = (t_window *)GetWindowLongPtr(hwnd, GWLP_USERDATA);
	context.backend = NULL;
	if (context.window)
		context.backend = (t_windows_backend *)context.window->backend_1;
	if (windows_handle_system_event(&context, &result)
		|| windows_handle_keyboard_event(&context, &result)
		|| windows_handle_pointer_event(&context, &result)
		|| windows_handle_content_event(&context, &result))
		return (result);
	return (DefWindowProc(hwnd, message, wparam, lparam));
}

/*
** Rôle: windows_register_class — Calcule et retourne register class à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_initialize_backend(),
**            windows_overlay_allocate_backend().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_events.c -> windows_register_class() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> GetLastError(),
**              LoadCursor(), RegisterClassA(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	windows_register_class(t_windows_backend *backend)
{
	WNDCLASSA	window_class;
	DWORD		error;

	memset(&window_class, 0, sizeof(window_class));
	window_class.lpfnWndProc = windows_message_handler;
	window_class.hInstance = backend->hinst;
	window_class.lpszClassName = backend->class_name;
	window_class.hCursor = LoadCursor(NULL, IDC_ARROW);
	if (RegisterClassA(&window_class))
		return (0);
	error = GetLastError();
	if (error == ERROR_CLASS_ALREADY_EXISTS)
		return (0);
	return (1);
}

/*
** Rôle: window_poll_events — Traite poll et met à jour uniquement l’état
**       d’entrée ou d’interface correspondant à cet
**       événement.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_reset_frame_input().
** Appelants: creature_prompt_modal(), runtime_frame(), markup_config_menu(),
**            weapon_config_menu(), dashboard_read_input(),
**            global_menu_read_action() (+9; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_events.c -> window_poll_events() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> DispatchMessage(),
**              PeekMessage(), TranslateMessage().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_poll_events(t_window *window)
{
	t_windows_backend	*backend;
	MSG				message;

	if (!window)
		return ;
	window_reset_frame_input(window);
	backend = (t_windows_backend *)window->backend_1;
	while (PeekMessage(&message, NULL, WM_QUIT, WM_QUIT, PM_REMOVE))
		window->running = 0;
	if (!backend || !backend->hwnd)
		return ;
	while (PeekMessage(&message, backend->hwnd, 0, 0, PM_REMOVE))
	{
		TranslateMessage(&message);
		DispatchMessage(&message);
	}
}

# endif
