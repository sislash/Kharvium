/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_system_join_path.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "file_system_modules.h"

/*
** Rôle: file_system_join_path — Construit ou résout le chemin utilisé par
**       fichier système join.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: a — objet source consulté en lecture seule par cette fonction.
** Paramètre: b — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_path_separator().
** Appelants: selftest_write_temporary_file(),
**            app_paths_copy_default_assets(),
**            app_paths_select_writable_root(), app_paths_build_logs(),
**            app_paths_join(), app_paths_copy_weapon_asset() (+3; index
**            complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_join_path.c -> file_system_join_path() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> snprintf(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int file_system_join_path(char *out, size_t outsz, const char *a, const char *b)
{
	size_t	length_a;
	int		written;
	char	separator;

	if (!out || outsz == 0)
		return (-1);
	if (!a)
		a = "";
	if (!b)
		b = "";
	length_a = strlen(a);
	separator = platform_path_separator();
	if (length_a == 0 || !*b || a[length_a - 1] == '/'
		|| a[length_a - 1] == '\\' || b[0] == '/' || b[0] == '\\')
		written = snprintf(out, outsz, "%s%s", a, b);
	else
		written = snprintf(out, outsz, "%s%c%s", a, separator, b);
	if (written < 0 || (size_t)written >= outsz)
		return (-1);
	return (0);
}

/*
** Rôle: file_system_get_executable_directory — Retourne system executable
**       répertoire en appliquant les validations et transformations propres
**       à cette opération, puis laisse les données concernées dans un état
**       cohérent.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv0 — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_parent_path(),
**            platform_get_executable_path().
** Appelants: app_paths_select_assets().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_join_path.c -> file_system_get_executable_directory()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int file_system_get_executable_directory(char *out, size_t outsz,
	const char *argv0)
{
	char	full[2048];
	int		rc;

	if (!out || outsz == 0)
		return (-1);
	out[0] = '\0';
	full[0] = '\0';
	(void)platform_get_executable_path(full, sizeof(full), argv0);

	rc = file_system_parent_path(out, outsz, full);
	return (rc);
}
