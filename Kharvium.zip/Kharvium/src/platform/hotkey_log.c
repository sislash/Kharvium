/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hotkey_log.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 15:55:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 15:55:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/hotkey_log.h"
#include "platform/app_paths.h"

#include <stdarg.h>
#include <stdio.h>

/*
** Rôle: platform_hotkey_log_message — Traite raccourci clavier log message
**       et met à jour uniquement l’état
**       d’entrée ou d’interface correspondant
**       à cet événement.
** Paramètre: format — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: ? — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_path_hotkeys_log().
** Appelants: windows_register_hotkey_list(),
**            windows_try_hotkey_combination(), x11_register_hotkey_list(),
**            x11_try_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hotkey_log.c -> platform_hotkey_log_message() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(), fputc(),
**              va_end(), va_start(), vfprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=6. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	platform_hotkey_log_message(const char *format, ...)
{
	FILE		*file;
	va_list	arguments;

	if (!format)
		return ;
	file = fopen(app_path_hotkeys_log(), "ab");
	if (!file)
		return ;
	va_start(arguments, format);
	vfprintf(file, format, arguments);
	va_end(arguments);
	fputc('\n', file);
	fclose(file);
}
