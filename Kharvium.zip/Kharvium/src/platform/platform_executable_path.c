/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_executable_path.c                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/platform_file_system.h"

#include <stdint.h>
#include <string.h>

#if defined(_WIN32) || defined(_WIN64)
# include <windows.h>
#else
# include <unistd.h>
extern ssize_t	readlink(const char *path, char *buf, size_t bufsiz);
#endif

/*
** Rôle: platform_executable_native — Calcule et retourne executable native à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: platform_get_executable_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_executable_path.c -> platform_executable_native() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> GetModuleFileNameA(),
**              readlink().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	platform_executable_native(char *out, size_t outsz)
{
	int64_t	length;

#if defined(_WIN32) || defined(_WIN64)
	length = (int64_t)GetModuleFileNameA(NULL, out, (DWORD)(outsz - 1));
#else
	length = (int64_t)readlink("/proc/self/exe", out,
		(ssize_t)(outsz - 1));
#endif
	if (length <= 0 || (size_t)length >= outsz)
		return (0);
	out[length] = '\0';
	return (1);
}

/*
** Rôle: platform_executable_fallback — Calcule et retourne executable
**       fallback à partir des paramètres fournis sans modifier les entrées
**       déclarées en lecture seule.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv0 — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: platform_get_executable_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_executable_path.c -> platform_executable_fallback()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strncpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	platform_executable_fallback(char *out, size_t outsz,
	const char *argv0)
{
	if (!argv0 || !argv0[0])
		return (-1);
	strncpy(out, argv0, outsz - 1);
	out[outsz - 1] = '\0';
	return (0);
}

/*
** Rôle: platform_get_executable_path — Retourne executable chemin en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv0 — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_executable_fallback(),
**            platform_executable_native().
** Appelants: file_system_get_executable_directory().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_executable_path.c -> platform_get_executable_path()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_get_executable_path(char *out, size_t outsz, const char *argv0)
{
	if (!out || outsz == 0)
		return (-1);
	out[0] = '\0';
	if (platform_executable_native(out, outsz))
		return (0);
	return (platform_executable_fallback(out, outsz, argv0));
}
