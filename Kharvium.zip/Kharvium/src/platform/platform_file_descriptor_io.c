/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_file_descriptor_io.c                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/platform_file_system.h"

#if defined(_WIN32) || defined(_WIN64)
# include <io.h>
#else
# include <unistd.h>
#endif

/*
** Rôle: platform_write_file_descriptor — Écrit descriptor vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: fd — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: buf — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: n — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: csv_journal_lock_acquire().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_file_descriptor_io.c -> platform_write_file_descriptor()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> _write(), write().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> write().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
long	platform_write_file_descriptor(int fd, const void *buf, size_t n)
{
	if (fd < 0 || !buf)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	return ((long)_write(fd, buf, (unsigned int)n));
#else
	return ((long)write(fd, buf, n));
#endif
}

/*
** Rôle: platform_close_file_descriptor — Ferme descriptor en appliquant les
**       transitions d’état et la gestion d’erreur nécessaires pour que la
**       ressource reste cohérente.
** Paramètre: fd — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: csv_journal_lock_release(),
**            file_system_directory_is_writable().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_file_descriptor_io.c -> platform_close_file_descriptor()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> _close(), close().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> close().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_close_file_descriptor(int fd)
{
	if (fd < 0)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	return (_close(fd));
#else
	return (close(fd));
#endif
}
