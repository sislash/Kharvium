/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths_internal.h                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef APP_PATHS_INTERNAL_H
# define APP_PATHS_INTERNAL_H

# include "platform/app_paths.h"

typedef struct s_app_paths_state
{
	int		initialized;
	char	root[1024];
	char	assets_root[1024];
	char	logs_dir[1024];
	char	hunt_csv[1024];
	char	session_offset[1024];
	char	session_range[1024];
	char	selected_weapon[1024];
	char	selected_fishing_rod[1024];
	char	selected_creature[1024];
	char	weapons_ini[1024];
	char	fishing_rods_ini[1024];
	char	options_cfg[1024];
	char	session_statistics_csv[1024];
	char	global_events_csv[1024];
	char	markup_ini[1024];
	char	finance_book[1024];
	char	parser_debug_log[1024];
	char	hotkeys_log[1024];
} 	t_app_paths_state;

typedef struct s_app_paths_init_context
{
	char		executable_dir[1024];
	char		parent[1024];
	char		data_root[1024];
	char		source[1024];
	const char	*assets_root;
	const char	*root;
	const char	*base;
} 	t_app_paths_init_context;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_paths_state — Consulte ou prépare l’état nécessaire à
**       application chemins.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_paths_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_paths_state(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_app_paths_state	*app_paths_state(void);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_paths_build_from_root — Construit paths from root à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: root — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_paths_build_from_root().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_paths_build_from_root(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int				app_paths_build_from_root(const char *root);
void			app_paths_copy_fishing_asset(
				t_app_paths_init_context *context);

#endif
