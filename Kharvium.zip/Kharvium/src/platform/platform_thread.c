/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_thread.c                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform_thread_internal.h"
#include "platform/platform_thread.h"

#include <stdlib.h>
#include <string.h>

#if defined(_WIN32) || defined(_WIN64)
# include <windows.h>

/*
** Rôle: platform_thread_windows_entry — Alloue ou redimensionne les
**       ressources nécessaires à thread entrée et signale explicitement tout
**       échec d’allocation.
** Paramètre: p — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type DWORD WINAPI; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_thread.c -> platform_thread_windows_entry() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fn(), free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static DWORD WINAPI	platform_thread_windows_entry(LPVOID p)
{
	t_th_ctx	*ctx;

	ctx = (t_th_ctx *)p;
	if (ctx && ctx->fn)
		(void)ctx->fn(ctx->arg);
	free(ctx);
	return (0);
}

/*
** Rôle: platform_thread_start — Démarre l’état associé à platform thread.
** Paramètre: t — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: fn — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: arg — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : t, arg.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: global_events_thread_start_internal(),
**            parse_worker_start_thread().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_thread.c -> platform_thread_start() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memcpy(), pthread_create().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_thread_start(t_platform_thread *t, t_platform_thread_fn fn,
	void *arg)
{
	t_th_ctx	*ctx;
	DWORD		id;
	HANDLE		h;

	if (!t || !fn)
		return (-1);
	if (t->valid)
		return (-1);
	ctx = (t_th_ctx *)malloc(sizeof(*ctx));
	if (!ctx)
		return (-1);
	ctx->fn = fn;
	ctx->arg = arg;
	h = CreateThread(NULL, 0, platform_thread_windows_entry, ctx, 0, &id);
	if (!h)
	{
		free(ctx);
		t->valid = 0;
		return (-1);
	}
	t->storage[0] = (uintptr_t)h;
	t->valid = 1;
	return (0);
}

/*
** Rôle: platform_thread_join — Calcule et retourne thread join à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Paramètre: t — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : t.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: global_events_thread_join_internal(),
**            parse_worker_cleanup_dead_thread(), parse_worker_join_thread().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_thread.c -> platform_thread_join() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memcpy(), memset(),
**              pthread_join().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	platform_thread_join(t_platform_thread *t)
{
	HANDLE	h;

	if (!t || !t->valid)
		return ;
	h = (HANDLE)t->storage[0];
	if (!h)
	{
		t->valid = 0;
		return ;
	}
	WaitForSingleObject(h, INFINITE);
	CloseHandle(h);
	t->storage[0] = 0;
	t->valid = 0;
}

#else

# include <pthread.h>

/*
** Rôle: platform_thread_start — Démarre l’état associé à platform thread.
** Paramètre: t — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: fn — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: arg — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : t, arg.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: global_events_thread_start_internal(),
**            parse_worker_start_thread().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_thread.c -> platform_thread_start() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memcpy(), pthread_create().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_thread_start(t_platform_thread *t, t_platform_thread_fn fn,
	void *arg)
{
	pthread_t	th;

	if (!t || !fn)
		return (-1);
	if (t->valid)
		return (-1);
	if (pthread_create(&th, NULL, fn, arg) != 0)
	{
		t->valid = 0;
		return (-1);
	}
	memcpy((void *)t->storage, (void *)&th, sizeof(th));
	t->valid = 1;
	return (0);
}

/*
** Rôle: platform_thread_join — Met à jour thread join en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: t — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : t.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: global_events_thread_join_internal(),
**            parse_worker_cleanup_dead_thread(), parse_worker_join_thread().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_thread.c -> platform_thread_join() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memcpy(), memset(),
**              pthread_join().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	platform_thread_join(t_platform_thread *t)
{
	pthread_t	th;

	if (!t || !t->valid)
		return ;
	memcpy((void *)&th, (void *)t->storage, sizeof(th));
	(void)pthread_join(th, NULL);
	memset((void *)t->storage, 0, sizeof(t->storage));
	t->valid = 0;
}

#endif
