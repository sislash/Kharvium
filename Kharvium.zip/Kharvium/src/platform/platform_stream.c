/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_stream.c                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/platform_file_system.h"

#include <stdio.h>

#if defined(_WIN32) || defined(_WIN64)
# include <io.h>
#else
# include <unistd.h>
# include <sys/types.h>

extern int	fseeko(FILE *stream, off_t offset, int whence);
extern off_t	ftello(FILE *stream);
extern int	ftruncate(int fd, off_t length);
#endif

/*
** Rôle: platform_stream_seek64 — Calcule et retourne stream seek64 à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: off — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: whence — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: csv_load_state_apply_offset(), csv_journal_stream_size(),
**            loot_envelope_seek().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_stream.c -> platform_stream_seek64() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> _fseeki64(), fseeko().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_stream_seek64(FILE *f, int64_t off, int whence)
{
	if (!f)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	return (_fseeki64(f, (long long)off, whence));
#else
	return (fseeko(f, (off_t)off, whence));
#endif
}

/*
** Rôle: platform_stream_tell64 — Calcule et retourne stream tell64 à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Retourne le résultat de type int64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: csv_index_build_scan(), csv_journal_stream_size().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_stream.c -> platform_stream_tell64() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> _ftelli64(), ftello().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int64_t	platform_stream_tell64(FILE *f)
{
	if (!f)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	return ((int64_t)_ftelli64(f));
#else
	return ((int64_t)ftello(f));
#endif
}

/*
** Rôle: platform_stream_truncate — Calcule et retourne stream truncate à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: new_size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_stream_file_descriptor().
** Appelants: file_system_truncate_stream().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_stream.c -> platform_stream_truncate() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> _chsize_s(), fflush(),
**              ftruncate().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fflush().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_stream_truncate(FILE *f, int64_t new_size)
{
	int	fd;

	if (!f)
		return (-1);
	if (new_size < 0)
		new_size = 0;
	fflush(f);
	fd = platform_stream_file_descriptor(f);
	if (fd < 0)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	if (_chsize_s(fd, (size_t)new_size) != 0)
		return (-1);
	return (0);
#else
	if (ftruncate(fd, (off_t)new_size) != 0)
		return (-1);
	return (0);
#endif
}
