/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_destroy.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef _WIN32

#  include "x11_window_backend_internal.h"

/*
** Rôle: x11_release_fonts — libère toutes les polices X11 chargées par le
**       backend pour les rôles typographiques de l'interface.
** Paramètre: backend — backend X11 possédant le Display et les FontStruct.
** Retour: Ne retourne rien; les pointeurs de police libérés sont obsolètes.
** Effets: appelle XFreeFont pour chaque rôle réellement chargé.
** Invariants: backend et son Display sont valides pendant toute la boucle.
** Relations: appelle directement -> aucune.
** Appelants: x11_release_backend().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_release_fonts().
** Dépendances: appels externes/macros directs -> XFreeFont().
** Mémoire: libère des ressources X11, sans free C direct.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend de la politique d'accès au Display de l'appelant.
** I/O: aucune primitive stdio appelée directement.
** Unités: nombre fixe de rôles WINDOW_FONT_ROLE_COUNT.
** Performance: boucle bornée par WINDOW_FONT_ROLE_COUNT.
** Portabilité: X11/Linux.
*/
static void	x11_release_fonts(t_x11_backend *backend)
{
	int	font_index;

	font_index = 0;
	while (font_index < WINDOW_FONT_ROLE_COUNT)
	{
		if (backend->fonts[font_index])
			XFreeFont(backend->d, backend->fonts[font_index]);
		font_index++;
	}
}

/*
** Rôle: x11_release_backend — détruit dans l'ordre les ressources X11 puis
**       libère la structure backend possédée par la fenêtre.
** Paramètre: backend — backend X11 entièrement ou partiellement initialisé.
** Retour: Ne retourne rien; backend est libéré avant le retour.
** Effets: retire les hotkeys, libère pixmap/polices/GC/fenêtre/Display puis C.
** Invariants: chaque ressource optionnelle est testée avant destruction.
** Relations: appelle directement -> x11_release_fonts(),
**            x11_unregister_hotkeys().
** Appelants: window_destroy().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_release_backend().
** Dépendances: appels externes/macros directs -> XCloseDisplay(),
**              XDestroyWindow(), XFreeGC(), XFreePixmap(), free().
** Mémoire: libère directement backend avec free().
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend de la politique d'accès au Display de l'appelant.
** I/O: aucune primitive stdio appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: coût borné hors appels natifs X11.
** Portabilité: X11/Linux.
*/
static void	x11_release_backend(t_x11_backend *backend)
{
	x11_unregister_hotkeys(backend);
	if (backend->back)
		XFreePixmap(backend->d, backend->back);
	x11_release_fonts(backend);
	if (backend->gc)
		XFreeGC(backend->d, backend->gc);
	if (backend->win)
		XDestroyWindow(backend->d, backend->win);
	if (backend->d)
		XCloseDisplay(backend->d);
	free(backend);
}

/*
** Rôle: window_destroy — Détruit proprement l’état associé à fenêtre.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_unregister_hotkeys().
** Appelants: runtime_shutdown(), legacy_global_menu_finish(),
**            overlay_demo_button(), overlay_toggle(),
**            overlay_tick_prepare().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_destroy.c -> window_destroy() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> XCloseDisplay(),
**              XDestroyWindow(), XFreeFont(), XFreeGC(), XFreePixmap(),
**              free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=6. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_destroy(t_window *w)
{
	t_x11_backend	*backend;

	if (!w)
		return ;
	backend = (t_x11_backend *)w->backend_1;
	if (backend)
		x11_release_backend(backend);
	w->backend_1 = NULL;
	w->backend_2 = NULL;
	w->backend_3 = NULL;
	w->pixels = NULL;
	w->pitch = 0;
}

/*
** Rôle: window_set_minimum_size — Calcule set minimum taille à partir des
**       entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_fit_size_to_screen().
** Appelants: runtime_initialize_window().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_destroy.c -> window_set_minimum_size() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> XFlush(),
**              XSetWMNormalHints(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_set_minimum_size(t_window *w, int width, int height)
{
	t_x11_backend	*b;
	XSizeHints		hints;

	if (!w || width <= 0 || height <= 0)
		return ;
	b = (t_x11_backend *)w->backend_1;
	if (!b || !b->d || !b->win || b->is_overlay)
		return ;
	x11_fit_size_to_screen(b, &width, &height);
	memset(&hints, 0, sizeof(hints));
	hints.flags = PMinSize;
	hints.min_width = width;
	hints.min_height = height;
	XSetWMNormalHints(b->d, b->win, &hints);
	XFlush(b->d);
}

# endif
