/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   chat_log_path.c                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/31                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/chat_log_path.h"
#include "platform/platform_file_system.h"
#include "platform/file_system.h"
#include "common/string_operations.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
** Rôle: chat_log_try_path — Construit ou résout le chemin utilisé par chat
**       log try.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_path_exists(),
**            string_copy_fits().
** Appelants: chat_log_build_default_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        chat_log_path.c -> chat_log_try_path() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	chat_log_try_path(char *out, size_t outsz, const char *path)
{
	if (!out || !path || outsz == 0)
		return (0);
	if (!platform_path_exists(path))
		return (0);
	return (string_copy_fits(out, outsz, path));
}

/*
** Rôle: chat_log_set_override_path — Met à jour chat log override chemin à
**       partir des valeurs courantes et conserve l’état partagé cohérent
**       pour la suite de la frame ou du calcul.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_copy_fits().
** Appelants: chat_log_build_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        chat_log_path.c -> chat_log_set_override_path() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> getenv().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	chat_log_set_override_path(char *out, size_t outsz)
{
	const char	*override;

	override = getenv("ENTROPIA_CHATLOG");
	if (override && override[0])
	{
		if (!string_copy_fits(out, outsz, override))
			return (-1);
		return (0);
	}
	return (1);
}

/*
** Rôle: chat_log_build_default_path — Construit chat log par défaut chemin à
**       partir des paramètres fournis et initialise tous les champs requis
**       avant qu’ils soient lus par une autre opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> chat_log_try_path(),
**            platform_home_directory(), platform_path_separator(),
**            string_copy_fits().
** Appelants: chat_log_build_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        chat_log_path.c -> chat_log_build_default_path() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	chat_log_build_default_path(char *out, size_t outsz)
{
	const char	*home;
	char		sep;
	char		p1[1024];
	char		p2[1024];

	home = platform_home_directory();
	if (!home || !home[0])
		return (1);
	sep = platform_path_separator();
	snprintf(p1, sizeof(p1),
			"%s%cDocuments%cEntropia Universe%cchat.log",
		home, sep, sep, sep);
	if (chat_log_try_path(out, outsz, p1))
		return (0);
	snprintf(p2, sizeof(p2),
			"%s%cOneDrive%cDocuments%cEntropia Universe%cchat.log",
		home, sep, sep, sep, sep);
	if (chat_log_try_path(out, outsz, p2))
		return (0);
	if (string_copy_fits(out, outsz, p1))
		return (0);
	return (-1);
}

/*
** Rôle: chat_log_set_fallback_path — Met à jour chat log fallback chemin à
**       partir des valeurs courantes et conserve l’état partagé cohérent
**       pour la suite de la frame ou du calcul.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_copy_fits().
** Appelants: chat_log_build_path().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        chat_log_path.c -> chat_log_set_fallback_path() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	chat_log_set_fallback_path(char *out, size_t outsz)
{
	if (!string_copy_fits(out, outsz, "chat.log"))
		return (-1);
	return (0);
}

/*
** Rôle: chat_log_build_path — Construit chat log chemin à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> chat_log_build_default_path(),
**            chat_log_set_fallback_path(), chat_log_set_override_path().
** Appelants: global_events_worker_execute_engine(),
**            parse_worker_initialize_chat_log_path(),
**            chat_log_is_available().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        chat_log_path.c -> chat_log_build_path() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	chat_log_build_path(char *out, size_t outsz)
{
	int	ret;

	if (!out || outsz == 0)
		return (-1);
	out[0] = '\0';
	ret = chat_log_set_override_path(out, outsz);
	if (ret != 1)
		return (ret);
	ret = chat_log_build_default_path(out, outsz);
	if (ret != 1)
		return (ret);
	return (chat_log_set_fallback_path(out, outsz));
}

