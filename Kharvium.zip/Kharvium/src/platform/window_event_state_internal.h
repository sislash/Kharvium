/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window_event_state_internal.h                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WINDOW_EVENT_STATE_INTERNAL_H
# define WINDOW_EVENT_STATE_INTERNAL_H

# include "platform/native_window.h"

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_reset_frame_input — Réinitialise frame entrée en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: window_reset_frame_input().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_reset_frame_input(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	window_reset_frame_input(t_window *window);

#endif
