/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_graphics_setup.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_initialize_fonts — crée les quatre rôles typographiques GDI
**       et sélectionne BODY comme police courante du back buffer.
** Paramètre: backend — backend Win32 recevant les handles de polices.
** Paramètre: device — contexte d'écran utilisé pour créer les polices.
** Retour: Ne retourne rien; les handles créés sont stockés dans backend.
** Effets: crée SMALL, BODY, BUTTON et TITLE puis peut modifier back_dc.
** Invariants: backend, device et back_dc sont initialisés par l'appelant.
** Relations: appelle directement -> windows_create_ui_font().
** Appelants: windows_initialize_graphics().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_initialize_fonts().
** Dépendances: appels externes/macros directs -> SelectObject().
** Mémoire: aucune allocation dynamique C directe; GDI possède les HFONT.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend exclusivement du backend fourni par l'appelant.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: tailles typographiques exprimées par les rôles de police.
** Performance: quatre créations de police bornées et une sélection GDI.
** Portabilité: Win32/GDI.
*/
static void	windows_initialize_fonts(t_windows_backend *backend, HDC device)
{
	backend->fonts[WINDOW_FONT_SMALL] = windows_create_ui_font(device,
		WINDOW_FONT_SMALL);
	backend->fonts[WINDOW_FONT_BODY] = windows_create_ui_font(device,
		WINDOW_FONT_BODY);
	backend->fonts[WINDOW_FONT_BUTTON] = windows_create_ui_font(device,
		WINDOW_FONT_BUTTON);
	backend->fonts[WINDOW_FONT_TITLE] = windows_create_ui_font(device,
		WINDOW_FONT_TITLE);
	if (backend->fonts[WINDOW_FONT_BODY])
		backend->old_font = (HFONT)SelectObject(backend->back_dc,
			backend->fonts[WINDOW_FONT_BODY]);
}

/*
** Rôle: windows_initialize_graphics — Initialise graphics à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_create_monospace_font(),
**            windows_initialize_bitmap_info().
** Appelants: window_initialize(), window_initialize_overlay().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_graphics_setup.c -> windows_initialize_graphics()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> CreateCompatibleBitmap(),
**              CreateCompatibleDC(), GetDC(), ReleaseDC(), SelectObject(),
**              malloc().
** Mémoire: opérations directes -> malloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=6. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	windows_initialize_graphics(t_window *window,
	t_windows_backend *backend, t_window_size size)
{
	HDC	device;

	device = GetDC(backend->hwnd);
	backend->back_dc = CreateCompatibleDC(device);
	backend->back_bmp = CreateCompatibleBitmap(device, size.width,
		size.height);
	backend->back_old_bmp = (HBITMAP)SelectObject(backend->back_dc,
		backend->back_bmp);
	windows_initialize_fonts(backend, device);
	ReleaseDC(backend->hwnd, device);
	window->pixels = malloc((size_t)size.width * (size_t)size.height * 4);
	if (!window->pixels)
		return (1);
	window->pitch = size.width;
	windows_initialize_bitmap_info(backend, size);
	return (0);
}

# endif
