/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window_hotkey_parse_internal.h                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WINDOW_HOTKEY_PARSE_INTERNAL_H
# define WINDOW_HOTKEY_PARSE_INTERNAL_H

# define WINDOW_HOTKEY_CTRL 1U
# define WINDOW_HOTKEY_ALT 2U
# define WINDOW_HOTKEY_SHIFT 4U
# define WINDOW_HOTKEY_META 8U

typedef struct s_window_hotkey_combination
{
	unsigned int	flags;
	char			key;
}   t_window_hotkey_combination;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_hotkey_parse_combination — Analyse raccourci clavier
**       combination depuis la source fournie, contrôle le format utile et ne
**       renseigne la destination qu’avec des données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: combination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : combination.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_hotkey_parse_combination().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_hotkey_parse_combination(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	window_hotkey_parse_combination(const char *text,
		t_window_hotkey_combination *combination);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_hotkey_registration_mask — Traite raccourci clavier
**       registration mask et met à jour
**       uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: overlay_registered — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: click_registered — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: window_hotkey_registration_mask().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_hotkey_registration_mask(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	window_hotkey_registration_mask(int overlay_registered,
		int click_registered);

#endif
