/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_ewmh.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_ewmh_add_state — Ajoute ewmh état dans la collection concernée en
**       respectant sa capacité, son ordre logique et la propriété de ses
**       éléments.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_overlay_set_topmost().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_ewmh.c -> x11_ewmh_add_state() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> RootWindow(),
**              XInternAtom(), XSendEvent(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_ewmh_add_state(const t_x11_ewmh_state_request *request)
{
	XEvent	event;
	Atom	message;

	if (!request || !request->display || !request->window)
		return ;
	message = XInternAtom(request->display, "_NET_WM_STATE", False);
	if (message == None)
		return ;
	memset(&event, 0, sizeof(event));
	event.xclient.type = ClientMessage;
	event.xclient.message_type = message;
	event.xclient.display = request->display;
	event.xclient.window = request->window;
	event.xclient.format = 32;
	event.xclient.data.l[0] = 1;
	event.xclient.data.l[1] = (long)request->first;
	event.xclient.data.l[2] = (long)request->second;
	event.xclient.data.l[3] = 1;
	XSendEvent(request->display, RootWindow(request->display, request->screen),
		False, SubstructureRedirectMask | SubstructureNotifyMask, &event);
}

#endif
