/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_draw.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: window_clear — Vide l’état associé à fenêtre.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_color_reference().
** Appelants: legacy_global_menu_draw(), tracker_overlay_tick(),
**            ui_chrome_render_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_draw.c -> window_clear() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> CreateSolidBrush(),
**              DeleteObject(), FillRect(), GetClientRect(), GetDC(),
**              ReleaseDC().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=6. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_clear(t_window *w, int color)
{
    t_windows_backend	*b;
    HDC			hdc;
    RECT		rc;
    HBRUSH		brush;

    if (!w)
        return ;
    b = (t_windows_backend *)w->backend_1;
    if (!b || !b->hwnd)
        return ;
    GetClientRect(b->hwnd, &rc);
    brush = CreateSolidBrush(windows_color_reference(color));
    if (w->use_buffer && b->back_dc)
        FillRect(b->back_dc, &rc, brush);
    else
    {
        hdc = GetDC(b->hwnd);
        FillRect(hdc, &rc, brush);
        ReleaseDC(b->hwnd, hdc);
    }
    DeleteObject(brush);
}

/*
** Rôle: window_fill_rectangle — Calcule le rectangle de mise en page
**       utilisé par fenêtre fill.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_color_reference().
** Appelants: session_picker_draw_shell(), weapon_picker_draw_shell(),
**            finance_analysis_panel_header(),
**            finance_analysis_panel_result(),
**            finance_capital_chart_last_point(),
**            finance_dashboard_panel_title() (+20; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_draw.c -> window_fill_rectangle() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> CreateSolidBrush(),
**              DeleteObject(), FillRect(), GetDC(), ReleaseDC().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_fill_rectangle(t_window *w,
	t_window_draw_rectangle request)
{
    t_windows_backend	*b;
    HDC			hdc;
    RECT		rc;
    HBRUSH		brush;

    if (!w || request.width <= 0 || request.height <= 0)
        return ;
    b = (t_windows_backend *)w->backend_1;
    if (!b || !b->hwnd)
        return ;
    rc.left = request.x;
    rc.top = request.y;
    rc.right = request.x + request.width;
    rc.bottom = request.y + request.height;
    brush = CreateSolidBrush(windows_color_reference(request.color));
    if (w->use_buffer && b->back_dc)
        FillRect(b->back_dc, &rc, brush);
    else
    {
        hdc = GetDC(b->hwnd);
        FillRect(hdc, &rc, brush);
        ReleaseDC(b->hwnd, hdc);
    }
    DeleteObject(brush);
}

/*
** Rôle: window_draw_text — Dessine texte dans le contexte graphique courant
**       en respectant la géométrie, le clipping et l’état des widgets
**       fournis.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_color_reference().
** Appelants: ui_draw_text_fit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_draw.c -> window_draw_text() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> GetDC(), ReleaseDC(),
**              SelectObject(), SetBkMode(), SetTextColor(), TextOutA(),
**              lstrlenA().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=7. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_draw_text(t_window *w,
	const t_window_draw_text_request *request)
{
    t_windows_backend	*b;
    HDC			hdc;
    HFONT			old;

    if (!w || !request || !request->text)
        return ;
    b = (t_windows_backend *)w->backend_1;
    if (!b || !b->hwnd)
        return ;
    if (w->use_buffer && b->back_dc)
        hdc = b->back_dc;
    else
        hdc = GetDC(b->hwnd);
    old = NULL;
    if (hdc && windows_font_for_role(b, request->font_role))
        old = (HFONT)SelectObject(hdc,
            windows_font_for_role(b, request->font_role));
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, windows_color_reference(request->color));
    TextOutA(hdc, request->x, request->y, request->text,
		(int)lstrlenA(request->text));
    if (old)
        SelectObject(hdc, old);
    if (!(w->use_buffer && b->back_dc))
        ReleaseDC(b->hwnd, hdc);
}

# endif
