/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_draw.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef _WIN32

#  include "x11_window_backend_internal.h"

/*
** Rôle: window_clear — Vide l’état associé à fenêtre.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_pick_destination(),
**            x11_resolve_color().
** Appelants: legacy_global_menu_draw(), tracker_overlay_tick(),
**            ui_chrome_render_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_draw.c -> window_clear() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> XFillRectangle(),
**              XSetForeground().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_clear(t_window *w, int color)
{
    t_x11_backend	*b;
    unsigned long	pix;
    Drawable		dst;

    if (!w)
        return ;
    b = (t_x11_backend *)w->backend_1;
    if (!b || !b->d || !b->gc)
        return ;
    dst = x11_pick_destination(w, b);
    pix = x11_resolve_color(b, color);
    XSetForeground(b->d, b->gc, pix);
    XFillRectangle(b->d, dst, b->gc, 0, 0,
                   (unsigned int)w->width, (unsigned int)w->height);
}

/*
** Rôle: window_fill_rectangle — Calcule le rectangle de mise en page
**       utilisé par fenêtre fill.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_pick_destination(),
**            x11_resolve_color().
** Appelants: session_picker_draw_shell(), weapon_picker_draw_shell(),
**            finance_analysis_panel_header(),
**            finance_analysis_panel_result(),
**            finance_capital_chart_last_point(),
**            finance_dashboard_panel_title() (+20; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_draw.c -> window_fill_rectangle() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> XFillRectangle(),
**              XSetForeground().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_fill_rectangle(t_window *w,
	t_window_draw_rectangle request)
{
    t_x11_backend	*b;
    unsigned long	pix;
    Drawable		dst;

    if (!w || request.width <= 0 || request.height <= 0)
        return ;
    b = (t_x11_backend *)w->backend_1;
    if (!b || !b->d || !b->gc)
        return ;
    dst = x11_pick_destination(w, b);
    pix = x11_resolve_color(b, request.color);
    XSetForeground(b->d, b->gc, pix);
    XFillRectangle(b->d, dst, b->gc, request.x, request.y,
                   (unsigned int)request.width, (unsigned int)request.height);
}

/*
** Rôle: window_draw_text — Dessine texte dans le contexte graphique courant
**       en respectant la géométrie, le clipping et l’état des widgets
**       fournis.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_pick_destination(),
**            x11_resolve_color().
** Appelants: ui_draw_text_fit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_draw.c -> window_draw_text() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> XDrawString(),
**              XSetForeground(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_draw_text(t_window *w,
	const t_window_draw_text_request *request)
{
	t_x11_backend	*backend;
	XFontStruct		*font;
	unsigned long	pixel;
	Drawable		destination;

	if (!w || !request || !request->text)
		return ;
	backend = (t_x11_backend *)w->backend_1;
	if (!backend || !backend->d || !backend->gc)
		return ;
	font = x11_font_for_role(backend, request->font_role);
	destination = x11_pick_destination(w, backend);
	pixel = x11_resolve_color(backend, request->color);
	XSetForeground(backend->d, backend->gc, pixel);
	if (font)
	{
		XSetFont(backend->d, backend->gc, font->fid);
		XDrawString(backend->d, destination, backend->gc, request->x,
			request->y + font->ascent, request->text,
			(int)strlen(request->text));
	}
}

# endif
