/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_backend_internal.h                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WINDOWS_WINDOW_BACKEND_INTERNAL_H
# define WINDOWS_WINDOW_BACKEND_INTERNAL_H

# ifdef _WIN32
#  include <windows.h>
#  include <stdio.h>
#  include <stdlib.h>
#  include <string.h>
#  include "platform/native_window.h"
#  include "platform/hotkey_combination.h"
#  include "platform/hotkey_log.h"
#  include "common/string_operations.h"
#  include "window_hotkey_parse_internal.h"
#  include "window_event_state_internal.h"
#  ifndef GET_X_LPARAM
#   define GET_X_LPARAM(lp) ((int)(short)LOWORD(lp))
#  endif
#  ifndef GET_Y_LPARAM
#   define GET_Y_LPARAM(lp) ((int)(short)HIWORD(lp))
#  endif
#  define HOTKEY_ID_OVERLAY 1001
#  define HOTKEY_ID_CLICK_THROUGH 1002

typedef struct s_win_backend
{
	HINSTANCE	hinst;
	HWND		hwnd;
	const char	*class_name;
	int			is_overlay;
	int			hotkey_overlay_registered;
	int			hotkey_click_registered;
	UINT		hotkey_overlay_mods;
	UINT		hotkey_overlay_vk;
	UINT		hotkey_click_mods;
	UINT		hotkey_click_vk;
	BITMAPINFO	bmi;
	HDC			back_dc;
	HBITMAP		back_bmp;
	HBITMAP		back_old_bmp;
	HFONT		fonts[WINDOW_FONT_ROLE_COUNT];
	HFONT		old_font;
	int			min_width;
	int			min_height;
}   t_windows_backend;

typedef struct s_windows_hotkey_definition
{
	UINT	modifiers;
	UINT	virtual_key;
}   t_windows_hotkey_definition;

typedef struct s_windows_hotkey_registration
{
	t_windows_backend	*backend;
	const char			*label;
	const char			*list;
	int					which;
	int					hotkey_id;
}   t_windows_hotkey_registration;

typedef struct s_window_size
{
	int	width;
	int	height;
}   t_window_size;

typedef struct s_windows_message_context
{
	HWND				hwnd;
	UINT				message;
	WPARAM				wparam;
	LPARAM				lparam;
	t_window			*window;
	t_windows_backend	*backend;
}   t_windows_message_context;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_parse_hotkey_combination — Analyse raccourci clavier
**       combination depuis la source fournie, contrôle le format utile et ne
**       renseigne la destination qu’avec des données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: definition — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : definition.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_parse_hotkey_combination().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_parse_hotkey_combination(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		windows_parse_hotkey_combination(const char *text,
			t_windows_hotkey_definition *definition);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_register_hotkey_list — Construit ou parcourt la liste
**       utilisée par Win32 register raccourci.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_register_hotkey_list().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_register_hotkey_list(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		windows_register_hotkey_list(t_windows_backend *backend,
			int which, const char *list);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_reset_hotkey_target — Réinitialise raccourci clavier target
**       en appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_reset_hotkey_target().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_reset_hotkey_target(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_reset_hotkey_target(t_windows_backend *backend, int which);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_store_hotkey_target — Traite store raccourci clavier target
**       et met à jour uniquement l’état
**       d’entrée ou d’interface correspondant
**       à cet événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: definition — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_store_hotkey_target().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_store_hotkey_target(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_store_hotkey_target(t_windows_backend *backend, int which,
			const t_windows_hotkey_definition *definition);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_format_hotkey_description — Formate raccourci clavier
**       description dans le buffer ou la représentation demandée sans
**       dépasser la capacité fournie par l’appelant.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_size — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: mods — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: virtual_key — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_format_hotkey_description().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_format_hotkey_description(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_format_hotkey_description(char *out, int out_size,
			UINT mods, UINT virtual_key);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_resize_buffers — Met à jour resize buffers en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_resize_buffers().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_resize_buffers(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_resize_buffers(t_window *window, int width, int height);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_clear_pixel_buffer — Réinitialise pixel buffer en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_clear_pixel_buffer().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_clear_pixel_buffer(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_clear_pixel_buffer(t_window *window, unsigned int color);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_color_reference — Retourne la référence normalisée de
**       couleur utilisée par les opérations du
**       module.
** Paramètre: rgb — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type COLORREF; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_color_reference().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_color_reference(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
COLORREF	windows_color_reference(int rgb);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_create_monospace_font — Crée monospace font à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: hdc — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type HFONT; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_create_monospace_font().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_create_monospace_font(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
HFONT	windows_create_ui_font(HDC device, t_window_font_role role);
HFONT	windows_font_for_role(t_windows_backend *backend,
			t_window_font_role role);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_set_key_state — Met à jour touche état à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: key — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_set_key_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_set_key_state(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_set_key_state(t_window *window, WPARAM key);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_unset_key_state — Consulte ou prépare l’état nécessaire à
**       Win32 unset key.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: key — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_unset_key_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_unset_key_state(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_unset_key_state(t_window *window, WPARAM key);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_message_handler — Met à jour message handler en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: hwnd — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: message — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: wparam — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: lparam — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type LRESULT CALLBACK; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_message_handler().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_message_handler(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
LRESULT CALLBACK	windows_message_handler(HWND hwnd, UINT message,
			WPARAM wparam, LPARAM lparam);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_handle_system_event — Traite system événement en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_handle_system_event().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_handle_system_event(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		windows_handle_system_event(t_windows_message_context *context,
			LRESULT *result);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_handle_keyboard_event — Traite clavier événement en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_handle_keyboard_event().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_handle_keyboard_event(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		windows_handle_keyboard_event(t_windows_message_context *context,
			LRESULT *result);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_handle_pointer_event — Traite pointer événement en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_handle_pointer_event().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_handle_pointer_event(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		windows_handle_pointer_event(t_windows_message_context *context,
			LRESULT *result);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_handle_content_event — Traite contenu événement en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_handle_content_event().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_handle_content_event(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		windows_handle_content_event(t_windows_message_context *context,
			LRESULT *result);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_register_class — Met à jour register class en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_register_class().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_register_class(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		windows_register_class(t_windows_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_release_initialization_backend — Libère initialization
**       backend, remet les
**       ressources possédées dans
**       un état sûr et évite de
**       laisser des pointeurs
**       utilisables après
**       libération.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_release_initialization_backend().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_release_initialization_backend(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_release_initialization_backend(t_window *window,
			t_windows_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_fit_size_to_work_area — Convertit vers fit taille work area
**       en appliquant les validations,
**       bornes et effets explicitement
**       définis par ce module.
** Paramètre: width — identifiant stable servant à retrouver ou associer
**            l’élément.
** Paramètre: height — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : width, height.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_fit_size_to_work_area().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_fit_size_to_work_area(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_fit_size_to_work_area(int *width, int *height);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_initialize_bitmap_info — Initialise bitmap info à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_initialize_bitmap_info().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_initialize_bitmap_info(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_initialize_bitmap_info(t_windows_backend *backend,
			t_window_size size);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_initialize_graphics — Initialise graphics à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_initialize_graphics().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_initialize_graphics(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		windows_initialize_graphics(t_window *window,
			t_windows_backend *backend, t_window_size size);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_overlay_allocate_backend — Met à jour allocate backend en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_overlay_allocate_backend().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_overlay_allocate_backend(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_windows_backend	*windows_overlay_allocate_backend(t_window *window);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_overlay_create_native — Crée native à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_overlay_create_native().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_overlay_create_native(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		windows_overlay_create_native(t_window *window,
			t_windows_backend *backend,
			const t_window_overlay_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_overlay_apply_style — Applique style en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_overlay_apply_style().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_overlay_apply_style(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_overlay_apply_style(t_windows_backend *backend,
			const t_window_overlay_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_overlay_initialize_state — Initialise état à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_overlay_initialize_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_overlay_initialize_state(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_overlay_initialize_state(t_window *window,
			const t_window_overlay_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: windows_apply_clip — Applique clip en appliquant les validations et
**       transformations propres à cette opération, puis laisse les données
**       concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: windows_apply_clip().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                windows_apply_clip(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	windows_apply_clip(t_window *window, t_windows_backend *backend);

# endif
#endif
