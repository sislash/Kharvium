/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_event_system.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_handle_create — Crée l’état associé à Win32 handle.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_handle_system_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_event_system.c -> windows_handle_create() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> SetWindowLongPtr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_handle_create(t_windows_message_context *context,
	LRESULT *result)
{
	if (context->message != WM_CREATE)
		return (0);
	context->window = (t_window *)((CREATESTRUCT *)context->lparam)
		->lpCreateParams;
	SetWindowLongPtr(context->hwnd, GWLP_USERDATA,
		(LONG_PTR)context->window);
	*result = 0;
	return (1);
}

/*
** Rôle: windows_handle_minimum_size — Calcule handle minimum taille à partir
**       des entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_handle_system_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_event_system.c -> windows_handle_minimum_size()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> AdjustWindowRect().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_handle_minimum_size(t_windows_message_context *context,
	LRESULT *result)
{
	MINMAXINFO	*info;
	RECT		rectangle;

	if (context->message != WM_GETMINMAXINFO || !context->backend
		|| context->backend->is_overlay || context->backend->min_width <= 0
		|| context->backend->min_height <= 0)
		return (0);
	info = (MINMAXINFO *)context->lparam;
	rectangle = (RECT){0, 0, context->backend->min_width,
		context->backend->min_height};
	AdjustWindowRect(&rectangle, WS_OVERLAPPEDWINDOW, FALSE);
	info->ptMinTrackSize.x = rectangle.right - rectangle.left;
	info->ptMinTrackSize.y = rectangle.bottom - rectangle.top;
	*result = 0;
	return (1);
}

/*
** Rôle: windows_handle_close — Ferme l’état associé à Win32 handle.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_handle_system_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_event_system.c -> windows_handle_close() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> DestroyWindow(),
**              PostQuitMessage().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_handle_close(t_windows_message_context *context,
	LRESULT *result)
{
	if (context->message == WM_CLOSE)
	{
		if (context->window && context->backend
			&& !context->backend->is_overlay)
			context->window->close_requested = 1;
		else
			DestroyWindow(context->hwnd);
		*result = 0;
		return (1);
	}
	if (context->message != WM_DESTROY)
		return (0);
	if (context->window && context->backend && context->backend->is_overlay)
		context->window->running = 0;
	else
		PostQuitMessage(0);
	*result = 0;
	return (1);
}

/*
** Rôle: windows_handle_system_event — Traite system événement en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_handle_close(),
**            windows_handle_create(), windows_handle_minimum_size().
** Appelants: windows_message_handler().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_event_system.c -> windows_handle_system_event()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	windows_handle_system_event(t_windows_message_context *context,
	LRESULT *result)
{
	if (windows_handle_create(context, result))
		return (1);
	if (windows_handle_minimum_size(context, result))
		return (1);
	if (windows_handle_close(context, result))
		return (1);
	if (context->message == WM_ERASEBKGND)
	{
		*result = 1;
		return (1);
	}
	return (0);
}

# endif
