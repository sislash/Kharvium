/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths_build.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "app_paths_internal.h"
#include "platform/file_system.h"
#include "common/string_operations.h"

/*
** Rôle: app_paths_join — Calcule et retourne paths join à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Paramètre: root — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: leaf — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : dst.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_join_path().
** Appelants: app_paths_build_config(), app_paths_build_logs(),
**            app_paths_build_tracking().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_build.c -> app_paths_join() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	app_paths_join(char *dst, size_t cap,
		const char *root, const char *leaf)
{
	return (file_system_join_path(dst, cap, root, leaf));
}

/*
** Rôle: app_paths_build_tracking — Construit paths tracking à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: paths — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : paths.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_join().
** Appelants: app_paths_build_from_root().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_build.c -> app_paths_build_tracking() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	app_paths_build_tracking(t_app_paths_state *paths)
{
	if (app_paths_join(paths->hunt_csv, sizeof(paths->hunt_csv),
			paths->root, APP_FILE_HUNT_CSV) != 0)
		return (-1);
	if (app_paths_join(paths->session_offset, sizeof(paths->session_offset),
			paths->root, APP_FILE_SESSION_OFFSET) != 0)
		return (-1);
	if (app_paths_join(paths->session_range, sizeof(paths->session_range),
			paths->root, APP_FILE_SESSION_RANGE) != 0)
		return (-1);
	if (app_paths_join(paths->selected_weapon, sizeof(paths->selected_weapon),
			paths->root, APP_FILE_SELECTED_WEAPON) != 0)
		return (-1);
	if (app_paths_join(paths->selected_fishing_rod,
			sizeof(paths->selected_fishing_rod), paths->root,
			APP_FILE_SELECTED_FISHING_ROD) != 0)
		return (-1);
	return (app_paths_join(paths->selected_creature,
			sizeof(paths->selected_creature), paths->root,
			APP_FILE_SELECTED_CREATURE));
}

/*
** Rôle: app_paths_build_config — Construit paths à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: paths — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : paths.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_join().
** Appelants: app_paths_build_from_root().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_build.c -> app_paths_build_config() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	app_paths_build_config(t_app_paths_state *paths)
{
	if (app_paths_join(paths->weapons_ini, sizeof(paths->weapons_ini),
			paths->root, APP_FILE_WEAPONS_INI) != 0)
		return (-1);
	if (app_paths_join(paths->fishing_rods_ini,
			sizeof(paths->fishing_rods_ini), paths->root,
			APP_FILE_FISHING_RODS_INI) != 0)
		return (-1);
	if (app_paths_join(paths->options_cfg, sizeof(paths->options_cfg),
			paths->root, APP_FILE_OPTIONS_CONFIG) != 0)
		return (-1);
	if (app_paths_join(paths->session_statistics_csv,
			sizeof(paths->session_statistics_csv), paths->root,
			APP_FILE_SESSION_STATISTICS_CSV) != 0)
		return (-1);
	if (app_paths_join(paths->global_events_csv,
			sizeof(paths->global_events_csv), paths->root,
			APP_FILE_GLOBAL_EVENTS_CSV) != 0)
		return (-1);
	if (app_paths_join(paths->markup_ini, sizeof(paths->markup_ini),
			paths->root, APP_FILE_MARKUP_INI) != 0)
		return (-1);
	return (app_paths_join(paths->finance_book, sizeof(paths->finance_book),
			paths->root, APP_FILE_FINANCE_BOOK));
}

/*
** Rôle: app_paths_build_logs — Construit paths logs à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: paths — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : paths.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_join(),
**            file_system_join_path().
** Appelants: app_paths_build_from_root().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_build.c -> app_paths_build_logs() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	app_paths_build_logs(t_app_paths_state *paths)
{
	char	temporary[1024];

	if (app_paths_join(paths->logs_dir, sizeof(paths->logs_dir),
			paths->root, APP_DIR_LOGS) != 0)
		return (-1);
	if (file_system_join_path(temporary, sizeof(temporary),
			APP_DIR_LOGS, "parser_debug.log") != 0)
		return (-1);
	if (app_paths_join(paths->parser_debug_log,
			sizeof(paths->parser_debug_log), paths->root, temporary) != 0)
		return (-1);
	if (file_system_join_path(temporary, sizeof(temporary),
			APP_DIR_LOGS, "hotkeys.log") != 0)
		return (-1);
	return (app_paths_join(paths->hotkeys_log, sizeof(paths->hotkeys_log),
			paths->root, temporary));
}

/*
** Rôle: app_paths_build_from_root — Construit paths from root à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: root — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_build_config(),
**            app_paths_build_logs(), app_paths_build_tracking(),
**            app_paths_state(), string_copy_safe().
** Appelants: app_paths_initialize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_build.c -> app_paths_build_from_root() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	app_paths_build_from_root(const char *root)
{
	t_app_paths_state	*paths;

	paths = app_paths_state();
	if (!root || !*root)
		root = ".";
	string_copy_safe(paths->root, sizeof(paths->root), root);
	if (app_paths_build_logs(paths) != 0)
		return (-1);
	if (app_paths_build_tracking(paths) != 0)
		return (-1);
	return (app_paths_build_config(paths));
}
