/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_initialize_utils.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_release_graphics_resources — libère les ressources GDI
**       détenues par le backend pendant une initialisation partielle.
** Paramètre: backend — backend Win32 dont les objets graphiques sont libérés.
** Retour: Ne retourne rien; les handles libérés ne doivent plus être utilisés.
** Effets: restaure les objets GDI précédents puis détruit polices, bitmap
**         et DC.
** Invariants: backend et back_dc sont valides; chaque handle optionnel est
**             contrôlé avant sa libération.
** Relations: appelle directement -> aucune.
** Appelants: windows_release_initialization_backend().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_release_graphics_resources().
** Dépendances: appels externes/macros directs -> DeleteDC(), DeleteObject(),
**              GetStockObject(), SelectObject().
** Mémoire: aucune allocation/libération dynamique C directe.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend exclusivement du backend fourni par l'appelant.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucle bornée par WINDOW_FONT_ROLE_COUNT.
** Portabilité: Win32/GDI.
*/
static void	windows_release_graphics_resources(t_windows_backend *backend)
{
	int	font_index;

	if (!backend->back_dc)
		return ;
	if (backend->old_font)
		SelectObject(backend->back_dc, backend->old_font);
	font_index = 0;
	while (font_index < WINDOW_FONT_ROLE_COUNT)
	{
		if (backend->fonts[font_index]
			&& backend->fonts[font_index] != (HFONT)GetStockObject(
					DEFAULT_GUI_FONT))
			DeleteObject(backend->fonts[font_index]);
		font_index++;
	}
	if (backend->back_old_bmp)
		SelectObject(backend->back_dc, backend->back_old_bmp);
	if (backend->back_bmp)
		DeleteObject(backend->back_bmp);
	DeleteDC(backend->back_dc);
}

/*
** Rôle: windows_release_initialization_backend — Libère initialization
**       backend, remet les
**       ressources possédées dans
**       un état sûr et évite de
**       laisser des pointeurs
**       utilisables après
**       libération.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize(), window_initialize_overlay().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_initialize_utils.c ->
**        windows_release_initialization_backend() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> DeleteDC(), DeleteObject(),
**              DestroyWindow(), GetStockObject(), SelectObject(),
**              UnregisterClassA(), UnregisterHotKey(), free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=8. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_release_initialization_backend(t_window *window,
	t_windows_backend *backend)
{
	if (!backend)
		return ;
	if (backend->hotkey_overlay_registered && backend->hwnd)
		UnregisterHotKey(backend->hwnd, HOTKEY_ID_OVERLAY);
	if (backend->hotkey_click_registered && backend->hwnd)
		UnregisterHotKey(backend->hwnd, HOTKEY_ID_CLICK_THROUGH);
	windows_release_graphics_resources(backend);
	if (backend->hwnd)
		DestroyWindow(backend->hwnd);
	UnregisterClassA(backend->class_name, backend->hinst);
	free(backend);
	if (window)
		window->backend_1 = NULL;
}

/*
** Rôle: windows_fit_size_to_work_area — Convertit vers fit taille work area
**       en appliquant les validations,
**       bornes et effets explicitement
**       définis par ce module.
** Paramètre: width — identifiant stable servant à retrouver ou associer
**            l’élément.
** Paramètre: height — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : width, height.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize(), window_set_minimum_size().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_initialize_utils.c ->
**        windows_fit_size_to_work_area() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> SystemParametersInfoA().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_fit_size_to_work_area(int *width, int *height)
{
	int	available_width;
	int	available_height;
	RECT	work_area;

	if (!width || !height)
		return ;
	if (!SystemParametersInfoA(SPI_GETWORKAREA, 0, &work_area, 0))
		return ;
	available_width = work_area.right - work_area.left;
	available_height = work_area.bottom - work_area.top;
	if (available_width > 640)
		available_width -= 32;
	if (available_height > 480)
		available_height -= 64;
	if (*width > available_width)
		*width = available_width;
	if (*height > available_height)
		*height = available_height;
}

# endif
