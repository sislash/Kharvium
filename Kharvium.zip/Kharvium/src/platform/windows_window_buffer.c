/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_buffer.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_update_bitmap_info — Met à jour bitmap info à partir des
**       valeurs courantes et conserve l’état partagé cohérent pour la suite
**       de la frame ou du calcul.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_resize_buffers().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_buffer.c -> windows_update_bitmap_info() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_update_bitmap_info(t_windows_backend *backend,
	int width, int height)
{
	memset(&backend->bmi, 0, sizeof(backend->bmi));
	backend->bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	backend->bmi.bmiHeader.biWidth = width;
	backend->bmi.bmiHeader.biHeight = -height;
	backend->bmi.bmiHeader.biPlanes = 1;
	backend->bmi.bmiHeader.biBitCount = 32;
	backend->bmi.bmiHeader.biCompression = BI_RGB;
}

/*
** Rôle: windows_resize_backbuffer — Alloue ou redimensionne les ressources
**       nécessaires à resize backbuffer et signale explicitement tout échec
**       d’allocation.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_resize_buffers().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_buffer.c -> windows_resize_backbuffer() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> CreateCompatibleBitmap(),
**              DeleteObject(), GetDC(), ReleaseDC(), SelectObject().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_resize_backbuffer(t_windows_backend *backend,
	int width, int height)
{
	HDC	device;

	if (!backend->back_dc)
		return ;
	if (backend->back_old_bmp)
		SelectObject(backend->back_dc, backend->back_old_bmp);
	if (backend->back_bmp)
		DeleteObject(backend->back_bmp);
	device = GetDC(backend->hwnd);
	backend->back_bmp = CreateCompatibleBitmap(device, width, height);
	ReleaseDC(backend->hwnd, device);
	backend->back_old_bmp = (HBITMAP)SelectObject(backend->back_dc,
		backend->back_bmp);
}

/*
** Rôle: windows_resize_buffers — Alloue ou redimensionne les ressources
**       nécessaires à resize buffers et signale explicitement tout échec
**       d’allocation.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_resize_backbuffer(),
**            windows_update_bitmap_info().
** Appelants: windows_handle_resize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_buffer.c -> windows_resize_buffers() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> free(), malloc().
** Mémoire: opérations directes -> free(), malloc(); le transfert de
**          propriété reste défini par Retour/Effets et les contrats des
**          fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_resize_buffers(t_window *window, int width, int height)
{
	t_windows_backend	*backend;
	unsigned int		*new_pixels;

	if (!window || width <= 0 || height <= 0)
		return ;
	backend = (t_windows_backend *)window->backend_1;
	if (!backend || !backend->hwnd
		|| (width == window->width && height == window->height))
		return ;
	new_pixels = malloc((size_t)width * (size_t)height * 4);
	if (!new_pixels)
		return ;
	free(window->pixels);
	window->pixels = new_pixels;
	window->width = width;
	window->height = height;
	window->pitch = width;
	windows_update_bitmap_info(backend, width, height);
	windows_resize_backbuffer(backend, width, height);
}

/*
** Rôle: windows_clear_pixel_buffer — Réinitialise pixel buffer en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_initialize_state(), windows_overlay_initialize_state().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_buffer.c -> windows_clear_pixel_buffer() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_clear_pixel_buffer(t_window *window, unsigned int color)
{
	int	index;
	int	count;

	if (!window || !window->pixels)
		return ;
	count = window->pitch * window->height;
	index = 0;
	while (index < count)
		window->pixels[index++] = color;
}

/*
** Rôle: windows_color_reference — Retourne la référence normalisée de
**       couleur utilisée par les opérations du
**       module.
** Paramètre: rgb — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type COLORREF; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_clear(), window_draw_text(), window_fill_rectangle(),
**            window_draw_line(), window_draw_polyline().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_buffer.c -> windows_color_reference() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> RGB().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
COLORREF	windows_color_reference(int rgb)
{
	int	red;
	int	green;
	int	blue;

	red = (rgb >> 16) & 0xFF;
	green = (rgb >> 8) & 0xFF;
	blue = rgb & 0xFF;
	return (RGB(red, green, blue));
}

# endif
