/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hotkey_combination.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 16:01:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 16:01:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/hotkey_combination.h"
#include "common/string_operations.h"

/*
** Rôle: hotkey_list_next_combination — Traite raccourci clavier liste next
**       combination et met à jour uniquement
**       l’état d’entrée ou d’interface
**       correspondant à cet événement.
** Paramètre: cursor — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: output_capacity — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_skip_spaces().
** Appelants: windows_register_hotkey_list(), x11_register_hotkey_list().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hotkey_combination.c -> hotkey_list_next_combination() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hotkey_list_next_combination(const char **cursor, char *output,
	int output_capacity)
{
	const char	*text;
	int			position;

	if (!cursor || !*cursor || !output || output_capacity <= 0)
		return (0);
	text = string_skip_spaces(*cursor);
	if (*text == '\0')
	{
		*cursor = text;
		return (0);
	}
	position = 0;
	while (*text && *text != ',' && position < output_capacity - 1)
		output[position++] = *text++;
	output[position] = '\0';
	while (*text && *text != ',')
		text++;
	if (*text == ',')
		text++;
	*cursor = text;
	return (1);
}
