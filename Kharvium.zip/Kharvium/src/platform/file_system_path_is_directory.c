/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_system_path_is_directory.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "file_system_modules.h"

/*
** Rôle: path_is_directory — Détermine si chemin répertoire respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: p — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_path_is_directory().
** Appelants: file_system_ensure_directory().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_path_is_directory.c -> path_is_directory() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	path_is_directory(const char *p)
{
	return (platform_path_is_directory(p));
}

/*
** Rôle: file_system_ensure_directory — Garantit system répertoire en
**       appliquant les validations, bornes
**       et effets explicitement définis par
**       ce module.
** Paramètre: dir — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> path_is_directory(),
**            platform_create_directory().
** Appelants: selftest_write_temporary_file(),
**            app_paths_select_writable_root(),
**            app_paths_ensure_logs_directory(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_path_is_directory.c -> file_system_ensure_directory()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	file_system_ensure_directory(const char *dir)
{
	if (!dir || !*dir)
		return (-1);
	if (platform_create_directory(dir) == 0)
		return (0);
	if (errno == EEXIST && path_is_directory(dir))
		return (0);
	return (-1);
}

/*
** Rôle: file_system_file_exists — Lit system exists depuis le fichier ou flux
**       prévu et propage les erreurs d’accès sans conserver d’état
**       partiellement valide.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: benchmark_execute(), selftest_validate(),
**            finance_app_initialize(), finance_reload_file(),
**            csv_journal_archive_sidecars(), csv_journal_load_journal() (+8;
**            index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_path_is_directory.c -> file_system_file_exists()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	file_system_file_exists(const char *path)
{
	FILE	*f;

	if (!path)
		return (0);
	f = fopen(path, "rb");
	if (!f)
		return (0);
	fclose(f);
	return (1);
}

/*
** Rôle: file_system_file_size — Calcule system taille à partir des entrées
**       courantes en respectant les unités, bornes et règles d’arrondi du
**       module.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_stats_live_state_update(), global_events_live_idle(),
**            monitor_health_update_io(), session_count_data_lines(),
**            hunt_series_live_resolve_end(), hunt_series_update_prepare()
**            (+3; index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_path_is_directory.c -> file_system_file_size() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(), fseek(),
**              ftell().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
long	file_system_file_size(const char *path)
{
	FILE	*f;
	long	sz;

	if (!path)
		return (-1);
	f = fopen(path, "rb");
	if (!f)
		return (-1);
	if (fseek(f, 0, SEEK_END) != 0)
	{
		fclose(f);
		return (-1);
	}
	sz = ftell(f);
	fclose(f);
	return (sz);
}

/*
** Rôle: file_system_directory_is_writable — Détermine si system répertoire
**       writable respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: dir — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_join_path(),
**            platform_close_file_descriptor(),
**            platform_open_exclusive_write().
** Appelants: selftest_validate(), app_paths_select_writable_root().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_path_is_directory.c ->
**        file_system_directory_is_writable() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> remove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	file_system_directory_is_writable(const char *dir)
{
	char	path[1024];
	int	fd;

	if (!dir || !*dir)
		return (0);
	if (file_system_join_path(path, sizeof(path), dir,
		".kharvium_write_test.tmp") != 0)
		return (0);
	fd = platform_open_exclusive_write(path);
	if (fd < 0)
		return (0);
	(void)platform_close_file_descriptor(fd);
	(void)remove(path);
	return (1);
}
