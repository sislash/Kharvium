/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_initialize.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_release_failed_initialization — Libère failed initialization,
**       remet les ressources possédées
**       dans un état sûr et évite de
**       laisser des pointeurs
**       utilisables après libération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize_common().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_initialize.c -> x11_release_failed_initialization()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> XCloseDisplay(),
**              XDestroyWindow(), XFreeGC(), free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	x11_release_failed_initialization(t_x11_initialize_context *context)
{
	t_x11_backend	*backend;

	backend = context->backend;
	if (!backend)
		return ;
	if (backend->gc)
		XFreeGC(backend->d, backend->gc);
	if (backend->win)
		XDestroyWindow(backend->d, backend->win);
	if (backend->d)
		XCloseDisplay(backend->d);
	free(backend);
	context->backend = NULL;
}

/*
** Rôle: window_initialize_common — Initialise l’état du module à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_initialize_context_backend(),
**            x11_initialize_graphics(), x11_initialize_native_window(),
**            x11_initialize_shape(), x11_initialize_window_state(),
**            x11_register_hotkeys(), x11_release_failed_initialization().
** Appelants: window_initialize(), window_initialize_overlay().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_initialize.c -> window_initialize_common() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=7; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_initialize_common(t_x11_initialize_context *context)
{
	if (!context || !context->window || context->width <= 0
		|| context->height <= 0)
		return (1);
	memset(context->window, 0, sizeof(*context->window));
	if (x11_initialize_context_backend(context))
		return (1);
	if (x11_initialize_native_window(context))
		return (x11_release_failed_initialization(context), 1);
	x11_initialize_shape(context->backend);
	x11_initialize_graphics(context);
	x11_initialize_window_state(context);
	if (!context->is_overlay)
		x11_register_hotkeys(context->backend, NULL, NULL);
	return (0);
}

/*
** Rôle: window_initialize — Initialise l’état associé à fenêtre.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: title — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_initialize_common().
** Appelants: runtime_initialize_window(), legacy_global_menu_init().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_initialize.c -> window_initialize() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_initialize(t_window *window, const char *title, int width,
	int height)
{
	t_x11_initialize_context	context;

	memset(&context, 0, sizeof(context));
	context.window = window;
	context.title = title;
	context.width = width;
	context.height = height;
	return (window_initialize_common(&context));
}

#endif
