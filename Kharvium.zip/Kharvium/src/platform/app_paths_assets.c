/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths_assets.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "app_paths_migration_internal.h"
#include "platform/app_paths.h"
#include "platform/file_system.h"

#define LEGACY_WEAPONS_INI "armes.ini"

/*
** Rôle: app_paths_required_catalog_file — Vérifie qu'un fichier CSV Fishing
**       obligatoire existe dans data/catalog pour la racine candidate.
** Paramètre: directory — racine d'assets candidate consultée en lecture.
** Paramètre: filename — nom du CSV attendu sous data/catalog.
** Retour: 1 si le fichier existe, 0 si le chemin est invalide ou absent.
** Effets: aucun état partagé n'est modifié.
** Invariants: les deux jointures restent bornées aux buffers de 1024 octets.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_file_exists(),
**            file_system_join_path().
** Appelants: app_paths_has_fishing_assets().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_assets.c -> app_paths_required_catalog_file().
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: réentrante pour des chemins distincts.
** I/O: test d'existence local uniquement.
** Unités: chemins de fichiers.
** Performance: deux jointures et un test d'existence, coût borné.
** Portabilité: C99 Windows/Linux via le backend file_system.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int app_paths_required_catalog_file(const char *directory,
	    const char *filename)
{
	char    catalog[1024];
	char    path[1024];

	if (file_system_join_path(catalog, sizeof(catalog), directory,
	        "data/catalog") != 0)
	    return (0);
	if (file_system_join_path(path, sizeof(path), catalog, filename) != 0)
	    return (0);
	return (file_system_file_exists(path));
}

/*
** Rôle: app_paths_has_fishing_assets — Valide le bloc complet requis par le
**       picker et le parseur Fishing avant d'accepter une racine d'assets.
** Paramètre: directory — racine d'assets candidate consultée en lecture.
** Retour: 1 si fishing_rods.ini et les cinq CSV Fishing requis existent.
** Effets: aucun état partagé n'est modifié.
** Invariants: un dossier bin/ contenant seulement les INI est refusé.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_required_catalog_file(),
**            file_system_file_exists(), file_system_join_path().
** Appelants: app_paths_directory_has_required_assets().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_assets.c -> app_paths_has_fishing_assets().
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: réentrante en lecture seule.
** I/O: six tests d'existence locaux au maximum.
** Unités: chemins de fichiers.
** Performance: coût constant au bootstrap, borné au nombre de fichiers.
** Portabilité: C99 Windows/Linux via le backend file_system.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int app_paths_has_fishing_assets(const char *directory)
{
	char    path[1024];

	if (file_system_join_path(path, sizeof(path), directory,
	        APP_FILE_FISHING_RODS_INI) != 0 || !file_system_file_exists(path))
	    return (0);
	if (!app_paths_required_catalog_file(directory, "items.csv")
	    || !app_paths_required_catalog_file(directory, "fishing_outputs.csv")
	    || !app_paths_required_catalog_file(directory, "fishing_skills.csv"))
	    return (0);
	return (app_paths_required_catalog_file(directory, "fishing_gear.csv")
	    && app_paths_required_catalog_file(directory, "fishing_ammo.csv"));
}

/*
** Rôle: app_paths_has_weapon_assets — Vérifie la présence du catalogue
**       arme courant ou de son ancien nom compatible dans une racine.
** Paramètre: directory — racine d'assets candidate consultée en lecture.
** Retour: 1 si weapons.ini ou armes.ini existe, 0 sinon.
** Effets: aucun état partagé n'est modifié.
** Invariants: aucun fichier n'est copié ou modifié pendant la détection.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_file_exists(),
**            file_system_join_path().
** Appelants: app_paths_directory_has_required_assets().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_assets.c -> app_paths_has_weapon_assets().
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: réentrante en lecture seule.
** I/O: deux tests d'existence locaux au maximum.
** Unités: chemins de fichiers.
** Performance: coût constant au bootstrap.
** Portabilité: C99 Windows/Linux via le backend file_system.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int app_paths_has_weapon_assets(const char *directory)
{
	char    weapons[1024];
	char    legacy[1024];

	if (file_system_join_path(weapons, sizeof(weapons), directory,
	        APP_FILE_WEAPONS_INI) != 0)
	    return (0);
	if (file_system_join_path(legacy, sizeof(legacy), directory,
	        LEGACY_WEAPONS_INI) != 0)
	    return (0);
	if (file_system_file_exists(weapons))
	    return (1);
	return (file_system_file_exists(legacy));
}

/*
** Rôle: app_paths_directory_has_required_assets — Détermine si une racine
**       contient tous les assets runtime nécessaires, Fishing inclus.
** Paramètre: directory — racine d'assets candidate consultée en lecture.
** Retour: 1 pour une racine complète, 0 pour une racine partielle/invalide.
** Effets: aucun état partagé n'est modifié.
** Invariants: bin/ n'est accepté que s'il contient aussi data/catalog.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_has_fishing_assets(),
**            app_paths_has_weapon_assets(), file_system_file_exists(),
**            file_system_join_path().
** Appelants: app_paths_select_assets().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_assets.c -> app_paths_directory_has_required_assets().
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: réentrante en lecture seule.
** I/O: tests d'existence des assets locaux uniquement.
** Unités: chemins de fichiers.
** Performance: coût constant exécuté seulement au bootstrap.
** Portabilité: C99 Windows/Linux via le backend file_system.
** --- Fin des liens techniques auto-vérifiés ---
*/
int app_paths_directory_has_required_assets(const char *directory)
{
	char    markup[1024];

	if (!directory || !*directory || !app_paths_has_weapon_assets(directory))
	    return (0);
	if (file_system_join_path(markup, sizeof(markup), directory,
	        APP_FILE_MARKUP_INI) != 0)
	    return (0);
	if (!file_system_file_exists(markup))
	    return (0);
	return (app_paths_has_fishing_assets(directory));
}
