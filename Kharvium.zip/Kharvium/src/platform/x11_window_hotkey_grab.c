/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_hotkey_grab.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

static int	g_x11_grab_error;

/*
** Rôle: x11_grab_error_handler — Calcule et retourne grab erreur handler à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: display — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : display, event.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_grab.c -> x11_grab_error_handler() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_x11_grab_error.
** Concurrence: état global mutable détecté (g_x11_grab_error);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	x11_grab_error_handler(Display *display, XErrorEvent *event)
{
	(void)display;
	if (event && event->error_code == BadAccess)
		g_x11_grab_error = 1;
	return (0);
}

/*
** Rôle: x11_try_grab_key — Calcule et retourne try grab touche à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Paramètre: display — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: root — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: keycode — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: modifiers — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : display.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_grab_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_grab.c -> x11_try_grab_key() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> XGrabKey(),
**              XSetErrorHandler(), XSync(), int().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_x11_grab_error.
** Concurrence: état global mutable détecté (g_x11_grab_error);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	x11_try_grab_key(Display *display, Window root, int keycode,
	unsigned int modifiers)
{
	int	(*old_handler)(Display *, XErrorEvent *);

	if (!display || !root || keycode == 0)
		return (0);
	g_x11_grab_error = 0;
	old_handler = XSetErrorHandler(x11_grab_error_handler);
	XGrabKey(display, keycode, modifiers, root, True,
		GrabModeAsync, GrabModeAsync);
	XSync(display, False);
	XSetErrorHandler(old_handler);
	return (g_x11_grab_error == 0);
}

/*
** Rôle: x11_grab_hotkey_combination — Traite grab raccourci clavier
**       combination et met à jour uniquement
**       l’état d’entrée ou d’interface
**       correspondant à cet événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: keycode — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: modifiers — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_build_grab_masks(),
**            x11_try_grab_key().
** Appelants: x11_try_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_grab.c -> x11_grab_hotkey_combination() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> RootWindow(), XSync(),
**              XUngrabKey().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=2; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	x11_grab_hotkey_combination(t_x11_backend *backend, int keycode,
	unsigned int modifiers)
{
	unsigned int	masks[4];
	int				index;
	Window			root;

	if (!backend || !backend->d || keycode == 0)
		return (0);
	root = RootWindow(backend->d, backend->screen);
	x11_build_grab_masks(backend, modifiers, masks);
	index = 0;
	while (index < 4 && x11_try_grab_key(backend->d, root, keycode,
			masks[index]))
		index++;
	if (index == 4)
		return (1);
	while (index-- > 0)
		XUngrabKey(backend->d, keycode, masks[index], root);
	XSync(backend->d, False);
	return (0);
}

/*
** Rôle: x11_ungrab_hotkey_combination — Traite ungrab raccourci clavier
**       combination et met à jour
**       uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: keycode — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: modifiers — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_build_grab_masks().
** Appelants: x11_unregister_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_grab.c -> x11_ungrab_hotkey_combination() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> RootWindow(), XUngrabKey().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_ungrab_hotkey_combination(t_x11_backend *backend, int keycode,
	unsigned int modifiers)
{
	unsigned int	masks[4];
	int				index;
	Window			root;

	if (!backend || !backend->d || keycode == 0)
		return ;
	root = RootWindow(backend->d, backend->screen);
	x11_build_grab_masks(backend, modifiers, masks);
	index = 0;
	while (index < 4)
		XUngrabKey(backend->d, keycode, masks[index++], root);
}

#endif
