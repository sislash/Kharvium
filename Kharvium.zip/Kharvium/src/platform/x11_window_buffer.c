/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_buffer.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef _WIN32

#  include "x11_window_backend_internal.h"

/*
** Resize handler: recreate Pixmap backbuffer + XImage + pixel buffer so the
** whole window remains drawable in fullscreen / maximized modes.
*/
/*
** Resize handler: recreate Pixmap backbuffer so the whole window remains
** drawable in fullscreen / maximized modes.
*/
/*
** Rôle: x11_resize_buffers — Met à jour resize buffers en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_apply_click_through().
** Appelants: x11_dispatch_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_buffer.c -> x11_resize_buffers() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> XCreatePixmap(),
**              XFreePixmap().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void x11_resize_buffers(t_window *w, int width, int height)
{
    t_x11_backend   *b;
    Pixmap          new_back;

    if (!w || width <= 0 || height <= 0)
        return ;
    b = (t_x11_backend *)w->backend_1;
    if (!b || !b->d || !b->win)
        return ;
    if (width == w->width && height == w->height)
        return ;

    new_back = XCreatePixmap(b->d, b->win, (unsigned int)width,
                             (unsigned int)height, (unsigned int)b->depth);
    if (!new_back)
        return ;
    if (b->back)
        XFreePixmap(b->d, b->back);
    b->back = new_back;

    w->width = width;
    w->height = height;
	x11_apply_click_through(w, b);
}

/*
** Rôle: x11_fit_size_to_screen — Convertit vers fit taille screen en
**       appliquant les validations, bornes et
**       effets explicitement définis par ce
**       module.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: width — identifiant stable servant à retrouver ou associer
**            l’élément.
** Paramètre: height — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend, width, height.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_set_minimum_size(), x11_initialize_context_backend().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_buffer.c -> x11_fit_size_to_screen() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> DisplayHeight(),
**              DisplayWidth().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_fit_size_to_screen(t_x11_backend *backend,
		int *width, int *height)
{
	int	available_width;
	int	available_height;

	if (!backend || !backend->d || !width || !height)
		return ;
	available_width = DisplayWidth(backend->d, backend->screen);
	available_height = DisplayHeight(backend->d, backend->screen);
	if (available_width > 640)
		available_width -= 32;
	if (available_height > 480)
		available_height -= 64;
	if (*width > available_width)
		*width = available_width;
	if (*height > available_height)
		*height = available_height;
}

# endif
