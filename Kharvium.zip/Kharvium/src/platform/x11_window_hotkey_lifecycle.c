/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_hotkey_lifecycle.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_register_hotkeys — Prépare ou applique les raccourcis clavier
**       de X11 register.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: overlay_list — objet source consulté en lecture seule par
**            cette fonction.
** Paramètre: click_list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_get_num_lock_mask(),
**            x11_register_hotkey_list(), x11_reset_hotkey_target().
** Appelants: window_rebind_hotkeys(), window_initialize_common().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_lifecycle.c -> x11_register_hotkeys() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_register_hotkeys(t_x11_backend *backend, const char *overlay_list,
	const char *click_list)
{
	if (!backend || !backend->d || backend->is_overlay)
		return ;
	backend->numlock_mask = x11_get_num_lock_mask(backend->d);
	x11_reset_hotkey_target(backend, 0);
	x11_reset_hotkey_target(backend, 1);
	(void)x11_register_hotkey_list(backend, 0, overlay_list);
	(void)x11_register_hotkey_list(backend, 1, click_list);
	backend->hotkeys_grabbed = (backend->hotkey_overlay_registered
		|| backend->hotkey_click_registered);
}

/*
** Rôle: x11_unregister_hotkeys — Prépare ou applique les raccourcis clavier
**       de X11 unregister.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_reset_hotkey_target(),
**            x11_ungrab_hotkey_combination().
** Appelants: window_destroy(), window_rebind_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_lifecycle.c -> x11_unregister_hotkeys() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_unregister_hotkeys(t_x11_backend *backend)
{
	if (!backend || !backend->d || !backend->hotkeys_grabbed)
		return ;
	if (backend->hotkey_overlay_registered && backend->hotkey_overlay_keycode)
		x11_ungrab_hotkey_combination(backend,
			(int)backend->hotkey_overlay_keycode,
			backend->hotkey_overlay_modifiers);
	if (backend->hotkey_click_registered && backend->hotkey_click_keycode)
		x11_ungrab_hotkey_combination(backend,
			(int)backend->hotkey_click_keycode,
			backend->hotkey_click_modifiers);
	backend->hotkeys_grabbed = 0;
	x11_reset_hotkey_target(backend, 0);
	x11_reset_hotkey_target(backend, 1);
}

#endif
