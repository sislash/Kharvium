/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_initialize.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_initialize_backend — Initialise backend à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_register_class().
** Appelants: window_initialize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_initialize.c -> windows_initialize_backend() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> GetModuleHandleA(), free(),
**              malloc(), memset().
** Mémoire: opérations directes -> free(), malloc(); le transfert de
**          propriété reste défini par Retour/Effets et les contrats des
**          fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static t_windows_backend	*windows_initialize_backend(t_window *window)
{
	t_windows_backend	*backend;

	backend = malloc(sizeof(*backend));
	if (!backend)
		return (NULL);
	memset(backend, 0, sizeof(*backend));
	backend->hinst = GetModuleHandleA(NULL);
	backend->class_name = "kharvium_window_class";
	window->backend_1 = backend;
	if (windows_register_class(backend) != 0)
	{
		window->backend_1 = NULL;
		free(backend);
		return (NULL);
	}
	return (backend);
}

/*
** Rôle: windows_create_main_window — Crée l’état du module à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: title — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_rebind_hotkeys().
** Appelants: window_initialize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_initialize.c -> windows_create_main_window() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> AdjustWindowRect(),
**              CreateWindowExA(), ShowWindow(), UpdateWindow().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_create_main_window(t_window *window,
	t_windows_backend *backend, const char *title, t_window_size size)
{
	RECT	rectangle;

	rectangle = (RECT){0, 0, size.width, size.height};
	AdjustWindowRect(&rectangle, WS_OVERLAPPEDWINDOW, FALSE);
	backend->hwnd = CreateWindowExA(0, backend->class_name, title,
		WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
		rectangle.right - rectangle.left, rectangle.bottom - rectangle.top,
		NULL, NULL, backend->hinst, window);
	if (!backend->hwnd)
		return (1);
	ShowWindow(backend->hwnd, SW_SHOW);
	UpdateWindow(backend->hwnd);
	(void)window_rebind_hotkeys(window, NULL, NULL);
	return (0);
}

/*
** Rôle: windows_initialize_state — Initialise état à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: title — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_clear_pixel_buffer().
** Appelants: window_initialize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_initialize.c -> windows_initialize_state() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_initialize_state(t_window *window, const char *title,
	t_window_size size)
{
	window->running = 1;
	window->title = title;
	window->width = size.width;
	window->height = size.height;
	window->use_buffer = 1;
	window->backend_2 = NULL;
	window->backend_3 = NULL;
	windows_clear_pixel_buffer(window, 0xFFFFFFFFu);
}

/*
** Rôle: window_initialize — Initialise l’état associé à fenêtre.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: title — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_create_main_window(),
**            windows_fit_size_to_work_area(), windows_initialize_backend(),
**            windows_initialize_graphics(), windows_initialize_state(),
**            windows_release_initialization_backend().
** Appelants: runtime_initialize_window(), legacy_global_menu_init().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_initialize.c -> window_initialize() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_initialize(t_window *window, const char *title, int width,
	int height)
{
	t_windows_backend	*backend;
	t_window_size		size;

	if (!window || width <= 0 || height <= 0)
		return (1);
	windows_fit_size_to_work_area(&width, &height);
	size = (t_window_size){width, height};
	memset(window, 0, sizeof(*window));
	backend = windows_initialize_backend(window);
	if (!backend)
		return (1);
	if (windows_create_main_window(window, backend, title, size)
		|| windows_initialize_graphics(window, backend, size))
	{
		windows_release_initialization_backend(window, backend);
		return (1);
	}
	windows_initialize_state(window, title, size);
	return (0);
}

# endif
