/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_file.c                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/platform_file_system.h"

#include <sys/stat.h>

#if defined(_WIN32) || defined(_WIN64)
# include <direct.h>
# include <share.h>
# include <io.h>
# include <fcntl.h>
#else
# include <unistd.h>
# include <fcntl.h>
# include <sys/types.h>
#endif

/*
** Rôle: platform_create_directory — Crée répertoire à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: directory_create_if_needed(), file_system_ensure_directory().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_file.c -> platform_create_directory() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> _mkdir(), mkdir().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> mkdir().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_create_directory(const char *path)
{
	if (!path || !*path)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	return (_mkdir(path));
#else
	return (mkdir(path, 0755));
#endif
}

/*
** Rôle: platform_path_is_directory — Détermine si chemin répertoire respecte
**       la condition attendue, sans modifier les données consultées.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: path_is_directory().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_file.c -> platform_path_is_directory() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> S_ISDIR(), _stat(), stat().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> stat().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_path_is_directory(const char *path)
{
	if (!path || !*path)
		return (0);
#if defined(_WIN32) || defined(_WIN64)
	{
		struct _stat	wst;

		if (_stat(path, &wst) != 0)
			return (0);
		return ((wst.st_mode & _S_IFDIR) != 0);
	}
#else
	{
		struct stat	st;

		if (stat(path, &st) != 0)
			return (0);
		return (S_ISDIR(st.st_mode));
	}
#endif
}

/*
** Rôle: platform_change_directory — Lit change répertoire depuis le fichier
**       ou flux prévu et propage les erreurs d’accès sans conserver d’état
**       partiellement valide.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: file_system_change_directory().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_file.c -> platform_change_directory() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> _chdir(), chdir().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_change_directory(const char *path)
{
	if (!path || !*path)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	return (_chdir(path));
#else
	return (chdir(path));
#endif
}

/*
** Rôle: platform_open_shared_read — Lit l’état associé à platform open
**       shared.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: file_system_open_shared_read().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_file.c -> platform_open_shared_read() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> _fsopen(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
FILE	*platform_open_shared_read(const char *path)
{
	if (!path)
		return (NULL);
#if defined(_WIN32) || defined(_WIN64)
	return (_fsopen(path, "rb", _SH_DENYNO));
#else
	return (fopen(path, "rb"));
#endif
}

/*
** Rôle: platform_open_exclusive_write — Écrit l’état associé à platform
**       open exclusive.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: csv_journal_lock_acquire(),
**            file_system_directory_is_writable().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_file.c -> platform_open_exclusive_write() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> _open(), open().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> open().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_open_exclusive_write(const char *path)
{
	if (!path || !*path)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	return (_open(path, _O_CREAT | _O_EXCL | _O_WRONLY | _O_BINARY,
			(_S_IREAD | _S_IWRITE)));
#else
	return (open(path, O_CREAT | O_EXCL | O_WRONLY, 0644));
#endif
}
