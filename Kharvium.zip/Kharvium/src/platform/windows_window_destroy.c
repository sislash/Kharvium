/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_destroy.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_destroy_hotkeys — Détruit et libère raccourcis clavier,
**       libère les ressources possédées et remet l’état modifiable dans une
**       configuration sûre pour éviter toute réutilisation invalide.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_destroy_backend().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_destroy.c -> windows_destroy_hotkeys() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> UnregisterHotKey().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_destroy_hotkeys(t_windows_backend *backend)
{
	if (backend->hotkey_overlay_registered && backend->hwnd)
		UnregisterHotKey(backend->hwnd, HOTKEY_ID_OVERLAY);
	if (backend->hotkey_click_registered && backend->hwnd)
		UnregisterHotKey(backend->hwnd, HOTKEY_ID_CLICK_THROUGH);
}

/*
** Rôle: windows_destroy_graphics — Détruit et libère graphics, libère les
**       ressources possédées et remet l’état modifiable dans une
**       configuration sûre pour éviter toute réutilisation invalide.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_destroy_backend().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_destroy.c -> windows_destroy_graphics() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> DeleteDC(), DeleteObject(),
**              GetStockObject(), SelectObject().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_destroy_graphics(t_windows_backend *backend)
{
	if (!backend->back_dc)
		return ;
	if (backend->old_font)
		SelectObject(backend->back_dc, backend->old_font);
	{
		int	font_index;

		font_index = 0;
		while (font_index < WINDOW_FONT_ROLE_COUNT)
		{
			if (backend->fonts[font_index]
				&& backend->fonts[font_index] != (HFONT)GetStockObject(
					DEFAULT_GUI_FONT))
				DeleteObject(backend->fonts[font_index]);
			font_index++;
		}
	}
	if (backend->back_old_bmp)
		SelectObject(backend->back_dc, backend->back_old_bmp);
	if (backend->back_bmp)
		DeleteObject(backend->back_bmp);
	DeleteDC(backend->back_dc);
}

/*
** Rôle: windows_destroy_backend — Détruit et libère backend, libère les
**       ressources possédées et remet l’état modifiable dans une
**       configuration sûre pour éviter toute réutilisation invalide.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_destroy_graphics(),
**            windows_destroy_hotkeys().
** Appelants: window_destroy().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_destroy.c -> windows_destroy_backend() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> DestroyWindow(),
**              UnregisterClassA(), free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_destroy_backend(t_windows_backend *backend)
{
	windows_destroy_hotkeys(backend);
	windows_destroy_graphics(backend);
	if (backend->hwnd)
		DestroyWindow(backend->hwnd);
	UnregisterClassA(backend->class_name, backend->hinst);
	free(backend);
}

/*
** Rôle: window_destroy — Détruit proprement l’état associé à fenêtre.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_destroy_backend().
** Appelants: runtime_shutdown(), legacy_global_menu_finish(),
**            overlay_demo_button(), overlay_toggle(),
**            overlay_tick_prepare().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_destroy.c -> window_destroy() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_destroy(t_window *window)
{
	if (!window)
		return ;
	free(window->pixels);
	if (window->backend_1)
		windows_destroy_backend((t_windows_backend *)window->backend_1);
	window->backend_1 = NULL;
	window->backend_2 = NULL;
	window->backend_3 = NULL;
	window->pixels = NULL;
	window->pitch = 0;
}

# endif
