/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_backend_internal.h                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef X11_WINDOW_BACKEND_INTERNAL_H
# define X11_WINDOW_BACKEND_INTERNAL_H

# ifndef _WIN32
#  include <X11/Xatom.h>
#  include <X11/Xlib.h>
#  include <X11/Xutil.h>
#  include <X11/keysym.h>
#  ifdef KHARVIUM_HAVE_X11_SHAPE
#   include <X11/extensions/shape.h>
#  endif
#  include <stdint.h>
#  include <stdio.h>
#  include <stdlib.h>
#  include <string.h>
#  include "platform/native_window.h"
#  include "platform/hotkey_combination.h"
#  include "platform/hotkey_log.h"
#  include "common/string_operations.h"
#  include "window_hotkey_parse_internal.h"
#  include "window_event_state_internal.h"
#  define X11_COLOR_CACHE_MAX 256

typedef struct s_x11_color_cache
{
	int			rgb;
	unsigned long	pixel;
}   t_x11_color_cache;

typedef struct s_x11_backend
{
	Display			*d;
	int				screen;
	Window			win;
	GC				gc;
	XFontStruct		*fonts[WINDOW_FONT_ROLE_COUNT];
	Atom			wm_delete;
	int				is_overlay;
	int				hotkeys_grabbed;
	unsigned int	numlock_mask;
	KeyCode			hotkey_overlay_keycode;
	KeyCode			hotkey_click_keycode;
	int				hotkey_overlay_registered;
	int				hotkey_click_registered;
	unsigned int	hotkey_overlay_modifiers;
	unsigned int	hotkey_click_modifiers;
	char			hotkey_overlay_key;
	char			hotkey_click_key;
	int				has_shape;
	int				click_through;
	Pixmap			back;
	Visual			*vis;
	int				depth;
	Colormap		cmap;
	t_x11_color_cache	color_cache[X11_COLOR_CACHE_MAX];
	int				color_cache_count;
}   t_x11_backend;

typedef struct s_x11_hotkey_definition
{
	unsigned int	modifiers;
	KeyCode			keycode;
	char			key;
}   t_x11_hotkey_definition;

typedef struct s_x11_hotkey_registration
{
	t_x11_backend	*backend;
	const char		*label;
	const char		*list;
	int				which;
}   t_x11_hotkey_registration;

typedef struct s_x11_ewmh_state_request
{
	Display	*display;
	int		screen;
	Window	window;
	Atom	first;
	Atom	second;
}   t_x11_ewmh_state_request;

typedef struct s_x11_initialize_context
{
	t_window		*window;
	const char		*title;
	int				width;
	int				height;
	int				is_overlay;
	t_x11_backend	*backend;
}   t_x11_initialize_context;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_grab_error_handler — Met à jour grab erreur handler en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: display — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : display, event.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_grab_error_handler().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_grab_error_handler(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			x11_grab_error_handler(Display *display, XErrorEvent *event);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_get_num_lock_mask — Retourne num lock mask en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: display — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type unsigned int; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : display.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_get_num_lock_mask().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_get_num_lock_mask(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
unsigned int	x11_get_num_lock_mask(Display *display);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_build_grab_masks — Construit grab masks à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: backend — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: modifiers — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: masks — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_build_grab_masks().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_build_grab_masks(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_build_grab_masks(const t_x11_backend *backend,
				unsigned int modifiers, unsigned int masks[4]);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_try_grab_key — Met à jour try grab touche en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: display — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: root — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: keycode — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: modifiers — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : display.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_try_grab_key().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_try_grab_key(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			x11_try_grab_key(Display *display, Window root, int keycode,
				unsigned int modifiers);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_grab_hotkey_combination — Traite grab raccourci clavier
**       combination et met à jour uniquement
**       l’état d’entrée ou d’interface
**       correspondant à cet événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: keycode — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: modifiers — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_grab_hotkey_combination().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_grab_hotkey_combination(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			x11_grab_hotkey_combination(t_x11_backend *backend,
				int keycode, unsigned int modifiers);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_ungrab_hotkey_combination — Traite ungrab raccourci clavier
**       combination et met à jour
**       uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: keycode — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: modifiers — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_ungrab_hotkey_combination().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_ungrab_hotkey_combination(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_ungrab_hotkey_combination(t_x11_backend *backend,
				int keycode, unsigned int modifiers);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_parse_hotkey_combination — Analyse raccourci clavier combination
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: definition — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend, definition.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_parse_hotkey_combination().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_parse_hotkey_combination(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			x11_parse_hotkey_combination(t_x11_backend *backend,
				const char *text, t_x11_hotkey_definition *definition);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_register_hotkey_list — Construit ou parcourt la liste utilisée
**       par X11 register raccourci.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_register_hotkey_list().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_register_hotkey_list(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			x11_register_hotkey_list(t_x11_backend *backend, int which,
				const char *list);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_reset_hotkey_target — Réinitialise raccourci clavier target en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_reset_hotkey_target().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_reset_hotkey_target(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_reset_hotkey_target(t_x11_backend *backend, int which);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_store_hotkey_target — Traite store raccourci clavier target et
**       met à jour uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: definition — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_store_hotkey_target().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_store_hotkey_target(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_store_hotkey_target(t_x11_backend *backend, int which,
				const t_x11_hotkey_definition *definition);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_register_hotkeys — Prépare ou applique les raccourcis clavier
**       de X11 register.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: overlay_list — objet source consulté en lecture seule par
**            cette fonction.
** Paramètre: click_list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_register_hotkeys().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_register_hotkeys(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_register_hotkeys(t_x11_backend *backend,
				const char *overlay_list, const char *click_list);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_unregister_hotkeys — Prépare ou applique les raccourcis clavier
**       de X11 unregister.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_unregister_hotkeys().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_unregister_hotkeys(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_unregister_hotkeys(t_x11_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_apply_click_through — Applique click through en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: b — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w, b.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_apply_click_through().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_apply_click_through(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_apply_click_through(t_window *window, t_x11_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_pick_destination — Met à jour pick destination en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type Drawable; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_pick_destination().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_pick_destination(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
Drawable	x11_pick_destination(t_window *window, t_x11_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_color_mask_shift — Retourne ou renseigne couleur mask shift
**       dans la représentation directement
**       utilisable par le reste du module.
** Paramètre: mask — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_color_mask_shift().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_color_mask_shift(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			x11_color_mask_shift(unsigned long mask);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_resolve_color — Détermine la couleur utilisée par X11 resolve.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: rgb — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type unsigned long; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_resolve_color().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_resolve_color(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
unsigned long	x11_resolve_color(t_x11_backend *backend, int rgb);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_ewmh_add_state — Ajoute ewmh état dans la collection concernée en
**       respectant sa capacité, son ordre logique et la propriété de ses
**       éléments.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_ewmh_add_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_ewmh_add_state(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_ewmh_add_state(const t_x11_ewmh_state_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_resize_buffers — Met à jour resize buffers en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_resize_buffers().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_resize_buffers(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_resize_buffers(t_window *window, int width, int height);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_fit_size_to_screen — Convertit vers fit taille screen en
**       appliquant les validations, bornes et
**       effets explicitement définis par ce
**       module.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: width — identifiant stable servant à retrouver ou associer
**            l’élément.
** Paramètre: height — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend, width, height.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_fit_size_to_screen().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_fit_size_to_screen(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_fit_size_to_screen(t_x11_backend *backend,
				int *width, int *height);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: window_initialize_common — Initialise l’état du module à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: window_initialize_common().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                window_initialize_common(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			window_initialize_common(t_x11_initialize_context *context);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_initialize_context_backend — Initialise contexte backend à partir
**       des paramètres fournis et initialise tous les champs requis avant
**       qu’ils soient lus par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_initialize_context_backend().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_initialize_context_backend(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			x11_initialize_context_backend(t_x11_initialize_context *context);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_initialize_native_window — Initialise native à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_initialize_native_window().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_initialize_native_window(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int			x11_initialize_native_window(t_x11_initialize_context *context);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_initialize_shape — Initialise shape à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_initialize_shape().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_initialize_shape(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_initialize_shape(t_x11_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_initialize_graphics — Initialise graphics à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_initialize_graphics().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_initialize_graphics(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_initialize_graphics(t_x11_initialize_context *context);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_initialize_window_state — Initialise état à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_initialize_window_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_initialize_window_state(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_initialize_window_state(t_x11_initialize_context *context);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_format_hotkey_description — Formate raccourci clavier description
**       dans le buffer ou la représentation demandée sans dépasser la
**       capacité fournie par l’appelant.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_size — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: modifiers — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: key — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_format_hotkey_description().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_format_hotkey_description(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_format_hotkey_description(char *out, int out_size,
				unsigned int modifiers, char key);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_apply_clip — Applique clip en appliquant les validations et
**       transformations propres à cette opération, puis laisse les données
**       concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_apply_clip().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_apply_clip(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_apply_clip(t_window *window, t_x11_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_overlay_set_fixed_size — Calcule set fixed taille à partir des
**       entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_overlay_set_fixed_size().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_overlay_set_fixed_size(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_overlay_set_fixed_size(t_x11_backend *backend,
				const t_window_overlay_request *request);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_overlay_disable_input — Traite disable entrée et met à jour
**       uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_overlay_disable_input().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_overlay_disable_input(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_overlay_disable_input(t_x11_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_overlay_set_window_type — Met à jour type à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_overlay_set_window_type().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_overlay_set_window_type(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_overlay_set_window_type(t_x11_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_overlay_set_opacity — Met à jour opacity à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: alpha — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_overlay_set_opacity().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_overlay_set_opacity(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_overlay_set_opacity(t_x11_backend *backend, int alpha);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_overlay_set_topmost — Met à jour topmost à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_overlay_set_topmost().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_overlay_set_topmost(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_overlay_set_topmost(t_x11_backend *backend);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_apply_pressed_key — Applique pressed touche en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: keysym — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_apply_pressed_key().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_apply_pressed_key(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_apply_pressed_key(t_window *window, KeySym keysym);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_apply_released_key — Applique released touche en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: keysym — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_apply_released_key().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_apply_released_key(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_apply_released_key(t_window *window, KeySym keysym);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_handle_key_press — Traite touche press en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend, event.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_handle_key_press().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_handle_key_press(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_handle_key_press(t_window *window, t_x11_backend *backend,
				XKeyEvent *event);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_handle_key_release — Libère handle touche, libère les ressources
**       possédées et remet l’état modifiable dans une configuration sûre
**       pour éviter toute réutilisation invalide.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, event.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_handle_key_release().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_handle_key_release(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_handle_key_release(t_window *window, XKeyEvent *event);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_handle_motion — Traite motion en appliquant les validations et
**       transformations propres à cette opération, puis laisse les données
**       concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, event.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_handle_motion().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_handle_motion(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_handle_motion(t_window *window, XMotionEvent *event);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_handle_button_press — Traite bouton press en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, event.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_handle_button_press().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_handle_button_press(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_handle_button_press(t_window *window, XButtonEvent *event);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_handle_button_release — Libère handle bouton, libère les
**       ressources possédées et remet l’état modifiable dans une
**       configuration sûre pour éviter toute réutilisation invalide.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, event.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_handle_button_release().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_handle_button_release(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_handle_button_release(t_window *window, XButtonEvent *event);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: x11_dispatch_event — Distribue événement en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend, event.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: x11_dispatch_event().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                x11_dispatch_event(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void		x11_dispatch_event(t_window *window, t_x11_backend *backend,
				XEvent *event);

XFontStruct	*x11_font_for_role(t_x11_backend *backend,
			t_window_font_role role);
void			x11_initialize_fonts(t_x11_backend *backend);
# endif
#endif
