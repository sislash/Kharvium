/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_hotkey_register.c                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifdef _WIN32

# include "windows_window_backend_internal.h"

/*
** Rôle: windows_reset_hotkey_target — Réinitialise raccourci clavier target
**       en appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_register_hotkey_list(), windows_unregister_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_register.c -> windows_reset_hotkey_target()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_reset_hotkey_target(t_windows_backend *backend, int which)
{
	if (which == 0)
	{
		backend->hotkey_overlay_registered = 0;
		backend->hotkey_overlay_mods = 0;
		backend->hotkey_overlay_vk = 0;
	}
	else
	{
		backend->hotkey_click_registered = 0;
		backend->hotkey_click_mods = 0;
		backend->hotkey_click_vk = 0;
	}
}

/*
** Rôle: windows_store_hotkey_target — Traite store raccourci clavier target
**       et met à jour uniquement l’état
**       d’entrée ou d’interface correspondant
**       à cet événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: definition — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_try_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_register.c -> windows_store_hotkey_target()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_store_hotkey_target(t_windows_backend *backend, int which,
	const t_windows_hotkey_definition *definition)
{
	if (which == 0)
	{
		backend->hotkey_overlay_registered = 1;
		backend->hotkey_overlay_mods = definition->modifiers;
		backend->hotkey_overlay_vk = definition->virtual_key;
	}
	else
	{
		backend->hotkey_click_registered = 1;
		backend->hotkey_click_mods = definition->modifiers;
		backend->hotkey_click_vk = definition->virtual_key;
	}
}

/*
** Rôle: windows_hotkey_registration_init — Initialise les données
**       nécessaires à Win32 raccourci registration.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : request, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_register_hotkey_list().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_register.c ->
**        windows_hotkey_registration_init() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_hotkey_registration_init(
	t_windows_hotkey_registration *request, t_windows_backend *backend,
	int which, const char *list)
{
	request->backend = backend;
	request->which = which;
	request->label = "lock";
	request->hotkey_id = HOTKEY_ID_CLICK_THROUGH;
	request->list = list;
	if (which == 0)
	{
		request->label = "overlay";
		request->hotkey_id = HOTKEY_ID_OVERLAY;
		if (!list)
			request->list = "Ctrl+Alt+O,Ctrl+Alt+Shift+O";
	}
	else if (!list)
		request->list = "Ctrl+Alt+P,Ctrl+Alt+Shift+P";
}

/*
** Rôle: windows_try_hotkey_combination — Traite try raccourci clavier
**       combination et met à jour
**       uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: combination — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_hotkey_log_message(),
**            windows_parse_hotkey_combination(),
**            windows_store_hotkey_target().
** Appelants: windows_register_hotkey_list().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_register.c ->
**        windows_try_hotkey_combination() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> GetLastError(),
**              RegisterHotKey().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_try_hotkey_combination(
	const t_windows_hotkey_registration *request, const char *combination)
{
	t_windows_hotkey_definition	definition;
	DWORD						error;

	if (!windows_parse_hotkey_combination(combination, &definition))
		return (platform_hotkey_log_message(
			"[WIN] invalid combo ignored: [%s]", combination), 0);
	if (RegisterHotKey(request->backend->hwnd, request->hotkey_id,
			definition.modifiers, definition.virtual_key))
	{
		windows_store_hotkey_target(request->backend, request->which,
			&definition);
		platform_hotkey_log_message("[WIN] hotkey %s registered: %s",
			request->label, combination);
		return (1);
	}
	error = GetLastError();
	platform_hotkey_log_message("[WIN] hotkey %s conflict: %s (err=%lu)",
		request->label, combination, (unsigned long)error);
	return (0);
}

/*
** Rôle: windows_register_hotkey_list — Construit ou parcourt la liste
**       utilisée par Win32 register raccourci.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hotkey_list_next_combination(),
**            platform_hotkey_log_message(),
**            windows_hotkey_registration_init(),
**            windows_reset_hotkey_target(),
**            windows_try_hotkey_combination().
** Appelants: window_rebind_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_register.c -> windows_register_hotkey_list()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	windows_register_hotkey_list(t_windows_backend *backend, int which,
	const char *list)
{
	t_windows_hotkey_registration	request;
	const char					*cursor;
	char						combination[128];

	if (!backend || !backend->hwnd || backend->is_overlay)
		return (0);
	windows_hotkey_registration_init(&request, backend, which, list);
	if (request.list && *request.list == '\0')
	{
		platform_hotkey_log_message("[WIN] hotkey %s disabled (empty list)",
			request.label);
		return (windows_reset_hotkey_target(backend, which), 0);
	}
	cursor = request.list;
	while (hotkey_list_next_combination(&cursor, combination,
			(int)sizeof(combination)))
		if (windows_try_hotkey_combination(&request, combination))
			return (1);
	windows_reset_hotkey_target(backend, which);
	platform_hotkey_log_message("[WIN] hotkey %s NOT available",
		request.label);
	return (0);
}

#endif
