/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_system.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "file_system_modules.h"

/*
** Rôle: directory_create_if_needed — Crée répertoire if needed à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_create_directory().
** Appelants: directory_create_recursive().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system.c -> directory_create_if_needed() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	directory_create_if_needed(const char *path)
{
	if (platform_create_directory(path) != 0 && errno != EEXIST)
		return (-1);
	return (0);
}

/*
** Rôle: path_trim_to_parent — Convertit vers chemin trim parent en
**       appliquant les validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: tmp — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : tmp.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: file_system_create_parent_directories().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system.c -> path_trim_to_parent() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	path_trim_to_parent(char *tmp)
{
	size_t	i;

	i = strlen(tmp);
	while (i > 0)
	{
		i--;
		if (tmp[i] == '/' || tmp[i] == '\\')
		{
			tmp[i] = '\0';
			return (1);
		}
	}
	return (0);
}

/*
** Rôle: directory_create_recursive — Crée répertoire recursive à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: tmp — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : tmp.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> directory_create_if_needed().
** Appelants: file_system_create_parent_directories().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system.c -> directory_create_recursive() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	directory_create_recursive(char *tmp)
{
	size_t	i;
	char	saved;

	i = 1;
	while (tmp[i])
	{
		if (tmp[i] == '/' || tmp[i] == '\\')
		{
			saved = tmp[i];
			tmp[i] = '\0';
			if (directory_create_if_needed(tmp) != 0)
				return (-1);
			tmp[i] = saved;
		}
		i++;
	}
	return (directory_create_if_needed(tmp));
}

/*
** Rôle: file_system_open_shared_read — Lit l’état associé à fichier système
**       open shared.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_open_shared_read().
** Appelants: hunt_stats_context_open_csv(), hunt_stats_live_open(),
**            app_feed_read_tail(), global_events_live_idle(),
**            global_events_open_streams(), live_ensure_stream() (+5; index
**            complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system.c -> file_system_open_shared_read() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
FILE	*file_system_open_shared_read(const char *path)
{
	return (platform_open_shared_read(path));
}

/*
** Rôle: file_system_create_parent_directories — Crée system parent
**       directories à partir des paramètres fournis et initialise tous les
**       champs requis avant qu’ils soient lus par une autre opération.
** Paramètre: filepath — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> directory_create_recursive(),
**            path_trim_to_parent(), string_copy_safe().
** Appelants: csv_index_append_prepare(), csv_index_build_open(),
**            csv_index_state_open_write(),
**            csv_journal_append_prepare_paths(), csv_journal_archive_file(),
**            file_system_copy_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system.c -> file_system_create_parent_directories() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	file_system_create_parent_directories(const char *filepath)
{
	char	tmp[1024];

	if (!filepath || !*filepath)
		return (-1);
	if (strlen(filepath) >= sizeof(tmp))
		return (-1);
	string_copy_safe(tmp, sizeof(tmp), filepath);
	if (!path_trim_to_parent(tmp))
		return (0);
	return (directory_create_recursive(tmp));
}
