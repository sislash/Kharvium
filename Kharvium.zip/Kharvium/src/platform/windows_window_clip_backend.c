/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_clip_backend.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_apply_clip — Applique clip en appliquant les validations et
**       transformations propres à cette opération, puis laisse les données
**       concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_clear_clip_rectangle(), window_set_clip_rectangle().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_clip_backend.c -> windows_apply_clip() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> IntersectClipRect(),
**              SelectClipRgn().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_apply_clip(t_window *w, t_windows_backend *backend)
{
	SelectClipRgn(backend->back_dc, NULL);
	if (!w->clip_current.active)
		return ;
	IntersectClipRect(backend->back_dc, w->clip_current.x,
		w->clip_current.y, w->clip_current.x + w->clip_current.width,
		w->clip_current.y + w->clip_current.height);
}

/*
** Rôle: window_set_clip_rectangle — Calcule set clip rectangle à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: rectangle — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_clip_intersection(),
**            windows_apply_clip().
** Appelants: finance_activity_page_render(),
**            finance_dashboard_render_compact(), weapon_frame_fields(),
**            markup_frame_fields(), ui_chart_basic_draw(),
**            ui_chart_render_series_cached() (+3; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_clip_backend.c -> window_set_clip_rectangle()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_set_clip_rectangle(t_window *w,
	t_window_clip_rectangle rectangle)
{
	t_windows_backend		*backend;
	t_window_clip_rectangle	next;

	if (!w || rectangle.width <= 0 || rectangle.height <= 0)
		return ;
	backend = (t_windows_backend *)w->backend_1;
	if (!backend || !backend->back_dc)
		return ;
	if (w->clip_stack_size < 8)
		w->clip_stack[w->clip_stack_size++] = w->clip_current;
	next = rectangle;
	next.active = 1;
	w->clip_current = window_clip_intersection(w->clip_current, next);
	windows_apply_clip(w, backend);
}

/*
** Rôle: window_clear_clip_rectangle — Calcule clear clip rectangle à partir
**       de la géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_apply_clip().
** Appelants: finance_activity_page_render(),
**            finance_dashboard_render_compact(), window_present(),
**            window_present(), weapon_frame_fields(), markup_frame_fields()
**            (+5; index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_clip_backend.c -> window_clear_clip_rectangle()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_clear_clip_rectangle(t_window *w)
{
	t_windows_backend	*backend;

	if (!w)
		return ;
	backend = (t_windows_backend *)w->backend_1;
	if (!backend || !backend->back_dc)
		return ;
	if (w->clip_stack_size > 0)
		w->clip_current = w->clip_stack[--w->clip_stack_size];
	else
		w->clip_current.active = 0;
	windows_apply_clip(w, backend);
}

# endif
