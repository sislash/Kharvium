/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_overlay.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: window_initialize_overlay — Initialise une fenêtre overlay native à
**       partir des paramètres demandés.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_initialize_graphics(),
**            windows_overlay_allocate_backend(),
**            windows_overlay_apply_style(), windows_overlay_create_native(),
**            windows_overlay_initialize_state(),
**            windows_release_initialization_backend().
** Appelants: overlay_open().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_overlay.c -> window_initialize_overlay() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_initialize_overlay(t_window *window,
	const t_window_overlay_request *request)
{
	t_windows_backend	*backend;
	t_window_size		size;

	if (!window || !request || request->width <= 0 || request->height <= 0)
		return (1);
	memset(window, 0, sizeof(*window));
	backend = windows_overlay_allocate_backend(window);
	if (!backend)
		return (1);
	size = (t_window_size){request->width, request->height};
	if (windows_overlay_create_native(window, backend, request))
	{
		windows_release_initialization_backend(window, backend);
		return (1);
	}
	windows_overlay_apply_style(backend, request);
	if (windows_initialize_graphics(window, backend, size))
	{
		windows_release_initialization_backend(window, backend);
		return (1);
	}
	windows_overlay_initialize_state(window, request);
	return (0);
}

/*
** Rôle: window_set_minimum_size — Calcule set minimum taille à partir des
**       entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: width — coordonnée ou dimension de la zone graphique
**            concernée.
** Paramètre: height — coordonnée ou dimension de la zone graphique
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_fit_size_to_work_area().
** Appelants: runtime_initialize_window().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_overlay.c -> window_set_minimum_size() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_set_minimum_size(t_window *window, int width, int height)
{
	t_windows_backend	*backend;

	if (!window || width <= 0 || height <= 0)
		return ;
	backend = (t_windows_backend *)window->backend_1;
	if (!backend || !backend->hwnd || backend->is_overlay)
		return ;
	windows_fit_size_to_work_area(&width, &height);
	backend->min_width = width;
	backend->min_height = height;
}

/*
** Rôle: window_set_overlay_click_through — Met à jour click through à partir
**       des valeurs courantes et conserve l’état partagé cohérent pour la
**       suite de la frame ou du calcul.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: enabled — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: overlay_set_demo(), overlay_toggle_click_through(),
**            overlay_open().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_overlay.c -> window_set_overlay_click_through()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> GetWindowLongPtr(),
**              SetWindowLongPtr(), SetWindowPos().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_set_overlay_click_through(t_window *window, int enabled)
{
	t_windows_backend	*backend;
	LONG_PTR		extended_style;
	HWND			insert_after;
	UINT			flags;

	if (!window)
		return ;
	backend = (t_windows_backend *)window->backend_1;
	if (!backend || !backend->hwnd || !backend->is_overlay)
		return ;
	extended_style = GetWindowLongPtr(backend->hwnd, GWL_EXSTYLE);
	if (enabled)
		extended_style |= (LONG_PTR)WS_EX_TRANSPARENT;
	else
		extended_style &= ~((LONG_PTR)WS_EX_TRANSPARENT);
	SetWindowLongPtr(backend->hwnd, GWL_EXSTYLE, extended_style);
	insert_after = HWND_TOP;
	if ((extended_style & (LONG_PTR)WS_EX_TOPMOST) != 0)
		insert_after = HWND_TOPMOST;
	flags = SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_FRAMECHANGED;
	SetWindowPos(backend->hwnd, insert_after, 0, 0, 0, 0, flags);
}

# endif
