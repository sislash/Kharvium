/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_system_modules.h                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FILE_SYSTEM_MODULES_H
# define FILE_SYSTEM_MODULES_H

# include "platform/file_system.h"
# include "platform/platform_file_system.h"
# include "common/string_operations.h"
# include <errno.h>
# include <stdio.h>
# include <string.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: directory_create_if_needed — Crée répertoire if needed à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: directory_create_if_needed().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                directory_create_if_needed(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	directory_create_if_needed(const char *path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: path_trim_to_parent — Convertit vers chemin trim parent en
**       appliquant les validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: tmp — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : tmp.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: path_trim_to_parent().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                path_trim_to_parent(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	path_trim_to_parent(char *tmp);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: directory_create_recursive — Crée répertoire recursive à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: tmp — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : tmp.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: directory_create_recursive().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                directory_create_recursive(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	directory_create_recursive(char *tmp);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: path_is_directory — Détermine si chemin répertoire respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: p — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: path_is_directory().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                path_is_directory(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	path_is_directory(const char *p);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_copy_stream — Copie system stream en préservant la
**       propriété des ressources, les compteurs et la cohérence de la
**       destination.
** Paramètre: in — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: out — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre; peut modifier les
**         paramètres non const suivants : in, out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_copy_stream().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_copy_stream(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	file_system_copy_stream(FILE *in, FILE *out);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_open_shared_read — Lit l’état associé à fichier système
**       open shared.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_open_shared_read().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_open_shared_read(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
FILE	*file_system_open_shared_read(const char *path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_create_parent_directories — Crée system parent
**       directories à partir des paramètres fournis et initialise tous les
**       champs requis avant qu’ils soient lus par une autre opération.
** Paramètre: filepath — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_create_parent_directories().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_create_parent_directories(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	file_system_create_parent_directories(const char *filepath);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_ensure_directory — Garantit system répertoire en
**       appliquant les validations, bornes
**       et effets explicitement définis par
**       ce module.
** Paramètre: dir — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_ensure_directory().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_ensure_directory(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	file_system_ensure_directory(const char *dir);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_file_exists — Met à jour system exists en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_file_exists().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_file_exists(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	file_system_file_exists(const char *path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_file_size — Calcule system taille à partir des entrées
**       courantes en respectant les unités, bornes et règles d’arrondi du
**       module.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_file_size().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_file_size(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
long	file_system_file_size(const char *path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_directory_is_writable — Détermine si system répertoire
**       writable respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: dir — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_directory_is_writable().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_directory_is_writable(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	file_system_directory_is_writable(const char *dir);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_copy_file — Copie system en préservant la propriété des
**       ressources, les compteurs et la cohérence de la destination.
** Paramètre: src — source consultée pour produire le résultat sans en
**            modifier la signification.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_copy_file().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_copy_file(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	file_system_copy_file(const char *src, const char *dst);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_truncate_stream — Met à jour system truncate stream en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: new_size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_truncate_stream().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_truncate_stream(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	file_system_truncate_stream(FILE *f, long new_size);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_change_directory — Met à jour system change répertoire en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_change_directory().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_change_directory(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int file_system_change_directory(const char *path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_parent_path — Construit ou résout le chemin utilisé par
**       fichier système parent.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_parent_path().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_parent_path(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int file_system_parent_path(char *out, size_t outsz, const char *path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_join_path — Construit ou résout le chemin utilisé par
**       fichier système join.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: a — objet source consulté en lecture seule par cette fonction.
** Paramètre: b — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_join_path().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_join_path(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int file_system_join_path(char *out, size_t outsz, const char *a,
	const char *b);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: file_system_get_executable_directory — Retourne system executable
**       répertoire en appliquant les validations et transformations propres
**       à cette opération, puis laisse les données concernées dans un état
**       cohérent.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv0 — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: file_system_get_executable_directory().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                file_system_get_executable_directory(); résolution
**                indirecte possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int file_system_get_executable_directory(char *out, size_t outsz,
	const char *argv0);

#endif
