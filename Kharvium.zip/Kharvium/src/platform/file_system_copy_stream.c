/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_system_copy_stream.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "file_system_modules.h"

/*
** Rôle: file_system_copy_stream — Copie system stream en préservant la
**       propriété des ressources, les compteurs et la cohérence de la
**       destination.
** Paramètre: in — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: out — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre; peut modifier les
**         paramètres non const suivants : in, out.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: file_system_copy_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_copy_stream.c -> file_system_copy_stream() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> ferror(), fflush(),
**              fread(), fwrite().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fflush(), fread(), fwrite().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	file_system_copy_stream(FILE *in, FILE *out)
{
	unsigned char	buffer[8192];
	size_t			count;

	count = fread(buffer, 1, sizeof(buffer), in);
	while (count > 0)
	{
		if (fwrite(buffer, 1, count, out) != count)
			return (-1);
		count = fread(buffer, 1, sizeof(buffer), in);
	}
	if (ferror(in) || fflush(out) != 0)
		return (-1);
	return (0);
}

/*
** Rôle: file_system_copy_file — Copie system en préservant la propriété des
**       ressources, les compteurs et la cohérence de la destination.
** Paramètre: src — source consultée pour produire le résultat sans en
**            modifier la signification.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_copy_stream(),
**            file_system_create_parent_directories().
** Appelants: app_paths_copy_default_assets(), app_paths_copy_weapon_asset(),
**            legacy_copy_if_missing().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_copy_stream.c -> file_system_copy_file() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	file_system_copy_file(const char *src, const char *dst)
{
	FILE	*in;
	FILE	*out;
	int		result;

	if (!src || !dst || !*src || !*dst)
		return (-1);
	if (file_system_create_parent_directories(dst) != 0)
		return (-1);
	in = fopen(src, "rb");
	if (!in)
		return (-1);
	out = fopen(dst, "wb");
	if (!out)
	{
		fclose(in);
		return (-1);
	}
	result = file_system_copy_stream(in, out);
	fclose(in);
	fclose(out);
	return (result);
}

/*
** Rôle: file_system_truncate_stream — Calcule et retourne system truncate
**       stream à partir des paramètres fournis sans modifier les entrées
**       déclarées en lecture seule.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: new_size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_stream_truncate().
** Appelants: hunt_csv_invalid_finish(),
**            hunt_csv_repair_trailing_partial_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_copy_stream.c -> file_system_truncate_stream() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	file_system_truncate_stream(FILE *f, long new_size)
{
	return (platform_stream_truncate(f, (int64_t)new_size));
}

/*
** Rôle: file_system_change_directory — Calcule et retourne system change
**       répertoire à partir des paramètres fournis sans modifier les entrées
**       déclarées en lecture seule.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_change_directory().
** Appelants: app_paths_initialize(), main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_copy_stream.c -> file_system_change_directory() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int file_system_change_directory(const char *path)
{
	if (!path || !*path)
		return (-1);
	return (platform_change_directory(path));
}

/*
** Rôle: file_system_parent_path — Construit ou résout le chemin utilisé par
**       fichier système parent.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_paths_select_assets(),
**            file_system_get_executable_directory().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        file_system_copy_stream.c -> file_system_parent_path() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memcpy(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int file_system_parent_path(char *out, size_t outsz, const char *path)
{
	size_t	len;
	size_t	i;

	if (!out || outsz == 0 || !path || !*path)
		return (-1);
	len = strlen(path);
	if (len + 1 > outsz)
		return (-1);
	memcpy(out, path, len + 1);
	i = len;
	while (i > 0)
	{
		i--;
		if (out[i] == '/' || out[i] == '\\')
		{
			out[i] = '\0';
			return (0);
		}
	}
	out[0] = '\0';
	return (-1);
}
