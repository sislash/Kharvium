/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window_clip.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/native_window.h"

/*
** Rôle: window_clip_intersection — Calcule et retourne clip intersection à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: parent — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: child — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type t_window_clip_rectangle; les chemins
**         d’erreur restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_set_clip_rectangle(), window_set_clip_rectangle().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        window_clip.c -> window_clip_intersection() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_window_clip_rectangle	window_clip_intersection(
	t_window_clip_rectangle parent, t_window_clip_rectangle child)
{
	int	right;
	int	bottom;

	if (!parent.active)
		return (child);
	if (child.x < parent.x)
		child.x = parent.x;
	if (child.y < parent.y)
		child.y = parent.y;
	right = child.x + child.width;
	if (right > parent.x + parent.width)
		right = parent.x + parent.width;
	bottom = child.y + child.height;
	if (bottom > parent.y + parent.height)
		bottom = parent.y + parent.height;
	child.width = right - child.x;
	child.height = bottom - child.y;
	if (child.width <= 0 || child.height <= 0)
		child.active = 0;
	return (child);
}
