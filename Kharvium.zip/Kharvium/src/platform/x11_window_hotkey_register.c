/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_hotkey_register.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_reset_hotkey_target — Réinitialise raccourci clavier target en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_register_hotkeys(), x11_unregister_hotkeys(),
**            x11_register_hotkey_list().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_register.c -> x11_reset_hotkey_target() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_reset_hotkey_target(t_x11_backend *backend, int which)
{
	if (which == 0)
	{
		backend->hotkey_overlay_registered = 0;
		backend->hotkey_overlay_modifiers = 0;
		backend->hotkey_overlay_keycode = 0;
		backend->hotkey_overlay_key = 0;
	}
	else
	{
		backend->hotkey_click_registered = 0;
		backend->hotkey_click_modifiers = 0;
		backend->hotkey_click_keycode = 0;
		backend->hotkey_click_key = 0;
	}
}

/*
** Rôle: x11_store_hotkey_target — Traite store raccourci clavier target et
**       met à jour uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: definition — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_try_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_register.c -> x11_store_hotkey_target() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_store_hotkey_target(t_x11_backend *backend, int which,
	const t_x11_hotkey_definition *definition)
{
	if (which == 0)
	{
		backend->hotkey_overlay_registered = 1;
		backend->hotkey_overlay_modifiers = definition->modifiers;
		backend->hotkey_overlay_keycode = definition->keycode;
		backend->hotkey_overlay_key = definition->key;
	}
	else
	{
		backend->hotkey_click_registered = 1;
		backend->hotkey_click_modifiers = definition->modifiers;
		backend->hotkey_click_keycode = definition->keycode;
		backend->hotkey_click_key = definition->key;
	}
}

/*
** Rôle: x11_hotkey_registration_init — Initialise les données nécessaires à
**       X11 raccourci registration.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : request, backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_register_hotkey_list().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_register.c -> x11_hotkey_registration_init()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	x11_hotkey_registration_init(t_x11_hotkey_registration *request,
	t_x11_backend *backend, int which, const char *list)
{
	request->backend = backend;
	request->which = which;
	request->label = "lock";
	request->list = list;
	if (which == 0)
	{
		request->label = "overlay";
		if (!list)
			request->list = "Ctrl+Alt+O,Ctrl+Alt+Shift+O";
	}
	else if (!list)
		request->list = "Ctrl+Alt+P,Ctrl+Alt+Shift+P";
}

/*
** Rôle: x11_try_hotkey_combination — Traite try raccourci clavier
**       combination et met à jour uniquement
**       l’état d’entrée ou d’interface
**       correspondant à cet événement.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: combination — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_hotkey_log_message(),
**            x11_grab_hotkey_combination(), x11_parse_hotkey_combination(),
**            x11_store_hotkey_target().
** Appelants: x11_register_hotkey_list().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_register.c -> x11_try_hotkey_combination()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	x11_try_hotkey_combination(
	const t_x11_hotkey_registration *request, const char *combination)
{
	t_x11_hotkey_definition	definition;

	if (!x11_parse_hotkey_combination(request->backend, combination,
			&definition))
		return (platform_hotkey_log_message(
			"[X11] invalid combo ignored: [%s]", combination), 0);
	if (!x11_grab_hotkey_combination(request->backend,
			(int)definition.keycode, definition.modifiers))
		return (platform_hotkey_log_message(
			"[X11] hotkey %s conflict: %s (BadAccess)", request->label,
			combination), 0);
	x11_store_hotkey_target(request->backend, request->which, &definition);
	platform_hotkey_log_message("[X11] hotkey %s grabbed: %s",
		request->label, combination);
	return (1);
}

/*
** Rôle: x11_register_hotkey_list — Construit ou parcourt la liste utilisée
**       par X11 register raccourci.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: which — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hotkey_list_next_combination(),
**            platform_hotkey_log_message(), x11_hotkey_registration_init(),
**            x11_reset_hotkey_target(), x11_try_hotkey_combination().
** Appelants: x11_register_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_register.c -> x11_register_hotkey_list() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	x11_register_hotkey_list(t_x11_backend *backend, int which,
	const char *list)
{
	t_x11_hotkey_registration	request;
	const char					*cursor;
	char						combination[128];

	if (!backend || !backend->d || backend->is_overlay)
		return (0);
	x11_hotkey_registration_init(&request, backend, which, list);
	if (request.list && *request.list == '\0')
	{
		platform_hotkey_log_message("[X11] hotkey %s disabled (empty list)",
			request.label);
		return (x11_reset_hotkey_target(backend, which), 0);
	}
	cursor = request.list;
	while (hotkey_list_next_combination(&cursor, combination,
			(int)sizeof(combination)))
		if (x11_try_hotkey_combination(&request, combination))
			return (1);
	x11_reset_hotkey_target(backend, which);
	platform_hotkey_log_message("[X11] hotkey %s NOT available", request.label);
	return (0);
}

#endif
