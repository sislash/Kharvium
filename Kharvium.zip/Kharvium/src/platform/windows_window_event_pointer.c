/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_event_pointer.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_handle_overlay_hit — Traite hit en appliquant les validations
**       et transformations propres à cette opération, puis laisse les
**       données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_handle_pointer_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_event_pointer.c -> windows_handle_overlay_hit()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> DefWindowProc(),
**              GET_X_LPARAM(), GET_Y_LPARAM(), ScreenToClient().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_handle_overlay_hit(t_windows_message_context *context,
	LRESULT *result)
{
	POINT	point;

	if (context->message == WM_MOUSEACTIVATE && context->backend
		&& context->backend->is_overlay)
	{
		*result = MA_NOACTIVATE;
		return (1);
	}
	if (context->message != WM_NCHITTEST || !context->backend
		|| !context->backend->is_overlay)
		return (0);
	*result = DefWindowProc(context->hwnd, context->message,
		context->wparam, context->lparam);
	if (*result != HTCLIENT)
		return (1);
	point.x = GET_X_LPARAM(context->lparam);
	point.y = GET_Y_LPARAM(context->lparam);
	ScreenToClient(context->hwnd, &point);
	*result = HTCLIENT;
	if (point.y >= 0 && point.y < 24)
		*result = HTCAPTION;
	return (1);
}

/*
** Rôle: windows_update_mouse_position — Met à jour souris position à partir
**       des valeurs courantes et conserve l’état partagé cohérent pour la
**       suite de la frame ou du calcul.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_handle_pointer_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_event_pointer.c -> windows_update_mouse_position()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> GET_X_LPARAM(),
**              GET_Y_LPARAM().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_update_mouse_position(t_windows_message_context *context)
{
	context->window->mouse_x = GET_X_LPARAM(context->lparam);
	context->window->mouse_y = GET_Y_LPARAM(context->lparam);
}

/*
** Rôle: windows_update_mouse_wheel — Met à jour souris wheel à partir des
**       valeurs courantes et conserve l’état partagé cohérent pour la suite
**       de la frame ou du calcul.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_handle_pointer_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_event_pointer.c -> windows_update_mouse_wheel()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> HIWORD().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_update_mouse_wheel(t_windows_message_context *context)
{
	short	delta;

	delta = (short)HIWORD(context->wparam);
	if (delta > 0)
		context->window->mouse_wheel++;
	else if (delta < 0)
		context->window->mouse_wheel--;
}

/*
** Rôle: windows_handle_pointer_event — Traite pointer événement en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: result — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context, result.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_handle_overlay_hit(),
**            windows_update_mouse_position(), windows_update_mouse_wheel().
** Appelants: windows_message_handler().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_event_pointer.c -> windows_handle_pointer_event()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	windows_handle_pointer_event(t_windows_message_context *context,
	LRESULT *result)
{
	if (windows_handle_overlay_hit(context, result))
		return (1);
	if (!context->window)
		return (0);
	if (context->message == WM_MOUSEMOVE || context->message == WM_LBUTTONDOWN
		|| context->message == WM_LBUTTONUP)
		windows_update_mouse_position(context);
	if (context->message == WM_LBUTTONDOWN)
		context->window->mouse_left_click = 1;
	else if (context->message == WM_LBUTTONUP)
		context->window->mouse_left_down = 0;
	else if (context->message == WM_MOUSEWHEEL)
		windows_update_mouse_wheel(context);
	else if (context->message != WM_MOUSEMOVE)
		return (0);
	if (context->message == WM_LBUTTONDOWN)
		context->window->mouse_left_down = 1;
	*result = 0;
	return (1);
}

# endif
