/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_overlay_input.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef _WIN32

#  include "x11_window_backend_internal.h"

/*
** Rôle: x11_apply_click_through — Applique click through en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: b — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w, b.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_resize_buffers(), window_set_overlay_click_through().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_overlay_input.c -> x11_apply_click_through() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> XFlush(),
**              XShapeCombineRectangles().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_apply_click_through(t_window *w, t_x11_backend *b)
{
	(void)w;
	(void)b;
# ifdef KHARVIUM_HAVE_X11_SHAPE
	if (!w || !b || !b->d || !b->win)
		return ;
	if (!b->has_shape)
		return ;
	if (b->click_through)
	{
		XShapeCombineRectangles(b->d, b->win, ShapeInput,
			0, 0, NULL, 0, ShapeSet, Unsorted);
	}
	else
	{
		XRectangle	r;

		r.x = 0;
		r.y = 0;
		r.width = (unsigned short)w->width;
		r.height = (unsigned short)w->height;
		XShapeCombineRectangles(b->d, b->win, ShapeInput,
			0, 0, &r, 1, ShapeSet, Unsorted);
	}
	XFlush(b->d);
# endif
}

/*
** Rôle: window_set_overlay_click_through — Met à jour click through à partir
**       des valeurs courantes et conserve l’état partagé cohérent pour la
**       suite de la frame ou du calcul.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: on — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_apply_click_through().
** Appelants: overlay_set_demo(), overlay_toggle_click_through(),
**            overlay_open().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_overlay_input.c -> window_set_overlay_click_through()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_set_overlay_click_through(t_window *w, int on)
{
	t_x11_backend	*b;

	if (!w)
		return ;
	b = (t_x11_backend *)w->backend_1;
	if (!b)
		return ;
	b->click_through = (on != 0);
	x11_apply_click_through(w, b);
}

# endif
