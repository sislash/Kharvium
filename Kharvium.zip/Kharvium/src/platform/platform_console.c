/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_console.c                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/platform_console.h"
#include "platform/platform_console_internal.h"

#include <stdio.h>

#if defined(_WIN32) || defined(_WIN64)
# include <windows.h>
# include <conio.h>
#else
# include <unistd.h>
# include <sys/select.h>
# include <termios.h>

#endif

/*
** Rôle: platform_console_key_available — Calcule et retourne console touche
**       available à partir des paramètres fournis sans modifier les entrées
**       déclarées en lecture seule.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_console_restore_mode(),
**            platform_console_set_raw_mode().
** Appelants: ui_user_wants_quit(), ui_getch_nonblock(), ui_key_available().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_console.c -> platform_console_key_available() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> FD_ISSET(), FD_SET(),
**              FD_ZERO(), _kbhit(), select().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_console_key_available(void)
{
#if !defined(_WIN32) && !defined(_WIN64)
	int				ret;
	fd_set			set;
	struct timeval	tv;
	struct termios	old;
#endif
#if defined(_WIN32) || defined(_WIN64)
	return (_kbhit() != 0);
#else

	if (platform_console_set_raw_mode(&old) != 0)
		return (0);
	FD_ZERO(&set);
	FD_SET(STDIN_FILENO, &set);
	tv.tv_sec = 0;
	tv.tv_usec = 0;
	ret = select(STDIN_FILENO + 1, &set, NULL, NULL, &tv);
	platform_console_restore_mode(&old);
	if (ret > 0 && FD_ISSET(STDIN_FILENO, &set))
		return (1);
	return (0);
#endif
}

/*
** Rôle: platform_console_getch — Calcule et retourne console getch à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> platform_console_restore_mode(),
**            platform_console_set_raw_mode().
** Appelants: ui_user_wants_quit(), ui_getch_nonblock().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_console.c -> platform_console_getch() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> _getch(), read().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> read().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_console_getch(void)
{
#if !defined(_WIN32) && !defined(_WIN64)
	unsigned char	ch;
	size_t			got;
	struct termios	old;
#endif
#if defined(_WIN32) || defined(_WIN64)
	return (_getch());
#else

	got = 0;
	if (platform_console_set_raw_mode(&old) != 0)
		return (-1);
	if (read(STDIN_FILENO, &ch, 1) == 1)
		got = 1;
	platform_console_restore_mode(&old);
	if (got == 1)
		return ((int)ch);
	return (-1);
#endif
}

/*
** Rôle: platform_console_clear_screen — Réinitialise console screen en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: ui_clear_screen().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_console.c -> platform_console_clear_screen() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs ->
**              FillConsoleOutputAttribute(), FillConsoleOutputCharacterA(),
**              GetConsoleScreenBufferInfo(), GetStdHandle(),
**              SetConsoleCursorPosition(), fflush(), fputs().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fflush().
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=7. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	platform_console_clear_screen(void)
{
#if defined(_WIN32) || defined(_WIN64)
	HANDLE						hout;
	CONSOLE_SCREEN_BUFFER_INFO	csbi;
	DWORD						cell_count;
	DWORD						count;
	COORD						home;

	hout = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hout == INVALID_HANDLE_VALUE)
		return ;
	if (!GetConsoleScreenBufferInfo(hout, &csbi))
		return ;
	cell_count = (DWORD)csbi.dwSize.X * (DWORD)csbi.dwSize.Y;
	count = 0;
	home.X = 0;
	home.Y = 0;
	FillConsoleOutputCharacterA(hout, ' ', cell_count, home, &count);
	FillConsoleOutputAttribute(hout, csbi.wAttributes, cell_count, home,
		&count);
	SetConsoleCursorPosition(hout, home);
#else
	fputs("\x1b[2J\x1b[H", stdout);
	fflush(stdout);
#endif
}

/*
** Rôle: platform_console_clear_viewport — Réinitialise console viewport en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: ui_clear_viewport().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_console.c -> platform_console_clear_viewport() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs ->
**              FillConsoleOutputAttribute(), FillConsoleOutputCharacterA(),
**              GetConsoleScreenBufferInfo(), GetStdHandle(),
**              SetConsoleCursorPosition(), fflush(), fputs().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fflush().
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=7. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	platform_console_clear_viewport(void)
{
#if defined(_WIN32) || defined(_WIN64)
	HANDLE						hout;
	CONSOLE_SCREEN_BUFFER_INFO	csbi;
	COORD						top_left;
	DWORD						cells;
	DWORD						count;

	hout = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hout == INVALID_HANDLE_VALUE)
		return ;
	if (!GetConsoleScreenBufferInfo(hout, &csbi))
		return ;
	top_left.X = csbi.srWindow.Left;
	top_left.Y = csbi.srWindow.Top;
	cells = (DWORD)(csbi.srWindow.Right - csbi.srWindow.Left + 1)
		* (DWORD)(csbi.srWindow.Bottom - csbi.srWindow.Top + 1);
	count = 0;
	FillConsoleOutputCharacterA(hout, ' ', cells, top_left, &count);
	FillConsoleOutputAttribute(hout, csbi.wAttributes, cells, top_left, &count);
	SetConsoleCursorPosition(hout, top_left);
#else
	fputs("\x1b[2J\x1b[H", stdout);
	fflush(stdout);
#endif
}

/*
** Rôle: platform_console_cursor_home — Met à jour console curseur home en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut appeler le backend natif et modifier l’état
**         graphique ou événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: ui_cursor_home().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_console.c -> platform_console_cursor_home() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> GetStdHandle(),
**              SetConsoleCursorPosition(), fflush(), fputs().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fflush().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	platform_console_cursor_home(void)
{
#if defined(_WIN32) || defined(_WIN64)
	HANDLE	hout;
	COORD	home;

	hout = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hout == INVALID_HANDLE_VALUE)
		return ;
	home.X = 0;
	home.Y = 0;
	SetConsoleCursorPosition(hout, home);
#else
	fputs("\x1b[H", stdout);
	fflush(stdout);
#endif
}
