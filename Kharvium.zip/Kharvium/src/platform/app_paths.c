/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/31                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "app_paths_internal.h"
#include "app_paths_migration_internal.h"
#include "platform/file_system.h"
#include "common/string_operations.h"

#include <stdlib.h>
#include <string.h>

/*
** Rôle: app_paths_select_assets — Sélectionne paths actifs en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: argv0 — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement ->
**            app_paths_directory_has_required_assets(),
**            file_system_get_executable_directory(),
**            file_system_parent_path(), string_copy_safe().
** Appelants: app_paths_initialize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère app_paths.c
**        -> app_paths_select_assets() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	app_paths_select_assets(t_app_paths_init_context *context,
		const char *argv0)
{
	if (file_system_get_executable_directory(context->executable_dir,
			sizeof(context->executable_dir), argv0) != 0
		|| context->executable_dir[0] == '\0')
		string_copy_safe(context->executable_dir,
			sizeof(context->executable_dir), ".");
	context->assets_root = context->executable_dir;
	if (app_paths_directory_has_required_assets(context->assets_root))
		return ;
	if (file_system_parent_path(context->parent, sizeof(context->parent),
			context->executable_dir) == 0 && context->parent[0]
		&& app_paths_directory_has_required_assets(context->parent))
		context->assets_root = context->parent;
}

/*
** Rôle: app_paths_home_base — Compare paths home base selon les règles de
**       chaîne du module et retourne le résultat sans modifier les entrées.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_paths_select_writable_root().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère app_paths.c
**        -> app_paths_home_base() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> getenv().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
static const char	*app_paths_home_base(void)
{
	const char	*base;

	base = getenv("KHARVIUM_HOME");
	if (!base || !*base)
		base = getenv("TRACKER_LOOT_HOME");
#if defined(_WIN32) || defined(_WIN64)
	if (!base || !*base)
		base = getenv("LOCALAPPDATA");
	if (!base || !*base)
		base = getenv("APPDATA");
	if (!base || !*base)
		base = getenv("USERPROFILE");
#else
	if (!base || !*base)
		base = getenv("XDG_DATA_HOME");
	if (!base || !*base)
		base = getenv("HOME");
#endif
	return (base);
}

/*
** Rôle: app_paths_select_writable_root — Sélectionne paths writable root en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_home_base(),
**            file_system_directory_is_writable(),
**            file_system_ensure_directory(), file_system_join_path().
** Appelants: app_paths_initialize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère app_paths.c
**        -> app_paths_select_writable_root() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	app_paths_select_writable_root(t_app_paths_init_context *context)
{
	context->root = context->assets_root;
	context->data_root[0] = '\0';
	if (file_system_directory_is_writable(context->root))
		return ;
	context->base = app_paths_home_base();
	if (!context->base || !*context->base)
		return ;
	if (file_system_join_path(context->data_root,
			sizeof(context->data_root), context->base, "kharvium") != 0)
		return ;
	if (file_system_ensure_directory(context->data_root) != 0)
		return ;
	if (file_system_directory_is_writable(context->data_root))
		context->root = context->data_root;
}

/*
** Rôle: app_paths_copy_default_assets — Copie paths par défaut actifs en
**       préservant la propriété des ressources, les compteurs et la
**       cohérence de la destination.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_path_markup_ini(),
**            app_path_weapons_ini(), app_paths_copy_weapon_asset(),
**            file_system_copy_file(), file_system_file_exists(),
**            file_system_join_path().
** Appelants: app_paths_initialize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère app_paths.c
**        -> app_paths_copy_default_assets() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	app_paths_copy_default_assets(t_app_paths_init_context *context)
{
	if (strcmp(context->root, context->assets_root) == 0)
		return ;
	if (!file_system_file_exists(app_path_weapons_ini()))
		(void)app_paths_copy_weapon_asset(context->assets_root,
			app_path_weapons_ini());
	app_paths_copy_fishing_asset(context);
	if (file_system_file_exists(app_path_markup_ini()))
		return ;
	if (file_system_join_path(context->source, sizeof(context->source),
			context->assets_root, APP_FILE_MARKUP_INI) == 0)
		(void)file_system_copy_file(context->source, app_path_markup_ini());
}

/*
** Rôle: app_paths_initialize — Initialise l’état associé à application
**       chemins.
** Paramètre: argv0 — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_build_from_root(),
**            app_paths_copy_default_assets(),
**            app_paths_ensure_logs_directory(),
**            app_paths_migrate_legacy_data(), app_paths_select_assets(),
**            app_paths_select_writable_root(), app_paths_state(),
**            file_system_change_directory() (+1; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Appelants: runtime_preflight().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère app_paths.c
**        -> app_paths_initialize() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=9; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	app_paths_initialize(const char *argv0)
{
	t_app_paths_state		*paths;
	t_app_paths_init_context	context;

	paths = app_paths_state();
	if (paths->initialized)
		return (0);
	app_paths_select_assets(&context, argv0);
	string_copy_safe(paths->assets_root, sizeof(paths->assets_root),
		context.assets_root);
	app_paths_select_writable_root(&context);
	if (app_paths_build_from_root(context.root) != 0)
		return (-1);
	app_paths_migrate_legacy_data(context.root);
	app_paths_copy_default_assets(&context);
	app_paths_ensure_logs_directory();
	file_system_change_directory(paths->root);
	paths->initialized = 1;
	return (0);
}
