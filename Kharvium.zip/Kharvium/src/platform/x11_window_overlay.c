/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_overlay.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: window_initialize_overlay — Initialise une fenêtre overlay native à
**       partir des paramètres demandés.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_initialize_common(),
**            x11_overlay_disable_input(), x11_overlay_set_fixed_size(),
**            x11_overlay_set_opacity(), x11_overlay_set_topmost(),
**            x11_overlay_set_window_type().
** Appelants: overlay_open().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_overlay.c -> window_initialize_overlay() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> XFlush(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_initialize_overlay(t_window *window,
	const t_window_overlay_request *request)
{
	t_x11_initialize_context	context;
	t_x11_backend			*backend;

	if (!request)
		return (1);
	memset(&context, 0, sizeof(context));
	context.window = window;
	context.title = request->title;
	context.width = request->width;
	context.height = request->height;
	context.is_overlay = 1;
	if (window_initialize_common(&context))
		return (1);
	backend = context.backend;
	x11_overlay_set_fixed_size(backend, request);
	x11_overlay_disable_input(backend);
	x11_overlay_set_window_type(backend);
	x11_overlay_set_opacity(backend, request->alpha_0_255);
	if (request->topmost)
		x11_overlay_set_topmost(backend);
	XFlush(backend->d);
	return (0);
}

#endif
