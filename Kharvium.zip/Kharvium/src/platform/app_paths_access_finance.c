/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths_access_finance.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "app_paths_internal.h"
#include "platform/file_system.h"

/*
** Rôle: app_path_finance_book — Calcule et retourne chemin book à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_state().
** Appelants: app_finance_save(), finance_app_initialize(),
**            finance_reload_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_access_finance.c -> app_path_finance_book() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
const char	*app_path_finance_book(void)
{
	return (app_paths_state()->finance_book);
}

/*
** Rôle: app_paths_ensure_logs_directory — Garantit paths logs répertoire en
**       appliquant les validations,
**       bornes et effets explicitement
**       définis par ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_paths_state(),
**            file_system_ensure_directory().
** Appelants: global_events_worker_execute_engine(),
**            parse_worker_execute_engine(), app_paths_initialize(),
**            global_events_menu_render(), legacy_global_menu_init().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_access_finance.c -> app_paths_ensure_logs_directory()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	app_paths_ensure_logs_directory(void)
{
	return (file_system_ensure_directory(app_paths_state()->logs_dir));
}
