/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_overlay_setup.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_overlay_set_fixed_size — Calcule set fixed taille à partir des
**       entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize_overlay().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_overlay_setup.c -> x11_overlay_set_fixed_size() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> XSetWMNormalHints(),
**              memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_overlay_set_fixed_size(t_x11_backend *backend,
	const t_window_overlay_request *request)
{
	XSizeHints	hints;

	memset(&hints, 0, sizeof(hints));
	hints.flags = PMinSize | PMaxSize;
	hints.min_width = request->width;
	hints.min_height = request->height;
	hints.max_width = request->width;
	hints.max_height = request->height;
	XSetWMNormalHints(backend->d, backend->win, &hints);
}

/*
** Rôle: x11_overlay_disable_input — Traite disable entrée et met à jour
**       uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize_overlay().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_overlay_setup.c -> x11_overlay_disable_input() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> XAllocWMHints(), XFree(),
**              XSetWMHints().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_overlay_disable_input(t_x11_backend *backend)
{
	XWMHints	*hints;

	hints = XAllocWMHints();
	if (!hints)
		return ;
	hints->flags = InputHint;
	hints->input = False;
	XSetWMHints(backend->d, backend->win, hints);
	XFree(hints);
}

/*
** Rôle: x11_overlay_set_window_type — Met à jour type à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize_overlay().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_overlay_setup.c -> x11_overlay_set_window_type() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> XChangeProperty(),
**              XInternAtom().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_overlay_set_window_type(t_x11_backend *backend)
{
	Atom	type_atom;
	Atom	utility_atom;

	type_atom = XInternAtom(backend->d, "_NET_WM_WINDOW_TYPE", False);
	utility_atom = XInternAtom(backend->d,
		"_NET_WM_WINDOW_TYPE_UTILITY", False);
	if (type_atom == None || utility_atom == None)
		return ;
	XChangeProperty(backend->d, backend->win, type_atom, XA_ATOM, 32,
		PropModeReplace, (unsigned char *)&utility_atom, 1);
}

/*
** Rôle: x11_overlay_set_opacity — Met à jour opacity à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: alpha — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize_overlay().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_overlay_setup.c -> x11_overlay_set_opacity() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> XChangeProperty(),
**              XInternAtom().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_overlay_set_opacity(t_x11_backend *backend, int alpha)
{
	unsigned long	opacity;
	Atom			opacity_atom;

	if (alpha < 0)
		alpha = 0;
	if (alpha > 255)
		alpha = 255;
	opacity = (unsigned long)((double)alpha / 255.0 * 4294967295.0);
	opacity_atom = XInternAtom(backend->d, "_NET_WM_WINDOW_OPACITY", False);
	if (opacity_atom == None)
		return ;
	XChangeProperty(backend->d, backend->win, opacity_atom, XA_CARDINAL, 32,
		PropModeReplace, (unsigned char *)&opacity, 1);
}

/*
** Rôle: x11_overlay_set_topmost — Met à jour topmost à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_ewmh_add_state().
** Appelants: window_initialize_overlay().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_overlay_setup.c -> x11_overlay_set_topmost() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> XInternAtom().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_overlay_set_topmost(t_x11_backend *backend)
{
	t_x11_ewmh_state_request	state;
	Atom					above;
	Atom					skip_taskbar;

	above = XInternAtom(backend->d, "_NET_WM_STATE_ABOVE", False);
	skip_taskbar = XInternAtom(backend->d,
		"_NET_WM_STATE_SKIP_TASKBAR", False);
	state.display = backend->d;
	state.screen = backend->screen;
	state.window = backend->win;
	state.first = above;
	state.second = skip_taskbar;
	if (above != None)
		x11_ewmh_add_state(&state);
	state.first = XInternAtom(backend->d, "_NET_WM_STATE_SKIP_PAGER", False);
	state.second = None;
	if (state.first != None)
		x11_ewmh_add_state(&state);
}

#endif
