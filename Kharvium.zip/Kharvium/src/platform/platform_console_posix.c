/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_console_posix.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/platform_console_internal.h"

#if !defined(_WIN32) && !defined(_WIN64)
# include <unistd.h>

/*
** Rôle: platform_console_set_raw_mode — exécute l’opération interne «
** platform console set raw mode » avec validation des bornes et erreurs.
** Paramètre: old — valeur « old » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Retour: Retourne 0 ou une valeur de succès selon le contrat local; une
** valeur non nulle/alternative propage une erreur ou un résultat de
** comparaison lorsque le corps le prévoit.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: platform_console_getch(), platform_console_key_available().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_console_posix.c -> platform_console_set_raw_mode() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> tcgetattr(), tcsetattr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

int	platform_console_set_raw_mode(struct termios *old)
{
	struct termios	newt;

	if (tcgetattr(STDIN_FILENO, old) != 0)
		return (-1);
	newt = *old;
	newt.c_lflag &= (unsigned int)~(ICANON | ECHO);
	newt.c_cc[VMIN] = 0;
	newt.c_cc[VTIME] = 0;
	if (tcsetattr(STDIN_FILENO, TCSANOW, &newt) != 0)
		return (-1);
	return (0);
}

/*
** Rôle: platform_console_restore_mode — exécute l’opération interne «
** platform console restore mode » avec validation des bornes et erreurs.
** Paramètre: old — valeur « old » utilisée uniquement selon le contrat et les
** validations de cette fonction.
** Retour: Ne retourne rien; les effets sont appliqués uniquement aux sorties
** et structures explicitement fournies.
** Effets: les modifications sont limitées aux buffers, collections, fichiers
** ou sorties explicitement identifiés par le corps; les erreurs sont
** propagées au niveau appelant.
** Invariants: les pointeurs et capacités obligatoires sont validés avant
** usage; une erreur ne doit pas laisser une collection possédée dans un état
** partiellement transféré.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: platform_console_getch(), platform_console_key_available().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_console_posix.c -> platform_console_restore_mode() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> tcsetattr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/

void	platform_console_restore_mode(const struct termios *old)
{
	if (old)
		(void)tcsetattr(STDIN_FILENO, TCSANOW, old);
}
#endif
