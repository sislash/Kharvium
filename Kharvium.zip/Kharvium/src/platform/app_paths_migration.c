/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths_migration.c                              +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 13:30:00 by tracker_loot       #+#    #+#            */
/*   Updated: 2026/08/28 13:30:00 by tracker_loot      ###   ########.fr      */
/*                                                                            */
/* ************************************************************************** */

#include "app_paths_migration_internal.h"
#include "platform/app_paths.h"
#include "platform/file_system.h"

#define LEGACY_WEAPONS_INI "armes.ini"
#define LEGACY_SELECTED_WEAPON "logs/weapon_selected.txt"
#define LEGACY_SELECTED_CREATURE "logs/mob_selected.txt"
#define LEGACY_SESSION_STATISTICS "logs/sessions_stats.csv"
#define LEGACY_GLOBAL_EVENTS "logs/globals.csv"

/*
** Rôle: legacy_copy_if_missing — Copie legacy if missing en préservant la
**       propriété des ressources, les compteurs et la cohérence de la
**       destination.
** Paramètre: root — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: legacy_name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: current_name — objet source consulté en lecture seule par
**            cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_copy_file(),
**            file_system_file_exists(), file_system_join_path().
** Appelants: app_paths_migrate_legacy_data().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_migration.c -> legacy_copy_if_missing() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	legacy_copy_if_missing(const char *root, const char *legacy_name,
		const char *current_name)
{
	char	legacy_path[1024];
	char	current_path[1024];

	if (file_system_join_path(legacy_path, sizeof(legacy_path), root,
			legacy_name) != 0)
		return (-1);
	if (file_system_join_path(current_path, sizeof(current_path), root,
			current_name) != 0)
		return (-1);
	if (file_system_file_exists(current_path))
		return (0);
	if (!file_system_file_exists(legacy_path))
		return (0);
	return (file_system_copy_file(legacy_path, current_path));
}

/*
** Rôle: app_paths_migrate_legacy_data — Migre paths legacy data en
**       appliquant les validations, bornes
**       et effets explicitement définis par
**       ce module.
** Paramètre: root — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> legacy_copy_if_missing().
** Appelants: app_paths_initialize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_migration.c -> app_paths_migrate_legacy_data() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	app_paths_migrate_legacy_data(const char *root)
{
	(void)legacy_copy_if_missing(root, LEGACY_WEAPONS_INI,
		APP_FILE_WEAPONS_INI);
	(void)legacy_copy_if_missing(root, LEGACY_SELECTED_WEAPON,
		APP_FILE_SELECTED_WEAPON);
	(void)legacy_copy_if_missing(root, LEGACY_SELECTED_CREATURE,
		APP_FILE_SELECTED_CREATURE);
	(void)legacy_copy_if_missing(root, LEGACY_SESSION_STATISTICS,
		APP_FILE_SESSION_STATISTICS_CSV);
	(void)legacy_copy_if_missing(root, LEGACY_GLOBAL_EVENTS,
		APP_FILE_GLOBAL_EVENTS_CSV);
}

/*
** Rôle: app_paths_copy_weapon_asset — Copie paths actif en préservant la
**       propriété des ressources, les compteurs et la cohérence de la
**       destination.
** Paramètre: assets_root — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: destination — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_copy_file(),
**            file_system_file_exists(), file_system_join_path().
** Appelants: app_paths_copy_default_assets().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        app_paths_migration.c -> app_paths_copy_weapon_asset() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	app_paths_copy_weapon_asset(const char *assets_root,
		const char *destination)
{
	char	source[1024];

	if (file_system_join_path(source, sizeof(source), assets_root,
			APP_FILE_WEAPONS_INI) != 0)
		return (-1);
	if (!file_system_file_exists(source))
	{
		if (file_system_join_path(source, sizeof(source), assets_root,
				LEGACY_WEAPONS_INI) != 0)
			return (-1);
	}
	if (!file_system_file_exists(source))
		return (-1);
	return (file_system_copy_file(source, destination));
}
