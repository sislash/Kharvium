/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_initialize_helpers.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_initialize_context_backend — Initialise contexte backend à partir
**       des paramètres fournis et initialise tous les champs requis avant
**       qu’ils soient lus par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_fit_size_to_screen().
** Appelants: window_initialize_common().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_initialize_helpers.c -> x11_initialize_context_backend()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> DefaultColormap(),
**              DefaultDepth(), DefaultScreen(), DefaultVisual(),
**              XOpenDisplay(), free(), malloc(), memset().
** Mémoire: opérations directes -> free(), malloc(); le transfert de
**          propriété reste défini par Retour/Effets et les contrats des
**          fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=8. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	x11_initialize_context_backend(t_x11_initialize_context *context)
{
	t_x11_backend	*backend;

	backend = (t_x11_backend *)malloc(sizeof(*backend));
	if (!backend)
		return (1);
	memset(backend, 0, sizeof(*backend));
	backend->d = XOpenDisplay(NULL);
	if (!backend->d)
		return (free(backend), 1);
	backend->screen = DefaultScreen(backend->d);
	x11_fit_size_to_screen(backend, &context->width, &context->height);
	backend->vis = DefaultVisual(backend->d, backend->screen);
	backend->depth = DefaultDepth(backend->d, backend->screen);
	backend->cmap = DefaultColormap(backend->d, backend->screen);
	backend->is_overlay = context->is_overlay;
	context->backend = backend;
	return (0);
}

/*
** Rôle: x11_initialize_native_window — Initialise native à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize_common().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_initialize_helpers.c -> x11_initialize_native_window()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> BlackPixel(), RootWindow(),
**              WhitePixel(), XCreateGC(), XCreateSimpleWindow(),
**              XInternAtom(), XMapWindow(), XSelectInput() (+2; index
**              complet dans docs/FUNCTION_CALL_GRAPH.md).
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=10. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	x11_initialize_native_window(t_x11_initialize_context *context)
{
	t_x11_backend	*backend;
	const char		*title;

	backend = context->backend;
	backend->win = XCreateSimpleWindow(backend->d,
		RootWindow(backend->d, backend->screen), 0, 0,
		(unsigned int)context->width, (unsigned int)context->height, 1,
		BlackPixel(backend->d, backend->screen),
		WhitePixel(backend->d, backend->screen));
	if (!backend->win)
		return (1);
	title = context->title;
	if (!title)
		title = "window";
	XStoreName(backend->d, backend->win, title);
	XSelectInput(backend->d, backend->win, ExposureMask | KeyPressMask
		| KeyReleaseMask | ButtonPressMask | ButtonReleaseMask
		| PointerMotionMask | StructureNotifyMask);
	backend->wm_delete = XInternAtom(backend->d, "WM_DELETE_WINDOW", False);
	XSetWMProtocols(backend->d, backend->win, &backend->wm_delete, 1);
	XMapWindow(backend->d, backend->win);
	backend->gc = XCreateGC(backend->d, backend->win, 0, NULL);
	return (backend->gc == 0);
}

/*
** Rôle: x11_initialize_shape — Initialise shape à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize_common().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_initialize_helpers.c -> x11_initialize_shape() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> XShapeQueryExtension(),
**              XShapeQueryVersion().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_initialize_shape(t_x11_backend *backend)
{
#ifdef KHARVIUM_HAVE_X11_SHAPE
	int	event_base;
	int	error_base;
	int	major;
	int	minor;

	backend->has_shape = 0;
	if (XShapeQueryExtension(backend->d, &event_base, &error_base)
		&& XShapeQueryVersion(backend->d, &major, &minor))
		backend->has_shape = 1;
#else
	backend->has_shape = 0;
#endif
}

/*
** Rôle: x11_initialize_graphics — Initialise graphics à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize_common().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_initialize_helpers.c -> x11_initialize_graphics()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> XCreatePixmap(),
**              XLoadQueryFont(), XSetFont().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_initialize_graphics(t_x11_initialize_context *context)
{
	t_x11_backend	*backend;

	backend = context->backend;
	x11_initialize_fonts(backend);
	backend->back = XCreatePixmap(backend->d, backend->win,
		(unsigned int)context->width, (unsigned int)context->height,
		(unsigned int)backend->depth);
}

/*
** Rôle: x11_initialize_window_state — Initialise état à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_initialize_common().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_initialize_helpers.c -> x11_initialize_window_state()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_initialize_window_state(t_x11_initialize_context *context)
{
	t_window	*window;

	window = context->window;
	window->running = 1;
	window->title = context->title;
	window->width = context->width;
	window->height = context->height;
	window->pitch = 0;
	window->pixels = NULL;
	window->use_buffer = 1;
	window->backend_1 = (void *)context->backend;
	window->backend_2 = NULL;
	window->backend_3 = NULL;
}

#endif
