/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window_hotkey_parse.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "window_hotkey_parse_internal.h"
#include "common/string_operations.h"
#include <string.h>

/*
** Rôle: window_hotkey_read_token — Lit raccourci clavier jeton depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: cursor — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: token — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_skip_spaces(),
**            string_to_lowercase_ascii().
** Appelants: window_hotkey_parse_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        window_hotkey_parse.c -> window_hotkey_read_token() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	window_hotkey_read_token(const char **cursor, char token[32])
{
	int	position;

	*cursor = string_skip_spaces(*cursor);
	position = 0;
	while (**cursor && **cursor != '+' && **cursor != ',' && position < 31)
		token[position++] = *(*cursor)++;
	token[position] = '\0';
	while (position > 0 && (token[position - 1] == ' '
			|| token[position - 1] == '\t'))
		token[--position] = '\0';
	string_to_lowercase_ascii(token);
}

/*
** Rôle: window_hotkey_apply_key — Applique raccourci clavier touche en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: token — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: combination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : combination.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_hotkey_apply_token().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        window_hotkey_parse.c -> window_hotkey_apply_key() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	window_hotkey_apply_key(const char *token,
	t_window_hotkey_combination *combination)
{
	char	key;

	if (token[0] == '\0' || token[1] != '\0')
		return (0);
	key = token[0];
	if (key >= 'a' && key <= 'z')
		key = (char)(key - 'a' + 'A');
	if (!((key >= 'A' && key <= 'Z') || (key >= '0' && key <= '9')))
		return (0);
	combination->key = key;
	return (1);
}

/*
** Rôle: window_hotkey_apply_token — Applique raccourci clavier jeton en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: token — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: combination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : combination.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_hotkey_apply_key().
** Appelants: window_hotkey_parse_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        window_hotkey_parse.c -> window_hotkey_apply_token() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	window_hotkey_apply_token(const char *token,
	t_window_hotkey_combination *combination)
{
	if (strcmp(token, "ctrl") == 0 || strcmp(token, "control") == 0)
		combination->flags |= WINDOW_HOTKEY_CTRL;
	else if (strcmp(token, "alt") == 0)
		combination->flags |= WINDOW_HOTKEY_ALT;
	else if (strcmp(token, "shift") == 0)
		combination->flags |= WINDOW_HOTKEY_SHIFT;
	else if (strcmp(token, "win") == 0 || strcmp(token, "meta") == 0)
		combination->flags |= WINDOW_HOTKEY_META;
	else
		return (window_hotkey_apply_key(token, combination));
	return (0);
}

/*
** Rôle: window_hotkey_parse_combination — Analyse raccourci clavier
**       combination depuis la source fournie, contrôle le format utile et ne
**       renseigne la destination qu’avec des données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: combination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : combination.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_hotkey_apply_token(),
**            window_hotkey_read_token().
** Appelants: windows_parse_hotkey_combination(),
**            x11_parse_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        window_hotkey_parse.c -> window_hotkey_parse_combination() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_hotkey_parse_combination(const char *text,
	t_window_hotkey_combination *combination)
{
	char	token[32];
	int		have_key;

	if (!text || !combination)
		return (0);
	memset(combination, 0, sizeof(*combination));
	have_key = 0;
	while (*text)
	{
		window_hotkey_read_token(&text, token);
		have_key |= window_hotkey_apply_token(token, combination);
		while (*text && *text != '+' && *text != ',')
			text++;
		if (*text != '+')
			break ;
		text++;
	}
	return (have_key);
}
/*
** Rôle: window_hotkey_registration_mask — Traite raccourci clavier
**       registration mask et met à jour
**       uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: overlay_registered — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: click_registered — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_get_hotkeys(), window_rebind_hotkeys(),
**            window_get_hotkeys(), window_rebind_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        window_hotkey_parse.c -> window_hotkey_registration_mask() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_hotkey_registration_mask(int overlay_registered,
	int click_registered)
{
	int	mask;

	mask = 0;
	if (overlay_registered)
		mask |= 1;
	if (click_registered)
		mask |= 2;
	return (mask);
}

