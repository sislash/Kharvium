/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_hotkey_mask.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_numlock_from_map — Construit à partir de numlock map en
**       appliquant les validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: map — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: numlock_keycode — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type unsigned int; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : map.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_get_num_lock_mask().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_mask.c -> x11_numlock_from_map() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=2; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
static unsigned int	x11_numlock_from_map(XModifierKeymap *map,
	KeyCode numlock_keycode)
{
	int	modifier;
	int	index;

	modifier = 0;
	while (modifier < 8)
	{
		index = 0;
		while (index < map->max_keypermod)
		{
			if (map->modifiermap[modifier * map->max_keypermod + index]
				== numlock_keycode)
				return (1U << modifier);
			index++;
		}
		modifier++;
	}
	return (0);
}

/*
** Rôle: x11_get_num_lock_mask — Retourne num lock mask en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: display — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type unsigned int; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : display.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_numlock_from_map().
** Appelants: x11_register_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_mask.c -> x11_get_num_lock_mask() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> XFreeModifiermap(),
**              XGetModifierMapping(), XKeysymToKeycode().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
unsigned int	x11_get_num_lock_mask(Display *display)
{
	unsigned int	mask;
	XModifierKeymap	*map;
	KeyCode			numlock_keycode;

	if (!display)
		return (0);
	numlock_keycode = XKeysymToKeycode(display, XK_Num_Lock);
	if (numlock_keycode == 0)
		return (0);
	map = XGetModifierMapping(display);
	if (!map)
		return (0);
	mask = x11_numlock_from_map(map, numlock_keycode);
	XFreeModifiermap(map);
	return (mask);
}

/*
** Rôle: x11_build_grab_masks — Construit grab masks à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: backend — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: modifiers — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: masks — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_grab_hotkey_combination(), x11_ungrab_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_mask.c -> x11_build_grab_masks() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_build_grab_masks(const t_x11_backend *backend,
	unsigned int modifiers, unsigned int masks[4])
{
	masks[0] = modifiers;
	masks[1] = modifiers | LockMask;
	masks[2] = modifiers | backend->numlock_mask;
	masks[3] = modifiers | backend->numlock_mask | LockMask;
}

#endif
