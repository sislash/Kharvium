/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_process.c                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/platform_file_system.h"

#if defined(_WIN32) || defined(_WIN64)
# include <io.h>
# include <process.h>
#else
# include <unistd.h>

extern int	fileno(FILE *stream);
#endif

/*
** Rôle: platform_stream_file_descriptor — Calcule et retourne stream
**       descriptor à partir des paramètres fournis sans modifier les entrées
**       déclarées en lecture seule.
** Paramètre: f — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : f.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: platform_stream_truncate(), storage_flush_sync().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_process.c -> platform_stream_file_descriptor() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> _fileno(), fileno().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_stream_file_descriptor(FILE *f)
{
	if (!f)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	return (_fileno(f));
#else
	return (fileno(f));
#endif
}

/*
** Rôle: platform_sync_file_descriptor — Calcule et retourne sync descriptor à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: fd — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: storage_flush_sync().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_process.c -> platform_sync_file_descriptor() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> _commit(), fsync().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fsync().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_sync_file_descriptor(int fd)
{
	if (fd < 0)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	return (_commit(fd));
#else
	return (fsync(fd));
#endif
}

/*
** Rôle: platform_process_id — Traite id en appliquant les validations et
**       transformations propres à cette opération, puis laisse les données
**       concernées dans un état cohérent.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: csv_journal_lock_acquire(), csv_journal_build_archive_path(),
**            storage_temp_path(), test_csv_paths_init(),
**            test_hunt_loot_unvalued_items(),
**            test_hunt_loot_missing_kill_id() (+11; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_process.c -> platform_process_id() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> _getpid(), getpid().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_process_id(void)
{
#if defined(_WIN32) || defined(_WIN64)
	return ((int)_getpid());
#else
	return ((int)getpid());
#endif
}
