/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_input.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: windows_set_navigation_key — Met à jour navigation touche à partir
**       des valeurs courantes et conserve l’état partagé cohérent pour la
**       suite de la frame ou du calcul.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: key — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_set_key_state().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_input.c -> windows_set_navigation_key() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_set_navigation_key(t_window *window, WPARAM key)
{
	if (key == VK_UP)
		window->key_up = 1;
	else if (key == VK_DOWN)
		window->key_down = 1;
	else if (key == VK_RETURN)
		window->key_enter = 1;
	else if (key == VK_ESCAPE)
		window->key_escape = 1;
	else
		return (0);
	return (1);
}

/*
** Rôle: windows_set_text_key — Met à jour texte touche à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: key — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_set_key_state().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_input.c -> windows_set_text_key() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_set_text_key(t_window *window, WPARAM key)
{
	if (key == VK_BACK)
		window->key_backspace = 1;
	else if (key == VK_DELETE)
		window->key_delete = 1;
	else if (key == VK_TAB)
		window->key_tab = 1;
	else
		return (0);
	return (1);
}

/*
** Rôle: windows_set_key_state — Met à jour touche état à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: key — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_set_navigation_key(),
**            windows_set_text_key().
** Appelants: windows_handle_keyboard_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_input.c -> windows_set_key_state() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_set_key_state(t_window *window, WPARAM key)
{
	if (windows_set_navigation_key(window, key)
		|| windows_set_text_key(window, key))
		return ;
	if (key == 'Z')
		window->key_z = 1;
	else if (key == 'Q')
		window->key_q = 1;
	else if (key == 'S')
		window->key_s = 1;
	else if (key == 'D')
		window->key_d = 1;
	else if (key == 'O')
		window->key_o = 1;
	else if (key == 'H')
		window->key_h = 1;
	else if (key == 'P')
		window->key_p = 1;
}

/*
** Rôle: windows_unset_key_state — Consulte ou prépare l’état nécessaire à
**       Win32 unset key.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: key — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: windows_handle_keyboard_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_input.c -> windows_unset_key_state() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_unset_key_state(t_window *window, WPARAM key)
{
	if (key == 'Z')
		window->key_z = 0;
	else if (key == 'Q')
		window->key_q = 0;
	else if (key == 'S')
		window->key_s = 0;
	else if (key == 'D')
		window->key_d = 0;
	else if (key == 'O')
		window->key_o = 0;
	else if (key == 'P')
		window->key_p = 0;
}

# endif
