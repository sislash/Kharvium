/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_event_state.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_apply_navigation_key — Applique navigation touche en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: keysym — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_apply_pressed_key().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_event_state.c -> x11_apply_navigation_key() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	x11_apply_navigation_key(t_window *window, KeySym keysym)
{
	if (keysym == XK_Up)
		window->key_up = 1;
	else if (keysym == XK_Down)
		window->key_down = 1;
	else if (keysym == XK_Return || keysym == XK_KP_Enter)
		window->key_enter = 1;
	else if (keysym == XK_Escape)
		window->key_escape = 1;
	else if (keysym == XK_BackSpace)
		window->key_backspace = 1;
	else if (keysym == XK_Delete)
		window->key_delete = 1;
	else if (keysym == XK_Tab)
		window->key_tab = 1;
	else
		return (0);
	return (1);
}

/*
** Rôle: x11_apply_pressed_key — Applique pressed touche en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: keysym — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_apply_navigation_key().
** Appelants: x11_handle_key_press().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_event_state.c -> x11_apply_pressed_key() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_apply_pressed_key(t_window *window, KeySym keysym)
{
	if (x11_apply_navigation_key(window, keysym))
		return ;
	if (keysym == XK_z || keysym == XK_Z)
		window->key_z = 1;
	else if (keysym == XK_q || keysym == XK_Q)
		window->key_q = 1;
	else if (keysym == XK_s || keysym == XK_S)
		window->key_s = 1;
	else if (keysym == XK_d || keysym == XK_D)
		window->key_d = 1;
	else if (keysym == XK_o || keysym == XK_O)
		window->key_o = 1;
	else if (keysym == XK_h || keysym == XK_H)
		window->key_h = 1;
	else if (keysym == XK_p || keysym == XK_P)
		window->key_p = 1;
}

/*
** Rôle: x11_apply_released_key — Applique released touche en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: keysym — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_handle_key_release().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_event_state.c -> x11_apply_released_key() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_apply_released_key(t_window *window, KeySym keysym)
{
	if (keysym == XK_z || keysym == XK_Z)
		window->key_z = 0;
	else if (keysym == XK_q || keysym == XK_Q)
		window->key_q = 0;
	else if (keysym == XK_s || keysym == XK_S)
		window->key_s = 0;
	else if (keysym == XK_d || keysym == XK_D)
		window->key_d = 0;
	else if (keysym == XK_o || keysym == XK_O)
		window->key_o = 0;
	else if (keysym == XK_p || keysym == XK_P)
		window->key_p = 0;
}

#endif
