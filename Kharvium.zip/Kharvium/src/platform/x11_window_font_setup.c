/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_font_setup.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef _WIN32

#  include "x11_window_backend_internal.h"

/*
** Rôle: x11_load_ui_font — Charge la police X11 correspondant au rôle UI.
** Paramètre: backend — backend X11 propriétaire de la connexion Display.
** Paramètre: role — SMALL, BODY, BUTTON ou TITLE.
** Retour: XFontStruct chargé ou NULL; les appelants gèrent le fallback BODY.
** Effets: alloue une ressource X11 via XLoadQueryFont().
** Invariants: aucune bibliothèque de police externe ni fichier embarqué.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_initialize_graphics().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_initialize_helpers.c -> x11_load_ui_font().
** Dépendances: XLoadQueryFont().
** Mémoire: la ressource XFontStruct est libérée par window_destroy().
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend de la connexion X11 fournie.
** I/O: aucune primitive stdio appelée directement.
** Unités: pixels définis par les polices X11 natives.
** Performance: exécuté uniquement à l'initialisation.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
static XFontStruct	*x11_load_ui_font(t_x11_backend *backend,
	t_window_font_role role)
{
	XFontStruct	*font;

	font = NULL;
	if (role == WINDOW_FONT_SMALL)
		font = XLoadQueryFont(backend->d, "7x13");
	else if (role == WINDOW_FONT_BUTTON)
		font = XLoadQueryFont(backend->d, "9x15bold");
	else if (role == WINDOW_FONT_TITLE)
		font = XLoadQueryFont(backend->d, "10x20");
	else
		font = XLoadQueryFont(backend->d, "9x15");
	if (!font && role != WINDOW_FONT_BODY)
		return (NULL);
	if (!font)
		font = XLoadQueryFont(backend->d, "fixed");
	return (font);
}

/*
** Rôle: x11_initialize_fonts — Charge les quatre rôles typographiques X11.
** Paramètre: backend — backend X11 propriétaire des ressources de police.
** Retour: Ne retourne rien; les handles chargés restent possédés par
**         backend.
** Effets: charge SMALL, BODY, BUTTON et TITLE puis sélectionne BODY dans GC.
** Invariants: BODY sert de secours aux mesures et au rendu des rôles absents.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_load_ui_font().
** Appelants: x11_initialize_graphics().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md.
** Dépendances: XSetFont().
** Mémoire: les XFontStruct sont libérés pendant window_destroy().
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: dépend de la connexion X11 fournie.
** I/O: aucune primitive stdio appelée directement.
** Unités: pixels des polices X11 natives.
** Performance: quatre chargements au démarrage.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_initialize_fonts(t_x11_backend *backend)
{
	if (!backend)
		return ;
	backend->fonts[WINDOW_FONT_SMALL] = x11_load_ui_font(backend,
		WINDOW_FONT_SMALL);
	backend->fonts[WINDOW_FONT_BODY] = x11_load_ui_font(backend,
		WINDOW_FONT_BODY);
	backend->fonts[WINDOW_FONT_BUTTON] = x11_load_ui_font(backend,
		WINDOW_FONT_BUTTON);
	backend->fonts[WINDOW_FONT_TITLE] = x11_load_ui_font(backend,
		WINDOW_FONT_TITLE);
	if (backend->fonts[WINDOW_FONT_BODY])
		XSetFont(backend->d, backend->gc,
			backend->fonts[WINDOW_FONT_BODY]->fid);
}

# endif
