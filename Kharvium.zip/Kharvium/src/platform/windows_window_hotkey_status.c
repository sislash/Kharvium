/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_hotkey_status.c                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifdef _WIN32

# include "windows_window_backend_internal.h"

/*
** Rôle: windows_format_hotkey_description — Formate raccourci clavier
**       description dans le buffer ou la représentation demandée sans
**       dépasser la capacité fournie par l’appelant.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_size — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: mods — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: virtual_key — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_get_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_status.c ->
**        windows_format_hotkey_description() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	windows_format_hotkey_description(char *out, int out_size, UINT mods,
	UINT virtual_key)
{
	int	position;

	if (!out || out_size <= 0)
		return ;
	position = 0;
	out[0] = '\0';
	if (mods & MOD_CONTROL)
		position += snprintf(out + position,
			(size_t)out_size - position, "Ctrl+");
	if (mods & MOD_ALT)
		position += snprintf(out + position,
			(size_t)out_size - position, "Alt+");
	if (mods & MOD_SHIFT)
		position += snprintf(out + position,
			(size_t)out_size - position, "Shift+");
	if (mods & MOD_WIN)
		position += snprintf(out + position,
			(size_t)out_size - position, "Win+");
	if (position < out_size - 1)
		out[position++] = (char)virtual_key;
	if (position >= out_size)
		position = out_size - 1;
	out[position] = '\0';
}

/*
** Rôle: window_get_hotkeys — Retourne raccourcis clavier en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: descriptions — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, descriptions.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_hotkey_registration_mask(),
**            windows_format_hotkey_description().
** Appelants: hotkeys_page_store_platform_state(), runtime_publish_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_status.c -> window_get_hotkeys() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_get_hotkeys(t_window *window,
	t_window_hotkey_descriptions *descriptions)
{
	t_windows_backend	*backend;

	if (descriptions && descriptions->overlay && descriptions->overlay_size > 0)
		descriptions->overlay[0] = '\0';
	if (descriptions && descriptions->click && descriptions->click_size > 0)
		descriptions->click[0] = '\0';
	if (!window || !window->backend_1)
		return (0);
	backend = (t_windows_backend *)window->backend_1;
	if (descriptions && backend->hotkey_overlay_mods)
		windows_format_hotkey_description(descriptions->overlay,
			descriptions->overlay_size, backend->hotkey_overlay_mods,
			backend->hotkey_overlay_vk);
	if (descriptions && backend->hotkey_click_mods)
		windows_format_hotkey_description(descriptions->click,
			descriptions->click_size, backend->hotkey_click_mods,
			backend->hotkey_click_vk);
	return (window_hotkey_registration_mask(backend->hotkey_overlay_registered,
		backend->hotkey_click_registered));
}

/*
** Rôle: windows_unregister_hotkeys — Prépare ou applique les raccourcis
**       clavier de Win32 unregister.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_reset_hotkey_target().
** Appelants: window_rebind_hotkeys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_status.c -> windows_unregister_hotkeys()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> UnregisterHotKey().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	windows_unregister_hotkeys(t_windows_backend *backend)
{
	if (backend->hotkey_overlay_registered)
		UnregisterHotKey(backend->hwnd, HOTKEY_ID_OVERLAY);
	if (backend->hotkey_click_registered)
		UnregisterHotKey(backend->hwnd, HOTKEY_ID_CLICK_THROUGH);
	windows_reset_hotkey_target(backend, 0);
	windows_reset_hotkey_target(backend, 1);
}

/*
** Rôle: window_rebind_hotkeys — Prépare ou applique les raccourcis clavier
**       de fenêtre rebind.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: overlay_list — objet source consulté en lecture seule par
**            cette fonction.
** Paramètre: click_list — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_hotkey_registration_mask(),
**            windows_register_hotkey_list(), windows_unregister_hotkeys().
** Appelants: hotkeys_page_apply_rebind(), runtime_load_hotkeys(),
**            windows_create_main_window().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_status.c -> window_rebind_hotkeys() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	window_rebind_hotkeys(t_window *window, const char *overlay_list,
	const char *click_list)
{
	t_windows_backend	*backend;

	if (!window || !window->backend_1)
		return (0);
	backend = (t_windows_backend *)window->backend_1;
	if (!backend->hwnd || backend->is_overlay)
		return (0);
	windows_unregister_hotkeys(backend);
	(void)windows_register_hotkey_list(backend, 0, overlay_list);
	(void)windows_register_hotkey_list(backend, 1, click_list);
	return (window_hotkey_registration_mask(backend->hotkey_overlay_registered,
		backend->hotkey_click_registered));
}

#endif
