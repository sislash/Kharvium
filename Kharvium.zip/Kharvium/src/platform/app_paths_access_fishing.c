/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   app_paths_access_fishing.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "app_paths_internal.h"

/*
** Rôle: app_path_selected_fishing_rod — Retourne le chemin persistant du
**       preset Fishing sélectionné dans le répertoire writable courant.
** Retour: pointeur interne vers le chemin construit par app_paths.
** Effets: aucun.
** Invariants: le chemin reste valide jusqu'à réinitialisation de app_paths.
** Relations: app_paths_state().
** Appelants: futur picker/cache Fishing et tests de chemins E90.
** Index: docs/FUNCTION_CALL_GRAPH.md -> app_path_selected_fishing_rod().
** Dépendances: état centralisé app_paths.
** Mémoire: aucune allocation.
** État partagé: lit l'état global central app_paths.
** Concurrence: lecture seule après initialisation.
** I/O: aucune.
** Unités: chemin de fichier.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
const char	*app_path_selected_fishing_rod(void)
{
	return (app_paths_state()->selected_fishing_rod);
}

/*
** Rôle: app_path_fishing_rods_ini — Retourne le chemin de fishing_rods.ini
**       dans le répertoire writable de l'installation courante.
** Retour: pointeur interne vers le chemin préparé au bootstrap.
** Effets: aucun.
** Invariants: aucun module Fishing ne doit hardcoder ce chemin ailleurs.
** Relations: app_paths_state().
** Appelants: futur picker/config Fishing et copie des assets par défaut.
** Index: docs/FUNCTION_CALL_GRAPH.md -> app_path_fishing_rods_ini().
** Dépendances: état central app_paths.
** Mémoire: aucune allocation.
** État partagé: lit l'état global central app_paths.
** Concurrence: lecture seule après initialisation.
** I/O: aucune.
** Unités: chemin de fichier.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
const char	*app_path_fishing_rods_ini(void)
{
	return (app_paths_state()->fishing_rods_ini);
}
