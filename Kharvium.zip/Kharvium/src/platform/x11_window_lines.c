/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_lines.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef _WIN32

#  include "x11_window_backend_internal.h"

/*
** Rôle: window_draw_line — Dessine ligne dans le contexte graphique courant
**       en respectant la géométrie, le clipping et l’état des widgets
**       fournis.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_pick_destination(),
**            x11_resolve_color().
** Appelants: finance_capital_chart_grid(), ui_chart_annotation_draw(),
**            ui_chart_hover_draw_cross(), ui_chart_overview_bounds(),
**            ui_chart_x_axis_tick(), ui_chart_render_y_tick().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_lines.c -> window_draw_line() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> XDrawLine(),
**              XSetForeground().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_draw_line(t_window *w,
	t_window_draw_line_request request)
{
	t_x11_backend	*b;
	unsigned long	pix;
	Drawable		dst;

	if (!w)
		return ;
	b = (t_x11_backend *)w->backend_1;
	if (!b || !b->d || !b->gc)
		return ;
	dst = x11_pick_destination(w, b);
	pix = x11_resolve_color(b, request.color);
	XSetForeground(b->d, b->gc, pix);
	XDrawLine(b->d, dst, b->gc, request.x0, request.y0, request.x1, request.y1);
}

/*
** Rôle: window_draw_polyline — Dessine polyline dans le contexte graphique
**       courant en respectant la géométrie, le clipping et l’état des
**       widgets fournis.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: pts — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: n — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_pick_destination(),
**            x11_resolve_color().
** Appelants: finance_capital_chart_draw(), ui_chart_overview_plot(),
**            ui_chart_basic_draw(), ui_chart_render_series_cached().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_lines.c -> window_draw_polyline() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> XDrawLines(),
**              XSetForeground().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_draw_polyline(t_window *w, const t_point_i *pts, int n,
	int color)
{
	t_x11_backend	*b;
	int				i;
	unsigned long	pix;
	Drawable		dst;
	XPoint			xp[1024];

	if (!w || !pts || n < 2)
		return ;
	b = (t_x11_backend *)w->backend_1;
	if (!b || !b->d || !b->gc)
		return ;
	if (n > (int)(sizeof(xp) / sizeof(xp[0])))
		n = (int)(sizeof(xp) / sizeof(xp[0]));
	dst = x11_pick_destination(w, b);
	pix = x11_resolve_color(b, color);
	XSetForeground(b->d, b->gc, pix);
	i = 0;
	while (i < n)
	{
		xp[i].x = (short)pts[i].x;
		xp[i].y = (short)pts[i].y;
		i++;
	}
	XDrawLines(b->d, dst, b->gc, xp, n, CoordModeOrigin);
}

/*
** Rôle: window_present — Met à jour present en appliquant explicitement les
**       paramètres, bornes et invariants décrits par le contrat de cette
**       fonction.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_clear_clip_rectangle().
** Appelants: creature_prompt_modal(), runtime_frame(), markup_config_menu(),
**            weapon_config_menu(), dashboard_draw_content(),
**            global_menu_finish_frame() (+10; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_lines.c -> window_present() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> XCopyArea(), XFlush().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_present(t_window *w)
{
    t_x11_backend	*b;

    if (!w)
        return ;
    b = (t_x11_backend *)w->backend_1;
    if (!b || !b->d)
        return ;
    window_clear_clip_rectangle(w);
    if (w->use_buffer && b->back)
    {
        XCopyArea(b->d, b->back, b->win, b->gc, 0, 0,
                  (unsigned int)w->width, (unsigned int)w->height, 0, 0);
    }
    XFlush(b->d);
}

# endif
