/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   platform_time.c                                   +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "platform/platform_time.h"

#if defined(_WIN32) || defined(_WIN64)
# include <windows.h>
#else
# include <sys/time.h>
# include <sys/select.h>

extern struct tm	*localtime_r(const time_t *t, struct tm *result);
#endif

/*
** Rôle: platform_sleep_milliseconds — Calcule et retourne sleep milliseconds
**       à partir des paramètres fournis sans modifier les entrées déclarées
**       en lecture seule.
** Paramètre: ms — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_overlay_demo_run_if_requested(),
**            parse_engine_reopen_input(), parse_engine_wait_for_input(),
**            frame_limiter_end_and_sleep(), global_menu_finish_frame(),
**            hunt_tracker_main_finish_frame() (+2; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_time.c -> platform_sleep_milliseconds() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> Sleep(), select().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: millisecondes.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	platform_sleep_milliseconds(int ms)
{
	if (ms <= 0)
		return ;
#if defined(_WIN32) || defined(_WIN64)
	Sleep((DWORD)ms);
#else
	{
		struct timeval	tv;

		tv.tv_sec = (time_t)(ms / 1000);
		tv.tv_usec = (suseconds_t)((ms % 1000) * 1000);
		(void)select(0, NULL, NULL, NULL, &tv);
	}
#endif
}

/*
** Rôle: platform_time_milliseconds — Calcule et retourne temps milliseconds à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Retour: Retourne le résultat de type uint64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_stats_live_state_finalize(), benchmark_series_run(),
**            benchmark_stats_run(), app_refresh_cached(),
**            monitor_health_on_io_error(), monitor_health_on_parse_error()
**            (+43; index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_time.c -> platform_time_milliseconds() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> GetTickCount64(),
**              gettimeofday().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: millisecondes.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
uint64_t	platform_time_milliseconds(void)
{
#if defined(_WIN32) || defined(_WIN64)
	return ((uint64_t)GetTickCount64());
#else
	{
		struct timeval	tv;

		gettimeofday(&tv, NULL);
		return ((uint64_t)tv.tv_sec * 1000ULL
			+ (uint64_t)tv.tv_usec / 1000ULL);
	}
#endif
}

/*
** Rôle: platform_localtime_safe — Convertit un time_t en heure locale de
**       manière sûre avec l'API native disponible sur Windows ou POSIX.
** Paramètre: out — structure tm destination entièrement renseignée en cas
**            de succès.
** Paramètre: t — horodatage source consulté sans être modifié.
** Retour: Retourne 0 si la conversion réussit et -1 si un pointeur est nul
**         ou si localtime_s/localtime_r signale une erreur.
** Effets: modifie uniquement la structure out fournie par l'appelant.
** Invariants: n'utilise jamais le buffer statique non réentrant de
**             localtime(); le choix Win32/POSIX reste fait à la compilation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_csv_format_local_timestamp(),
**            hunt_tracker_format_local_time().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        platform_time.c -> platform_localtime_safe() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> localtime_r(),
**              localtime_s().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 avec compilation conditionnelle locale.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	platform_localtime_safe(struct tm *out, const time_t *t)
{
	if (!out || !t)
		return (-1);
#if defined(_WIN32) || defined(_WIN64)
	if (localtime_s(out, t) != 0)
		return (-1);
	return (0);
#else
	if (localtime_r(t, out) == NULL)
		return (-1);
	return (0);
#endif
}
