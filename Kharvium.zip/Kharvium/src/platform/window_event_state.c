/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window_event_state.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "window_event_state_internal.h"

/*
** Rôle: window_reset_frame_input — Réinitialise frame entrée en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_poll_events(), window_poll_events().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        window_event_state.c -> window_reset_frame_input() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_reset_frame_input(t_window *window)
{
	window->close_requested = 0;
	window->key_up = 0;
	window->key_down = 0;
	window->key_enter = 0;
	window->key_escape = 0;
	window->mouse_left_click = 0;
	window->mouse_wheel = 0;
	window->text_len = 0;
	window->text_input[0] = '\0';
	window->key_backspace = 0;
	window->key_delete = 0;
	window->key_tab = 0;
	window->key_o = 0;
	window->key_h = 0;
	window->key_p = 0;
}
