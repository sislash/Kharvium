/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_hotkey_parse.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifdef _WIN32

# include "windows_window_backend_internal.h"

/*
** Rôle: windows_parse_hotkey_combination — Analyse raccourci clavier
**       combination depuis la source fournie, contrôle le format utile et ne
**       renseigne la destination qu’avec des données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: definition — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : definition.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_hotkey_parse_combination().
** Appelants: windows_try_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_hotkey_parse.c -> windows_parse_hotkey_combination()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	windows_parse_hotkey_combination(const char *text,
	t_windows_hotkey_definition *definition)
{
	t_window_hotkey_combination	parsed;

	if (!definition || !window_hotkey_parse_combination(text, &parsed))
		return (0);
	definition->modifiers = 0;
	if (parsed.flags & WINDOW_HOTKEY_CTRL)
		definition->modifiers |= MOD_CONTROL;
	if (parsed.flags & WINDOW_HOTKEY_ALT)
		definition->modifiers |= MOD_ALT;
	if (parsed.flags & WINDOW_HOTKEY_SHIFT)
		definition->modifiers |= MOD_SHIFT;
	if (parsed.flags & WINDOW_HOTKEY_META)
		definition->modifiers |= MOD_WIN;
	definition->virtual_key = (UINT)parsed.key;
	return (1);
}

#endif
