/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_hotkey_parse.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_hotkey_modifiers — Traite raccourci clavier modifiers et met à
**       jour uniquement l’état d’entrée ou
**       d’interface correspondant à cet événement.
** Paramètre: flags — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type unsigned int; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_parse_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_parse.c -> x11_hotkey_modifiers() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
static unsigned int	x11_hotkey_modifiers(unsigned int flags)
{
	unsigned int	modifiers;

	modifiers = 0;
	if (flags & WINDOW_HOTKEY_CTRL)
		modifiers |= ControlMask;
	if (flags & WINDOW_HOTKEY_ALT)
		modifiers |= Mod1Mask;
	if (flags & WINDOW_HOTKEY_SHIFT)
		modifiers |= ShiftMask;
	if (flags & WINDOW_HOTKEY_META)
		modifiers |= Mod4Mask;
	return (modifiers);
}

/*
** Rôle: x11_parse_hotkey_combination — Analyse raccourci clavier combination
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: definition — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend, definition.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_hotkey_parse_combination(),
**            x11_hotkey_modifiers().
** Appelants: x11_try_hotkey_combination().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_hotkey_parse.c -> x11_parse_hotkey_combination() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> XKeysymToKeycode().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	x11_parse_hotkey_combination(t_x11_backend *backend, const char *text,
	t_x11_hotkey_definition *definition)
{
	t_window_hotkey_combination	parsed;
	KeySym					keysym;

	if (!backend || !backend->d || !definition)
		return (0);
	if (!window_hotkey_parse_combination(text, &parsed))
		return (0);
	keysym = (KeySym)parsed.key;
	if (parsed.key >= 'A' && parsed.key <= 'Z')
		keysym = (KeySym)(parsed.key - 'A' + 'a');
	definition->keycode = XKeysymToKeycode(backend->d, keysym);
	if (definition->keycode == 0)
		return (0);
	definition->modifiers = x11_hotkey_modifiers(parsed.flags);
	definition->key = parsed.key;
	return (1);
}

#endif
