/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   windows_window_lines.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifdef _WIN32

#  include "windows_window_backend_internal.h"

/*
** Rôle: window_draw_line — Dessine ligne dans le contexte graphique courant
**       en respectant la géométrie, le clipping et l’état des widgets
**       fournis.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_color_reference().
** Appelants: finance_capital_chart_grid(), ui_chart_annotation_draw(),
**            ui_chart_hover_draw_cross(), ui_chart_overview_bounds(),
**            ui_chart_x_axis_tick(), ui_chart_render_y_tick().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_lines.c -> window_draw_line() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> GetDC(), GetStockObject(),
**              LineTo(), MoveToEx(), ReleaseDC(), SelectObject(),
**              SetDCPenColor().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=7. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_draw_line(t_window *window, t_window_draw_line_request request)
{
	t_windows_backend	*backend;
	HDC				device;
	HPEN				old_pen;

	if (!window)
		return ;
	backend = (t_windows_backend *)window->backend_1;
	if (!backend || !backend->hwnd)
		return ;
	device = GetDC(backend->hwnd);
	if (window->use_buffer && backend->back_dc)
		device = backend->back_dc;
	old_pen = (HPEN)SelectObject(device, GetStockObject(DC_PEN));
	SetDCPenColor(device, windows_color_reference(request.color));
	MoveToEx(device, request.x0, request.y0, NULL);
	LineTo(device, request.x1, request.y1);
	if (old_pen)
		SelectObject(device, old_pen);
	if (!(window->use_buffer && backend->back_dc))
		ReleaseDC(backend->hwnd, device);
}

/*
** Rôle: windows_copy_polyline_points — Copie polyline points en préservant la
**       propriété des ressources, les compteurs et la cohérence de la
**       destination.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: points — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : output.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_draw_polyline().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_lines.c -> windows_copy_polyline_points() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	windows_copy_polyline_points(POINT *output, const t_point_i *points,
	int count)
{
	int	index;

	if (count > 1024)
		count = 1024;
	index = 0;
	while (index < count)
	{
		output[index].x = points[index].x;
		output[index].y = points[index].y;
		index++;
	}
	return (count);
}

/*
** Rôle: window_draw_polyline — Dessine polyline dans le contexte graphique
**       courant en respectant la géométrie, le clipping et l’état des
**       widgets fournis.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: points — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> windows_color_reference(),
**            windows_copy_polyline_points().
** Appelants: finance_capital_chart_draw(), ui_chart_overview_plot(),
**            ui_chart_basic_draw(), ui_chart_render_series_cached().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_lines.c -> window_draw_polyline() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> GetDC(), GetStockObject(),
**              Polyline(), ReleaseDC(), SelectObject(), SetDCPenColor().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=6. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_draw_polyline(t_window *window, const t_point_i *points,
	int count, int color)
{
	t_windows_backend	*backend;
	POINT				native_points[1024];
	HDC				device;
	HPEN				old_pen;

	if (!window || !points || count < 2)
		return ;
	backend = (t_windows_backend *)window->backend_1;
	if (!backend || !backend->hwnd)
		return ;
	count = windows_copy_polyline_points(native_points, points, count);
	device = GetDC(backend->hwnd);
	if (window->use_buffer && backend->back_dc)
		device = backend->back_dc;
	old_pen = (HPEN)SelectObject(device, GetStockObject(DC_PEN));
	SetDCPenColor(device, windows_color_reference(color));
	Polyline(device, native_points, count);
	if (old_pen)
		SelectObject(device, old_pen);
	if (!(window->use_buffer && backend->back_dc))
		ReleaseDC(backend->hwnd, device);
}

/*
** Rôle: window_present — Met à jour present en appliquant explicitement les
**       paramètres, bornes et invariants décrits par le contrat de cette
**       fonction.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_clear_clip_rectangle().
** Appelants: creature_prompt_modal(), runtime_frame(), markup_config_menu(),
**            weapon_config_menu(), dashboard_draw_content(),
**            global_menu_finish_frame() (+10; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        windows_window_lines.c -> window_present() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> BitBlt(), GetDC(),
**              ReleaseDC(), StretchDIBits().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: Win32/GDI.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_present(t_window *window)
{
	t_windows_backend	*backend;
	HDC				device;

	if (!window)
		return ;
	backend = (t_windows_backend *)window->backend_1;
	if (!backend || !backend->hwnd)
		return ;
	device = GetDC(backend->hwnd);
	window_clear_clip_rectangle(window);
	if (window->use_buffer && backend->back_dc && backend->back_bmp)
		BitBlt(device, 0, 0, window->width, window->height,
			backend->back_dc, 0, 0, SRCCOPY);
	else if (window->use_buffer && window->pixels)
		StretchDIBits(device, 0, 0, window->width, window->height,
			0, 0, window->width, window->height, window->pixels,
			&backend->bmi, DIB_RGB_COLORS, SRCCOPY);
	ReleaseDC(backend->hwnd, device);
}

# endif
