/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_events.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_dispatch_event — Distribue événement en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: event — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend, event.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_handle_button_press(),
**            x11_handle_button_release(), x11_handle_key_press(),
**            x11_handle_key_release(), x11_handle_motion(),
**            x11_resize_buffers().
** Appelants: window_poll_events().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_events.c -> x11_dispatch_event() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	x11_dispatch_event(t_window *window, t_x11_backend *backend,
	XEvent *event)
{
	if (event->type == DestroyNotify)
		window->running = 0;
	else if (event->type == ClientMessage
		&& (Atom)event->xclient.data.l[0] == backend->wm_delete)
		window->close_requested = 1;
	else if (event->type == KeyPress)
		x11_handle_key_press(window, backend, &event->xkey);
	else if (event->type == KeyRelease)
		x11_handle_key_release(window, &event->xkey);
	else if (event->type == MotionNotify)
		x11_handle_motion(window, &event->xmotion);
	else if (event->type == ConfigureNotify)
		x11_resize_buffers(window, event->xconfigure.width,
			event->xconfigure.height);
	else if (event->type == ButtonPress)
		x11_handle_button_press(window, &event->xbutton);
	else if (event->type == ButtonRelease)
		x11_handle_button_release(window, &event->xbutton);
}

/*
** Rôle: window_poll_events — Traite poll et met à jour uniquement l’état
**       d’entrée ou d’interface correspondant à cet
**       événement.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> window_reset_frame_input(),
**            x11_dispatch_event().
** Appelants: creature_prompt_modal(), runtime_frame(), markup_config_menu(),
**            weapon_config_menu(), dashboard_read_input(),
**            global_menu_read_action() (+9; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_events.c -> window_poll_events() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> XNextEvent(), XPending().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	window_poll_events(t_window *window)
{
	t_x11_backend	*backend;
	XEvent			event;

	if (!window)
		return ;
	window_reset_frame_input(window);
	backend = (t_x11_backend *)window->backend_1;
	if (!backend || !backend->d)
		return ;
	while (XPending(backend->d) > 0)
	{
		XNextEvent(backend->d, &event);
		x11_dispatch_event(window, backend, &event);
	}
}

#endif
