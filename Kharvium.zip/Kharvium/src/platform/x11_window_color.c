/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   x11_window_color.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef _WIN32

# include "x11_window_backend_internal.h"

/*
** Rôle: x11_pick_destination — Calcule et retourne pick destination à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: window — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type Drawable; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : window, backend.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: window_clear(), window_draw_text(), window_fill_rectangle(),
**            window_draw_line(), window_draw_polyline().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_color.c -> x11_pick_destination() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
Drawable	x11_pick_destination(t_window *window, t_x11_backend *backend)
{
	if (window && window->use_buffer && backend && backend->back)
		return (backend->back);
	return (backend->win);
}

/*
** Rôle: x11_color_mask_shift — Retourne ou renseigne couleur mask shift
**       dans la représentation directement
**       utilisable par le reste du module.
** Paramètre: mask — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_color_compute().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_color.c -> x11_color_mask_shift() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	x11_color_mask_shift(unsigned long mask)
{
	int	shift;

	shift = 0;
	while (mask != 0 && (mask & 1UL) == 0UL)
	{
		mask >>= 1;
		shift++;
	}
	return (shift);
}

/*
** Rôle: x11_color_cache_find — Recherche l’état associé à X11 color cache.
** Paramètre: backend — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: rgb — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: pixel — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : pixel.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: x11_resolve_color().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_color.c -> x11_color_cache_find() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	x11_color_cache_find(const t_x11_backend *backend, int rgb,
	unsigned long *pixel)
{
	int	index;

	index = 0;
	while (index < backend->color_cache_count)
	{
		if (backend->color_cache[index].rgb == rgb)
		{
			*pixel = backend->color_cache[index].pixel;
			return (1);
		}
		index++;
	}
	return (0);
}

/*
** Rôle: x11_color_compute — Calcule l’état associé à X11 color.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: rgb — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type unsigned long; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_color_mask_shift().
** Appelants: x11_resolve_color().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_color.c -> x11_color_compute() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> BlackPixel(),
**              XAllocColor().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
static unsigned long	x11_color_compute(t_x11_backend *backend, int rgb)
{
	XColor	color;
	unsigned long	red;
	unsigned long	green;
	unsigned long	blue;

	if (backend->vis && (backend->vis->class == TrueColor
			|| backend->vis->class == DirectColor))
	{
		red = (unsigned long)((rgb >> 16) & 0xFF);
		green = (unsigned long)((rgb >> 8) & 0xFF);
		blue = (unsigned long)(rgb & 0xFF);
		return (((red << x11_color_mask_shift(backend->vis->red_mask))
				& backend->vis->red_mask)
			| ((green << x11_color_mask_shift(backend->vis->green_mask))
				& backend->vis->green_mask)
			| ((blue << x11_color_mask_shift(backend->vis->blue_mask))
				& backend->vis->blue_mask));
	}
	color.red = (unsigned short)(((rgb >> 16) & 0xFF) * 257);
	color.green = (unsigned short)(((rgb >> 8) & 0xFF) * 257);
	color.blue = (unsigned short)((rgb & 0xFF) * 257);
	color.flags = DoRed | DoGreen | DoBlue;
	if (!XAllocColor(backend->d, backend->cmap, &color))
		return (BlackPixel(backend->d, backend->screen));
	return (color.pixel);
}

/*
** Rôle: x11_resolve_color — Détermine la couleur utilisée par X11 resolve.
** Paramètre: backend — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: rgb — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type unsigned long; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut appeler le backend natif et modifier l’état graphique ou
**         événementiel de la fenêtre; peut modifier les paramètres non
**         const suivants : backend.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> x11_color_cache_find(),
**            x11_color_compute().
** Appelants: window_clear(), window_draw_text(), window_fill_rectangle(),
**            window_draw_line(), window_draw_polyline().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        x11_window_color.c -> x11_resolve_color() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: X11/Linux.
** --- Fin des liens techniques auto-vérifiés ---
*/
unsigned long	x11_resolve_color(t_x11_backend *backend, int rgb)
{
	int				index;
	unsigned long	pixel;

	if (!backend || !backend->d)
		return (0);
	if (x11_color_cache_find(backend, rgb, &pixel))
		return (pixel);
	pixel = x11_color_compute(backend, rgb);
	index = backend->color_cache_count;
	if (index >= X11_COLOR_CACHE_MAX)
		index = (rgb ^ (rgb >> 8) ^ (rgb >> 16)) & 255;
	else
		backend->color_cache_count++;
	backend->color_cache[index].rgb = rgb;
	backend->color_cache[index].pixel = pixel;
	return (pixel);
}

#endif
