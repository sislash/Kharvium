/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_navigation_go_back.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main_modules.h"

/*
** Rôle: app_navigation_go_back — Calcule et retourne navigation go retour à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_back_target(),
**            app_navigation_history_pop(), app_navigation_set_page().
** Appelants: app_modal_navigation_handle_click(),
**            app_modal_page_frame_render(), runtime_navigation_keys(),
**            topbar_spaces_back().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_navigation_go_back.c -> app_navigation_go_back() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	app_navigation_go_back(t_window *w, t_app *app)
{
	t_page	target;

	if (!w || !app)
		return ;
	if (app_navigation_history_pop(app, app->page, &target))
	{
		app_navigation_set_page(w, app, target, 0);
		return ;
	}
	if (app_navigation_back_target(app->page, app->prev_page, &target))
		app_navigation_set_page(w, app, target, 0);
}

/*
** Rôle: app_navigation_activate — Rend navigation activate avec les
**       primitives UI disponibles en respectant la zone d’affichage et
**       l’état de la frame courante.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_go_to(),
**            app_navigation_page_for_cursor(), app_request_quit().
** Appelants: app_sidebar_navigation_render(), sidebar_application_group(),
**            sidebar_system_group(), app_sidebar_navigation_compact(),
**            sidebar_finance_group(), sidebar_tracker_group().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_navigation_go_back.c -> app_navigation_activate() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	app_navigation_activate(t_window *w, t_app *app, int index)
{
	t_page	page;

	if (index == 9)
	{
		app_request_quit(w, app);
		return ;
	}
	if (!app_navigation_page_for_cursor(index, &page))
		return ;
	app_navigation_go_to(w, app, page);
}

/*
** Rôle: app_navigation_item_height — Calcule la hauteur nécessaire à
**       application navigation objet.
** Paramètre: ly — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: sidebar_prepare().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_navigation_go_back.c -> app_navigation_item_height() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	app_navigation_item_height(const t_ui_layout *ly)
{
	if (ly->sidebar.h < 590)
		return (26);
	if (ly->sidebar.h < 650)
		return (29);
	return (32);
}

/*
** Rôle: app_navigation_group_render — Rend l’état associé à application
**       navigation group.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> ui_list().
** Appelants: sidebar_group().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_navigation_go_back.c -> app_navigation_group_render() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	app_navigation_group_render(
	const t_navigation_group_request *request)
{
	int	selected;
	int	clicked;

	selected = request->selected;
	clicked = ui_list(&(t_lst){request->w, request->ui, request->area,
		request->items, request->count, &selected,
		request->area.h / request->count, 0, 0});
	if (clicked < 0)
		return (-1);
	return (clicked);
}

/*
** Rôle: sidebar_compact_items — Construit ou traite les objets appartenant
**       à sidebar compact.
** Paramètre: items — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_sidebar_navigation_compact().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_navigation_go_back.c -> sidebar_compact_items() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	sidebar_compact_items(const char **items)
{
	items[0] = LOCALIZE("Finance / Tableau de bord", "Finance / Dashboard");
	items[1] = LOCALIZE("Tracker / Chasse", "Tracker / Hunt");
	items[2] = "Tracker / Globals";
	items[3] = LOCALIZE("Tracker / Graph LIVE", "Tracker / LIVE Graph");
	items[4] = LOCALIZE("Tracker / Sessions", "Tracker / Sessions");
	items[5] = LOCALIZE("Application / Configuration",
		"Application / Settings");
	items[6] = LOCALIZE("Systeme / Sante", "System / Health");
	items[7] = LOCALIZE("Systeme / Maintenance", "System / Maintenance");
	items[8] = LOCALIZE("Systeme / Aide", "System / Help");
	items[9] = LOCALIZE("Systeme / Quitter", "System / Quit");
}
