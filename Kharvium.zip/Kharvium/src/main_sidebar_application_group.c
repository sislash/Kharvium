/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_sidebar_application_group.c                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main_modules.h"

/*
** Rôle: sidebar_application_group — Construit ou rend le groupe logique de
**       sidebar application.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_activate(),
**            sidebar_group(), sidebar_section_header().
** Appelants: app_sidebar_navigation_render().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_sidebar_application_group.c -> sidebar_application_group()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	sidebar_application_group(t_sidebar_context *ctx)
{
	const char	*items[1];
	int		selected;
	int		clicked;

	items[0] = LOCALIZE("Configuration", "Settings");
	sidebar_section_header(ctx, LOCALIZE("APPLICATION", "APPLICATION"),
		ctx->ui->theme->text2);
	ctx->area = (t_rect){ctx->layout->sidebar.x, ctx->y,
		ctx->layout->sidebar.w, ctx->item_h};
	selected = -1;
	if (ctx->app->nav_cursor == 5)
		selected = 0;
	clicked = sidebar_group(ctx, items, 1, selected);
	if (!ctx->locked && clicked >= 0)
	{
		ctx->app->nav_cursor = 5;
		app_navigation_activate(ctx->w, ctx->app, 5);
	}
}

/*
** Rôle: sidebar_system_group — Construit ou rend le groupe logique de
**       sidebar système.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_activate(),
**            sidebar_group(), sidebar_section_header().
** Appelants: app_sidebar_navigation_render().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_sidebar_application_group.c -> sidebar_system_group() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	sidebar_system_group(t_sidebar_context *ctx)
{
	const char	*items[4];
	int		selected;
	int		clicked;

	items[0] = LOCALIZE("Sante", "Health");
	items[1] = LOCALIZE("Maintenance", "Maintenance");
	items[2] = LOCALIZE("Aide", "Help");
	items[3] = LOCALIZE("Quitter", "Quit");
	ctx->y = ctx->layout->sidebar.y + ctx->layout->sidebar.h
		- ctx->header_h - ctx->item_h * 4 - UI_PAD;
	sidebar_section_header(ctx, LOCALIZE("SYSTEME", "SYSTEM"),
		ctx->ui->theme->danger);
	ctx->area = (t_rect){ctx->layout->sidebar.x, ctx->y,
		ctx->layout->sidebar.w, ctx->item_h * 4};
	selected = -1;
	if (ctx->app->nav_cursor >= 6)
		selected = ctx->app->nav_cursor - 6;
	clicked = sidebar_group(ctx, items, 4, selected);
	if (!ctx->locked && clicked >= 0)
	{
		ctx->app->nav_cursor = clicked + 6;
		app_navigation_activate(ctx->w, ctx->app, ctx->app->nav_cursor);
	}
}

/*
** Rôle: sidebar_prepare — Prépare l’état associé à sidebar.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_item_height(),
**            finance_page_is_active().
** Appelants: app_sidebar_navigation_render().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_sidebar_application_group.c -> sidebar_prepare() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	sidebar_prepare(t_sidebar_context *ctx)
{
	ctx->locked = (ctx->app->finance_form != FIN_FORM_NONE);
	if (finance_page_is_active(ctx->app->page)
		&& ctx->w->mouse_x >= ctx->layout->content.x)
		ctx->locked = 1;
	if (!ctx->locked && ctx->w->key_up)
		ctx->app->nav_cursor--;
	if (!ctx->locked && ctx->w->key_down)
		ctx->app->nav_cursor++;
	if (ctx->app->nav_cursor < 0)
		ctx->app->nav_cursor = 0;
	if (ctx->app->nav_cursor > 9)
		ctx->app->nav_cursor = 9;
	ctx->item_h = app_navigation_item_height(ctx->layout);
	ctx->header_h = 22;
	ctx->y = ctx->layout->sidebar.y + UI_PAD;
}

/*
** Rôle: app_sidebar_navigation_render — Rend l’état associé à application
**       sidebar navigation.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: layout — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, ui, layout,
**         app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_activate(),
**            app_sidebar_navigation_compact(), sidebar_application_group(),
**            sidebar_finance_group(), sidebar_prepare(),
**            sidebar_system_group(), sidebar_tracker_group().
** Appelants: runtime_render_standard_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_sidebar_application_group.c -> app_sidebar_navigation_render()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=7; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	app_sidebar_navigation_render(t_window *w, t_ui_state *ui,
	t_ui_layout *layout, t_app *app)
{
	t_sidebar_context	ctx;

	if (!w || !ui || !layout || !app)
		return ;
	memset(&ctx, 0, sizeof(ctx));
	ctx.w = w;
	ctx.ui = ui;
	ctx.layout = layout;
	ctx.app = app;
	sidebar_prepare(&ctx);
	if (app_sidebar_navigation_compact(&ctx))
		return ;
	app->nav_scroll = 0;
	sidebar_finance_group(&ctx);
	sidebar_tracker_group(&ctx);
	sidebar_application_group(&ctx);
	sidebar_system_group(&ctx);
	if (!ctx.locked && w->key_enter)
		app_navigation_activate(w, app, app->nav_cursor);
}

/*
** Rôle: topbar_spaces_primary — Calcule et renseigne les espacements
**       principaux de la barre supérieure en
**       fonction de la largeur disponible et des
**       éléments visibles.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx, state.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_go_to(), ui_btn().
** Appelants: topbar_spaces_render().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_sidebar_application_group.c -> topbar_spaces_primary() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	topbar_spaces_primary(t_topbar_context *ctx,
	t_topbar_spaces *state)
{
	const char	*label;

	label = "FINANCE";
	if (ctx->w->width < 520)
		label = "FIN";
	if (ui_btn(&(t_btn){ctx->w, ctx->ui, state->button, label,
			state->finance_style, state->enabled}))
		app_navigation_go_to(ctx->w, ctx->app, PAGE_DASHBOARD);
	state->button.x += state->button.w + 6;
	label = "TRACKER";
	if (ctx->w->width < 520)
		label = "TRACK";
	if (ui_btn(&(t_btn){ctx->w, ctx->ui, state->button, label,
			state->tracker_style, state->enabled}))
		app_navigation_go_to(ctx->w, ctx->app, PAGE_HUNT);
	state->button.x += state->button.w + 6;
}
