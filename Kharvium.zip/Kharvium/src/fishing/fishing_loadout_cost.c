/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout_cost.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_loadout_cost_internal.h"
#include <string.h>

/*
** Rôle: fishing_cost_quality — Convertit présence/complétude en qualité E82.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_loadout_calculate_cost().
** Mémoire: aucune.
** Invariants: absence=UNKNOWN, manque=PARTIAL_COST, complet=COMPLETE.
** Retour: qualité structurée.
** Effets: aucun.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost.c ->
** fishing_cost_quality().
** Dépendances: enum t_data_quality.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: enum.
** Performance: O(1).
** Portabilité: C99.
*/
static t_data_quality	fishing_cost_quality(int present, int complete)
{
	if (!present)
		return (DATA_UNKNOWN);
	if (!complete)
		return (DATA_PARTIAL_COST);
	return (DATA_COMPLETE);
}

/*
** Rôle: fishing_cost_add_ammo — Ajoute ammo en gardant deux qualités séparées.
** Relations: fishing_cost_ammo_tt(), fishing_cost_ammo_basis().
** Appelants: fishing_loadout_calculate_cost().
** Mémoire: aucune.
** Invariants: aucune consommation n'est déduite du chat.log silencieux.
** Retour: aucun.
** Effets: met à jour flags de complétude et coût ammo.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost.c ->
** fishing_cost_add_ammo().
** Dépendances: catalogue local ammo.
** État partagé: aucun.
** Concurrence: objets distincts requis.
** I/O: aucune.
** Unités: quantité/uPED5.
** Performance: O(taille catalogue ammo).
** Portabilité: C99 Windows/Linux.
*/
static void	fishing_cost_add_ammo(const t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *catalog, t_fishing_loadout_cost *cost,
	int *complete)
{
	int64_t	consumed;

	if (!fishing_cost_ammo_tt(snapshot, catalog, cost, &consumed))
	{
		complete[0] = 0;
		complete[1] = 0;
		return ;
	}
	if (!fishing_cost_ammo_basis(snapshot, consumed, cost))
		complete[1] = 0;
}

/*
** Rôle: fishing_loadout_calculate_cost — Calcule uniquement les coûts mesurés.
** Relations: fishing_cost_components(), fishing_cost_add_ammo(), money_add(),
**            fishing_cost_quality().
** Appelants: UI/Finance futurs et tests E88.
** Mémoire: aucune allocation.
** Invariants: TT et coût économique ont des qualités indépendantes.
** Retour: 1 si paramètres valides, 0 sinon.
** Effets: initialise/remplit cost.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost.c ->
** fishing_loadout_calculate_cost().
** Dépendances: fixed-point t_money et catalogue local.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: uPED5.
** Performance: O(5 + taille catalogue ammo).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_loadout_calculate_cost(const t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *catalog, t_fishing_loadout_cost *cost)
{
	int	complete[2];
	int	present;

	if (!snapshot || !catalog || !cost)
		return (0);
	memset(cost, 0, sizeof(*cost));
	complete[0] = 1;
	complete[1] = 1;
	present = fishing_cost_components(snapshot, cost,
			&complete[0], &complete[1]);
	if (snapshot->ammo.item_type_id > 0)
	{
		present++;
		fishing_cost_add_ammo(snapshot, catalog, cost, complete);
	}
	cost->total_tt_cost = money_add(cost->gear_tt_decay, cost->ammo_tt_cost);
	cost->total_cost_basis_consumed = money_add(cost->gear_cost_basis_consumed,
			cost->ammo_cost_basis_consumed);
	cost->tt_quality = fishing_cost_quality(present, complete[0]);
	cost->cost_basis_quality = fishing_cost_quality(present, complete[1]);
	return (1);
}
