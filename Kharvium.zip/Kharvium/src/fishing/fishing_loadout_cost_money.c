/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout_cost_money.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_loadout_cost_internal.h"
#include <limits.h>

/*
** Rôle: fishing_money_prorate — Prorate un coût historique sans flottant.
** Relations: aucune fonction projet appelée directement.
** Appelants: coût gear/ammo E88.
** Mémoire: aucune.
** Invariants: 0<=used<=basis; overflow refusé.
** Retour: 1 avec out, 0 sinon.
** Effets: écrit out sur succès.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost_money.c ->
** fishing_money_prorate().
** Dépendances: INT64_MAX.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: uPED5 et unité homogène used/basis.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_money_prorate(t_money total, int64_t used,
	int64_t basis, t_money *out)
{
	if (!out || total < 0 || used < 0 || basis <= 0 || used > basis)
		return (0);
	if (used == 0 || total == 0)
	{
		*out = 0;
		return (1);
	}
	if (total > INT64_MAX / used)
		return (0);
	*out = (total * used) / basis;
	return (1);
}

/*
** Rôle: fishing_money_multiply — Multiplie TT unitaire par quantité.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_cost_ammo_tt().
** Mémoire: aucune.
** Invariants: valeurs non négatives; overflow refusé.
** Retour: 1 sur produit représentable, 0 sinon.
** Effets: écrit out sur succès.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost_money.c ->
** fishing_money_multiply().
** Dépendances: INT64_MAX.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: uPED5 * quantité.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_money_multiply(t_money unit, int64_t quantity, t_money *out)
{
	if (!out || unit < 0 || quantity < 0)
		return (0);
	if (quantity != 0 && unit > INT64_MAX / quantity)
		return (0);
	*out = unit * quantity;
	return (1);
}
