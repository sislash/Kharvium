/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_session_economics.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing/fishing_session_economics.h"
#include "common/money.h"
#include <string.h>

/*
** Rôle: fishing_session_result_quality — Combine qualité du loot et du coût
**       sans promouvoir une information partielle en résultat complet.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_session_economics_build().
** Mémoire: aucune allocation.
** Invariants: COMPLETE exige simultanément loot et coût complets.
** Retour: qualité E82 du résultat financier correspondant.
** Effets: aucun.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_economics.c ->
** fishing_session_result_quality().
** Dépendances: enum t_data_quality.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: aucune.
** Performance: O(1).
** Portabilité: C99.
*/
static t_data_quality	fishing_session_result_quality(t_data_quality loot,
	t_data_quality cost)
{
	if (loot == DATA_COMPLETE && cost == DATA_COMPLETE)
		return (DATA_COMPLETE);
	if (loot == DATA_UNKNOWN || cost == DATA_UNKNOWN)
		return (DATA_UNKNOWN);
	if (loot != DATA_COMPLETE)
		return (DATA_PARTIAL_VALUE);
	return (DATA_PARTIAL_COST);
}

/*
** Rôle: fishing_session_average — Calcule une moyenne monétaire entière sans
**       flottant; la division tronque vers zéro comme les entiers C99.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_session_fill_averages().
** Mémoire: aucune allocation.
** Invariants: count strictement positif requis pour déclarer la moyenne.
** Retour: moyenne uPED5 ou zéro si indisponible.
** Effets: aucun.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_economics.c ->
** fishing_session_average().
** Dépendances: arithmétique entière C99.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: uPED5 par événement.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static t_money	fishing_session_average(t_money total, long count)
{
	if (count <= 0)
		return (0);
	return (total / count);
}

/*
** Rôle: fishing_session_fill_averages — Calcule les coûts moyens uniquement
**       lorsque la qualité de la famille de coût est complète.
** Relations: fishing_session_average().
** Appelants: fishing_session_economics_build().
** Mémoire: aucune allocation.
** Invariants: aucune moyenne partielle n'est présentée comme coût complet.
** Retour: aucun.
** Effets: remplit les quatre champs de moyenne de output.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_economics.c ->
** fishing_session_fill_averages().
** Dépendances: résumé E89.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: uPED5 par tentative/prise.
** Performance: O(1).
** Portabilité: C99.
*/
static void	fishing_session_fill_averages(t_fishing_session_economics *output)
{
	if (output->tt_cost_quality == DATA_COMPLETE)
	{
		output->tt_cost_per_attempt = fishing_session_average(
				output->total_tt_cost, output->events.attempts);
		output->tt_cost_per_catch = fishing_session_average(
				output->total_tt_cost, output->events.catches);
	}
	if (output->cost_basis_quality == DATA_COMPLETE)
	{
		output->basis_cost_per_attempt = fishing_session_average(
				output->total_cost_basis, output->events.attempts);
		output->basis_cost_per_catch = fishing_session_average(
				output->total_cost_basis, output->events.catches);
	}
}

/*
** Rôle: fishing_session_fill_results — Calcule Net TT et résultat sur base
**       d'acquisition seulement quand chaque opérande est complet.
** Relations: money_subtract().
** Appelants: fishing_session_economics_build().
** Mémoire: aucune allocation.
** Invariants: une valeur inconnue/partielle ne produit jamais un faux Net.
** Retour: aucun.
** Effets: renseigne qualités, flags et résultats de output.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_economics.c ->
** fishing_session_fill_results().
** Dépendances: fixed-point money et qualité E82.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: uPED5.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static void	fishing_session_fill_results(t_fishing_session_economics *output)
{
	output->tt_result_quality = fishing_session_result_quality(
			output->events.loot_quality, output->tt_cost_quality);
	output->basis_result_quality = fishing_session_result_quality(
			output->events.loot_quality, output->cost_basis_quality);
	if (output->tt_result_quality == DATA_COMPLETE)
	{
		output->tt_net = money_subtract(output->events.loot_tt,
				output->total_tt_cost);
		output->has_tt_result = 1;
	}
	if (output->basis_result_quality == DATA_COMPLETE)
	{
		output->cost_basis_net = money_subtract(output->events.loot_tt,
				output->total_cost_basis);
		output->has_basis_result = 1;
	}
}

/*
** Rôle: fishing_session_economics_build — Fusionne le journal V4 E87 et le
**       coût mesuré E88 en un résumé économique canonique E89.
** Relations: fishing_session_fill_averages(), fishing_session_fill_results().
** Appelants: tests E89 et futurs UI/export/bridge Finance.
** Mémoire: aucune allocation; copie de structures de valeur.
** Invariants: events doit appartenir à une session positive déjà trouvée.
** Retour: 1 si le résumé est construit, 0 si les entrées sont incohérentes.
** Effets: réinitialise puis renseigne output.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_economics.c ->
** fishing_session_economics_build().
** Dépendances: modèle E87/E88 et memset().
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: compteurs et uPED5.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_session_economics_build(const t_fishing_session_events *events,
	const t_fishing_loadout_cost *cost, t_fishing_session_economics *output)
{
	if (!events || !cost || !output || !events->found
		|| events->session_id <= 0)
		return (0);
	memset(output, 0, sizeof(*output));
	output->events = *events;
	output->gear_tt_decay = cost->gear_tt_decay;
	output->ammo_tt_cost = cost->ammo_tt_cost;
	output->total_tt_cost = cost->total_tt_cost;
	output->gear_cost_basis = cost->gear_cost_basis_consumed;
	output->ammo_cost_basis = cost->ammo_cost_basis_consumed;
	output->total_cost_basis = cost->total_cost_basis_consumed;
	output->tt_cost_quality = cost->tt_quality;
	output->cost_basis_quality = cost->cost_basis_quality;
	fishing_session_fill_results(output);
	fishing_session_fill_averages(output);
	return (1);
}
