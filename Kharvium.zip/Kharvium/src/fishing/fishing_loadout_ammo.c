/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout_ammo.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing/fishing_loadout.h"
#include <string.h>

/*
** Rôle: fishing_loadout_set_ammo — Capture les Spool avant/après mesurées.
** Relations: memset().
** Appelants: collecte explicite future et tests E88.
** Mémoire: aucune.
** Invariants: valeurs négatives signifient mesure absente.
** Retour: 1 si ammo canonique enregistrée, 0 sinon.
** Effets: remplace snapshot->ammo.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_ammo.c ->
** fishing_loadout_set_ammo().
** Dépendances: modèle ammo E88.
** État partagé: snapshot mutable.
** Concurrence: synchronisation externe si partagé.
** I/O: aucune.
** Unités: quantité de Spool Cells.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_loadout_set_ammo(t_fishing_loadout_snapshot *snapshot,
	const t_catalog_fishing_ammo *ammo, int64_t before, int64_t after)
{
	if (!snapshot || !ammo || ammo->item_type_id <= 0)
		return (0);
	memset(&snapshot->ammo, 0, sizeof(snapshot->ammo));
	snapshot->ammo.item_type_id = ammo->item_type_id;
	if (before >= 0)
		snapshot->ammo.has_quantity_before = 1;
	if (after >= 0)
		snapshot->ammo.has_quantity_after = 1;
	snapshot->ammo.quantity_before = before;
	snapshot->ammo.quantity_after = after;
	return (1);
}

/*
** Rôle: fishing_loadout_set_ammo_basis — Enregistre la base de coût ammo.
** Relations: aucune fonction projet appelée directement.
** Appelants: intégration inventaire future et tests E88.
** Mémoire: aucune.
** Invariants: quantité d'acquisition >0; coût >=0, y compris Restricted=0.
** Retour: 1 sur base enregistrée, 0 sinon.
** Effets: modifie snapshot->ammo.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_ammo.c ->
** fishing_loadout_set_ammo_basis().
** Dépendances: fixed-point t_money.
** État partagé: snapshot mutable.
** Concurrence: synchronisation externe si partagé.
** I/O: aucune.
** Unités: quantité et uPED5.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_loadout_set_ammo_basis(t_fishing_loadout_snapshot *snapshot,
	int64_t acquisition_quantity, t_money acquisition_cost)
{
	if (!snapshot || snapshot->ammo.item_type_id <= 0)
		return (0);
	if (acquisition_quantity <= 0 || acquisition_cost < 0)
		return (0);
	snapshot->ammo.acquisition_quantity = acquisition_quantity;
	snapshot->ammo.acquisition_cost = acquisition_cost;
	snapshot->ammo.has_acquisition_basis = 1;
	return (1);
}
