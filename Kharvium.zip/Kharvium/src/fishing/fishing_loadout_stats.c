/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout_stats.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing/fishing_loadout.h"
#include <limits.h>

/*
** Rôle: fishing_stat_add — Additionne une contribution x100 sans overflow et
**       propage explicitement l'inconnu lorsque la source vaut -1.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_loadout_strength(), fishing_loadout_flexibility().
** Mémoire: aucune.
** Invariants: -1 signifie inconnu; les stats valides sont non négatives.
** Retour: 1 si l'addition reste connue/représentable, 0 sinon.
** Effets: modifie total.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_stats.c ->
** fishing_stat_add().
** Dépendances: limites int32.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: valeur x100.
** Performance: O(1).
** Portabilité: C99.
*/
static int	fishing_stat_add(int32_t *total, int32_t value)
{
	if (!total || value < 0 || *total < 0)
		return (0);
	if (*total > INT32_MAX - value)
		return (0);
	*total += value;
	return (1);
}

/*
** Rôle: fishing_component_gear — Résout le gear canonique d'un slot présent
**       dans le snapshot, sans fallback par nom ou réseau.
** Relations: catalog_registry_find_fishing_gear().
** Appelants: calculs de stats E88.
** Mémoire: pointeur interne const uniquement.
** Invariants: item_type_id UNKNOWN renvoie NULL.
** Retour: définition gear locale ou NULL.
** Effets: aucun.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_stats.c ->
** fishing_component_gear().
** Dépendances: registre catalogue.
** État partagé: aucun.
** Concurrence: réentrante en lecture seule.
** I/O: aucune.
** Unités: ID canonique.
** Performance: O(n) catalogue gear.
** Portabilité: C99 Windows/Linux.
*/
static const t_catalog_fishing_gear	*fishing_component_gear(
	const t_fishing_component_snapshot *component,
	const t_catalog_registry *catalog)
{
	if (!component || !catalog || component->item_type_id <= 0)
		return (NULL);
	return (catalog_registry_find_fishing_gear(catalog,
			component->item_type_id));
}

/*
** Rôle: fishing_loadout_add_primary_stat — Cumule Rod+Blank+Line pour une
**       stat de combat Fishing officielle sans inclure Reel Strength.
** Relations: fishing_component_gear(), fishing_stat_add().
** Appelants: fishing_loadout_strength(), fishing_loadout_flexibility().
** Mémoire: aucune.
** Invariants: une contribution inconnue rend le total inconnu.
** Retour: 1 si toutes les contributions présentes sont connues, 0 sinon.
** Effets: renseigne total.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_stats.c ->
** fishing_loadout_add_primary_stat().
** Dépendances: slots fixes Rod/Blank/Line.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: x100.
** Performance: O(3 * recherche catalogue).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_loadout_add_primary_stat(
	const t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *catalog, int32_t *total, int flexibility)
{
	const t_catalog_fishing_gear	*gear;
	int				slot;
	int32_t				value;

	*total = 0;
	slot = FISHING_GEAR_SLOT_ROD;
	while (slot <= FISHING_GEAR_SLOT_LINE)
	{
		if (slot == FISHING_GEAR_SLOT_REEL)
		{
			slot++;
			continue ;
		}
		gear = fishing_component_gear(&snapshot->components[slot - 1], catalog);
		if (gear)
		{
			value = gear->strength_x100;
			if (flexibility)
				value = gear->flexibility_x100;
			if (!fishing_stat_add(total, value))
				return (0);
		}
		slot++;
	}
	return (1);
}

/*
** Rôle: fishing_loadout_set_secondary_stats — Renseigne Reel/Line/Lure depuis
**       leurs définitions locales sans extrapoler les champs absents.
** Relations: fishing_component_gear().
** Appelants: fishing_loadout_compute_stats().
** Mémoire: aucune.
** Invariants: chaque champ garde -1 si son composant ou sa stat est inconnu.
** Retour: aucun.
** Effets: modifie snapshot->stats.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_stats.c ->
** fishing_loadout_set_secondary_stats().
** Dépendances: slots fixes E88.
** État partagé: snapshot mutable fourni.
** Concurrence: synchronisation externe si partagé.
** I/O: aucune.
** Unités: x100, centimètres.
** Performance: trois recherches catalogue.
** Portabilité: C99 Windows/Linux.
*/
static void	fishing_loadout_set_secondary_stats(
	t_fishing_loadout_snapshot *snapshot, const t_catalog_registry *catalog)
{
	const t_catalog_fishing_gear	*gear;

	gear = fishing_component_gear(&snapshot->components[1], catalog);
	if (gear)
	{
		snapshot->stats.reel_strength_x100 = gear->strength_x100;
		snapshot->stats.reel_speed_x100 = gear->reel_speed_x100;
	}
	gear = fishing_component_gear(&snapshot->components[3], catalog);
	if (gear)
		snapshot->stats.line_length_cm = gear->line_length_cm;
	gear = fishing_component_gear(&snapshot->components[4], catalog);
	if (gear)
	{
		snapshot->stats.lure_depth_cm = gear->lure_depth_cm;
		snapshot->stats.lure_quality_x100 = gear->lure_quality_x100;
	}
}

/*
** Rôle: fishing_loadout_compute_stats — Calcule le snapshot combiné E88 à
**       partir des cinq composants locaux sélectionnés.
** Relations: fishing_loadout_add_primary_stat(),
**            fishing_loadout_set_secondary_stats().
** Appelants: UI/planner futur et tests E88.
** Mémoire: aucune allocation.
** Invariants: Strength/Flexibility excluent le reel; Reel Strength reste
**             séparée comme le modèle Fishing l'exige.
** Retour: 1 si snapshot/catalog valides, 0 sinon; les stats inconnues restent
**         -1 au lieu d'être inventées.
** Effets: remplace snapshot->stats.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_stats.c ->
** fishing_loadout_compute_stats().
** Dépendances: catalogue gear local uniquement.
** État partagé: snapshot mutable.
** Concurrence: synchronisation externe si partagé.
** I/O: aucune.
** Unités: x100 et cm.
** Performance: O(nombre fixe de slots * recherche catalogue).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_loadout_compute_stats(t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *catalog)
{
	int32_t	strength;
	int32_t	flexibility;

	if (!snapshot || !catalog)
		return (0);
	strength = -1;
	flexibility = -1;
	if (!fishing_loadout_add_primary_stat(snapshot, catalog, &strength, 0))
		strength = -1;
	if (!fishing_loadout_add_primary_stat(snapshot, catalog, &flexibility, 1))
		flexibility = -1;
	snapshot->stats.strength_x100 = strength;
	snapshot->stats.flexibility_x100 = flexibility;
	snapshot->stats.reel_strength_x100 = -1;
	snapshot->stats.reel_speed_x100 = -1;
	snapshot->stats.line_length_cm = -1;
	snapshot->stats.lure_depth_cm = -1;
	snapshot->stats.lure_quality_x100 = -1;
	fishing_loadout_set_secondary_stats(snapshot, catalog);
	return (1);
}
