/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rules.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing/fishing_rules.h"
#include "hunt/hunt_event_parse.h"
#include <string.h>

/*
** Rôle: fishing_parse_loot_line — Extrait uniquement les lignes LOOT_ITEM
**       sans appliquer les règles combat de la chasse.
** Relations: hunt_event_initialize_from_chat_line(), parse_received_line().
** Appelants: parse_engine_process_fishing().
** Mémoire: aucune allocation dynamique.
** Invariants: les lignes RECEIVED_OTHER ne deviennent jamais du loot.
** Retour: Retourne la valeur de succès ou le résultat métier décrit
**         par le rôle; zéro/NULL signale un rejet ou une absence selon le cas.
** Effets: modifie uniquement les destinations ou contextes mutables déclarés.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rules.c ->
** fishing_parse_loot_line().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** I/O: aucune E/S directe hors appels explicitement documentés.
** Unités: IDs, quantités et uPED conservent leurs unités de structure.
** Performance: coût local borné ou linéaire sur la collection parcourue.
** Portabilité: C99 portable; aucune dépendance C++ ou bibliothèque externe.
*/
int	fishing_parse_loot_line(const char *line_in, t_hunt_event *event)
{
	char	line[TRACKER_CHAT_LINE_CAP];
	char	ts[32];
	int		result;

	if (!line_in || !event)
		return (0);
	hunt_event_initialize_from_chat_line(line_in, event, line, ts);
	result = parse_received_line(line, ts, event);
	if (result != 1)
		return (0);
	return (strcmp(event->type, "LOOT_ITEM") == 0);
}

/*
** Rôle: fishing_event_role — Résout le rôle Fishing exact d'un LOOT_ITEM
**       depuis le catalogue data-driven courant.
** Relations: catalog_registry_find_fishing_output().
** Appelants: parser Fishing et fonctions de confirmation/nommage.
** Mémoire: aucune allocation.
** Invariants: absence du catalogue ou du nom retourne UNKNOWN.
** Retour: Retourne la valeur de succès ou le résultat métier décrit
**         par le rôle; zéro/NULL signale un rejet ou une absence selon le cas.
** Effets: modifie uniquement les destinations ou contextes mutables déclarés.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rules.c ->
** fishing_event_role().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** I/O: aucune E/S directe hors appels explicitement documentés.
** Unités: IDs, quantités et uPED conservent leurs unités de structure.
** Performance: coût local borné ou linéaire sur la collection parcourue.
** Portabilité: C99 portable; aucune dépendance C++ ou bibliothèque externe.
*/
t_fishing_output_role	fishing_event_role(const t_catalog_registry *catalog,
	const t_hunt_event *event)
{
	const t_catalog_fishing_output	*output;

	if (!catalog || !event || strcmp(event->type, "LOOT_ITEM") != 0)
		return (FISHING_OUTPUT_UNKNOWN);
	output = catalog_registry_find_fishing_output(catalog, event->name);
	if (!output)
		return (FISHING_OUTPUT_UNKNOWN);
	return (output->role);
}

/*
** Rôle: fishing_event_confirms_catch — Confirme une prise grâce à un raw fish
**       catalogué ou Fish Scrap, sans heuristique sur le nom.
** Relations: fishing_event_role().
** Appelants: parse_engine_process_fishing().
** Mémoire: aucune allocation.
** Invariants: huiles et outputs UNKNOWN ne confirment jamais seuls une prise.
** Retour: Retourne la valeur de succès ou le résultat métier décrit
**         par le rôle; zéro/NULL signale un rejet ou une absence selon le cas.
** Effets: modifie uniquement les destinations ou contextes mutables déclarés.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rules.c ->
** fishing_event_confirms_catch().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** I/O: aucune E/S directe hors appels explicitement documentés.
** Unités: IDs, quantités et uPED conservent leurs unités de structure.
** Performance: coût local borné ou linéaire sur la collection parcourue.
** Portabilité: C99 portable; aucune dépendance C++ ou bibliothèque externe.
*/
int	fishing_event_confirms_catch(const t_catalog_registry *catalog,
	const t_hunt_event *event)
{
	t_fishing_output_role	role;

	role = fishing_event_role(catalog, event);
	if (role == FISHING_OUTPUT_RAW_FISH)
		return (1);
	return (role == FISHING_OUTPUT_FISH_SCRAP);
}

/*
** Rôle: fishing_event_can_name_catch — Autorise uniquement RAW_FISH comme nom
**       d'espèce principal de l'enveloppe legacy KILL_FISHING.
** Relations: fishing_event_role().
** Appelants: fishing_group_catch_name().
** Mémoire: aucune allocation.
** Invariants: Fish Oil et family oils ne deviennent jamais une espèce.
** Retour: Retourne la valeur de succès ou le résultat métier décrit
**         par le rôle; zéro/NULL signale un rejet ou une absence selon le cas.
** Effets: modifie uniquement les destinations ou contextes mutables déclarés.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rules.c ->
** fishing_event_can_name_catch().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** I/O: aucune E/S directe hors appels explicitement documentés.
** Unités: IDs, quantités et uPED conservent leurs unités de structure.
** Performance: coût local borné ou linéaire sur la collection parcourue.
** Portabilité: C99 portable; aucune dépendance C++ ou bibliothèque externe.
*/
int	fishing_event_can_name_catch(const t_catalog_registry *catalog,
	const t_hunt_event *event)
{
	return (fishing_event_role(catalog, event) == FISHING_OUTPUT_RAW_FISH);
}
