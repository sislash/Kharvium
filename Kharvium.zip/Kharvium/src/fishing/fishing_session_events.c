/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_session_events.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing/fishing_session_economics.h"
#include "io/tracker_event_csv.h"
#include "common/money.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: fishing_session_add_loot — Agrège une ligne LOOT_ITEM et conserve
**       explicitement l'absence de valeur comme qualité partielle.
** Relations: money_add().
** Appelants: fishing_session_add_event().
** Mémoire: aucune allocation.
** Invariants: une valeur négative n'est jamais ajoutée au TT connu.
** Retour: aucun.
** Effets: modifie uniquement events.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_events.c ->
** fishing_session_add_loot().
** Dépendances: fixed-point money et flags V4.
** État partagé: aucun.
** Concurrence: réentrante pour agrégats distincts.
** I/O: aucune.
** Unités: lignes et uPED5.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static void	fishing_session_add_loot(t_fishing_session_events *events,
	const t_tracker_event_record *row)
{
	events->loot_rows++;
	if (!(row->flags & TRACKER_EVENT_FLAG_VALUE_KNOWN) || row->value_uPED < 0)
	{
		events->loot_rows_without_value++;
		return ;
	}
	events->loot_tt = money_add(events->loot_tt, row->value_uPED);
}

/*
** Rôle: fishing_session_add_event — Classe uniquement les événements Fishing
**       sémantiques utiles aux statistiques de session E89.
** Relations: fishing_session_add_loot(), strcmp().
** Appelants: fishing_session_events_read_v4().
** Mémoire: aucune allocation.
** Invariants: FISHING_CANDIDATE et FISHING_SKILL ne deviennent pas des prises.
** Retour: aucun.
** Effets: incrémente les compteurs de events.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_events.c ->
** fishing_session_add_event().
** Dépendances: noms persistants V4 stables E87.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: compteurs et uPED5.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static void	fishing_session_add_event(t_fishing_session_events *events,
	const t_tracker_event_record *row)
{
	if (strcmp(row->event_type, "FISHING_ATTEMPT") == 0)
	{
		events->attempts++;
		if (strcmp(row->target_or_item, "CONFIRMED_CATCH") == 0)
			events->confirmed_attempts++;
	}
	else if (strcmp(row->event_type, "FISHING_CATCH") == 0)
		events->catches++;
	else if (strcmp(row->event_type, "LOOT_ITEM") == 0)
		fishing_session_add_loot(events, row);
}

/*
** Rôle: fishing_session_finish_quality — Déduit la complétude du loot depuis
**       le nombre de lignes et les valeurs réellement présentes.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_session_events_read_v4().
** Mémoire: aucune allocation.
** Invariants: zéro ligne de loot reste UNKNOWN au lieu de devenir zéro prouvé.
** Retour: aucun.
** Effets: renseigne events->loot_quality.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_events.c ->
** fishing_session_finish_quality().
** Dépendances: enum de qualité E82.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: compteurs.
** Performance: O(1).
** Portabilité: C99.
*/
static void	fishing_session_finish_quality(t_fishing_session_events *events)
{
	if (events->loot_rows <= 0)
		events->loot_quality = DATA_UNKNOWN;
	else if (events->loot_rows_without_value > 0)
		events->loot_quality = DATA_PARTIAL_VALUE;
	else
		events->loot_quality = DATA_COMPLETE;
}

/*
** Rôle: fishing_session_process_line — Valide une ligne V4 et agrège seulement
**       la session Fishing ciblée; le header est explicitement ignoré.
** Relations: tracker_event_csv_parse_line(), fishing_session_add_event().
** Appelants: fishing_session_events_read_v4().
** Mémoire: aucune allocation; row pointe dans line pendant l'appel.
** Invariants: une ligne non-header malformée fait échouer le scan.
** Retour: 1 si ligne header/valide, 0 si corruption.
** Effets: peut modifier events.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_events.c ->
** fishing_session_process_line().
** Dépendances: CSV V4.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune directe.
** Unités: identifiants, compteurs, uPED5.
** Performance: O(longueur de ligne).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_session_process_line(char *line, int64_t session_id,
	t_fishing_session_events *events)
{
	t_tracker_event_record	row;

	if (strncmp(line, "timestamp_unix,", 15) == 0)
		return (1);
	if (!tracker_event_csv_parse_line(line, &row))
		return (0);
	if (row.session_id != session_id
		|| row.activity_type != TRACKER_ACTIVITY_TYPE_FISHING)
		return (1);
	events->found = 1;
	fishing_session_add_event(events, &row);
	return (1);
}

/*
** Rôle: fishing_session_events_read_v4 — Agrège une session Fishing depuis
**       tracker_events.csv avec détection stricte des lignes corrompues.
** Relations: fishing_session_process_line(), fishing_session_finish_quality().
** Appelants: tests E89 et futurs écrans/export/bridge Finance.
** Mémoire: aucune allocation dynamique; buffer de ligne sur pile.
** Invariants: session_id doit être positif; output est remis à zéro d'abord.
** Retour: 1 si lecture complète valide, 0 sur erreur stdio/format.
** Effets: ouvre/ferme path et renseigne events.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_session_events.c ->
** fishing_session_events_read_v4().
** Dépendances: fopen(), fgets(), fclose(), ferror(), memset().
** État partagé: aucun.
** Concurrence: lecture cohérente requise si writer simultané.
** I/O: lecture séquentielle V4.
** Unités: session_id, compteurs et uPED5.
** Performance: O(n) sur les lignes du journal.
** Portabilité: C99 Windows/Linux.
*/
int	fishing_session_events_read_v4(const char *path, int64_t session_id,
	t_fishing_session_events *events)
{
	char	line[4096];
	FILE	*file;
	int	ok;

	if (!path || !events || session_id <= 0)
		return (0);
	memset(events, 0, sizeof(*events));
	events->session_id = session_id;
	file = fopen(path, "rb");
	if (!file)
		return (0);
	ok = 1;
	while (ok && fgets(line, sizeof(line), file))
		ok = fishing_session_process_line(line, session_id, events);
	if (ferror(file) || fclose(file) != 0)
		ok = 0;
	fishing_session_finish_quality(events);
	return (ok);
}
