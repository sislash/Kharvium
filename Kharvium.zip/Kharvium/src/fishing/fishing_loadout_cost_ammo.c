/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout_cost_ammo.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_loadout_cost_internal.h"

/*
** Rôle: fishing_ammo_consumed — Mesure les Spool consommées before/after.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_cost_ammo_tt().
** Mémoire: aucune.
** Invariants: before>=after>=0.
** Retour: 1 avec quantité consommée, 0 sinon.
** Effets: écrit consumed.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost_ammo.c ->
** fishing_ammo_consumed().
** Dépendances: snapshot ammo.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: cellules.
** Performance: O(1).
** Portabilité: C99.
*/
static int	fishing_ammo_consumed(const t_fishing_ammo_snapshot *ammo,
	int64_t *consumed)
{
	if (!ammo || !consumed || ammo->item_type_id <= 0)
		return (0);
	if (!ammo->has_quantity_before || !ammo->has_quantity_after)
		return (0);
	if (ammo->quantity_after < 0
		|| ammo->quantity_before < ammo->quantity_after)
		return (0);
	*consumed = ammo->quantity_before - ammo->quantity_after;
	return (1);
}

/*
** Rôle: fishing_cost_ammo_tt — Calcule le TT des Spool mesurées.
** Relations: catalog_registry_find_fishing_ammo(), fishing_ammo_consumed(),
**            fishing_money_multiply().
** Appelants: fishing_loadout_calculate_cost().
** Mémoire: aucune.
** Invariants: unit_tt est une propriété système locale, pas un prix marché.
** Retour: 1 si TT calculable, 0 sinon.
** Effets: écrit ammo_tt_cost et consumed.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost_ammo.c ->
** fishing_cost_ammo_tt().
** Dépendances: catalogue local ammo.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: quantité et uPED5.
** Performance: O(taille catalogue ammo).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_cost_ammo_tt(const t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *catalog, t_fishing_loadout_cost *cost,
	int64_t *consumed)
{
	const t_catalog_fishing_ammo	*ammo;

	ammo = catalog_registry_find_fishing_ammo(catalog,
			snapshot->ammo.item_type_id);
	if (!ammo || !fishing_ammo_consumed(&snapshot->ammo, consumed))
		return (0);
	return (fishing_money_multiply(ammo->unit_tt, *consumed,
			&cost->ammo_tt_cost));
}

/*
** Rôle: fishing_cost_ammo_basis — Prorate la base réelle des Spool.
** Relations: fishing_money_prorate().
** Appelants: fishing_loadout_calculate_cost().
** Mémoire: aucune.
** Invariants: consumed=0 coûte zéro; sinon base explicite requise.
** Retour: 1 si coût calculable, 0 sinon.
** Effets: écrit ammo_cost_basis_consumed.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost_ammo.c ->
** fishing_cost_ammo_basis().
** Dépendances: snapshot ammo.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: quantité et uPED5.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_cost_ammo_basis(const t_fishing_loadout_snapshot *snapshot,
	int64_t consumed, t_fishing_loadout_cost *cost)
{
	if (consumed == 0)
	{
		cost->ammo_cost_basis_consumed = 0;
		return (1);
	}
	if (!snapshot->ammo.has_acquisition_basis)
		return (0);
	return (fishing_money_prorate(snapshot->ammo.acquisition_cost, consumed,
			snapshot->ammo.acquisition_quantity,
			&cost->ammo_cost_basis_consumed));
}
