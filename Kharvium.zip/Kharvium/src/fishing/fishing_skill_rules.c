/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_skill_rules.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing/fishing_rules.h"
#include "hunt/hunt_event_parse.h"
#include "common/string_operations.h"
#include <string.h>

/*
** Rôle: fishing_skill_extract_name — Extrait le nom compris entre le texte
**       "experience in your" et le suffixe "skill" sans troncature.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_parse_skill_line().
** Mémoire: aucune allocation.
** Invariants: le nom doit tenir entièrement dans destination.
** Retour: Retourne la valeur de succès ou le résultat métier décrit
**         par le rôle; zéro/NULL signale un rejet ou une absence selon le cas.
** Effets: modifie uniquement les destinations ou contextes mutables déclarés.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_skill_rules.c ->
** fishing_skill_extract_name().
** Dépendances: API projet et libc explicitement citées dans Relations.
** État partagé: aucun nouvel état global mutable introduit par la fonction.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** I/O: aucune E/S directe hors appels explicitement documentés.
** Unités: IDs, quantités et uPED conservent leurs unités de structure.
** Performance: coût local borné ou linéaire sur la collection parcourue.
** Portabilité: C99 portable; aucune dépendance C++ ou bibliothèque externe.
*/
static int	fishing_skill_extract_name(const char *line, char *destination,
	size_t capacity)
{
	const char	*start;
	const char	*end;
	size_t		length;

	start = strstr(line, " experience in your ");
	if (!start)
		return (0);
	start += strlen(" experience in your ");
	end = strstr(start, " skill");
	if (!end || end <= start)
		return (0);
	length = (size_t)(end - start);
	if (length + 1 > capacity)
		return (0);
	memcpy(destination, start, length);
	destination[length] = '\0';
	return (1);
}

/*
** Rôle: fishing_parse_skill_line — Produit un événement FISHING_SKILL pour
**       un gain de skill exact appartenant au catalogue Fishing.
** Relations: catalog_registry_is_fishing_skill(),
**            fishing_skill_extract_name(),
**            hunt_event_initialize_from_chat_line().
** Appelants: parse_engine_process_fishing().
** Mémoire: aucune allocation.
** Invariants: les gains Provisioning/Cooking et skills inconnus sont rejetés.
** Retour: Retourne le résultat de validation ou de traitement décrit
**         par le rôle; zéro signale un rejet ou une erreur locale.
** Effets: modifie uniquement les objets mutables explicitement fournis.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_skill_rules.c ->
** fishing_parse_skill_line().
** Dépendances: fonctions projet/libc citées explicitement dans Relations.
** État partagé: aucun nouvel état global mutable introduit ici.
** Concurrence: réentrante hors objets mutables partagés par l’appelant.
** I/O: uniquement les E/S indiquées explicitement par le rôle/Relations.
** Unités: conserve les unités natives des structures manipulées.
** Performance: coût borné ou linéaire sur la collection parcourue.
** Portabilité: C99 portable, sans C++ ni bibliothèque externe.
*/
int	fishing_parse_skill_line(const t_catalog_registry *catalog,
	const char *line_in, t_hunt_event *event)
{
	char	line[TRACKER_CHAT_LINE_CAP];
	char	ts[32];
	char	skill[CATALOG_SKILL_CAP];

	if (!catalog || !line_in || !event)
		return (0);
	if (!strstr(line_in, "You have gained "))
		return (0);
	if (!fishing_skill_extract_name(line_in, skill, sizeof(skill)))
		return (0);
	if (!catalog_registry_is_fishing_skill(catalog, skill))
		return (0);
	hunt_event_initialize_from_chat_line(line_in, event, line, ts);
	string_copy_safe(event->type, sizeof(event->type), "FISHING_SKILL");
	string_copy_safe(event->name, sizeof(event->name), skill);
	return (1);
}
