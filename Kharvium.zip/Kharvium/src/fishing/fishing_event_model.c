/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_event_model.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing/fishing_event_model.h"

/*
** Rôle: fishing_attempt_result_name — Convertit le résultat sémantique d'une
**       tentative Fishing vers son libellé persistant stable.
** Paramètre: result — valeur enum consultée en lecture seule.
** Retour: chaîne statique; "UNKNOWN" si result n'est pas reconnu.
** Effets: aucun.
** Invariants: aucune allocation et aucun résultat hors domaine n'est inventé.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: parseur Fishing E87 et tests du modèle sémantique.
** Dépendances: aucune fonction libc directe.
** Mémoire: aucune allocation/libération directe.
** État partagé: aucun symbole global mutable.
** Concurrence: réentrant.
** I/O: aucune.
** Unités: aucune.
** Performance: coût constant.
** Portabilité: C99 portable Windows/Linux.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        fishing_event_model.c -> fishing_attempt_result_name().
** --- Fin des liens techniques auto-vérifiés ---
*/
const char	*fishing_attempt_result_name(t_fishing_attempt_result result)
{
	if (result == FISHING_ATTEMPT_CONFIRMED_CATCH)
		return ("CONFIRMED_CATCH");
	if (result == FISHING_ATTEMPT_NO_BITE)
		return ("NO_BITE");
	if (result == FISHING_ATTEMPT_FAILED_REEL)
		return ("FAILED_REEL");
	if (result == FISHING_ATTEMPT_CANCELLED)
		return ("CANCELLED");
	if (result == FISHING_ATTEMPT_INTERRUPTED)
		return ("INTERRUPTED");
	return ("UNKNOWN");
}
