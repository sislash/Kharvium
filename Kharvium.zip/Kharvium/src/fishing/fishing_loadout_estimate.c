/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout_estimate.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_loadout_cost_internal.h"
#include "common/money.h"
#include <string.h>

/*
** Rôle: fishing_estimate_add_component — Ajoute le decay catalogue connu
**       d'un composant sélectionné au sous-total TT par tentative.
** Paramètre: snapshot — composant runtime identifié par son ID canonique.
** Paramètre: catalog — registre Fishing local consulté en lecture seule.
** Paramètre: estimate — résultat partiel mis à jour sans inventer
**       pour une donnée inconnue.
** Retour: aucun.
** Effets: incrémente le compteur connu/inconnu et le sous-total gear.
** Invariants: un decay négatif reste inconnu; zéro est une valeur valide.
** Relations: catalog_registry_find_fishing_gear(), money_add().
** Appelants: fishing_loadout_estimate_tt_per_attempt().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_estimate_add_component().
** Dépendances: catalogue Fishing local et arithmétique fixe t_money.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun.
** Concurrence: réentrante pour sorties distinctes.
** I/O: aucune.
** Unités: uPED5 par tentative.
** Performance: O(taille catalogue gear) par composant présent.
** Portabilité: C99 Windows/Linux.
*/
static void	fishing_estimate_add_component(
	const t_fishing_component_snapshot *snapshot,
	const t_catalog_registry *catalog, t_fishing_loadout_estimate *estimate)
{
	const t_catalog_fishing_gear	*gear;

	gear = catalog_registry_find_fishing_gear(catalog, snapshot->item_type_id);
	if (!gear || gear->decay_per_use < 0)
	{
		estimate->unknown_components++;
		return ;
	}
	estimate->gear_tt_per_attempt = money_add(estimate->gear_tt_per_attempt,
		gear->decay_per_use);
	estimate->known_components++;
}

/*
** Rôle: fishing_estimate_add_ammo — Calcule le TT de Spool Cell consommé
**       par tentative depuis l'ammo burn de la canne et le TT unitaire.
** Paramètre: snapshot — montage actif contenant Rod et Ammo sélectionnées.
** Paramètre: catalog — registre local des équipements et munitions Fishing.
** Paramètre: estimate — résultat dont la partie ammo est renseignée.
** Retour: aucun.
** Effets: renseigne ammo_required, ammo_known et ammo_tt_per_attempt.
** Invariants: Baitfishing n'exige aucune ammo; une donnée absente reste N/D.
** Relations: catalog_registry_find_fishing_gear(),
**            catalog_registry_find_fishing_ammo(), fishing_money_multiply().
** Appelants: fishing_loadout_estimate_tt_per_attempt().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_estimate_add_ammo().
** Dépendances: propriétés système locales ammo burn et TT unitaire.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun.
** Concurrence: réentrante pour sorties distinctes.
** I/O: aucune.
** Unités: quantité de cellules et uPED5 par tentative.
** Performance: deux recherches catalogue au maximum.
** Portabilité: C99 Windows/Linux.
*/
static void	fishing_estimate_add_ammo(
	const t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *catalog, t_fishing_loadout_estimate *estimate)
{
	const t_catalog_fishing_gear	*rod;
	const t_catalog_fishing_ammo	*ammo;

	rod = catalog_registry_find_fishing_gear(catalog,
			snapshot->components[0].item_type_id);
	if (!rod)
		return ;
	if (rod->method == FISHING_METHOD_BAITFISHING)
	{
		estimate->ammo_known = 1;
		return ;
	}
	estimate->ammo_required = 1;
	ammo = catalog_registry_find_fishing_ammo(catalog,
			snapshot->ammo.item_type_id);
	if (!ammo || ammo->unit_tt < 0 || rod->ammo_burn < 0)
		return ;
	if (!fishing_money_multiply(ammo->unit_tt, rod->ammo_burn,
			&estimate->ammo_tt_per_attempt))
		return ;
	estimate->ammo_known = 1;
}

/*
** Rôle: fishing_estimate_quality — Qualifie le sous-total technique calculé
**       afin qu'une estimation partielle ne soit jamais affichée comme totale.
** Paramètre: estimate — estimation déjà alimentée par gear et ammo.
** Retour: DATA_COMPLETE, DATA_PARTIAL_COST ou DATA_UNKNOWN.
** Effets: aucun.
** Invariants: COMPLETE exige tous les composants présents et l'ammo requise.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_loadout_estimate_tt_per_attempt().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_estimate_quality().
** Dépendances: enum t_data_quality.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: aucune.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static t_data_quality	fishing_estimate_quality(
	const t_fishing_loadout_estimate *estimate)
{
	if (estimate->unknown_components == 0
		&& (!estimate->ammo_required || estimate->ammo_known))
		return (DATA_COMPLETE);
	if (estimate->known_components > 0 || estimate->ammo_known)
		return (DATA_PARTIAL_COST);
	return (DATA_UNKNOWN);
}

/*
** Rôle: fishing_loadout_estimate_tt_per_attempt — Recalcule immédiatement
**       le coût TT technique d'une tentative depuis le montage sélectionné.
** Paramètre: snapshot — Rod/Reel/Blank/Line/Lure/Ammo actifs.
** Paramètre: catalog — définitions locales contenant decay et ammo burn.
** Paramètre: estimate — destination totalement réinitialisée puis remplie.
** Retour: 1 si les paramètres sont valides, 0 sinon.
** Effets: remplace estimate; ne modifie ni snapshot ni catalogue.
** Invariants: aucun MU/prix marché n'est utilisé; les champs inconnus restent
**             explicitement partiels au lieu d'être estimés arbitrairement.
** Relations: fishing_estimate_add_component(), fishing_estimate_add_ammo(),
**            fishing_estimate_quality(), money_add(), memset().
** Appelants: picker Fishing, restauration, UI Tracker et tests E110.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**    fishing_loadout_estimate_tt_per_attempt().
** Dépendances: catalogue Fishing local et arithmétique fixed-point.
** Mémoire: aucune allocation dynamique.
** État partagé: aucun.
** Concurrence: réentrante pour sorties distinctes.
** I/O: aucune.
** Unités: uPED5 par tentative.
** Performance: O(5 * taille catalogue gear + taille catalogue ammo).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_loadout_estimate_tt_per_attempt(
	const t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *catalog, t_fishing_loadout_estimate *estimate)
{
	int	index;

	if (!snapshot || !catalog || !estimate)
		return (0);
	memset(estimate, 0, sizeof(*estimate));
	index = 0;
	while (index < FISHING_LOADOUT_COMPONENTS)
	{
		if (snapshot->components[index].item_type_id > 0)
			fishing_estimate_add_component(&snapshot->components[index],
				catalog, estimate);
		index++;
	}
	fishing_estimate_add_ammo(snapshot, catalog, estimate);
	estimate->total_tt_per_attempt = money_add(estimate->gear_tt_per_attempt,
		estimate->ammo_tt_per_attempt);
	estimate->quality = fishing_estimate_quality(estimate);
	return (1);
}
