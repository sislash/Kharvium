/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing/fishing_loadout.h"
#include <string.h>

/*
** Rôle: fishing_loadout_initialize — Initialise un snapshot E88 sans coût ni
**       stat inventé; les stats inconnues utilisent explicitement -1.
** Relations: memset().
** Appelants: UI/config futurs et tests E88 avant toute saisie de loadout.
** Mémoire: aucune allocation; snapshot reste propriété de l'appelant.
** Invariants: aucun slot/item/ammo n'est implicitement sélectionné.
** Retour: aucun.
** Effets: réinitialise entièrement snapshot.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout.c ->
** fishing_loadout_initialize().
** Dépendances: libc memset().
** État partagé: aucun.
** Concurrence: réentrante pour snapshots distincts.
** I/O: aucune.
** Unités: stats inconnues = -1.
** Performance: O(taille fixe du snapshot).
** Portabilité: C99 Windows/Linux.
*/
void	fishing_loadout_initialize(t_fishing_loadout_snapshot *snapshot)
{
	if (!snapshot)
		return ;
	memset(snapshot, 0, sizeof(*snapshot));
	snapshot->stats.strength_x100 = -1;
	snapshot->stats.flexibility_x100 = -1;
	snapshot->stats.reel_strength_x100 = -1;
	snapshot->stats.reel_speed_x100 = -1;
	snapshot->stats.line_length_cm = -1;
	snapshot->stats.lure_depth_cm = -1;
	snapshot->stats.lure_quality_x100 = -1;
}

/*
** Rôle: fishing_loadout_slot_index — Convertit un slot stable 1..5 en index
**       de tableau fixe sans accepter UNKNOWN ou valeur hors domaine.
** Relations: aucune fonction projet appelée directement.
** Appelants: setters de composant E88.
** Mémoire: aucune.
** Invariants: FISHING_LOADOUT_COMPONENTS reste aligné avec les cinq slots.
** Retour: index 0..4 ou -1 si invalide.
** Effets: aucun.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout.c ->
** fishing_loadout_slot_index().
** Dépendances: constantes du modèle loadout.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: index.
** Performance: O(1).
** Portabilité: C99.
*/
static int	fishing_loadout_slot_index(t_fishing_gear_slot slot)
{
	if (slot < FISHING_GEAR_SLOT_ROD || slot > FISHING_GEAR_SLOT_LURE)
		return (-1);
	return ((int)slot - 1);
}

/*
** Rôle: fishing_loadout_set_component — Capture l'item et, seulement lorsque
**       fournis, ses TT avant/après pour mesurer le decay réel.
** Relations: fishing_loadout_slot_index().
** Appelants: collecte manuelle/import future et tests de coût E88.
** Mémoire: aucune allocation.
** Invariants: le slot vient du gear local; tt négatif signifie non fourni.
** Retour: 1 si le composant est enregistré, 0 sinon.
** Effets: remplace le snapshot du slot ciblé.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout.c ->
** fishing_loadout_set_component().
** Dépendances: modèle catalogue/loadout.
** État partagé: snapshot mutable fourni par appelant.
** Concurrence: synchronisation externe si partagé.
** I/O: aucune.
** Unités: TT en uPED5.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_loadout_set_component(t_fishing_loadout_snapshot *snapshot,
	const t_catalog_fishing_gear *gear, t_money tt_before, t_money tt_after)
{
	t_fishing_component_snapshot	*component;
	int				index;

	if (!snapshot || !gear || gear->item_type_id <= 0)
		return (0);
	index = fishing_loadout_slot_index(gear->slot);
	if (index < 0)
		return (0);
	component = &snapshot->components[index];
	memset(component, 0, sizeof(*component));
	component->item_type_id = gear->item_type_id;
	component->slot = gear->slot;
	if (tt_before >= 0)
		component->has_tt_before = 1;
	if (tt_after >= 0)
		component->has_tt_after = 1;
	component->tt_before = tt_before;
	component->tt_after = tt_after;
	return (1);
}

/*
** Rôle: fishing_loadout_set_component_basis — Ajoute le coût d'acquisition
**       historique d'un composant sans utiliser le MU de marché courant.
** Relations: fishing_loadout_slot_index().
** Appelants: saisie/inventaire futur et tests E88.
** Mémoire: aucune allocation.
** Invariants: acquisition_tt doit être positif et coût non négatif.
** Retour: 1 si la base est applicable à un slot présent, 0 sinon.
** Effets: renseigne la base historique du composant.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout.c ->
** fishing_loadout_set_component_basis().
** Dépendances: modèle loadout.
** État partagé: snapshot mutable de l'appelant.
** Concurrence: synchronisation externe si partagé.
** I/O: aucune.
** Unités: uPED5.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_loadout_set_component_basis(t_fishing_loadout_snapshot *snapshot,
	t_fishing_gear_slot slot, t_money acquisition_tt, t_money acquisition_cost)
{
	t_fishing_component_snapshot	*component;
	int				index;

	if (!snapshot || acquisition_tt <= 0 || acquisition_cost < 0)
		return (0);
	index = fishing_loadout_slot_index(slot);
	if (index < 0 || snapshot->components[index].item_type_id <= 0)
		return (0);
	component = &snapshot->components[index];
	component->acquisition_tt = acquisition_tt;
	component->acquisition_cost = acquisition_cost;
	component->has_acquisition_basis = 1;
	return (1);
}
