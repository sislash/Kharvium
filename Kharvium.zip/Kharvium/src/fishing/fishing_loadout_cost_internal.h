/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout_cost_internal.h                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FISHING_LOADOUT_COST_INTERNAL_H
# define FISHING_LOADOUT_COST_INTERNAL_H

# include "fishing/fishing_loadout.h"

int	fishing_money_prorate(t_money total, int64_t used,
		int64_t basis, t_money *out);
int	fishing_money_multiply(t_money unit, int64_t quantity, t_money *out);
int	fishing_cost_components(const t_fishing_loadout_snapshot *snapshot,
		t_fishing_loadout_cost *cost, int *tt_complete,
		int *basis_complete);
int	fishing_cost_ammo_tt(const t_fishing_loadout_snapshot *snapshot,
		const t_catalog_registry *catalog, t_fishing_loadout_cost *cost,
		int64_t *consumed);
int	fishing_cost_ammo_basis(const t_fishing_loadout_snapshot *snapshot,
		int64_t consumed, t_fishing_loadout_cost *cost);

#endif
