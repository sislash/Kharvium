/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_loadout_cost_gear.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_loadout_cost_internal.h"

/*
** Rôle: fishing_component_decay — Calcule uniquement un decay TT mesuré.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_cost_components().
** Mémoire: aucune.
** Invariants: before>=after>=0 et deux mesures présentes.
** Retour: 1 avec decay, 0 sinon.
** Effets: écrit decay.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost_gear.c ->
** fishing_component_decay().
** Dépendances: snapshot composant.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: uPED5.
** Performance: O(1).
** Portabilité: C99.
*/
static int	fishing_component_decay(
	const t_fishing_component_snapshot *component, t_money *decay)
{
	if (!component || !decay || component->item_type_id <= 0)
		return (0);
	if (!component->has_tt_before || !component->has_tt_after)
		return (0);
	if (component->tt_after < 0 || component->tt_before < component->tt_after)
		return (0);
	*decay = component->tt_before - component->tt_after;
	return (1);
}

/*
** Rôle: fishing_component_basis_cost — Prorate la base réelle au decay.
** Relations: fishing_money_prorate().
** Appelants: fishing_cost_components().
** Mémoire: aucune.
** Invariants: decay mesuré; coût courant de marché jamais consulté.
** Retour: 1 si coût calculable, 0 sinon.
** Effets: écrit basis_cost.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost_gear.c ->
** fishing_component_basis_cost().
** Dépendances: base historique du composant.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: uPED5.
** Performance: O(1).
** Portabilité: C99.
*/
static int	fishing_component_basis_cost(
	const t_fishing_component_snapshot *component, t_money decay,
	t_money *basis_cost)
{
	if (decay == 0)
	{
		*basis_cost = 0;
		return (1);
	}
	if (!component->has_acquisition_basis)
		return (0);
	return (fishing_money_prorate(component->acquisition_cost, decay,
			component->acquisition_tt, basis_cost));
}

/*
** Rôle: fishing_cost_one_component — Ajoute un composant présent au coût.
** Relations: fishing_component_decay(), fishing_component_basis_cost(),
**            money_add().
** Appelants: fishing_cost_components().
** Mémoire: aucune.
** Invariants: TT et coût économique gardent leur complétude indépendante.
** Retour: aucun.
** Effets: modifie cost et flags de complétude.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost_gear.c ->
** fishing_cost_one_component().
** Dépendances: fixed-point money.
** État partagé: aucun.
** Concurrence: objets distincts requis.
** I/O: aucune.
** Unités: uPED5.
** Performance: O(1).
** Portabilité: C99.
*/
static void	fishing_cost_one_component(
	const t_fishing_component_snapshot *component,
	t_fishing_loadout_cost *cost, int *tt_complete, int *basis_complete)
{
	t_money	decay;
	t_money	basis_cost;

	if (!fishing_component_decay(component, &decay))
	{
		*tt_complete = 0;
		*basis_complete = 0;
		return ;
	}
	cost->gear_tt_decay = money_add(cost->gear_tt_decay, decay);
	if (!fishing_component_basis_cost(component, decay, &basis_cost))
		*basis_complete = 0;
	else
		cost->gear_cost_basis_consumed = money_add(
			cost->gear_cost_basis_consumed, basis_cost);
}

/*
** Rôle: fishing_cost_components — Agrège les cinq slots réellement présents.
** Relations: fishing_cost_one_component().
** Appelants: fishing_loadout_calculate_cost().
** Mémoire: aucune.
** Invariants: slot absent n'est pas inventé ni facturé.
** Retour: nombre de composants présents.
** Effets: remplit coût gear et complétude.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_loadout_cost_gear.c ->
** fishing_cost_components().
** Dépendances: tableau fixe cinq slots.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: uPED5.
** Performance: O(5).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_cost_components(const t_fishing_loadout_snapshot *snapshot,
	t_fishing_loadout_cost *cost, int *tt_complete, int *basis_complete)
{
	int	present;
	int	index;

	present = 0;
	index = 0;
	while (index < FISHING_LOADOUT_COMPONENTS)
	{
		if (snapshot->components[index].item_type_id > 0)
		{
			present++;
			fishing_cost_one_component(&snapshot->components[index], cost,
				tt_complete, basis_complete);
		}
		index++;
	}
	return (present);
}
