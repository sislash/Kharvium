/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_runtime_render_ui.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main_modules.h"

/*
** Rôle: runtime_render_ui — Rend runtime dans le contexte graphique courant
**       en respectant la géométrie, le clipping et l’état des widgets
**       fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_modal_page_frame_render(),
**            app_navigation_page_uses_modal_frame(),
**            runtime_render_standard_frame().
** Appelants: runtime_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_ui.c -> runtime_render_ui() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	runtime_render_ui(t_app_runtime *runtime)
{
	runtime->modal = app_navigation_page_uses_modal_frame(runtime->app.page);
	if (runtime->modal)
	{
		app_modal_page_frame_render(&runtime->window, &runtime->ui,
			&runtime->app);
		return ;
	}
	runtime_render_standard_frame(runtime);
}

/*
** Rôle: runtime_overlay_shortcuts — Met à jour runtime shortcuts en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> overlay_is_enabled(),
**            overlay_sync_session_clock(), overlay_toggle(),
**            overlay_toggle_click_through(), platform_time_milliseconds().
** Appelants: runtime_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_ui.c -> runtime_overlay_shortcuts() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: millisecondes.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	runtime_overlay_shortcuts(t_app_runtime *runtime)
{
	if (runtime->window.key_o)
	{
		overlay_toggle(runtime->app.core);
		if (overlay_is_enabled() && runtime->app.session_start_ms == 0)
			runtime->app.session_start_ms = platform_time_milliseconds();
	}
	if (runtime->window.key_p)
		overlay_toggle_click_through();
	overlay_sync_session_clock(&runtime->app.session_start_ms);
}

/*
** Rôle: runtime_overlay_tick — Exécute un cycle l’état associé à exécution
**       overlay.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> overlay_is_enabled(),
**            overlay_sync_session_clock(), platform_time_milliseconds(),
**            tracker_overlay_tick().
** Appelants: runtime_frame().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_ui.c -> runtime_overlay_tick() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: millisecondes.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	runtime_overlay_tick(t_app_runtime *runtime)
{
	uint64_t			elapsed;
	t_hunt_stats		*stats;

	if (!overlay_is_enabled())
		return ;
	elapsed = 0ULL;
	if (runtime->app.session_start_ms != 0)
		elapsed = platform_time_milliseconds()
			- runtime->app.session_start_ms;
	stats = NULL;
	if (runtime->app.hunt_stats_ok)
		stats = &runtime->app.hunt_stats;
	tracker_overlay_tick(stats, elapsed);
	overlay_sync_session_clock(&runtime->app.session_start_ms);
}

/*
** Rôle: runtime_frame — Traite une frame complète de exécution.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_refresh_cached(),
**            frame_limiter_begin(), frame_limiter_end_and_sleep(),
**            runtime_navigation_keys(), runtime_overlay_shortcuts(),
**            runtime_overlay_tick(), runtime_render_ui(),
**            window_poll_events() (+1; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_ui.c -> runtime_frame() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=9; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	runtime_frame(t_app_runtime *runtime)
{
	frame_limiter_begin(&runtime->limiter);
	window_poll_events(&runtime->window);
	runtime_navigation_keys(runtime);
	app_refresh_cached(&runtime->app);
	runtime_render_ui(runtime);
	runtime_overlay_shortcuts(runtime);
	runtime_overlay_tick(runtime);
	window_present(&runtime->window);
	frame_limiter_end_and_sleep(&runtime->limiter);
}

/*
** Rôle: runtime_shutdown — Arrête proprement exécution et libère ses
**       ressources.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_finance_shutdown(),
**            app_state_shutdown(), app_weapon_picker_close(),
**            window_destroy().
** Appelants: main().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_runtime_render_ui.c -> runtime_shutdown() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	runtime_shutdown(t_app_runtime *runtime)
{
	app_weapon_picker_close(&runtime->app);
	app_fishing_rod_picker_close(&runtime->app);
	app_finance_shutdown(&runtime->app);
	app_state_shutdown(&runtime->core);
	window_destroy(&runtime->window);
}
