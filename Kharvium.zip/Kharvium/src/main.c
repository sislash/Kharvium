/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main_modules.h"

/*
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètre: argc — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : argv.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_state_shutdown(), runtime_frame(),
**            runtime_initialize_base(), runtime_initialize_window(),
**            runtime_preflight(), runtime_shutdown().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère main.c ->
**        main() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=6; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	main(int argc, char **argv)
{
	t_app_runtime	runtime;
	int			result;

	runtime_initialize_base(&runtime);
	result = runtime_preflight(&runtime, argc, argv);
	if (result >= 0)
	{
		app_state_shutdown(&runtime.core);
		return (result);
	}
	if (!runtime_initialize_window(&runtime))
	{
		app_state_shutdown(&runtime.core);
		return (1);
	}
	while (runtime.window.running)
		runtime_frame(&runtime);
	runtime_shutdown(&runtime);
	return (0);
}
