/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_modules.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MAIN_MODULES_H
# define MAIN_MODULES_H

# include "ui/main_menu.h" /* parser_workers_stop_all() */
# include "app/app_brand.h"
# include "common/string_operations.h"
# include "ui/frame_limiter.h"
# include "ui/ui_layout.h"
# include "ui/ui_chrome.h"
# include "ui/ui_theme_types.h"
# include "ui/ui_widgets.h"
# include "ui/ui_geometry.h"
# include "ui/ui_console.h"
# include "ui/ui_dialog.h"
# include "ui/ui_data_actions.h"
# include "platform/native_window.h"
# include "ui/live_chart_screen.h"
# include "ui/config_menu.h"
# include "hunt/hunt_series_live.h"
# include "analytics/hunt_stats_live.h"
# include "io/hunt_csv.h"
# include "parse/parse_worker.h"
# include "app/global_events_worker.h"
# include "analytics/hunt_stats.h"
# include "app/global_events_stats.h"
# include "core/session_runtime.h"
# include "core/session_export.h"
# include "core/session_catalog.h"
# include "config/selected_weapon.h"
# include "config/selected_creature.h"
# include "config/weapon_config.h"
# include "ui/tracker_overlay.h"
# include "config/sweat_settings.h"
# include "common/localization.h"
# include "app/app_state.h"
# include "app/app_ui_state.h"
# include "app/app_topbar_internal.h"
# include "app/app_sidebar_internal.h"
# include "app/app_modal_frame_internal.h"
# include "app/app_runtime_internal.h"
# include "app/app_cache_internal.h"
# include "app/app_input_internal.h"
# include "app/app_picker_internal.h"
# include "app/app_tracker_session_start.h"
# include "app/app_session_actions_internal.h"
# include "app/app_navigation.h"
# include "app/app_quit_guard.h"
# include "app/finance_view_state.h"
# include "common/duration_format.h"
# include "platform/chat_log_path.h"
# include "app/app_benchmark.h"
# include "app/app_selftest.h"
# include "app/app_overlay_demo.h"
# include "app/page_layout.h"
# include "app/tracker_pages.h"
# include "app/app_utility_pages.h"
# include "app/config_page.h"
# include "app/hotkeys_page.h"
# include "app/help_page.h"
# include "app/system_health_page.h"
# include "app/finance_page.h"
# include "io/csv_format.h"
# include "platform/app_paths.h"
# include "platform/file_system.h"
# include "io/csv_persistence.h"
# include "platform/platform_time.h"
# include "common/money.h"
# include <stdio.h>
# include <string.h>
# include <stdlib.h>

# define APP_MODAL_NONE 0
# define APP_MODAL_MESSAGE 1
# define APP_MODAL_CONFIRM 2
# define APP_MODAL_MOB 3
# define APP_ACT_CLEAR_HUNT_CSV 3
# define APP_ACTION_CLEAR_GLOBAL_EVENTS_CSV 4
# define APP_ACT_QUIT_FORCE 5

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: minimum_integer — Met à jour minimum integer en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: a — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: b — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: minimum_integer().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                minimum_integer(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	minimum_integer(int a, int b);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_close — Ferme l’état associé à application modale.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_close().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_close(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_modal_close(t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_set_lines — Met à jour modale lignes à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: lines — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: n — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_set_lines().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_set_lines(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_modal_set_lines(t_app *app, const char **lines, int n);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: modal_frame_layout — Calcule la mise en page et les zones de modale
**       frame.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: modal_frame_layout().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                modal_frame_layout(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	modal_frame_layout(t_modal_frame_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: modal_message_render — Rend l’état associé à modale message.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: modal_message_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                modal_message_render(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	modal_message_render(t_modal_frame_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: modal_confirm_keyboard — Traite les touches de navigation,
**       validation et annulation de la modale de
**       confirmation, met à jour son résultat et
**       la ferme lorsque le choix est final.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: modal_confirm_keyboard().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                modal_confirm_keyboard(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	modal_confirm_keyboard(t_modal_frame_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: modal_confirm_content — Construit ou rend le contenu de modale
**       confirm.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: modal_confirm_content().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                modal_confirm_content(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	modal_confirm_content(t_modal_frame_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: modal_confirm_render — Rend l’état associé à modale confirm.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: modal_confirm_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                modal_confirm_render(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	modal_confirm_render(t_modal_frame_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: modal_creature_content — Construit ou rend le contenu de modale
**       creature.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: modal_creature_content().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                modal_creature_content(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	modal_creature_content(t_modal_frame_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: modal_creature_buttons — Gère les boutons et leurs actions pour
**       modale creature.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: modal_creature_buttons().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                modal_creature_buttons(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	modal_creature_buttons(t_modal_frame_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: modal_creature_finish — Finalise le traitement de modale creature
**       et son état de sortie.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: modal_creature_finish().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                modal_creature_finish(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	modal_creature_finish(t_modal_frame_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: modal_creature_render — Rend l’état associé à modale creature.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: modal_creature_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                modal_creature_render(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	modal_creature_render(t_modal_frame_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_frame — Traite une frame complète de application modale.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: content — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : w, ui, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_frame().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_frame(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_modal_frame(t_window *w, t_ui_state *ui, t_app *app,
	t_rect content);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_quit_confirm_lines — Construit ou traite les lignes appartenant
**       à application quit confirm.
** Paramètre: guard — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: msg — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_quit_confirm_lines().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_quit_confirm_lines(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_quit_confirm_lines(t_app_quit_guard guard,
	const char **msg);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_request_quit — Enregistre la demande de quit et met à jour les
**       états associés uniquement lorsque les
**       validations métier requises réussissent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_request_quit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_request_quit(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_request_quit(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_clear_hunt_csv — Réinitialise l’état du module en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_clear_hunt_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_clear_hunt_csv(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_clear_hunt_csv(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_clear_global_events_csv — Réinitialise l’état du module en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_clear_global_events_csv().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_clear_global_events_csv(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_clear_global_events_csv(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_process_result — Traite modale résultat en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_process_result().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_process_result(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_modal_process_result(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_prepare_leave — Prépare navigation leave à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: next — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_prepare_leave().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_prepare_leave(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_navigation_prepare_leave(t_app *app, t_page next);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_set_page — Met à jour navigation page à partir des
**       valeurs courantes et conserve l’état partagé cohérent pour la suite
**       de la frame ou du calcul.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: remember — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_set_page().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_set_page(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_navigation_set_page(t_window *w, t_app *app, t_page page,
	int remember);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_go_to — Convertit vers navigation go en appliquant
**       les validations, bornes et effets
**       explicitement définis par ce module.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_go_to().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_go_to(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_navigation_go_to(t_window *w, t_app *app, t_page page);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_go_back — Met à jour navigation go retour en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_go_back().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_go_back(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_navigation_go_back(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_activate — Met à jour navigation activate en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_activate().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_activate(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_navigation_activate(t_window *w, t_app *app, int index);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_item_height — Calcule la hauteur nécessaire à
**       application navigation objet.
** Paramètre: ly — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_item_height().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_item_height(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_item_height(const t_ui_layout *ly);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_navigation_group_render — Rend l’état associé à application
**       navigation group.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_navigation_group_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_navigation_group_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_navigation_group_render(
	const t_navigation_group_request *request);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sidebar_compact_items — Construit ou traite les objets appartenant
**       à sidebar compact.
** Paramètre: items — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: sidebar_compact_items().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sidebar_compact_items(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	sidebar_compact_items(const char **items);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_sidebar_navigation_compact — Met à jour barre latérale navigation
**       compact en appliquant explicitement les paramètres, bornes et
**       invariants décrits par le contrat de cette fonction.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_sidebar_navigation_compact().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_sidebar_navigation_compact(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_sidebar_navigation_compact(t_sidebar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sidebar_section_header — Construit ou rend l’en-tête utilisé par
**       sidebar section.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: label — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: color — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: sidebar_section_header().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sidebar_section_header(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	sidebar_section_header(t_sidebar_context *ctx,
	const char *label, unsigned int color);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sidebar_group — Construit ou rend le groupe logique de sidebar.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: items — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: selected — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: sidebar_group().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sidebar_group(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	sidebar_group(t_sidebar_context *ctx, const char **items,
	int count, int selected);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sidebar_finance_group — Construit ou rend le groupe logique de
**       sidebar finance.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sidebar_finance_group().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sidebar_finance_group(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	sidebar_finance_group(t_sidebar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sidebar_tracker_group — Construit ou rend le groupe logique de
**       sidebar Tracker.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sidebar_tracker_group().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sidebar_tracker_group(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	sidebar_tracker_group(t_sidebar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sidebar_application_group — Construit ou rend le groupe logique de
**       sidebar application.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sidebar_application_group().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sidebar_application_group(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	sidebar_application_group(t_sidebar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sidebar_system_group — Construit ou rend le groupe logique de
**       sidebar système.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sidebar_system_group().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sidebar_system_group(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	sidebar_system_group(t_sidebar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: sidebar_prepare — Prépare l’état associé à sidebar.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: sidebar_prepare().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                sidebar_prepare(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	sidebar_prepare(t_sidebar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_sidebar_navigation_render — Rend l’état associé à application
**       sidebar navigation.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: layout — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, ui, layout,
**         app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_sidebar_navigation_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_sidebar_navigation_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_sidebar_navigation_render(t_window *w, t_ui_state *ui,
	t_ui_layout *layout, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_spaces_primary — Calcule et renseigne les espacements
**       principaux de la barre supérieure en
**       fonction de la largeur disponible et des
**       éléments visibles.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx, state.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_spaces_primary().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_spaces_primary(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_spaces_primary(t_topbar_context *ctx,
	t_topbar_spaces *state);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_spaces_back — Calcule les espacements de barre supérieure
**       back et renseigne les positions utilisées par
**       la mise en page.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx, state.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_spaces_back().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_spaces_back(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_spaces_back(t_topbar_context *ctx,
	t_topbar_spaces *state);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_spaces_render — Rend l’état associé à topbar spaces.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_spaces_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_spaces_render(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_spaces_render(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_geometry_initialize — Initialise l’état associé à topbar
**       geometry.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_geometry_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_geometry_initialize(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_geometry_initialize(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_finance_crumb — Construit et affiche le fil d’Ariane Finance
**       de la barre supérieure à partir de la page et du sous-écran
**       actuellement actifs.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_finance_crumb().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_finance_crumb(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*topbar_finance_crumb(t_page page);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_application_crumb — Construit le fil d’Ariane correspondant à
**       barre supérieure application pour refléter précisément la navigation
**       active.
** Paramètre: page — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_application_crumb().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_application_crumb(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*topbar_application_crumb(t_page page);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_session_crumb — Construit le fil d’Ariane correspondant à
**       barre supérieure session pour refléter précisément la navigation
**       active.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_session_crumb().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_session_crumb(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	topbar_session_crumb(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_tracker_crumb — Construit le fil d’Ariane correspondant à
**       barre supérieure pour refléter précisément la navigation active.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_tracker_crumb().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_tracker_crumb(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	topbar_tracker_crumb(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_build_crumb — Construit le fil d’Ariane correspondant à barre
**       supérieure build pour refléter précisément la navigation active.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_build_crumb().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_build_crumb(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_build_crumb(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_draw_left_text — Dessine barre supérieure left texte dans le
**       contexte graphique courant en respectant la géométrie, le clipping
**       et l’état des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_draw_left_text().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_draw_left_text(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_draw_left_text(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_format_range_status — Retourne barre supérieure format plage
**       état dans la forme directement utilisable par le rendu ou
**       l’appelant.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: hunt_state — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: globals_state — objet source consulté en lecture seule par
**            cette fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_format_range_status().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_format_range_status(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_format_range_status(t_topbar_context *ctx,
	const char *hunt_state, const char *globals_state);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_format_current_status — Retourne barre supérieure format
**       courant état dans la forme directement utilisable par le rendu ou
**       l’appelant.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: hunt_state — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: globals_state — objet source consulté en lecture seule par
**            cette fonction.
** Paramètre: time_buffer — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_format_current_status().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_format_current_status(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_format_current_status(t_topbar_context *ctx,
	const char *hunt_state, const char *globals_state, const char *time_buffer);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_build_tracker_status — Retourne barre supérieure build état
**       dans la forme directement utilisable par le rendu ou l’appelant.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_build_tracker_status().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_build_tracker_status(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_build_tracker_status(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_center_color — Détermine la couleur utilisée par topbar
**       center.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type unsigned int; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_center_color().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_center_color(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
unsigned int	topbar_center_color(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_draw_center — Dessine barre supérieure center dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_draw_center().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_draw_center(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_draw_center(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_language_button — Gère le bouton et son interaction pour
**       topbar language.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_language_button().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_language_button(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_language_button(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_finance_reload — Recharge l’état associé à topbar finance.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: enabled — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_finance_reload().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_finance_reload(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_finance_reload(t_topbar_context *ctx, int enabled);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_finance_save — Sauvegarde l’état associé à topbar finance.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: enabled — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_finance_save().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_finance_save(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_finance_save(t_topbar_context *ctx, int enabled);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_finance_status — Détermine ou formate l’état courant de
**       topbar finance.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_finance_status().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_finance_status(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_finance_status(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_finance_actions — Gère les actions utilisateur ou métier de
**       topbar finance.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_finance_actions().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_finance_actions(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_finance_actions(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_tracker_loadout_action — Exécute l’action associée à topbar
**       arme.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les montants persistants restent en représentation entière
**             fixe, sans dépendre d’un prix supposé immuable.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_tracker_loadout_action().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_tracker_loadout_action(); résolution indirecte possible
**                pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_tracker_loadout_action(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_overlay_button_state — Consulte ou prépare l’état nécessaire
**       à topbar overlay bouton.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: label — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: style — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: width — identifiant stable servant à retrouver ou associer
**            l’élément.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx, style,
**         width.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_overlay_button_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_overlay_button_state(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_overlay_button_state(t_topbar_context *ctx,
	const char **label, int *style, int *width);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_overlay_action — Exécute l’action associée à topbar overlay.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_overlay_action().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_overlay_action(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_overlay_action(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_export_action — Exécute l’action associée à topbar export.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_export_action().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_export_action(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_export_action(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_toggle_hunt — Met à jour barre supérieure toggle en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: running — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_toggle_hunt().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_toggle_hunt(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_toggle_hunt(t_topbar_context *ctx, int running);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_toggle_globals — Met à jour barre supérieure toggle globals en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: running — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_toggle_globals().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_toggle_globals(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_toggle_globals(t_topbar_context *ctx, int running);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_run_button_state — Met à jour barre supérieure run bouton état
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx, state.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_run_button_state().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_run_button_state(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_run_button_state(t_topbar_context *ctx,
	t_topbar_action_state *state);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_run_action — Rend et met à jour barre supérieure run action en
**       utilisant le contexte UI courant et les interactions de cette frame.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_run_action().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_run_action(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_run_action(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: topbar_tracker_actions — Gère les actions utilisateur ou métier de
**       topbar Tracker.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: topbar_tracker_actions().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                topbar_tracker_actions(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	topbar_tracker_actions(t_topbar_context *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_navigation_button — Gère le bouton et son interaction
**       pour application modale navigation.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Retourne le résultat de type t_rect; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : w.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_navigation_button().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_navigation_button(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_rect	app_modal_navigation_button(t_window *w, int index);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_point_is_inside_rectangle — Détermine si point inside rectangle
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: rect — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : w.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_point_is_inside_rectangle().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_point_is_inside_rectangle(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_point_is_inside_rectangle(t_window *w, t_rect rect);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_navigation_handle_click — Traite modale navigation click en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_navigation_handle_click().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_navigation_handle_click(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_modal_navigation_handle_click(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_navigation_render — Rend l’état associé à application
**       modale navigation.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, ui, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_navigation_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_navigation_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_modal_navigation_render(t_window *w, t_ui_state *ui, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_page_frame_render — Rend l’état associé à application
**       modale page frame.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, ui, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_page_frame_render().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_page_frame_render(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_modal_page_frame_render(t_window *w, t_ui_state *ui, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_draw_top_bar — Dessine top bar dans le contexte graphique courant
**       en respectant la géométrie, le clipping et l’état des widgets
**       fournis.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: ui — état des widgets et du thème utilisé pendant cette frame.
** Paramètre: layout — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, ui, layout,
**         app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_draw_top_bar().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_draw_top_bar(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_draw_top_bar(t_window *w, t_ui_state *ui, t_ui_layout *layout,
	t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_initialize_base — Initialise runtime base à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_initialize_base().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_initialize_base(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_initialize_base(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_preflight — Met à jour runtime preflight en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: argc — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : runtime, argv.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_preflight().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_preflight(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	runtime_preflight(t_app_runtime *runtime, int argc, char **argv);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_load_hotkeys — Charge runtime raccourcis clavier depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_load_hotkeys().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_load_hotkeys(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_load_hotkeys(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_publish_hotkeys — Prépare ou applique les raccourcis
**       clavier de exécution publish.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_publish_hotkeys().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_publish_hotkeys(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_publish_hotkeys(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_initialize_window — Initialise runtime à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_initialize_window().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_initialize_window(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	runtime_initialize_window(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_navigation_keys — Met à jour runtime navigation touches en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_navigation_keys().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_navigation_keys(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_navigation_keys(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_footer — Met à jour runtime pied en appliquant explicitement
**       les paramètres, bornes et invariants décrits par le contrat de cette
**       fonction.
** Paramètre: runtime — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_footer().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_footer(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const char	*runtime_footer(const t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_prepare_chrome — Prépare runtime chrome à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_prepare_chrome().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_prepare_chrome(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_prepare_chrome(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_render_finance_page — Rend runtime page dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_render_finance_page().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_render_finance_page(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	runtime_render_finance_page(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_render_finance_detail — Rend runtime detail dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_render_finance_detail().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_render_finance_detail(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	runtime_render_finance_detail(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_render_tracker_page — Rend runtime page dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_render_tracker_page().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_render_tracker_page(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	runtime_render_tracker_page(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_render_utility_page — Rend runtime utility page dans le
**       contexte graphique courant en respectant la géométrie, le clipping
**       et l’état des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_render_utility_page().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_render_utility_page(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	runtime_render_utility_page(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_render_content — Rend runtime contenu dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_render_content().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_render_content(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_render_content(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_render_dialogs — Rend runtime dialogs dans le contexte
**       graphique courant en respectant la géométrie, le clipping et l’état
**       des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_render_dialogs().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_render_dialogs(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_render_dialogs(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_lock_inputs — Lit ou prépare les entrées de exécution lock.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_lock_inputs().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_lock_inputs(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_lock_inputs(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_render_standard_frame — Rend runtime standard frame dans le
**       contexte graphique courant en respectant la géométrie, le clipping
**       et l’état des widgets fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_render_standard_frame().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_render_standard_frame(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_render_standard_frame(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_render_ui — Rend runtime dans le contexte graphique courant
**       en respectant la géométrie, le clipping et l’état des widgets
**       fournis.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_render_ui().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_render_ui(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_render_ui(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_overlay_shortcuts — Met à jour runtime shortcuts en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_overlay_shortcuts().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_overlay_shortcuts(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_overlay_shortcuts(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_overlay_tick — Exécute un cycle l’état associé à exécution
**       overlay.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_overlay_tick().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_overlay_tick(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_overlay_tick(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_frame — Traite une frame complète de exécution.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_frame().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_frame(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_frame(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: runtime_shutdown — Arrête proprement exécution et libère ses
**       ressources.
** Paramètre: runtime — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : runtime.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: runtime_shutdown().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                runtime_shutdown(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	runtime_shutdown(t_app_runtime *runtime);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_swallow_inputs — Lit ou prépare les entrées de application
**       swallow.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_swallow_inputs().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_swallow_inputs(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_swallow_inputs(t_window *w);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_open_message_request — Enregistre la demande de modale open
**       message et ne modifie les écritures métier associées qu’après
**       validation complète des préconditions.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_open_message_request().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_open_message_request(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_modal_open_message_request(
	const t_app_modal_request *request);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_open_confirm_request — Enregistre la demande de modale open
**       confirmation et ne modifie les écritures métier associées qu’après
**       validation complète des préconditions.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_open_confirm_request().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_open_confirm_request(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_modal_open_confirm_request(
	const t_app_modal_request *request);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_creature_available — Met à jour creature available en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_creature_available().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_creature_available(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	app_creature_available(char *out, size_t outsz);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_modal_open_creature — Ouvre modale creature en appliquant les
**       transitions d’état et la gestion d’erreur nécessaires pour que la
**       ressource reste cohérente.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: action — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_modal_open_creature().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_modal_open_creature(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_modal_open_creature(t_window *w, t_app *app, int action);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_tracker_start_live — Démarre LIVE en appliquant les validations et
**       transformations propres à cette opération, puis laisse les données
**       concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_tracker_start_live().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_tracker_start_live(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_tracker_start_live(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_tracker_start_replay — Démarre REPLAY en appliquant les validations
**       et transformations propres à cette opération, puis laisse les
**       données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: app_tracker_start_replay().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_tracker_start_replay(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_tracker_start_replay(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_open_confirm_clear_hunt — Réinitialise open confirmation en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_open_confirm_clear_hunt().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_open_confirm_clear_hunt(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_open_confirm_clear_hunt(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: app_confirm_clear_global_events — Réinitialise confirmation en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: app_confirm_clear_global_events().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                app_confirm_clear_global_events(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	app_confirm_clear_global_events(t_window *w, t_app *app);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: main — Point d’entrée : initialise, exécute puis arrête proprement
**       le programme.
** Paramètre: argc — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: argv — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : argv.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: main(), main(), main(), main(), main(), main(), main(),
**                 main(), main(), main(), main(), main(), main(), main(),
**                 main(), main(), main(), main(), main(), main(), main(),
**                 main(), main(), main(), main(), main(), main(), main(),
**                 main(), main(), main(), main(), main(), main(), main(),
**                 main(), main(), main(), main(), main().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous main();
**                résolution indirecte possible pour callbacks et backends
**                plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	main(int argc, char **argv);

#endif
