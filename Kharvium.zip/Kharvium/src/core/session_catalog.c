/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_catalog.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "session_catalog_internal.h"
#include <stdlib.h>
#include <string.h>

/*
** Rôle: session_catalog_capacity — Calcule session catalogue capacité à
**       partir des entrées courantes en respectant les unités, bornes et
**       règles d’arrondi du module.
** Paramètre: maximum_items — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne une taille, un nombre d’éléments ou un indice calculé
**         par cette opération.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: sessions_list_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog.c -> session_catalog_capacity() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static size_t	session_catalog_capacity(size_t maximum_items)
{
	size_t	capacity;

	capacity = 256;
	if (maximum_items != 0)
		capacity = maximum_items;
	if (capacity > 2048)
		capacity = 2048;
	return (capacity);
}

/*
** Rôle: session_catalog_read — Lit l’état associé à session catalogue.
** Paramètre: load — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : load.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_catalog_parse_line().
** Appelants: sessions_list_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog.c -> session_catalog_read() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fgets().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	session_catalog_read(t_session_catalog_load *load)
{
	while (fgets(load->line, (int)sizeof(load->line), load->file))
	{
		if (!session_catalog_parse_line(load->line, &load->entry))
			continue ;
		load->ring[load->index] = load->entry;
		load->index = (load->index + 1) % load->capacity;
		if (load->count < load->capacity)
			load->count++;
	}
	return (load->count != 0);
}

/*
** Rôle: session_catalog_copy_result — Copie session catalogue résultat en
**       préservant la propriété des ressources, les compteurs et la
**       cohérence de la destination.
** Paramètre: load — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : load, output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: sessions_list_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog.c -> session_catalog_copy_result() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> calloc().
** Mémoire: opérations directes -> calloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	session_catalog_copy_result(t_session_catalog_load *load,
	t_sessions_list *output)
{
	output->items = (t_session_entry *)calloc(load->count,
			sizeof(*output->items));
	if (!output->items)
		return (0);
	output->count = load->count;
	load->start = 0;
	if (load->count == load->capacity)
		load->start = load->index;
	load->copy_index = 0;
	while (load->copy_index < load->count)
	{
		load->source_index = (load->start + load->copy_index) % load->capacity;
		output->items[load->copy_index] = load->ring[load->source_index];
		load->copy_index++;
	}
	return (1);
}

/*
** Rôle: sessions_list_load — Charge l’état associé à sessions liste.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: maximum_items — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; effectue
**         directement des E/S fichier ou une modification de chemin; peut
**         modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_catalog_capacity(),
**            session_catalog_copy_result(), session_catalog_read().
** Appelants: session_picker_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog.c -> sessions_list_load() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> calloc(), fclose(),
**              fopen(), free(), memset().
** Mémoire: opérations directes -> calloc(), free(); le transfert de
**          propriété reste défini par Retour/Effets et les contrats des
**          fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=5. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	sessions_list_load(const char *csv_path, size_t maximum_items,
	t_sessions_list *output)
{
	t_session_catalog_load	load;
	int					result;

	if (!output || !csv_path)
		return (-1);
	output->items = NULL;
	output->count = 0;
	memset(&load, 0, sizeof(load));
	load.file = fopen(csv_path, "rb");
	if (!load.file)
		return (-1);
	load.capacity = session_catalog_capacity(maximum_items);
	load.ring = (t_session_entry *)calloc(load.capacity, sizeof(*load.ring));
	if (!load.ring)
	{
		fclose(load.file);
		return (-1);
	}
	result = 0;
	if (session_catalog_read(&load)
		&& !session_catalog_copy_result(&load, output))
		result = -1;
	fclose(load.file);
	free(load.ring);
	return (result);
}

/*
** Rôle: sessions_list_free — Libère l’état associé à sessions liste.
** Paramètre: list — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : list.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_session_picker_close(), session_picker_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog.c -> sessions_list_free() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	sessions_list_free(t_sessions_list *list)
{
	if (!list)
		return ;
	free(list->items);
	list->items = NULL;
	list->count = 0;
}
