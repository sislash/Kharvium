/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_catalog_parse_fields.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "session_catalog_internal.h"

/*
** Rôle: session_catalog_parse_metrics — Analyse session catalogue metrics
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: fields — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: entry — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : fields, entry.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_catalog_parse_double(),
**            session_catalog_parse_long().
** Appelants: session_catalog_parse_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_parse_fields.c -> session_catalog_parse_metrics()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED, pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	session_catalog_parse_metrics(char **fields, int count,
	t_session_entry *entry)
{
	if (count > 3)
		session_catalog_parse_long(fields[3], &entry->kills);
	if (count > 4)
		session_catalog_parse_long(fields[4], &entry->shots);
	if (count > 5)
		session_catalog_parse_double(fields[5], &entry->loot_ped);
	if (count > 6)
		session_catalog_parse_double(fields[6], &entry->expense_ped);
	if (count > 7)
		session_catalog_parse_double(fields[7], &entry->net_ped);
	if (count > 8)
		session_catalog_parse_double(fields[8], &entry->return_pct);
}

/*
** Rôle: session_catalog_parse_offsets — Analyse session catalogue offsets
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: fields — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: entry — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : fields, entry.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_catalog_parse_long().
** Appelants: session_catalog_parse_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_parse_fields.c -> session_catalog_parse_offsets()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	session_catalog_parse_offsets(char **fields, int count,
	t_session_entry *entry)
{
	long	start_offset;
	long	end_offset;

	if (count <= 10)
		return ;
	if (!session_catalog_parse_long(fields[9], &start_offset)
		|| !session_catalog_parse_long(fields[10], &end_offset))
		return ;
	entry->start_offset = start_offset;
	entry->end_offset = end_offset;
	entry->has_offsets = 1;
}

/*
** Rôle: session_catalog_parse_creature — Analyse session catalogue creature
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: fields — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: entry — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : fields, entry.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_catalog_copy_string().
** Appelants: session_catalog_parse_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_parse_fields.c -> session_catalog_parse_creature()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	session_catalog_parse_creature(char **fields, int count,
	t_session_entry *entry)
{
	if (count <= 11)
		return ;
	session_catalog_copy_string(entry->mob, sizeof(entry->mob), fields[11]);
	entry->has_mob = (entry->mob[0] != '\0');
}
