/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core_combat_segment.c                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/core_combat_segment.h"

/*
** Rôle: core_combat_segment_reset — Réinitialise l’état associé à cœur
**       combat segment.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: core_combat_segment_take_on_kill(), core_session_reset().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_combat_segment.c -> core_combat_segment_reset() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	core_combat_segment_reset(t_core_combat_seg *s)
{
	if (!s)
		return ;
	s->shots = 0;
	s->hits = 0;
}

/*
** Rôle: core_combat_segment_on_shot — Met à jour combat segment on tir en
**       appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: is_hit — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: core_session_on_shot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_combat_segment.c -> core_combat_segment_on_shot() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	core_combat_segment_on_shot(t_core_combat_seg *s, int is_hit)
{
	if (!s)
		return ;
	s->shots++;
	if (is_hit)
		s->hits++;
}

/*
** Rôle: core_combat_segment_take_on_kill — Traite l’événement kill associé
**       à cœur combat segment take on.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: out_shots — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_hits — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s, out_shots,
**         out_hits.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_combat_segment_reset().
** Appelants: core_session_on_kill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_combat_segment.c -> core_combat_segment_take_on_kill() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	core_combat_segment_take_on_kill(t_core_combat_seg *s,
					long *out_shots,
					long *out_hits)
{
	if (out_shots)
		*out_shots = 0;
	if (out_hits)
		*out_hits = 0;
	if (!s)
		return ;
	if (out_shots)
		*out_shots = s->shots;
	if (out_hits)
		*out_hits = s->hits;
	core_combat_segment_reset(s);
}
