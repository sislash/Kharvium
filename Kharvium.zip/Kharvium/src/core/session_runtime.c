/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_runtime.c                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/31                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/session_runtime.h"

#include <stdio.h>

/*
** Rôle: session_load_offset — Calcule session load offset à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_stats_live_tick(), cache_refresh_options(),
**            snapshot_prepare_range(), stop_export_prepare(),
**            hunt_series_live_update_current(),
**            topbar_format_current_status() (+4; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime.c -> session_load_offset() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fscanf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fscanf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
long	session_load_offset(const char *path)
{
	FILE	*f;
	long	v;

	if (!path)
		return (0);
	f = fopen(path, "rb");
	if (!f)
		return (0);
	v = 0;
	fscanf(f, "%ld", &v);
	fclose(f);
	return (v);
}

/*
** Rôle: session_save_offset — Calcule session save offset à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: offset — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_action_set_offset_end(), stop_export_finish(),
**            hunt_export_show_success(),
**            hunt_tracker_action_set_offset_to_end(),
**            overlay_export_write().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime.c -> session_save_offset() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_save_offset(const char *path, long offset)
{
	FILE	*f;

	if (!path)
		return (-1);
	f = fopen(path, "wb");
	if (!f)
		return (-1);
	fprintf(f, "%ld", offset);
	fclose(f);
	return (0);
}
