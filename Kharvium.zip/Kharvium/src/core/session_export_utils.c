/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_export_utils.c                            +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "session_export_internal.h"

/*
** Rôle: session_export_copy_string — Copie session export string en
**       préservant la propriété des ressources, les compteurs et la
**       cohérence de la destination.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Paramètre: src — source consultée pour produire le résultat sans en
**            modifier la signification.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: format_row_timestamp(), scan_row_timestamp().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_utils.c -> session_export_copy_string() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	session_export_copy_string(char *dst, size_t size, const char *src)
{
	if (!dst || size == 0)
		return ;
	if (!src)
	{
		dst[0] = '\0';
		return ;
	}
	snprintf(dst, size, "%s", src);
}

/*
** Rôle: session_export_initialize_ranges — Initialise session export ranges à
**       partir des paramètres fournis et initialise tous les champs requis
**       avant qu’ils soient lus par une autre opération.
** Paramètre: range — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : range.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_extract_range_timestamps().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_utils.c -> session_export_initialize_ranges()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	session_export_initialize_ranges(t_session_range_info *range)
{
	if (!range)
		return ;
	range->start_timestamp[0] = '\0';
	range->end_timestamp[0] = '\0';
	if (range->start_offset < 0)
		range->start_offset = 0;
	if (range->end_offset >= 0 && range->end_offset < range->start_offset)
		range->end_offset = range->start_offset;
}
