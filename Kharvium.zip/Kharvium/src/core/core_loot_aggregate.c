/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core_loot_aggregate.c                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/core_loot_aggregate.h"

/*
** Rôle: core_loot_should_merge — Fusionne l’état associé à cœur loot
**       should.
** Paramètre: last_t — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: last_kill_id — identifiant stable servant à retrouver ou
**            associer l’élément.
** Paramètre: t — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: kill_id — identifiant stable servant à retrouver ou associer
**            l’élément.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_loot_merge(), test_loot_merge_rules().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_loot_aggregate.c -> core_loot_should_merge() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	core_loot_should_merge(time_t last_t,
				int64_t last_kill_id,
				time_t t,
				int64_t kill_id)
{
	if (t == 0)
		return (0);
	if (kill_id > 0)
		return (last_kill_id == kill_id);
	if (last_kill_id > 0)
		return (0);
	return (last_t == t);
}

/*
** Rôle: core_time_relative_seconds — Calcule et retourne temps relative
**       seconds à partir des paramètres fournis sans modifier les entrées
**       déclarées en lecture seule.
** Paramètre: t0 — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: t — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_push_hits(), hunt_series_push_kill(),
**            hunt_series_push_shots(), hunt_series_push_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_loot_aggregate.c -> core_time_relative_seconds() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	core_time_relative_seconds(time_t t0, time_t t)
{
	int	rel;

	if (!t0 || !t)
		return (0);
	rel = 0;
	if (t > t0)
		rel = (int)(t - t0);
	if (rel < 0)
		rel = 0;
	return (rel);
}
