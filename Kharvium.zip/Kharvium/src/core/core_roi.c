/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core_roi.c                                        +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/core_roi.h"

#include "common/money.h"
#include <limits.h>

/*
** Rôle: money_clamp_pos — Borne pos en appliquant les validations et
**       transformations propres à cette opération, puis laisse les données
**       concernées dans un état cohérent.
** Paramètre: a — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: b — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne un montant monétaire entier avec saturation explicite
**         des dépassements, compatible avec la précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les limites des entiers sont traitées explicitement avant
**             tout dépassement.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: core_money_add_clamped().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère core_roi.c
**        -> money_clamp_pos() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static t_money	money_clamp_pos(t_money a, t_money b)
{
	if (a > (t_money)INT64_MAX - b)
		return ((t_money)INT64_MAX);
	return (a + b);
}

/*
** Rôle: money_clamp_neg — Borne neg en appliquant les validations et
**       transformations propres à cette opération, puis laisse les données
**       concernées dans un état cohérent.
** Paramètre: a — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: b — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les limites des entiers sont traitées explicitement avant
**             tout dépassement.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: core_money_add_clamped().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère core_roi.c
**        -> money_clamp_neg() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static t_money	money_clamp_neg(t_money a, t_money b)
{
	if (a < (t_money)INT64_MIN - b)
		return ((t_money)INT64_MIN);
	return (a + b);
}

/*
** Rôle: core_money_add_clamped — Ajoute clamped dans la collection concernée
**       en respectant sa capacité, son ordre logique et la propriété de ses
**       éléments.
** Paramètre: a — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: b — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_clamp_neg(), money_clamp_pos().
** Appelants: core_session_add_expense(), core_session_add_loot(),
**            hunt_series_cost_add(), hunt_series_loot_prefix(),
**            hunt_series_loot_write(), hunt_series_metric_add() (+5; index
**            complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère core_roi.c
**        -> core_money_add_clamped() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_money	core_money_add_clamped(t_money a, t_money b)
{
	if (b > 0)
		return (money_clamp_pos(a, b));
	if (b < 0)
		return (money_clamp_neg(a, b));
	return (a);
}

/*
** Rôle: core_money_multiply_long_clamped — Calcule et retourne multiply long
**       clamped à partir des paramètres fournis sans modifier les entrées
**       déclarées en lecture seule.
** Paramètre: v — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Paramètre: n — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne un montant monétaire entier avec saturation explicite
**         des dépassements, compatible avec la précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les limites des entiers sont traitées explicitement avant
**             tout dépassement.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_cost_add(), hunt_series_roi_add(),
**            test_money_clamp().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère core_roi.c
**        -> core_money_multiply_long_clamped() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_money	core_money_multiply_long_clamped(t_money v, long n)
{
	int		sign;
	uint64_t	av;
	uint64_t	an;

	if (n <= 0 || v == 0)
		return (0);
	sign = 1;
	if (v < 0)
	{
		sign = -1;
		av = (uint64_t)(-v);
	}
	else
		av = (uint64_t)v;
	an = (uint64_t)n;
	if (an != 0 && av > (uint64_t)INT64_MAX / an)
	{
		if (sign > 0)
			return ((t_money)INT64_MAX);
		return ((t_money)INT64_MIN);
	}
	if (sign > 0)
		return ((t_money)(av * an));
	return ((t_money)-(int64_t)(av * an));
}

/*
** Rôle: core_cost_pick_maximum — Calcule coût pick maximum à partir de
**       l’état courant en respectant les unités,
**       bornes et conventions du module.
** Paramètre: logged_cost — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Paramètre: model_cost — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_cost_add(), hunt_series_roi_emit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère core_roi.c
**        -> core_cost_pick_maximum() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_money	core_cost_pick_maximum(t_money logged_cost, t_money model_cost)
{
	if (logged_cost > 0 && model_cost > 0)
	{
		if (logged_cost > model_cost)
			return (logged_cost);
		return (model_cost);
	}
	if (logged_cost > 0)
		return (logged_cost);
	return (model_cost);
}
