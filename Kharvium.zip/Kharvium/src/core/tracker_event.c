/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tracker_event.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/tracker_event.h"
#include <string.h>

/*
** Rôle: tracker_activity_type_name — Convertit un identifiant d'activité en
**       libellé stable utilisé par le journal Tracker V4.
** Paramètre: type — activité à convertir sans modification de l'appelant.
** Retour: pointeur vers une chaîne statique toujours valide.
** Effets: aucun.
** Invariants: toute valeur non reconnue produit "UNKNOWN".
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: tracker_event_csv_write(), tests du journal Tracker.
** Mémoire: aucune allocation/libération directe.
** Concurrence: fonction réentrante; uniquement chaînes constantes.
** I/O: aucune.
** Unités: aucune.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        tracker_event.c -> tracker_activity_type_name() (chemin complet dans
**        l’index).
** Dépendances: libc/stdio et API projet explicitement citées dans Relations.
** État partagé: aucun symbole global mutable référencé directement.
** Performance: coût local borné; aucune récursion ni collection non bornée
**            cachée.
** --- Fin des liens techniques auto-vérifiés ---
*/
const char	*tracker_activity_type_name(t_tracker_activity_type type)
{
	static const char	*names[] = {
		"UNKNOWN", "HUNTING", "FISHING", "MINING_PLANETSIDE",
		"MINING_SPACE", "CRAFTING", "COOKING", "HARVESTING",
		"SWEATING", "SERVICE", "TRANSPORT", "TRADING",
		"INVESTMENT", "OTHER"};

	if (type < TRACKER_ACTIVITY_TYPE_UNKNOWN
		|| type > TRACKER_ACTIVITY_TYPE_OTHER)
		return (names[0]);
	return (names[(int)type]);
}

/*
** Rôle: tracker_activity_type_parse — Recherche le type d'activité associé à
**       un libellé V4 exact et conserve UNKNOWN en cas d'ambiguïté.
** Paramètre: text — chaîne persistante consultée en lecture seule.
** Retour: valeur enum correspondante ou UNKNOWN.
** Effets: aucun.
** Invariants: aucune normalisation implicite ne transforme un texte libre en
**             activité métier.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> tracker_activity_type_name().
** Appelants: tracker_event_csv_parse_line().
** Dépendances: strcmp().
** Mémoire: aucune allocation/libération directe.
** Concurrence: fonction réentrante.
** I/O: aucune.
** Unités: aucune.
** Portabilité: C99 portable.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        tracker_event.c -> tracker_activity_type_parse() (chemin complet dans
**        l’index).
** État partagé: aucun symbole global mutable référencé directement.
** Performance: coût local borné; aucune récursion ni collection non bornée
**            cachée.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_tracker_activity_type	tracker_activity_type_parse(const char *text)
{
	int	index;

	if (!text || !text[0])
		return (TRACKER_ACTIVITY_TYPE_UNKNOWN);
	index = (int)TRACKER_ACTIVITY_TYPE_UNKNOWN;
	while (index <= (int)TRACKER_ACTIVITY_TYPE_OTHER)
	{
		if (strcmp(text, tracker_activity_type_name(
				(t_tracker_activity_type)index)) == 0)
			return ((t_tracker_activity_type)index);
		index++;
	}
	return (TRACKER_ACTIVITY_TYPE_UNKNOWN);
}
