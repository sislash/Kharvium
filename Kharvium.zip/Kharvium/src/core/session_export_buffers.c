/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_export_buffers.c                          +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "session_export_internal.h"
#include "common/money.h"

/*
** Rôle: format_offsets — Formate offsets.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: buffers — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : buffers.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_export_build_buffers().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_buffers.c -> format_offsets() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	format_offsets(const t_session_export_request *request,
		t_session_bufs *buffers)
{
	if (request->start_offset >= 0)
		snprintf(buffers->start_off, sizeof(buffers->start_off), "%ld",
			request->start_offset);
	else
		buffers->start_off[0] = '\0';
	if (request->end_offset >= 0)
		snprintf(buffers->end_off, sizeof(buffers->end_off), "%ld",
			request->end_offset);
	else
		buffers->end_off[0] = '\0';
}

/*
** Rôle: session_export_build_buffers — Construit session export buffers à
**       partir des paramètres fournis et initialise tous les champs requis
**       avant qu’ils soient lus par une autre opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: buffers — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : buffers.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> format_offsets(),
**            money_format_ped_4_decimals().
** Appelants: session_export_write().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_buffers.c -> session_export_build_buffers() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED, pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	session_export_build_buffers(const t_session_export_request *request,
		t_session_bufs *buffers)
{
	const t_hunt_stats	*stats;
	double			return_percentage;

	stats = request->stats;
	return_percentage = 0.0;
	if (stats->expense_used > 0)
		return_percentage = ((double)stats->loot_ped
				/ (double)stats->expense_used) * 100.0;
	snprintf(buffers->kills, sizeof(buffers->kills), "%ld", stats->kills);
	snprintf(buffers->shots, sizeof(buffers->shots), "%ld", stats->shots);
	money_format_ped_4_decimals(buffers->loot, sizeof(buffers->loot),
		stats->loot_ped);
	money_format_ped_4_decimals(buffers->exp, sizeof(buffers->exp),
		stats->expense_used);
	money_format_ped_4_decimals(buffers->net, sizeof(buffers->net),
		stats->net_ped);
	snprintf(buffers->ret, sizeof(buffers->ret), "%.2f", return_percentage);
	format_offsets(request, buffers);
}
