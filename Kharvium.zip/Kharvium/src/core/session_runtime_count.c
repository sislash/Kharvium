/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_runtime_count.c                           +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/session_runtime.h"
#include "io/csv_index.h"
#include "platform/file_system.h"

#include <limits.h>
#include <stdio.h>
#include <string.h>

/*
** Rôle: session_index_rows — Construit les lignes de données destinées à
**       session index.
** Paramètre: state — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_count_data_lines().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime_count.c -> session_index_rows() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static long	session_index_rows(const t_csv_index_state *state)
{
	if (state->data_rows > (unsigned long long)LONG_MAX)
		return (LONG_MAX);
	return ((long)state->data_rows);
}

/*
** Rôle: session_index_current — Lit session index courant depuis le fichier
**       ou flux prévu et propage les erreurs d’accès sans conserver d’état
**       partiellement valide.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: report — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : state, report.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_index_state_load().
** Appelants: session_count_data_lines().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime_count.c -> session_index_current() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	session_index_current(const char *path, long size,
	t_csv_index_state *state, t_csv_index_report *report)
{
	if (!csv_index_state_load(path, state, report))
		return (0);
	if (size >= 0 && (unsigned long long)size != state->bytes)
		return (0);
	return (1);
}

/*
** Rôle: session_count_lines_fallback — Compte session lignes fallback en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_count_data_lines().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime_count.c -> session_count_lines_fallback() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fgets(), fopen(),
**              strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static long	session_count_lines_fallback(const char *path)
{
	char	buffer[4096];
	int		first;
	FILE	*stream;
	long	lines;

	stream = fopen(path, "rb");
	if (!stream)
		return (0);
	lines = 0;
	first = 1;
	while (fgets(buffer, (int)sizeof(buffer), stream))
	{
		if (first && strstr(buffer, "timestamp")
			&& (strstr(buffer, "event_type") || strstr(buffer, ",type,")))
			first = 0;
		else
		{
			first = 0;
			lines++;
		}
	}
	fclose(stream);
	return (lines);
}

/*
** Rôle: session_count_data_lines — Compte session data lignes en appliquant
**       les validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_index_state_rebuild(),
**            csv_index_state_store(), file_system_file_size(),
**            session_count_lines_fallback(), session_index_current(),
**            session_index_rows().
** Appelants: hunt_stats_live_range_tick(), snapshot_prepare_range(),
**            app_action_set_offset_end(), stop_export_prepare(),
**            session_export_last_row(), hunt_series_live_resolve_end() (+3;
**            index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime_count.c -> session_count_data_lines() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
long	session_count_data_lines(const char *csv_path)
{
	t_csv_index_state	state;
	t_csv_index_report	report;
	long				size;

	if (!csv_path)
		return (0);
	size = file_system_file_size(csv_path);
	if (session_index_current(csv_path, size, &state, &report))
		return (session_index_rows(&state));
	if (csv_index_state_rebuild(csv_path, &state, &report))
	{
		(void)csv_index_state_store(csv_path, &state, NULL);
		return (session_index_rows(&state));
	}
	return (session_count_lines_fallback(csv_path));
}
