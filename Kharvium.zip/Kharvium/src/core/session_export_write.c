/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_export_write.c                            +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "session_export_internal.h"
#include "common/money.h"
#include "config/selected_creature.h"
#include "io/csv_format.h"
#include "platform/app_paths.h"

#include <string.h>

/*
** Rôle: ensure_sessions_header — Construit ou rend l’en-tête utilisé par
**       ensure sessions.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_export_write().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_write.c -> ensure_sessions_header() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fprintf(), fseek(),
**              ftell().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	ensure_sessions_header(FILE *file)
{
	long	position;

	fseek(file, 0, SEEK_END);
	position = ftell(file);
	if (position != 0)
		return ;
	fprintf(file, "session_start,session_end,weapon,kills,shots,");
	fprintf(file, "loot_ped,expense_ped,net_ped,return_pct,start_offset,");
	fprintf(file, "end_offset,mob\n");
}

/*
** Rôle: build_fields — Construit champs.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: row — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : row.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_export_write().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_write.c -> build_fields() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	build_fields(const t_session_export_request *request,
		t_session_export_row *row)
{
	const char	*weapon;

	weapon = "";
	if (request->stats->weapon_name[0] != '\0')
		weapon = request->stats->weapon_name;
	row->fields[0] = request->session_start_ts;
	row->fields[1] = request->session_end_ts;
	row->fields[2] = weapon;
	row->fields[3] = row->buffers.kills;
	row->fields[4] = row->buffers.shots;
	row->fields[5] = row->buffers.loot;
	row->fields[6] = row->buffers.exp;
	row->fields[7] = row->buffers.net;
	row->fields[8] = row->buffers.ret;
	row->fields[9] = row->buffers.start_off;
	row->fields[10] = row->buffers.end_off;
	row->fields[11] = row->creature;
}

/*
** Rôle: write_fields — Écrit champs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: fields — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : file.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_write_field().
** Appelants: session_export_write().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_write.c -> write_fields() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fputc().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	write_fields(FILE *file, const char **fields)
{
	int	index;

	index = 0;
	while (index < 12)
	{
		csv_write_field(file, fields[index]);
		if (index < 11)
			fputc(',', file);
		else
			fputc('\n', file);
		index++;
	}
}

/*
** Rôle: session_export_write — Écrit l’état associé à session export.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_path_selected_creature(),
**            build_fields(), ensure_sessions_header(),
**            selected_creature_load(), selected_creature_sanitize(),
**            session_export_build_buffers(), write_fields().
** Appelants: session_export_stats_csv(),
**            session_export_stats_csv_with_offsets().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_write.c -> session_export_write() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=7; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_export_write(const t_session_export_request *request)
{
	FILE			*file;
	t_session_export_row	row;

	if (!request || !request->out_csv_path || !request->stats)
		return (0);
	file = fopen(request->out_csv_path, "ab");
	if (!file)
		return (0);
	memset(&row, 0, sizeof(row));
	session_export_build_buffers(request, &row.buffers);
	selected_creature_load(app_path_selected_creature(), row.creature,
		sizeof(row.creature));
	selected_creature_sanitize(row.creature);
	build_fields(request, &row);
	ensure_sessions_header(file);
	write_fields(file, row.fields);
	fclose(file);
	return (1);
}
