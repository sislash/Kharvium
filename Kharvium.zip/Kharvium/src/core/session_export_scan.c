/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_export_scan.c                             +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "session_export_internal.h"
#include "io/csv_index.h"
#include "io/hunt_csv.h"

#include <limits.h>
#include <string.h>

/*
** Rôle: seek_to_data_row — Construit ou traite une ligne appartenant à seek
**       to données.
** Paramètre: scan — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: target_row — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Paramètre: data_index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : data_index.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_index_lookup_row_offset().
** Appelants: session_export_scan_first(), session_export_scan_last().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_scan.c -> seek_to_data_row() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fseek(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	seek_to_data_row(const t_session_scan *scan, long target_row,
		long *data_index)
{
	t_csv_index_checkpoint	checkpoint;
	t_csv_index_row_query	query;

	memset(&checkpoint, 0, sizeof(checkpoint));
	*data_index = 0;
	if (target_row <= 0)
		return (fseek(scan->f, 0, SEEK_SET) == 0);
	query.csv_path = scan->csv_path;
	query.row_index = (unsigned long long)target_row;
	if (!csv_index_lookup_row_offset(&query, &checkpoint, NULL))
		return (fseek(scan->f, 0, SEEK_SET) == 0);
	if (checkpoint.byte_offset > (unsigned long long)LONG_MAX)
		return (fseek(scan->f, 0, SEEK_SET) == 0);
	if (fseek(scan->f, (long)checkpoint.byte_offset, SEEK_SET) != 0)
		return (fseek(scan->f, 0, SEEK_SET) == 0);
	*data_index = (long)checkpoint.row_index;
	return (1);
}

/*
** Rôle: format_row_timestamp — Formate ligne horodatage.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_size — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : line, out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_format_local_timestamp(),
**            hunt_csv_parse_row_inplace(), session_export_copy_string().
** Appelants: scan_row_timestamp().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_scan.c -> format_row_timestamp() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	format_row_timestamp(char *line, char *out, size_t out_size)
{
	t_hunt_csv_row_view	row;
	char			timestamp[64];

	if (!hunt_csv_parse_row_inplace(line, &row) || row.timestamp_unix <= 0)
		return (0);
	hunt_csv_format_local_timestamp(timestamp, sizeof(timestamp),
		row.timestamp_unix);
	if (timestamp[0] == '\0')
		snprintf(timestamp, sizeof(timestamp), "%lld",
			(long long)row.timestamp_unix);
	session_export_copy_string(out, out_size, timestamp);
	return (1);
}

/*
** Rôle: scan_row_timestamp — Calcule et retourne scan ligne timestamp à
**       partir des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: scan — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: state — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : state.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> format_row_timestamp(),
**            hunt_csv_line_is_header(), session_export_copy_string().
** Appelants: session_export_scan_first(), session_export_scan_last().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_scan.c -> scan_row_timestamp() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	scan_row_timestamp(const t_session_scan *scan,
		t_session_scan_state *state)
{
	if (state->first_line && hunt_csv_line_is_header(state->line))
	{
		state->first_line = 0;
		return (0);
	}
	state->first_line = 0;
	if (state->data_index < scan->start_row)
	{
		state->data_index++;
		return (0);
	}
	if (scan->last_row >= 0 && state->data_index > scan->last_row)
		return (-1);
	session_export_copy_string(state->work, sizeof(state->work), state->line);
	state->data_index++;
	return (format_row_timestamp(state->work, scan->out, scan->out_size));
}

/*
** Rôle: session_export_scan_first — Exporte session scan first vers la
**       destination prévue en respectant le
**       format, les bornes et la politique
**       d’erreur du module.
** Paramètre: scan — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> scan_row_timestamp(),
**            seek_to_data_row().
** Appelants: session_extract_range_timestamps().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_scan.c -> session_export_scan_first() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fgets(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_export_scan_first(const t_session_scan *scan)
{
	t_session_scan_state	state;
	int			result;

	memset(&state, 0, sizeof(state));
	state.first_line = 1;
	if (!seek_to_data_row(scan, scan->start_row, &state.data_index))
		return (0);
	while (fgets(state.line, sizeof(state.line), scan->f))
	{
		result = scan_row_timestamp(scan, &state);
		if (result != 0)
			return (result > 0);
	}
	return (0);
}

/*
** Rôle: session_export_scan_last — Exporte session scan last vers la
**       destination prévue en respectant le
**       format, les bornes et la politique
**       d’erreur du module.
** Paramètre: scan — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> scan_row_timestamp(),
**            seek_to_data_row().
** Appelants: session_extract_range_timestamps().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export_scan.c -> session_export_scan_last() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fgets(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_export_scan_last(const t_session_scan *scan)
{
	t_session_scan_state	state;
	int			result;
	int			found;

	memset(&state, 0, sizeof(state));
	state.first_line = 1;
	found = 0;
	if (!seek_to_data_row(scan, scan->last_row, &state.data_index))
		return (0);
	while (fgets(state.line, sizeof(state.line), scan->f))
	{
		result = scan_row_timestamp(scan, &state);
		if (result < 0)
			break ;
		if (result > 0)
			found = 1;
	}
	return (found);
}
