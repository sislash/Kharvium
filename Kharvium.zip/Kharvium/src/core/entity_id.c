/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   entity_id.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/entity_id.h"

/*
** Rôle: entity_id_is_valid — Vérifie la convention globale des identifiants
**       canoniques sans dépendre du type d'entité référencé.
** Paramètre: id — identifiant à contrôler.
** Retour: Retourne 1 pour une valeur positive, 0 pour UNKNOWN ou invalide.
** Effets: aucun.
** Invariants: zéro reste l'unique valeur UNKNOWN commune aux catalogues.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: catalog_registry_add_item(), catalog_registry_add_world().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        entity_id.c -> entity_id_is_valid().
** Dépendances: aucune.
** Mémoire: aucune allocation/libération.
** État partagé: aucun.
** Concurrence: fonction pure et réentrante.
** I/O: aucune.
** Unités: identifiant entier.
** Performance: O(1).
** Portabilité: C99 portable.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	entity_id_is_valid(t_entity_id id)
{
	return (id > ENTITY_ID_UNKNOWN);
}
