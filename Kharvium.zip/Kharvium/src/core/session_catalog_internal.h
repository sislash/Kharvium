/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_catalog_internal.h                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SESSION_CATALOG_INTERNAL_H
# define SESSION_CATALOG_INTERNAL_H

# include "core/session_catalog.h"
# include <stdio.h>

typedef struct s_session_catalog_load
{
	FILE			*file;
	char			line[2048];
	t_session_entry	entry;
	t_session_entry	*ring;
	size_t		capacity;
	size_t		count;
	size_t		index;
	size_t		start;
	size_t		copy_index;
	size_t		source_index;
}   t_session_catalog_load;

typedef struct s_session_label_format
{
	char		*output;
	size_t		capacity;
	const char	*start;
	const char	*end;
}   t_session_label_format;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_catalog_copy_string — Copie session catalogue string en
**       préservant la propriété des ressources, les compteurs et la
**       cohérence de la destination.
** Paramètre: destination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Paramètre: source — source consultée pour produire le résultat sans en
**            modifier la signification.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : destination.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_catalog_copy_string().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_catalog_copy_string(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	session_catalog_copy_string(char *destination, size_t capacity,
			const char *source);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_catalog_parse_long — Analyse session catalogue long depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: value — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : value.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_catalog_parse_long().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_catalog_parse_long(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		session_catalog_parse_long(const char *text, long *value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_catalog_parse_double — Analyse session catalogue double
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: value — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : value.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_catalog_parse_double().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_catalog_parse_double(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		session_catalog_parse_double(const char *text, double *value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_catalog_parse_metrics — Analyse session catalogue metrics
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: fields — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: entry — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : fields, entry.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: session_catalog_parse_metrics().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_catalog_parse_metrics(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	session_catalog_parse_metrics(char **fields, int count,
			t_session_entry *entry);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_catalog_parse_offsets — Analyse session catalogue offsets
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: fields — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: entry — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : fields, entry.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_catalog_parse_offsets().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_catalog_parse_offsets(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	session_catalog_parse_offsets(char **fields, int count,
			t_session_entry *entry);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_catalog_parse_creature — Analyse session catalogue creature
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: fields — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: entry — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : fields, entry.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: session_catalog_parse_creature().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_catalog_parse_creature(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	session_catalog_parse_creature(char **fields, int count,
			t_session_entry *entry);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_catalog_parse_line — Analyse session catalogue ligne depuis
**       la source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: entry — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : entry.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_catalog_parse_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_catalog_parse_line(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int		session_catalog_parse_line(const char *line, t_session_entry *entry);

#endif
