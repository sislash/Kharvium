/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_runtime_range.c                           +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/session_runtime.h"

#include <stdio.h>

/*
** Rôle: session_range_normalize — Normalise les données de session plage
**       vers leur forme canonique.
** Paramètre: start — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: end — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : start, end.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_load_range(), session_save_range().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime_range.c -> session_range_normalize() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	session_range_normalize(long *start, long *end)
{
	if (*start < 0)
		*start = 0;
	if (*end >= 0 && *end < *start)
		*end = *start;
}

/*
** Rôle: session_load_range — Calcule session load plage à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: out_start — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: out_end — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants :
**         out_start, out_end.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_range_normalize().
** Appelants: hunt_stats_live_range_active(), hunt_series_live_tick().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime_range.c -> session_load_range() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fscanf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fscanf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_load_range(const char *path, long *out_start, long *out_end)
{
	FILE	*stream;
	long	start;
	long	end;

	if (out_start)
		*out_start = 0;
	if (out_end)
		*out_end = -1;
	if (!path || !out_start || !out_end)
		return (0);
	stream = fopen(path, "rb");
	if (!stream)
		return (0);
	start = 0;
	end = -1;
	if (fscanf(stream, "%ld %ld", &start, &end) < 1)
	{
		fclose(stream);
		return (0);
	}
	fclose(stream);
	session_range_normalize(&start, &end);
	*out_start = start;
	*out_end = end;
	return (1);
}

/*
** Rôle: session_save_range — Calcule session save plage à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: start — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: end — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_range_normalize().
** Appelants: app_session_picker_apply_range().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime_range.c -> session_save_range() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_save_range(const char *path, long start, long end)
{
	FILE	*stream;

	if (!path)
		return (-1);
	session_range_normalize(&start, &end);
	stream = fopen(path, "wb");
	if (!stream)
		return (-1);
	fprintf(stream, "%ld %ld\n", start, end);
	fclose(stream);
	return (0);
}

/*
** Rôle: session_clear_range — Calcule session clear plage à partir de la
**       géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_action_set_offset_end(), stop_export_prepare(),
**            sessions_page_buttons_render(), hunt_live_chart_live_button().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_runtime_range.c -> session_clear_range() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> remove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> remove().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_clear_range(const char *path)
{
	if (!path)
		return (-1);
	remove(path);
	return (0);
}
