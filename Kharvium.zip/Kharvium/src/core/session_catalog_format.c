/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_catalog_format.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "session_catalog_internal.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: session_catalog_format_offsets — Formate session catalogue offsets
**       dans le buffer ou la représentation demandée sans dépasser la
**       capacité fournie par l’appelant.
** Paramètre: entry — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: format — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: sessions_format_label().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_format.c -> session_catalog_format_offsets()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	session_catalog_format_offsets(const t_session_entry *entry,
	const t_session_label_format *format)
{
	if (entry->has_mob)
		snprintf(format->output, format->capacity,
			"%s -> %s | %s | Mob:%s | K:%ld Loot:%.2f (off %ld..%ld)",
			format->start, format->end, entry->weapon, entry->mob, entry->kills,
			entry->loot_ped, entry->start_offset, entry->end_offset);
	else
		snprintf(format->output, format->capacity,
			"%s -> %s | %s | K:%ld Loot:%.2f (off %ld..%ld)",
			format->start, format->end, entry->weapon, entry->kills,
			entry->loot_ped, entry->start_offset, entry->end_offset);
}

/*
** Rôle: session_catalog_format_without_offsets — Formate session catalogue
**       without offsets dans le buffer ou la représentation demandée sans
**       dépasser la capacité fournie par l’appelant.
** Paramètre: entry — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: format — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: sessions_format_label().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_format.c ->
**        session_catalog_format_without_offsets() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: PED.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	session_catalog_format_without_offsets(
	const t_session_entry *entry, const t_session_label_format *format)
{
	if (entry->has_mob)
		snprintf(format->output, format->capacity,
			"%s -> %s | %s | Mob:%s | K:%ld Loot:%.2f (no offsets)",
			format->start, format->end, entry->weapon, entry->mob, entry->kills,
			entry->loot_ped);
	else
		snprintf(format->output, format->capacity,
			"%s -> %s | %s | K:%ld Loot:%.2f (no offsets)",
			format->start, format->end, entry->weapon, entry->kills,
			entry->loot_ped);
}

/*
** Rôle: sessions_format_label — Retourne sessions format libellé dans la
**       forme directement utilisable par le rendu ou l’appelant.
** Paramètre: entry — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_catalog_copy_string(),
**            session_catalog_format_offsets(),
**            session_catalog_format_without_offsets().
** Appelants: session_picker_build_items().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_format.c -> sessions_format_label() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	sessions_format_label(const t_session_entry *entry, char *output,
	size_t capacity)
{
	char				start[32];
	char				end[32];
	t_session_label_format	format;

	if (!output || capacity == 0)
		return (0);
	if (!entry)
	{
		output[0] = '\0';
		return (0);
	}
	session_catalog_copy_string(start, sizeof(start), entry->start_ts);
	session_catalog_copy_string(end, sizeof(end), entry->end_ts);
	if (strlen(start) > 19)
		start[19] = '\0';
	if (strlen(end) > 19)
		end[19] = '\0';
	format = (t_session_label_format){output, capacity, start, end};
	if (entry->has_offsets)
		session_catalog_format_offsets(entry, &format);
	else
		session_catalog_format_without_offsets(entry, &format);
	return (1);
}
