/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core_roi_percent.c                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/core_roi.h"

#include "common/money.h"
/*
** Rôle: core_roi_percent — Calcule et retourne roi mode pourcentage à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Paramètre: loot_uPED — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Paramètre: cost_uPED — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_roi_emit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_roi_percent.c -> core_roi_percent() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
double	core_roi_percent(t_money loot_uPED, t_money cost_uPED)
{
	if (cost_uPED <= 0)
		return (0.0);
	return (((double)loot_uPED * 100.0) / (double)cost_uPED);
}
