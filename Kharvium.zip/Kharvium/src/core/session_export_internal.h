/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_export_internal.h                         +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SESSION_EXPORT_INTERNAL_H
# define SESSION_EXPORT_INTERNAL_H

# include <stdio.h>
# include "core/session_export.h"

typedef struct s_session_export_request
{
	const char		*out_csv_path;
	const t_hunt_stats	*stats;
	const char		*session_start_ts;
	const char		*session_end_ts;
	long			start_offset;
	long			end_offset;
}t_session_export_request;

typedef struct s_session_bufs
{
	char	kills[64];
	char	shots[64];
	char	loot[64];
	char	exp[64];
	char	net[64];
	char	ret[64];
	char	start_off[64];
	char	end_off[64];
}t_session_bufs;

typedef struct s_session_scan_state
{
	char	line[1024];
	char	work[1024];
	long	data_index;
	int		first_line;
}t_session_scan_state;

typedef struct s_session_export_row
{
	t_session_bufs	buffers;
	const char	*fields[12];
	char		creature[128];
}t_session_export_row;

typedef struct s_session_scan
{
	FILE		*f;
	const char	*csv_path;
	long		start_row;
	long		last_row;
	char		*out;
	size_t		out_size;
}t_session_scan;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_export_copy_string — Copie session export string en
**       préservant la propriété des ressources, les compteurs et la
**       cohérence de la destination.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Paramètre: src — source consultée pour produire le résultat sans en
**            modifier la signification.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_export_copy_string().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_export_copy_string(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	session_export_copy_string(char *dst, size_t size, const char *src);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_export_initialize_ranges — Initialise session export ranges à
**       partir des paramètres fournis et initialise tous les champs requis
**       avant qu’ils soient lus par une autre opération.
** Paramètre: range — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : range.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_export_initialize_ranges().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_export_initialize_ranges(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	session_export_initialize_ranges(t_session_range_info *range);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_export_scan_first — Exporte session scan first vers la
**       destination prévue en respectant le
**       format, les bornes et la politique
**       d’erreur du module.
** Paramètre: scan — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_export_scan_first().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_export_scan_first(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	session_export_scan_first(const t_session_scan *scan);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_export_scan_last — Exporte session scan last vers la
**       destination prévue en respectant le
**       format, les bornes et la politique
**       d’erreur du module.
** Paramètre: scan — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_export_scan_last().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_export_scan_last(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	session_export_scan_last(const t_session_scan *scan);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_export_build_buffers — Construit session export buffers à
**       partir des paramètres fournis et initialise tous les champs requis
**       avant qu’ils soient lus par une autre opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: buffers — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : buffers.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: session_export_build_buffers().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_export_build_buffers(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	session_export_build_buffers(const t_session_export_request *request,
		t_session_bufs *buffers);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: session_export_write — Écrit l’état associé à session export.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: session_export_write().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                session_export_write(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	session_export_write(const t_session_export_request *request);

#endif
