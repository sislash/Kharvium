/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_catalog_parse.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "session_catalog_internal.h"
#include "common/string_operations.h"
#include "io/csv_format.h"
#include <stdlib.h>
#include <string.h>

/*
** Rôle: session_catalog_clear_entry — Réinitialise session catalogue entrée
**       en appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: entry — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : entry.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_catalog_parse_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_parse.c -> session_catalog_clear_entry() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	session_catalog_clear_entry(t_session_entry *entry)
{
	if (!entry)
		return ;
	memset(entry, 0, sizeof(*entry));
	entry->end_offset = -1;
}

/*
** Rôle: session_catalog_copy_string — Copie session catalogue string en
**       préservant la propriété des ressources, les compteurs et la
**       cohérence de la destination.
** Paramètre: destination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Paramètre: source — source consultée pour produire le résultat sans en
**            modifier la signification.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : destination.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_copy_safe().
** Appelants: sessions_format_label(), session_catalog_parse_line(),
**            session_catalog_parse_creature().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_parse.c -> session_catalog_copy_string() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	session_catalog_copy_string(char *destination, size_t capacity,
	const char *source)
{
	if (!destination || capacity == 0)
		return ;
	if (!source)
	{
		destination[0] = '\0';
		return ;
	}
	string_copy_safe(destination, capacity, source);
}

/*
** Rôle: session_catalog_parse_long — Analyse session catalogue long depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: value — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : value.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_catalog_parse_metrics(),
**            session_catalog_parse_offsets().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_parse.c -> session_catalog_parse_long() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strtol().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_catalog_parse_long(const char *text, long *value)
{
	char	*end;

	if (value)
		*value = 0;
	if (!text || !*text || !value)
		return (0);
	end = NULL;
	*value = strtol(text, &end, 10);
	return (end != text);
}

/*
** Rôle: session_catalog_parse_double — Analyse session catalogue double
**       depuis la source fournie, contrôle le format utile et ne renseigne
**       la destination qu’avec des données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: value — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : value.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: session_catalog_parse_metrics().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_parse.c -> session_catalog_parse_double() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strtod().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_catalog_parse_double(const char *text, double *value)
{
	char	*end;

	if (value)
		*value = 0.0;
	if (!text || !*text || !value)
		return (0);
	end = NULL;
	*value = strtod(text, &end);
	return (end != text);
}

/*
** Rôle: session_catalog_parse_line — Analyse session catalogue ligne depuis
**       la source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: entry — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : entry.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_split_fields(),
**            session_catalog_clear_entry(), session_catalog_copy_string(),
**            session_catalog_parse_creature(),
**            session_catalog_parse_metrics(),
**            session_catalog_parse_offsets().
** Appelants: session_catalog_read().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_catalog_parse.c -> session_catalog_parse_line() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_catalog_parse_line(const char *line, t_session_entry *entry)
{
	char	buffer[1024];
	char	*fields[16];
	int		field_count;

	if (!line || !entry)
		return (0);
	if (strstr(line, "session_start") && strstr(line, "session_end"))
		return (0);
	session_catalog_copy_string(buffer, sizeof(buffer), line);
	field_count = csv_split_fields(buffer, fields, 16);
	if (field_count < 2)
		return (0);
	session_catalog_clear_entry(entry);
	session_catalog_copy_string(entry->start_ts, sizeof(entry->start_ts),
		fields[0]);
	session_catalog_copy_string(entry->end_ts, sizeof(entry->end_ts),
		fields[1]);
	if (field_count > 2)
		session_catalog_copy_string(entry->weapon, sizeof(entry->weapon),
			fields[2]);
	session_catalog_parse_metrics(fields, field_count, entry);
	session_catalog_parse_offsets(fields, field_count, entry);
	session_catalog_parse_creature(fields, field_count, entry);
	return (1);
}
