/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core_session.c                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core/core_session.h"

#include "core/core_roi.h"
#include "common/money.h"

/*
** Rôle: core_session_reset — Réinitialise l’état associé à cœur session.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_combat_segment_reset().
** Appelants: hunt_series_clear_all(), test_combat_segment().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_session.c -> core_session_reset() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	core_session_reset(t_core_session *s)
{
	if (!s)
		return ;
	s->shots_total = 0;
	s->hits_total = 0;
	s->kills_total = 0;
	s->loot_total_uPED = 0;
	s->expense_total_uPED = 0;
	core_combat_segment_reset(&s->combat_seg);
}

/*
** Rôle: core_session_on_shot — Met à jour session on tir en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: is_hit — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_combat_segment_on_shot().
** Appelants: hunt_series_process_shot(), test_combat_segment().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_session.c -> core_session_on_shot() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	core_session_on_shot(t_core_session *s, int is_hit)
{
	if (!s)
		return ;
	s->shots_total++;
	s->hits_total += (is_hit != 0);
	core_combat_segment_on_shot(&s->combat_seg, is_hit);
}

/*
** Rôle: core_session_on_kill — Traite l’événement kill associé à cœur
**       session on.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: out_seg_shots — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: out_seg_hits — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s,
**         out_seg_shots, out_seg_hits.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_combat_segment_take_on_kill().
** Appelants: hunt_series_process_kill(), test_combat_segment().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_session.c -> core_session_on_kill() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	core_session_on_kill(t_core_session *s,
					long *out_seg_shots,
					long *out_seg_hits)
{
	if (!s)
	{
		if (out_seg_shots)
			*out_seg_shots = 0;
		if (out_seg_hits)
			*out_seg_hits = 0;
		return ;
	}
	s->kills_total++;
	core_combat_segment_take_on_kill(&s->combat_seg, out_seg_shots,
		out_seg_hits);
}

/*
** Rôle: core_session_add_loot — Ajoute session loot dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: v_uPED — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_money_add_clamped().
** Appelants: hunt_series_process_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_session.c -> core_session_add_loot() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	core_session_add_loot(t_core_session *s, t_money v_uPED)
{
	if (!s)
		return ;
	s->loot_total_uPED = core_money_add_clamped(s->loot_total_uPED, v_uPED);
}

/*
** Rôle: core_session_add_expense — Ajoute session expense dans la collection
**       concernée en respectant sa capacité, son ordre logique et la
**       propriété de ses éléments.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: v_uPED — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_money_add_clamped().
** Appelants: hunt_series_process_expense().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        core_session.c -> core_session_add_expense() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	core_session_add_expense(t_core_session *s, t_money v_uPED)
{
	if (!s)
		return ;
	s->expense_total_uPED = core_money_add_clamped(s->expense_total_uPED,
		v_uPED);
}
