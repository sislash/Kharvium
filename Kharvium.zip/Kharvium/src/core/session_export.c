/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   session_export.c                                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/31                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#define _CRT_SECURE_NO_WARNINGS

#include "session_export_internal.h"
#include "core/session_runtime.h"
#include "platform/file_system.h"

#include <string.h>

/*
** Rôle: session_export_last_row — Construit ou traite une ligne appartenant
**       à session export last.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: range — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_count_data_lines().
** Appelants: session_extract_range_timestamps().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export.c -> session_export_last_row() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static long	session_export_last_row(const char *path,
		const t_session_range_info *range)
{
	long	count;

	if (range->end_offset >= 0)
		return (range->end_offset - 1);
	count = session_count_data_lines(path);
	if (count <= 0)
		return (-1);
	return (count - 1);
}

/*
** Rôle: session_extract_range_timestamps — Calcule session extract plage
**       timestamps à partir de l’état
**       courant en respectant les
**       unités, bornes et conventions du
**       module.
** Paramètre: hunt_csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: range — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : range.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_open_shared_read(),
**            session_export_initialize_ranges(), session_export_last_row(),
**            session_export_scan_first(), session_export_scan_last().
** Appelants: snapshot_prepare_range(), stop_export_write(),
**            session_extract_timestamps_from_offset(),
**            hunt_export_compute(), overlay_export_write().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export.c -> session_extract_range_timestamps() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose().
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_extract_range_timestamps(const char *hunt_csv_path,
		t_session_range_info *range)
{
	t_session_scan	scan;

	if (!hunt_csv_path || !range)
		return (0);
	session_export_initialize_ranges(range);
	memset(&scan, 0, sizeof(scan));
	scan.last_row = session_export_last_row(hunt_csv_path, range);
	if (scan.last_row < range->start_offset)
		return (1);
	scan.f = file_system_open_shared_read(hunt_csv_path);
	if (!scan.f)
		return (0);
	scan.csv_path = hunt_csv_path;
	scan.start_row = range->start_offset;
	scan.out = range->start_timestamp;
	scan.out_size = sizeof(range->start_timestamp);
	session_export_scan_first(&scan);
	scan.out = range->end_timestamp;
	scan.out_size = sizeof(range->end_timestamp);
	session_export_scan_last(&scan);
	fclose(scan.f);
	return (1);
}

/*
** Rôle: session_extract_timestamps_from_offset — Construit à partir de
**       session extract timestamps
**       offset en appliquant les
**       validations, bornes et
**       effets explicitement
**       définis par ce module.
** Paramètre: hunt_csv_path — chemin du fichier ou répertoire ciblé par
**            l’opération.
** Paramètre: range — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : range.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_extract_range_timestamps().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export.c -> session_extract_timestamps_from_offset()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_extract_timestamps_from_offset(const char *hunt_csv_path,
		t_session_range_info *range)
{
	if (!range)
		return (0);
	range->end_offset = -1;
	return (session_extract_range_timestamps(hunt_csv_path, range));
}

/*
** Rôle: session_export_stats_csv_with_offsets — Exporte session with
**       offsets vers la destination
**       prévue en respectant le
**       format, les bornes et la
**       politique d’erreur du
**       module.
** Paramètre: out_csv_path — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: stats — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: range — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_export_write().
** Appelants: app_export_snapshot(), stop_export_write(),
**            hunt_export_show_success(), overlay_export_write().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export.c -> session_export_stats_csv_with_offsets() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_export_stats_csv_with_offsets(const char *out_csv_path,
		const t_hunt_stats *stats, const t_session_range_info *range)
{
	t_session_export_request	request;

	if (!range)
		return (0);
	memset(&request, 0, sizeof(request));
	request.out_csv_path = out_csv_path;
	request.stats = stats;
	request.session_start_ts = range->start_timestamp;
	request.session_end_ts = range->end_timestamp;
	request.start_offset = range->start_offset;
	request.end_offset = range->end_offset;
	return (session_export_write(&request));
}

/*
** Rôle: session_export_stats_csv — Exporte session vers la destination
**       prévue en respectant le format, les
**       bornes et la politique d’erreur du
**       module.
** Paramètre: out_csv_path — destination renseignée avec le résultat, dans
**            la capacité fournie par l’appelant.
** Paramètre: stats — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: start_ts — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: end_ts — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> session_export_write().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        session_export.c -> session_export_stats_csv() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	session_export_stats_csv(const char *out_csv_path,
		const t_hunt_stats *stats, const char *start_ts, const char *end_ts)
{
	t_session_export_request	request;

	memset(&request, 0, sizeof(request));
	request.out_csv_path = out_csv_path;
	request.stats = stats;
	request.session_start_ts = start_ts;
	request.session_end_ts = end_ts;
	request.start_offset = -1;
	request.end_offset = -1;
	return (session_export_write(&request));
}
