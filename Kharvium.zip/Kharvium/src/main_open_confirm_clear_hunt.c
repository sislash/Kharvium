/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_open_confirm_clear_hunt.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main_modules.h"

/*
** Rôle: app_open_confirm_clear_hunt — Réinitialise open confirmation en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_modal_open_confirm_request(),
**            app_path_hunt_csv().
** Appelants: maintenance_buttons().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_open_confirm_clear_hunt.c -> app_open_confirm_clear_hunt()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	app_open_confirm_clear_hunt(t_window *w, t_app *app)
{
	const char	*msg[3];

	msg[0] = LOCALIZE("Vider le CSV chasse ?", "Clear hunt CSV?");
	msg[1] = app_path_hunt_csv();
	msg[2] = "";
	app_modal_open_confirm_request(&(t_app_modal_request){w, app,
		APP_ACT_CLEAR_HUNT_CSV,
		LOCALIZE("MAINTENANCE", "MAINTENANCE"), msg, 3});
}

/*
** Rôle: app_confirm_clear_global_events — Réinitialise confirmation en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_modal_open_confirm_request(),
**            app_path_global_events_csv().
** Appelants: global_action_buttons_render(), maintenance_buttons().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_open_confirm_clear_hunt.c -> app_confirm_clear_global_events()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	app_confirm_clear_global_events(t_window *w, t_app *app)
{
	const char	*msg[3];

	msg[0] = LOCALIZE("Vider le CSV globals ?", "Clear globals CSV?");
	msg[1] = app_path_global_events_csv();
	msg[2] = "";
	app_modal_open_confirm_request(&(t_app_modal_request){w, app,
		APP_ACTION_CLEAR_GLOBAL_EVENTS_CSV,
		LOCALIZE("MAINTENANCE", "MAINTENANCE"), msg, 3});
}

/*
** Rôle: app_quit_confirm_lines — Construit ou traite les lignes appartenant
**       à application quit confirm.
** Paramètre: guard — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: msg — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_request_quit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_open_confirm_clear_hunt.c -> app_quit_confirm_lines() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	app_quit_confirm_lines(t_app_quit_guard guard,
	const char **msg)
{
	msg[0] = LOCALIZE("Quitter " APP_BRAND_NAME " ?",
		"Quit " APP_BRAND_NAME "?");
	msg[1] = LOCALIZE("Une saisie Finance en cours sera perdue.",
		"An active Finance form will be lost.");
	if (guard == APP_QUIT_UNSAVED_FINANCE)
		msg[1] = LOCALIZE("La sauvegarde Finance a echoue.",
			"Finance save failed.");
	else if (guard == APP_QUIT_ACTIVITY_DRAFT)
		msg[1] = LOCALIZE("Le brouillon de run en cours sera perdu.",
			"The current run draft will be lost.");
	msg[2] = LOCALIZE("Confirmer pour quitter sans conserver cet etat.",
		"Confirm to quit without preserving this state.");
	msg[3] = "";
}

/*
** Rôle: app_request_quit — Enregistre la demande de quit et met à jour les
**       états associés uniquement lorsque les
**       validations métier requises réussissent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_finance_save(),
**            app_modal_open_confirm_request(), app_quit_confirm_lines(),
**            app_quit_guard_state().
** Appelants: app_navigation_activate(), runtime_navigation_keys().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_open_confirm_clear_hunt.c -> app_request_quit() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	app_request_quit(t_window *w, t_app *app)
{
	t_app_quit_guard	guard;
	const char		*msg[4];

	if (!w || !app)
		return ;
	guard = app_quit_guard_state(app);
	if (guard == APP_QUIT_UNSAVED_FINANCE)
	{
		if (app_finance_save(app))
			guard = app_quit_guard_state(app);
	}
	if (guard == APP_QUIT_SAFE)
	{
		w->running = 0;
		return ;
	}
	app_quit_confirm_lines(guard, msg);
	app_modal_open_confirm_request(&(t_app_modal_request){w, app,
		APP_ACT_QUIT_FORCE, LOCALIZE("QUITTER", "QUIT"), msg, 4});
}

/*
** Rôle: app_clear_hunt_csv — Réinitialise l’état du module en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: w — fenêtre native ciblée par le rendu ou la gestion des
**            événements.
** Paramètre: app — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w, app.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_modal_open_message_request(),
**            app_path_hunt_csv(), csv_persistence_clear_hunt_atomic(),
**            hunt_series_live_force_reset(), hunt_stats_live_force_reset(),
**            ui_ensure_hunt_csv().
** Appelants: app_modal_process_result().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_open_confirm_clear_hunt.c -> app_clear_hunt_csv() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: millisecondes.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	app_clear_hunt_csv(t_window *w, t_app *app)
{
	int			rc;
	const char	*msg[3];

	if (!w)
		return ;
	rc = csv_persistence_clear_hunt_atomic(app_path_hunt_csv());
	if (rc == 0)
	{
		ui_ensure_hunt_csv();
		hunt_stats_live_force_reset();
		hunt_series_live_force_reset();
		app->last_refresh_ms = 0;
		msg[0] = LOCALIZE("OK : CSV chasse vide.", "OK: Hunt CSV cleared.");
		msg[1] = app_path_hunt_csv();
		msg[2] = "";
		app_modal_open_message_request(&(t_app_modal_request){w, app,
		APP_ACT_NONE, LOCALIZE("MAINTENANCE", "MAINTENANCE"), msg, 3});
		return ;
	}
	msg[0] = LOCALIZE("[ERREUR] Impossible de vider le CSV chasse.",
		"[ERROR] Cannot clear hunt CSV.");
	msg[1] = app_path_hunt_csv();
	msg[2] = "";
	app_modal_open_message_request(&(t_app_modal_request){w, app,
		APP_ACT_NONE, LOCALIZE("MAINTENANCE", "MAINTENANCE"), msg, 3});
}
