/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_filter.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_internal.h"
#include "common/string_operations.h"
#include <ctype.h>
#include <string.h>

static const char *const	g_loot_items_exact[] = {
	"Sopur", "Nessit", "Trutun", "Kaldon", "Brukite", "Papplon",
	"Bombardo", "Haimoros", "Caroot", "Vibrant Sweat", "Daily Token",
	"Combat Token", "Fen Token Gold", "Mayhem Token",
	"Entropia Unreal Token", "Common Dung", NULL
};

static const char *const	g_received_contains[] = {
	"Daily Token", "Combat Token", "Fen Token Gold", "Mayhem Token",
	"Entropia Unreal Token", "Vibrant Sweat", NULL
};

/*
** Rôle: hunt_name_skip_left — Ignore nom left en appliquant les
**       validations, bornes et effets explicitement
**       définis par ce module.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_loot_name_excluded().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_filter.c -> hunt_name_skip_left() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> isspace().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static const char	*hunt_name_skip_left(const char *text)
{
	while (*text && isspace((unsigned char)*text))
		text++;
	return (text);
}

/*
** Rôle: hunt_name_trim_right — Retourne ou renseigne nom trim right dans la
**       représentation directement utilisable par le
**       reste du module.
** Paramètre: start — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_loot_name_excluded().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_filter.c -> hunt_name_trim_right() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> isspace(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static const char	*hunt_name_trim_right(const char *start)
{
	const char	*end;

	end = start + strlen(start);
	while (end > start && (isspace((unsigned char)end[-1]) || end[-1] == '.'))
		end--;
	return (end);
}

/*
** Rôle: hunt_name_copy — Copie l’état associé à chasse nom.
** Paramètre: dst — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: cap — capacité maximale du buffer, utilisée pour empêcher tout
**            dépassement.
** Paramètre: start — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: end — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : dst.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_loot_name_excluded().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_filter.c -> hunt_name_copy() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> isspace().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_name_copy(char *dst, size_t cap,
		const char *start, const char *end)
{
	size_t	out;
	int	space;

	out = 0;
	space = 0;
	while (start < end && out + 1 < cap)
	{
		if (isspace((unsigned char)*start))
			space = 1;
		else
		{
			if (space && out > 0 && out + 1 < cap)
				dst[out++] = ' ';
			space = 0;
			dst[out++] = *start;
		}
		start++;
	}
	dst[out] = '\0';
}

/*
** Rôle: hunt_name_in_list — Construit ou parcourt la liste utilisée par
**       chasse nom in.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: items — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: contains — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_contains_case_insensitive(),
**            string_equal_case_insensitive().
** Appelants: hunt_series_loot_name_excluded().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_filter.c -> hunt_name_in_list() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	hunt_name_in_list(const char *name, const char *const *items,
		int contains)
{
	int	index;

	index = 0;
	while (items[index])
	{
		if (!contains && string_equal_case_insensitive(name, items[index]))
			return (1);
		if (contains && string_contains_case_insensitive(name, items[index]))
			return (1);
		index++;
	}
	return (0);
}

/*
** Rôle: hunt_series_loot_name_excluded — Retourne ou renseigne loot nom
**       excluded dans la représentation
**       directement utilisable par le
**       reste du module.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_name_copy(), hunt_name_in_list(),
**            hunt_name_skip_left(), hunt_name_trim_right().
** Appelants: hunt_series_process_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_filter.c -> hunt_series_loot_name_excluded() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_loot_items_exact,
**               g_received_contains.
** Concurrence: état global mutable détecté (g_loot_items_exact,
**              g_received_contains); synchronisation externe requise si
**              plusieurs threads y accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_series_loot_name_excluded(const char *type, const char *name)
{
	const char	*start;
	const char	*end;
	char		trimmed[256];

	if (!name || !*name)
		return (0);
	start = hunt_name_skip_left(name);
	end = hunt_name_trim_right(start);
	hunt_name_copy(trimmed, sizeof(trimmed), start, end);
	if (!*trimmed)
		return (0);
	if (hunt_name_in_list(trimmed, g_loot_items_exact, 0))
		return (1);
	if (type && strcmp(type, "RECEIVED_OTHER") == 0
		&& hunt_name_in_list(trimmed, g_received_contains, 1))
		return (1);
	return (0);
}
