/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_markers.c                                    +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt/hunt_markers.h"
#include <stdio.h>

/*
** Rôle: hunt_markers_append — Ajoute l’état associé à chasse markers.
** Paramètre: output — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: marker — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output, count.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_markers_append_kill(), hunt_markers_append_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_markers.c -> hunt_markers_append() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	hunt_markers_append(t_hunt_marker *output, int *count,
	const t_hunt_marker *marker, int capacity)
{
	if (!output || !count || !marker || *count >= capacity)
		return (0);
	output[*count] = *marker;
	(*count)++;
	return (1);
}

/*
** Rôle: hunt_markers_append_kill — Ajoute markers kill vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: build — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : count.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_markers_append().
** Appelants: hunt_markers_build_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_markers.c -> hunt_markers_append_kill() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_markers_append_kill(const t_hunt_marker_build *build,
	int index, int *count)
{
	t_hunt_marker	marker;

	if (!build->has_kill || !build->has_kill[index])
		return ;
	marker = (t_hunt_marker){index, HUNT_MARKER_KILL, 1, 0.0};
	hunt_markers_append(build->output, count, &marker,
		build->output_capacity);
}

/*
** Rôle: hunt_markers_append_loot — Ajoute markers loot vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: build — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : count.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_markers_append().
** Appelants: hunt_markers_build_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_markers.c -> hunt_markers_append_loot() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_markers_append_loot(const t_hunt_marker_build *build,
	int index, int *count)
{
	t_hunt_marker	marker;

	marker = (t_hunt_marker){index, HUNT_MARKER_LOOT, 1,
		build->loot_values[index]};
	if (build->group_counts && build->group_counts[index] > 1)
		marker.group_count = build->group_counts[index];
	hunt_markers_append(build->output, count, &marker,
		build->output_capacity);
}

/*
** Rôle: hunt_markers_build_loot — Construit markers loot à partir des
**       paramètres fournis et initialise tous les champs requis avant qu’ils
**       soient lus par une autre opération.
** Paramètre: build — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_markers_append_kill(),
**            hunt_markers_append_loot().
** Appelants: hunt_live_chart_loot_annotations(), check_missing_markers(),
**            check_baseline_markers().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_markers.c -> hunt_markers_build_loot() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_markers_build_loot(const t_hunt_marker_build *build)
{
	int	index;
	int	count;

	if (build && build->output_count)
		*build->output_count = 0;
	if (!build || !build->loot_values || !build->output || !build->output_count)
		return (0);
	count = 0;
	index = 0;
	while (index < build->count)
	{
		hunt_markers_append_kill(build, index, &count);
		hunt_markers_append_loot(build, index, &count);
		index++;
	}
	*build->output_count = count;
	return (1);
}

/*
** Rôle: hunt_markers_format_text — Formate markers texte dans le buffer ou la
**       représentation demandée sans dépasser la capacité fournie par
**       l’appelant.
** Paramètre: marker — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: destination — objet ou buffer fourni par l’appelant; il peut
**            être mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: capacity — capacité maximale du buffer, utilisée pour empêcher
**            tout dépassement.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : destination.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_live_chart_loot_annotation_add(),
**            test_hunt_loot_marker_format().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_markers.c -> hunt_markers_format_text() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_markers_format_text(const t_hunt_marker *marker,
	char *destination, size_t capacity)
{
	if (!destination || capacity == 0)
		return (0);
	if (!marker)
		return (destination[0] = '\0', 0);
	if (marker->kind == HUNT_MARKER_KILL)
		return (snprintf(destination, capacity, "K") >= 0);
	if (marker->kind == HUNT_MARKER_LOOT && marker->group_count > 1)
		return (snprintf(destination, capacity, "%.2f x%d", marker->value,
				marker->group_count) >= 0);
	if (marker->kind == HUNT_MARKER_LOOT)
		return (snprintf(destination, capacity, "%.2f", marker->value) >= 0);
	destination[0] = '\0';
	return (0);
}
