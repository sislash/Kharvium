/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_rules_get_loot_fields.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_rules_modules.h"

/*
** Rôle: get_loot_fields — Retourne loot champs.
** Paramètre: start — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: fields — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : fields.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> extract_item_name(), find_value_token(),
**            parse_loot_value(), skip_value_token().
** Appelants: parse_received_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_get_loot_fields.c -> get_loot_fields() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> atoi(), isspace(),
**              strlen(), strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=1; appels projet directs=4; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	get_loot_fields(const char *start, t_hunt_loot_fields *fields)
{
	const char	*xpos;
	const char	*valp;
	const char	*vstart;

	xpos = strstr(start, " x (");
	valp = find_value_token(start);
	if (!xpos || !valp || xpos >= valp)
		return (0);
	if (!extract_item_name(start, xpos, fields->item, sizeof(fields->item)))
		return (0);
	fields->quantity = atoi(xpos + (int)strlen(" x ("));
	vstart = skip_value_token(start, valp);
	while (*vstart && isspace((unsigned char)*vstart))
		vstart++;
	fields->value_uPED = 0;
	return (parse_loot_value(vstart, &fields->value_uPED));
}

/*
** Rôle: parse_received_loot — Analyse received loot.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: ts — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : ev.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> get_loot_fields(), received_start(),
**            set_loot_event(), set_sweat_event().
** Appelants: parse_received_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_get_loot_fields.c -> parse_received_loot() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	parse_received_loot(const char *line, const char *ts,
	t_hunt_event *ev)
{
	const char			*start;
	t_hunt_loot_fields	fields;

	start = received_start(line);
	if (!start)
		return (0);
	if (!get_loot_fields(start, &fields))
		return (-1);
	if (strcmp(fields.item, "Vibrant Sweat") == 0)
		return (set_sweat_event(ev, fields.quantity) + 2);
	set_loot_event(ev, fields.item, fields.quantity, fields.value_uPED);
	(void)ts;
	return (1);
}

/*
** Rôle: set_received_other — Définit received other.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: start — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : ev.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_copy_safe(), trim_final_dot().
** Appelants: parse_received_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_get_loot_fields.c -> set_received_other() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	set_received_other(t_hunt_event *ev, const char *start)
{
	char	tmp[512];

	string_copy_safe(tmp, sizeof(tmp), start);
	trim_final_dot(tmp);
	string_copy_safe(ev->type, sizeof(ev->type), "RECEIVED_OTHER");
	string_copy_safe(ev->name, sizeof(ev->name), tmp);
	return (0);
}

/*
** Rôle: parse_received_line — Analyse received ligne.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: ts — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : ev.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> parse_received_loot(), received_start(),
**            set_received_other().
** Appelants: hunt_parse_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_get_loot_fields.c -> parse_received_line() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	parse_received_line(const char *line, const char *ts,
								t_hunt_event *ev)
{
	const char	*start;
	int			ok;

	start = received_start(line);
	if (!start)
		return (0);
	ok = parse_received_loot(line, ts, ev);
	if (ok == 1)
		return (1);
	if (ok == 2)
		return (2);
	set_received_other(ev, start);
	return (1);
}

/*
** Rôle: parse_kill_line — Analyse kill ligne.
** Paramètre: r — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: ts — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : r, ev.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> parse_normalization_kill_start(),
**            parse_timestamp_to_time(), string_copy_safe(),
**            trim_final_dot().
** Appelants: hunt_parse_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_get_loot_fields.c -> parse_kill_line() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	parse_kill_line(t_hunt_rules *r, const char *line,
			const char *ts, t_hunt_event *ev)
{
	const char	*start;
	char		mob[256];
	time_t		kt;

	start = parse_normalization_kill_start(line);
	if (!start)
		return (0);
	if (!r)
		return (-1);
	string_copy_safe(mob, sizeof(mob), start);
	trim_final_dot(mob);
	kt = parse_timestamp_to_time(ts);
	if (kt)
		r->last_explicit_kill_t = kt;
	string_copy_safe(ev->type, sizeof(ev->type), "KILL");
	string_copy_safe(ev->name, sizeof(ev->name), mob);
	if (ts[0])
		snprintf(r->last_kill_ts, sizeof(r->last_kill_ts), "%s", ts);
	return (1);
}
