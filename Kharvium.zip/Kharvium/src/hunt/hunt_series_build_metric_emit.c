/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_build_metric_emit.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_build_internal.h"

/*
** Rôle: hunt_series_metric_emit — Émet la donnée ou l’événement produit par
**       chasse série metric.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: state — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : output, state.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_metric_read_value(),
**            hunt_series_metric_result().
** Appelants: hunt_series_bucket_metric_build().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_metric_emit.c -> hunt_series_metric_emit()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_metric_emit(
	const t_hunt_series_bucket_request *request,
	t_hunt_series_output *output, t_hunt_series_build_state *state)
{
	t_hunt_series_metric_value	value;
	long				absolute;

	while (state->index < request->series->count
		&& state->count < HS_MAX_POINTS)
	{
		hunt_series_metric_read_value(request, state->index, &value);
		if (value.valid)
		{
			output->values[state->count] = hunt_series_metric_result(
					request, state, &value);
			if (output->values[state->count] > state->maximum)
				state->maximum = output->values[state->count];
			absolute = request->series->first_bucket + state->index;
			output->x_seconds[state->count] = (int)(absolute
					* (long)request->series->bucket_sec);
			state->count++;
		}
		state->index++;
	}
}
