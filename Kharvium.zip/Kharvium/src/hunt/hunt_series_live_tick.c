/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_live_tick.c                           +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_live_internal.h"
#include "core/session_runtime.h"
#include "platform/app_paths.h"
#include "platform/file_system.h"

#include <stdio.h>

/*
** Rôle: hunt_series_live_resolve_end — Formate LIVE resolve end dans le
**       buffer destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: start — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: end_raw — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type long; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_path_hunt_csv(),
**            file_system_file_size(), session_count_data_lines().
** Appelants: hunt_series_live_update_range().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_live_tick.c -> hunt_series_live_resolve_end() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_hunt_series_live.
** Concurrence: état global mutable détecté (g_hunt_series_live);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static long	hunt_series_live_resolve_end(long start, long end_raw)
{
	long int	resolved;
	long int	size;

	resolved = end_raw;
	if (resolved >= 0)
		return (resolved);
	size = file_system_file_size(app_path_hunt_csv());
	if (size >= 0 && g_hunt_series_live.cached_eof_size == size
		&& g_hunt_series_live.cached_eof_lines >= 0)
		return (g_hunt_series_live.cached_eof_lines);
	resolved = session_count_data_lines(app_path_hunt_csv());
	g_hunt_series_live.cached_eof_size = size;
	g_hunt_series_live.cached_eof_lines = resolved;
	if (resolved < start)
		resolved = start;
	return (resolved);
}

/*
** Rôle: hunt_series_live_range_result — Construit ou vérifie le résultat de
**       chasse série LIVE plage.
** Paramètre: start — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: raw — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: end — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: ok — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_sanity_check().
** Appelants: hunt_series_live_update_range().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_live_tick.c -> hunt_series_live_range_result() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_hunt_series_live.
** Concurrence: état global mutable détecté (g_hunt_series_live);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_live_range_result(long start, long raw,
	long end, int ok)
{
	g_hunt_series_live.view.ready = (ok != 0);
	g_hunt_series_live.view.mode = 1;
	g_hunt_series_live.view.range_start = start;
	g_hunt_series_live.view.range_end = end;
	g_hunt_series_live.view.range_end_raw = raw;
	g_hunt_series_live.view.offset = -1;
	g_hunt_series_live.warning[0] = '\0';
	if (!ok)
		snprintf(g_hunt_series_live.warning, sizeof(g_hunt_series_live.warning),
			"WARN: rebuild range failed");
	else if (end > start && g_hunt_series_live.series.t0 == 0
		&& g_hunt_series_live.series.count == 0
		&& g_hunt_series_live.series.core.shots_total == 0
		&& g_hunt_series_live.series.core.hits_total == 0
		&& g_hunt_series_live.series.core.kills_total == 0
		&& g_hunt_series_live.series.core.loot_total_uPED == 0)
		snprintf(g_hunt_series_live.warning, sizeof(g_hunt_series_live.warning),
			"WARN: range has no parsed data");
	else if (!hunt_series_sanity_check(&g_hunt_series_live.series))
		snprintf(g_hunt_series_live.warning, sizeof(g_hunt_series_live.warning),
			"WARN: series sanity check failed");
}

/*
** Rôle: hunt_series_live_update_range — Calcule LIVE update plage à partir de
**       la géométrie et de l’état courants sans dépasser les limites
**       disponibles.
** Paramètre: start — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: raw — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_path_hunt_csv(),
**            hunt_series_live_range_result(),
**            hunt_series_live_resolve_end(), hunt_series_rebuild_range().
** Appelants: hunt_series_live_tick().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_live_tick.c -> hunt_series_live_update_range() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_hunt_series_live.
** Concurrence: état global mutable détecté (g_hunt_series_live);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_live_update_range(long start, long raw)
{
	t_hunt_series_range_request	request;
	int				needs_rebuild;
	int				ok;
	long				end;

	needs_rebuild = (!g_hunt_series_live.view.ready
		|| g_hunt_series_live.view.mode != 1
		|| start != g_hunt_series_live.view.range_start
		|| raw != g_hunt_series_live.view.range_end_raw);
	if (!needs_rebuild)
		return ;
	end = hunt_series_live_resolve_end(start, raw);
	if (end < start)
		end = start;
	request.csv_path = app_path_hunt_csv();
	request.start_line = start;
	request.end_line = end;
	request.bucket_sec = 60;
	ok = hunt_series_rebuild_range(&g_hunt_series_live.series, &request);
	hunt_series_live_range_result(start, raw, end, ok);
}

/*
** Rôle: hunt_series_live_update_current — Met à jour LIVE courant à partir
**       des valeurs courantes et conserve l’état partagé cohérent pour la
**       suite de la frame ou du calcul.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_path_hunt_csv(),
**            app_path_session_offset(), hunt_series_reset(),
**            hunt_series_sanity_check(), hunt_series_update(),
**            session_load_offset().
** Appelants: hunt_series_live_tick().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_live_tick.c -> hunt_series_live_update_current()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_hunt_series_live.
** Concurrence: état global mutable détecté (g_hunt_series_live);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_live_update_current(void)
{
	long	offset;

	offset = session_load_offset(app_path_session_offset());
	if (!g_hunt_series_live.view.ready || g_hunt_series_live.view.mode != 0
		|| offset != g_hunt_series_live.view.offset)
	{
		hunt_series_reset(&g_hunt_series_live.series, offset, 60);
		g_hunt_series_live.view = (t_hunt_live_view_state){1, offset, 0,
			-1, -1, -2};
		g_hunt_series_live.warning[0] = '\0';
	}
	hunt_series_update(&g_hunt_series_live.series, app_path_hunt_csv());
	if (!hunt_series_sanity_check(&g_hunt_series_live.series))
		snprintf(g_hunt_series_live.warning, sizeof(g_hunt_series_live.warning),
			"WARN: series sanity check failed");
}

/*
** Rôle: hunt_series_live_tick — Exécute un cycle l’état associé à chasse
**       série LIVE.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_path_session_range(),
**            hunt_live_view_range_normalize(),
**            hunt_series_live_update_current(),
**            hunt_series_live_update_range(), session_load_range().
** Appelants: app_refresh_cached(), hunt_series_live_bootstrap(),
**            hunt_live_chart_live_button(),
**            hunt_tracker_live_tick_quarter_second(),
**            hunt_tracker_screen_stats_once(), overlay_refresh_stats().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_live_tick.c -> hunt_series_live_tick() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_live_tick(void)
{
	long	start;
	long	raw;

	start = 0;
	raw = -1;
	if (session_load_range(app_path_session_range(), &start, &raw))
	{
		hunt_live_view_range_normalize(&start, &raw);
		hunt_series_live_update_range(start, raw);
		return ;
	}
	hunt_series_live_update_current();
}
