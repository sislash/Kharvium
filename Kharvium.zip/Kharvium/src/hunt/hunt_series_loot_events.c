/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_loot_events.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_internal.h"
#include "core/core_loot_aggregate.h"
#include "core/core_roi.h"

/*
** Rôle: hunt_series_loot_has_kill — Détermine si loot kill respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: relative — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: kill_id — identifiant stable servant à retrouver ou associer
**            l’élément.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_loot_append().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_loot_events.c -> hunt_series_loot_has_kill() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	hunt_series_loot_has_kill(const t_hunt_series *series,
		int relative, int64_t kill_id)
{
	if (kill_id > 0)
		return (1);
	if (series->kill_ev_count <= 0)
		return (0);
	return (series->kill_ev_sec[series->kill_ev_count - 1] == relative);
}

/*
** Rôle: hunt_series_loot_merge — Fusionne l’état associé à chasse série
**       loot.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: time — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: kill_id — identifiant stable servant à retrouver ou associer
**            l’élément.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_loot_should_merge(),
**            core_money_add_clamped().
** Appelants: hunt_series_push_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_loot_events.c -> hunt_series_loot_merge() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	hunt_series_loot_merge(t_hunt_series *series, time_t time,
		int64_t kill_id, t_money value)
{
	int	index;

	if (series->loot_ev_count <= 0)
		return (0);
	if (!core_loot_should_merge(series->last_loot_ev_t,
			series->last_loot_ev_kill_id, time, kill_id))
		return (0);
	index = series->loot_ev_count - 1;
	series->loot_ev_uPED[index] = core_money_add_clamped(
			series->loot_ev_uPED[index], value);
	series->loot_ev_group_count[index]++;
	return (1);
}

/*
** Rôle: hunt_series_loot_append — Ajoute l’état associé à chasse série
**       loot.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: relative — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: kill_id — identifiant stable servant à retrouver ou associer
**            l’élément.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les accès indexés sont bornés avant lecture ou écriture; un
**             kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_evict_loot(),
**            hunt_series_eviction_chunk_size(), hunt_series_loot_has_kill().
** Appelants: hunt_series_push_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_loot_events.c -> hunt_series_loot_append() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_loot_append(t_hunt_series *series, int relative,
		int64_t kill_id, t_money value)
{
	int	index;
	int	drop;

	if (series->loot_ev_count >= HS_MAX_EVENTS)
	{
		drop = hunt_series_eviction_chunk_size();
		hunt_series_evict_loot(series, drop);
	}
	index = series->loot_ev_count;
	series->loot_ev_sec[index] = relative;
	series->loot_ev_uPED[index] = value;
	series->loot_ev_group_count[index] = 1;
	series->loot_ev_kill_id[index] = 0;
	if (kill_id > 0)
		series->loot_ev_kill_id[index] = kill_id;
	series->loot_ev_has_kill[index] = hunt_series_loot_has_kill(
			series, relative, kill_id);
	series->loot_ev_count++;
}

/*
** Rôle: hunt_series_push_loot — Ajoute loot dans la collection concernée en
**       respectant sa capacité, son ordre et ses
**       invariants de propriété.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: time — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: kill_id — identifiant stable servant à retrouver ou associer
**            l’élément.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_time_relative_seconds(),
**            hunt_series_loot_append(), hunt_series_loot_merge().
** Appelants: hunt_series_process_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_loot_events.c -> hunt_series_push_loot() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_push_loot(t_hunt_series *series, time_t time,
		int64_t kill_id, t_money value)
{
	int	relative;

	if (!series || !series->t0 || !time)
		return ;
	if (hunt_series_loot_merge(series, time, kill_id, value))
		return ;
	relative = core_time_relative_seconds(series->t0, time);
	hunt_series_loot_append(series, relative, kill_id, value);
	series->last_loot_ev_t = time;
	series->last_loot_ev_kill_id = kill_id;
}
