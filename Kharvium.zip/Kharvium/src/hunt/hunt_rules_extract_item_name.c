/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_rules_extract_item_name.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_rules_modules.h"

/*
** Rôle: extract_item_name — Retourne extract objet nom dans la forme
**       directement utilisable par le rendu ou l’appelant.
** Paramètre: start — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: xpos — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: item — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: itemsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : item.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: get_loot_fields().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_extract_item_name.c -> extract_item_name() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> isspace(), memcpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	extract_item_name(const char *start, const char *xpos,
							  char *item, size_t itemsz)
{
	size_t	len;

	len = (size_t)(xpos - start);
	while (len > 0 && isspace((unsigned char)start[len - 1]))
		len--;
	if (len >= itemsz)
		len = itemsz - 1;
	memcpy(item, start, len);
	item[len] = '\0';
	return (len > 0);
}

/*
** Rôle: skip_value_token — Ignore valeur token en appliquant les
**       validations, bornes et effets explicitement
**       définis par ce module.
** Paramètre: start — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: valp — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: get_loot_fields().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_extract_item_name.c -> skip_value_token() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strlen(), strstr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
const char	*skip_value_token(const char *start, const char *valp)
{
	size_t					i;
	const char				*p;
	static const char *const	val[] = {
		" Value:",
		" Value :",
		" Valeur:",
		" Valeur :"
	};

	i = 0;
	while (i < sizeof(val) / sizeof(val[0]))
	{
		p = strstr(start, val[i]);
		if (p == valp)
			return (p + strlen(val[i]));
		i++;
	}
	return (valp);
}

/*
** Rôle: set_loot_event — Définit loot événement.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: item — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: qty — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: value_uPED — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : ev.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_format_ped_4_decimals(),
**            string_copy_safe().
** Appelants: parse_received_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_extract_item_name.c -> set_loot_event() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	set_loot_event(t_hunt_event *ev, const char *item,
						   int qty, t_money value_uPED)
{
	char	qtybuf[32];
	char	pedbuf[64];

	snprintf(qtybuf, sizeof(qtybuf), "%d", qty);
	money_format_ped_4_decimals(pedbuf, sizeof(pedbuf), value_uPED);
	string_copy_safe(ev->type, sizeof(ev->type), "LOOT_ITEM");
	string_copy_safe(ev->name, sizeof(ev->name), item);
	string_copy_safe(ev->qty, sizeof(ev->qty), qtybuf);
	string_copy_safe(ev->value, sizeof(ev->value), pedbuf);
	return (0);
}

/*
** Rôle: set_sweat_event — Définit sweat événement.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: qty — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 0 selon la condition évaluée; les autres branches
**         binaires sont explicitement visibles dans le corps.
** Effets: peut modifier les paramètres non const suivants : ev.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_format_ped_4_decimals(),
**            string_copy_safe().
** Appelants: parse_received_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_extract_item_name.c -> set_sweat_event() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	set_sweat_event(t_hunt_event *ev, int qty)
{
	char	qtybuf[32];
	char	pedbuf[64];

	snprintf(qtybuf, sizeof(qtybuf), "%d", qty);
	money_format_ped_4_decimals(pedbuf, sizeof(pedbuf), 0);
	string_copy_safe(ev->type, sizeof(ev->type), "SWEAT");
	string_copy_safe(ev->name, sizeof(ev->name), "Vibrant Sweat");
	string_copy_safe(ev->qty, sizeof(ev->qty), qtybuf);
	string_copy_safe(ev->value, sizeof(ev->value), pedbuf);
	return (0);
}

/*
** Rôle: parse_loot_value — Analyse loot valeur.
** Paramètre: start — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: value_uPED — montant en représentation entière fixe; aucune
**            valeur flottante persistante n’est requise.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : value_uPED.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_ped().
** Appelants: get_loot_fields().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_extract_item_name.c -> parse_loot_value() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> isspace(), memcpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	parse_loot_value(const char *start, t_money *value_uPED)
{
	char	buf[64];
	size_t	len;

	len = 0;
	while (start[len] && !isspace((unsigned char)start[len])
		&& len + 1 < sizeof(buf))
		len++;
	if (!len || (start[len] && !isspace((unsigned char)start[len])))
		return (0);
	memcpy(buf, start, len);
	buf[len] = '\0';
	return (money_parse_ped(buf, value_uPED));
}
