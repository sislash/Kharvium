/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_rules.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_rules_modules.h"

/*
** Rôle: hunt_rules_clear — Vide l’état associé à chasse rules.
** Paramètre: r — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : r.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_rules_initialize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules.c -> hunt_rules_clear() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_rules_clear(t_hunt_rules *r)
{
	if (!r)
		return ;
	memset(r, 0, sizeof(*r));
}

/*
** Rôle: now_timestamp — Calcule et retourne now timestamp à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Paramètre: buf — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: bufsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : buf.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_event_initialize_from_chat_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules.c -> now_timestamp() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> localtime(), strftime(),
**              time().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	now_timestamp(char *buf, size_t bufsz)
{
	time_t		t;
	struct tm	*lt;

	if (!buf || bufsz == 0)
		return;
	t = time(NULL);
	lt = localtime(&t);
	if (!lt)
	{
		buf[0] = '\0';
		return;
	}
	strftime(buf, bufsz, "%Y-%m-%d %H:%M:%S", lt);
}

/*
** Rôle: string_is_two_digits — Détermine si string two digits respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: p — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: extract_chatlog_timestamp().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules.c -> string_is_two_digits() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> isdigit().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	string_is_two_digits(const char *p)
{
	return (p && isdigit((unsigned char)p[0]) && isdigit((unsigned char)p[1]));
}

/*
** Rôle: string_is_four_digits — Détermine si string four digits respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: p — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: extract_chatlog_timestamp().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules.c -> string_is_four_digits() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> isdigit().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	string_is_four_digits(const char *p)
{
	if (!p)
		return (0);
	return (isdigit((unsigned char)p[0]) && isdigit((unsigned char)p[1])
	&& isdigit((unsigned char)p[2]) && isdigit((unsigned char)p[3]));
}

/*
** Rôle: extract_chatlog_timestamp — Formate extract chatlog timestamp dans le
**       buffer destination fourni, avec une taille explicitement bornée par
**       l’appelant.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_is_four_digits(),
**            string_is_two_digits().
** Appelants: hunt_event_initialize_from_chat_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules.c -> extract_chatlog_timestamp() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> snprintf(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	extract_chatlog_timestamp(const char *line, char *out, size_t outsz)
{
	if (!line || !out || outsz < 20)
		return (0);
	if (strlen(line) < 19)
		return (0);
	if (!string_is_four_digits(line) || line[4] != '-'
		|| !string_is_two_digits(line + 5))
		return (0);
	if (line[7] != '-' || !string_is_two_digits(line + 8) || line[10] != ' ')
		return (0);
	if (!string_is_two_digits(line + 11) || line[13] != ':'
		|| !string_is_two_digits(line + 14))
		return (0);
	if (line[16] != ':' || !string_is_two_digits(line + 17))
		return (0);
	snprintf(out, outsz, "%.19s", line);
	return (1);
}
