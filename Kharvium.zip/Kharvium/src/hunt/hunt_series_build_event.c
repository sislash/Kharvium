/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_build_event.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_build_internal.h"

/*
** Rôle: hunt_series_event_count — Compte l’état associé à chasse série
**       événement.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_build_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_event.c -> hunt_series_event_count() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	hunt_series_event_count(
	const t_hunt_series_event_request *request)
{
	if (request->metric == HUNT_SERIES_EVENT_KILLS)
		return (request->series->kill_ev_count);
	if (request->metric == HUNT_SERIES_EVENT_HITS)
		return (request->series->hits_ev_count);
	return (request->series->shots_ev_count);
}

/*
** Rôle: hunt_series_event_seconds — Traite événement seconds et met à jour
**       uniquement l’état d’entrée ou
**       d’interface correspondant à cet
**       événement.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_build_event(), hunt_series_event_emit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_event.c -> hunt_series_event_seconds() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static const int	*hunt_series_event_seconds(
	const t_hunt_series_event_request *request)
{
	if (request->metric == HUNT_SERIES_EVENT_KILLS)
		return (request->series->kill_ev_sec);
	if (request->metric == HUNT_SERIES_EVENT_HITS)
		return (request->series->hits_ev_sec);
	return (request->series->shots_ev_sec);
}

/*
** Rôle: hunt_series_event_emit — Émet la donnée ou l’événement produit par
**       chasse série événement.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: state — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : output, state.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_event_seconds(),
**            hunt_series_event_value().
** Appelants: hunt_series_build_event().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_event.c -> hunt_series_event_emit() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_event_emit(
	const t_hunt_series_event_request *request,
	t_hunt_series_output *output, t_hunt_series_build_state *state)
{
	const int	*seconds;
	int		valid;
	double		value;

	seconds = hunt_series_event_seconds(request);
	while (state->index < state->count && output->count < HS_MAX_POINTS)
	{
		value = hunt_series_event_value(request, state->index, &valid);
		if (valid)
		{
			output->x_seconds[output->count] = seconds[state->index];
			output->values[output->count] = value;
			if (value > output->maximum)
				output->maximum = value;
			output->count++;
		}
		state->index++;
	}
}

/*
** Rôle: hunt_series_build_event — Construit événement à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_event_count(),
**            hunt_series_event_emit(), hunt_series_event_seconds(),
**            hunt_series_event_start(), hunt_series_output_prepare().
** Appelants: hunt_chart_build_events().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_event.c -> hunt_series_build_event() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_series_build_event(const t_hunt_series_event_request *request,
		t_hunt_series_output *output)
{
	t_hunt_series_build_state	state;
	const int			*seconds;

	if (!request || !request->series
		|| !hunt_series_output_prepare(request->series, output))
		return (0);
	state = (t_hunt_series_build_state){0};
	seconds = hunt_series_event_seconds(request);
	state.count = hunt_series_event_count(request);
	if (state.count <= 0)
		return (1);
	state.start = hunt_series_event_start(seconds, state.count,
			request->last_minutes);
	state.index = state.start;
	hunt_series_event_emit(request, output, &state);
	return (1);
}
