/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_rules_hunt_should_ignore_line.c               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_rules_modules.h"

/*
** Rôle: hunt_should_ignore_line — Détermine si ignore ligne respecte la
**       condition attendue, sans modifier les données consultées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement ->
**            parse_normalization_should_ignore_line().
** Appelants: parse_engine_process_hunt().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_hunt_should_ignore_line.c -> hunt_should_ignore_line()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_should_ignore_line(const char *line)
{
	return (parse_normalization_should_ignore_line(line));
}

/*
** Rôle: hunt_parse_line — Analyse ligne depuis la source fournie, contrôle le
**       format utile et ne renseigne la destination qu’avec des données
**       validées.
** Paramètre: r — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: line_in — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : r, ev.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_event_initialize_from_chat_line(),
**            maybe_grouped_kill(), parse_kill_line(), parse_received_line(),
**            parse_shot_line().
** Appelants: parse_engine_process_hunt(), run_normalization_sequence().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_hunt_should_ignore_line.c -> hunt_parse_line() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_parse_line(t_hunt_rules *r, const char *line_in,
			t_hunt_event *ev)
{
	char	line[MAX_LINE];
	char	ts[32];
	int		ret;
	int		sweat_ret;

	if (!line_in || !ev)
		return (-1);
	if (!r)
		return (-1);
	hunt_event_initialize_from_chat_line(line_in, ev, line, ts);
	if (parse_shot_line(r, line, ts, ev))
		return (0);
	sweat_ret = parse_received_line(line, ts, ev);
	if (sweat_ret)
	{
		if (sweat_ret == 2)
			return (0);
		ret = maybe_grouped_kill(r, line, ts);
		return (ret);
	}
	ret = parse_kill_line(r, line, ts, ev);
	if (ret > 0)
		return (0);
	return (-1);
}
