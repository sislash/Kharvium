/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_event_types.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28 15:05:00 by kharvium          #+#    #+#             */
/*   Updated: 2026/08/28 15:05:00 by kharvium         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt/hunt_event_types.h"
#include "common/string_operations.h"

#include <string.h>

/*
** Rôle: hunt_event_type_is_loot — Détermine si événement type loot respecte
**       la condition attendue, sans modifier les données consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_stats_add_loot(), hunt_event_type_is_loot_or_sweat().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_event_types.c -> hunt_event_type_is_loot() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_event_type_is_loot(const char *type)
{
	if (!type)
		return (0);
	if (strncmp(type, "LOOT", 4) == 0)
		return (1);
	return (strncmp(type, "RECEIVED", 8) == 0);
}

/*
** Rôle: hunt_event_type_is_envelope_item — Détermine si événement type
**       enveloppe objet respecte la condition attendue, sans modifier les
**       données consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_envelope_stats_process(), hunt_stats_process_value(),
**            hunt_csv_loot_capture_item().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_event_types.c -> hunt_event_type_is_envelope_item() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_event_type_is_envelope_item(const char *type)
{
	if (!type)
		return (0);
	return (strncmp(type, "LOOT", 4) == 0);
}

/*
** Rôle: hunt_event_type_is_sweat — Détermine si événement type sweat respecte
**       la condition attendue, sans modifier les données consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_event_type_is_loot_or_sweat().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_event_types.c -> hunt_event_type_is_sweat() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_event_type_is_sweat(const char *type)
{
	if (!type)
		return (0);
	return (strcmp(type, "SWEAT") == 0);
}

/*
** Rôle: hunt_event_type_is_loot_or_sweat — Détermine si événement type loot
**       or sweat respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_event_type_is_loot(),
**            hunt_event_type_is_sweat().
** Appelants: hunt_series_process_row().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_event_types.c -> hunt_event_type_is_loot_or_sweat() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_event_type_is_loot_or_sweat(const char *type)
{
	return (hunt_event_type_is_loot(type) || hunt_event_type_is_sweat(type));
}

/*
** Rôle: hunt_event_type_is_expense — Détermine si événement type expense
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: type — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_contains_case_insensitive().
** Appelants: hunt_stats_process_value(), hunt_series_process_row().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_event_types.c -> hunt_event_type_is_expense() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_event_type_is_expense(const char *type)
{
	if (!type)
		return (0);
	if (strcmp(type, "SPEND") == 0 || strcmp(type, "DECAY") == 0)
		return (1);
	if (strcmp(type, "AMMO") == 0 || strcmp(type, "REPAIR") == 0)
		return (1);
	if (string_contains_case_insensitive(type, "SPEND"))
		return (1);
	if (string_contains_case_insensitive(type, "DECAY"))
		return (1);
	if (string_contains_case_insensitive(type, "AMMO"))
		return (1);
	return (string_contains_case_insensitive(type, "REPAIR"));
}
