/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_events.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_internal.h"
#include "core/core_loot_aggregate.h"

/*
** Rôle: hunt_series_push_kill — Traite l’événement kill associé à chasse
**       série push.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: time — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_time_relative_seconds(),
**            hunt_series_evict_kills(), hunt_series_eviction_chunk_size().
** Appelants: hunt_series_process_kill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_events.c -> hunt_series_push_kill() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_push_kill(t_hunt_series *series, time_t time)
{
	int	relative;
	int	drop;

	if (!series || !series->t0 || !time)
		return ;
	relative = core_time_relative_seconds(series->t0, time);
	if (series->kill_ev_count >= HS_MAX_EVENTS)
	{
		drop = hunt_series_eviction_chunk_size();
		hunt_series_evict_kills(series, drop);
	}
	series->kill_ev_sec[series->kill_ev_count] = relative;
	series->kill_ev_count++;
}

/*
** Rôle: hunt_series_push_hits — Ajoute hits dans la collection concernée en
**       respectant sa capacité, son ordre et ses
**       invariants de propriété.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: time — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: hits — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_time_relative_seconds(),
**            hunt_series_evict_hits(), hunt_series_eviction_chunk_size().
** Appelants: hunt_series_process_kill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_events.c -> hunt_series_push_hits() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_push_hits(t_hunt_series *series, time_t time, long hits)
{
	int	relative;
	int	drop;

	if (!series || !series->t0 || !time || hits <= 0)
		return ;
	relative = core_time_relative_seconds(series->t0, time);
	if (series->hits_ev_count >= HS_MAX_EVENTS)
	{
		drop = hunt_series_eviction_chunk_size();
		hunt_series_evict_hits(series, drop);
	}
	series->hits_ev_sec[series->hits_ev_count] = relative;
	series->hits_ev_hits[series->hits_ev_count] = (int)hits;
	series->hits_ev_count++;
}

/*
** Rôle: hunt_series_push_shots — Ajoute tirs dans la collection concernée
**       en respectant sa capacité, son ordre et
**       ses invariants de propriété.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: time — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: shots — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: hits — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_time_relative_seconds(),
**            hunt_series_evict_shots(), hunt_series_eviction_chunk_size().
** Appelants: hunt_series_process_kill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_events.c -> hunt_series_push_shots() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_push_shots(t_hunt_series *series, time_t time,
		long shots, long hits)
{
	int	relative;
	int	drop;
	long	safe_hits;

	if (!series || !series->t0 || !time || shots <= 0)
		return ;
	relative = core_time_relative_seconds(series->t0, time);
	safe_hits = hits;
	if (safe_hits < 0)
		safe_hits = 0;
	if (series->shots_ev_count >= HS_MAX_EVENTS)
	{
		drop = hunt_series_eviction_chunk_size();
		hunt_series_evict_shots(series, drop);
	}
	series->shots_ev_sec[series->shots_ev_count] = relative;
	series->shots_ev_shots[series->shots_ev_count] = (int)shots;
	series->shots_ev_hits[series->shots_ev_count] = (int)safe_hits;
	series->shots_ev_count++;
}

/*
** Rôle: hunt_series_mark_loot_kill — Traite l’événement kill associé à
**       chasse série mark loot.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: time — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_process_kill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_events.c -> hunt_series_mark_loot_kill() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_mark_loot_kill(t_hunt_series *series, time_t time)
{
	if (!series || !time || series->loot_ev_count <= 0)
		return ;
	if (series->last_loot_ev_t == time)
		series->loot_ev_has_kill[series->loot_ev_count - 1] = 1;
}
