/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_live_internal.h                       +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_SERIES_LIVE_INTERNAL_H
# define HUNT_SERIES_LIVE_INTERNAL_H

# include "hunt/hunt_live_view_state.h"
# include "hunt/hunt_series_live.h"

typedef struct s_hunt_series_live_context
{
	t_hunt_series			series;
	t_hunt_live_view_state	view;
	long				cached_eof_lines;
	long				cached_eof_size;
	char				warning[96];
} t_hunt_series_live_context;

extern t_hunt_series_live_context	g_hunt_series_live;

#endif
