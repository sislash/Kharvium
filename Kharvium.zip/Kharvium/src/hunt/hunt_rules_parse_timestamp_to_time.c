/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_rules_parse_timestamp_to_time.c               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_rules_modules.h"

/*
** Rôle: parse_timestamp_to_time — Analyse horodatage to temps.
** Paramètre: ts — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type time_t; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: parse_kill_line(), maybe_grouped_kill(), update_combat_time().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_parse_timestamp_to_time.c -> parse_timestamp_to_time()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset(), mktime(),
**              sscanf(), strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
time_t	parse_timestamp_to_time(const char *ts)
{
	int			value[6];
	struct tm	tm;

	if (!ts || strlen(ts) < 19)
		return ((time_t)0);
	memset(&tm, 0, sizeof(tm));
	if (sscanf(ts, "%d-%d-%d %d:%d:%d", &value[0], &value[1],
			&value[2], &value[3], &value[4], &value[5]) != 6)
		return ((time_t)0);
	tm.tm_year = value[0] - 1900;
	tm.tm_mon = value[1] - 1;
	tm.tm_mday = value[2];
	tm.tm_hour = value[3];
	tm.tm_min = value[4];
	tm.tm_sec = value[5];
	tm.tm_isdst = -1;
	return (mktime(&tm));
}

/*
** Rôle: trim_final_dot — Calcule et retourne trim final dot à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: parse_kill_line(), set_received_other().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_parse_timestamp_to_time.c -> trim_final_dot() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	trim_final_dot(char *s)
{
	size_t	n;

	if (!s)
		return;
	n = strlen(s);
	while (n && (s[n - 1] == ' ' || s[n - 1] == '\t'))
		s[--n] = '\0';
	if (n && s[n - 1] == '.')
		s[n - 1] = '\0';
}

/*
** Rôle: hunt_event_clear — Vide l’état associé à chasse événement.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ev.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_event_initialize_from_chat_line(), push_pending_kill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_parse_timestamp_to_time.c -> hunt_event_clear() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_event_clear(t_hunt_event *ev)
{
	if (!ev)
		return;
	memset(ev, 0, sizeof(*ev));
}

/*
** Rôle: hunt_rules_initialize — Initialise l’état associé à chasse rules.
** Paramètre: r — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : r.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_rules_clear().
** Appelants: app_state_initialize(), main(), run_normalization_sequence().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_parse_timestamp_to_time.c -> hunt_rules_initialize()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_rules_initialize(t_hunt_rules *r)
{
	hunt_rules_clear(r);
}

/*
** Rôle: hunt_pending_pop — Retire pending dans la collection concernée en
**       respectant sa capacité, son ordre et ses
**       invariants de propriété.
** Paramètre: r — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: ev — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : r, ev.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: parse_engine_flush_pending(), run_normalization_sequence().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_rules_parse_timestamp_to_time.c -> hunt_pending_pop() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_pending_pop(t_hunt_rules *r, t_hunt_event *ev)
{
	if (!r || !ev || !r->has_pending)
		return (0);
	*ev = r->pending;
	r->has_pending = 0;
	memset(&r->pending, 0, sizeof(r->pending));
	return (1);
}
