/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_event_evict.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_internal.h"
#include <string.h>

/*
** Rôle: hunt_series_eviction_chunk_size — Calcule eviction chunk taille à
**       partir des entrées courantes en respectant les unités, bornes et
**       règles d’arrondi du module.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_push_hits(), hunt_series_push_kill(),
**            hunt_series_push_shots(), hunt_series_loot_append().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_event_evict.c -> hunt_series_eviction_chunk_size()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_series_eviction_chunk_size(void)
{
	int	count;

	count = HS_EVICT_CHUNK;
	if (count <= 0)
		count = 1;
	if (count >= HS_MAX_EVENTS)
		count = HS_MAX_EVENTS / 4;
	if (count <= 0)
		count = 1;
	return (count);
}

/*
** Rôle: hunt_series_evict_kills — Met à jour evict kills en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: drop — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_push_kill().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_event_evict.c -> hunt_series_evict_kills() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memmove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_evict_kills(t_hunt_series *series, int drop)
{
	memmove(&series->kill_ev_sec[0], &series->kill_ev_sec[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->kill_ev_sec[0]));
	series->kill_ev_count = HS_MAX_EVENTS - drop;
}

/*
** Rôle: hunt_series_evict_hits — Met à jour evict hits en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: drop — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_push_hits().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_event_evict.c -> hunt_series_evict_hits() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memmove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_evict_hits(t_hunt_series *series, int drop)
{
	memmove(&series->hits_ev_sec[0], &series->hits_ev_sec[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->hits_ev_sec[0]));
	memmove(&series->hits_ev_hits[0], &series->hits_ev_hits[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->hits_ev_hits[0]));
	series->hits_ev_count = HS_MAX_EVENTS - drop;
}

/*
** Rôle: hunt_series_evict_shots — Met à jour evict tirs en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: drop — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_push_shots().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_event_evict.c -> hunt_series_evict_shots() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memmove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_evict_shots(t_hunt_series *series, int drop)
{
	memmove(&series->shots_ev_sec[0], &series->shots_ev_sec[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->shots_ev_sec[0]));
	memmove(&series->shots_ev_shots[0], &series->shots_ev_shots[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->shots_ev_shots[0]));
	memmove(&series->shots_ev_hits[0], &series->shots_ev_hits[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->shots_ev_hits[0]));
	series->shots_ev_count = HS_MAX_EVENTS - drop;
}

/*
** Rôle: hunt_series_evict_loot — Met à jour evict loot en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: drop — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_loot_append().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_event_evict.c -> hunt_series_evict_loot() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> memmove().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_evict_loot(t_hunt_series *series, int drop)
{
	memmove(&series->loot_ev_sec[0], &series->loot_ev_sec[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->loot_ev_sec[0]));
	memmove(&series->loot_ev_uPED[0], &series->loot_ev_uPED[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->loot_ev_uPED[0]));
	memmove(&series->loot_ev_group_count[0],
		&series->loot_ev_group_count[drop],
		(size_t)(HS_MAX_EVENTS - drop)
		* sizeof(series->loot_ev_group_count[0]));
	memmove(&series->loot_ev_kill_id[0], &series->loot_ev_kill_id[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->loot_ev_kill_id[0]));
	memmove(&series->loot_ev_has_kill[0], &series->loot_ev_has_kill[drop],
		(size_t)(HS_MAX_EVENTS - drop) * sizeof(series->loot_ev_has_kill[0]));
	series->loot_ev_count = HS_MAX_EVENTS - drop;
}
