/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_live.c                                +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/09                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_live_internal.h"

t_hunt_series_live_context	g_hunt_series_live = {
	{0}, {0, -1, -1, -1, -1, -2}, -1, -1, {0}
};

/*
** Rôle: hunt_series_live_force_reset — Réinitialise l’état associé à chasse
**       série LIVE force.
** Paramètres: aucun paramètre explicite.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: app_action_set_offset_end(), stop_export_finish(),
**            hunt_series_live_bootstrap(), app_clear_hunt_csv(),
**            hunt_live_chart_live_button(), hunt_export_show_success() (+2;
**            index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_live.c -> hunt_series_live_force_reset() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_hunt_series_live.
** Concurrence: état global mutable détecté (g_hunt_series_live);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_live_force_reset(void)
{
	g_hunt_series_live.view.ready = 0;
	g_hunt_series_live.view.offset = -1;
	g_hunt_series_live.view.mode = -1;
	g_hunt_series_live.view.range_start = -1;
	g_hunt_series_live.view.range_end = -1;
	g_hunt_series_live.view.range_end_raw = -2;
	g_hunt_series_live.warning[0] = '\0';
}

/*
** Rôle: hunt_series_live_warning_text — Construit ou transforme le texte
**       utilisé par chasse série LIVE warning.
** Paramètres: aucun paramètre explicite.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_live_chart_status_finish().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_live.c -> hunt_series_live_warning_text() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: symboles globaux g_* référencés -> g_hunt_series_live.
** Concurrence: état global mutable détecté (g_hunt_series_live);
**              synchronisation externe requise si plusieurs threads y
**              accèdent simultanément.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
const char	*hunt_series_live_warning_text(void)
{
	if (g_hunt_series_live.warning[0] == '\0')
		return (NULL);
	return (g_hunt_series_live.warning);
}

/*
** Rôle: hunt_series_live_bootstrap — Met à jour LIVE bootstrap en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_live_force_reset(),
**            hunt_series_live_tick().
** Appelants: runtime_initialize_window().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_live.c -> hunt_series_live_bootstrap() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_live_bootstrap(void)
{
	hunt_series_live_force_reset();
	hunt_series_live_tick();
}
