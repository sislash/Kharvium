/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_process.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_internal.h"
#include "hunt/hunt_event_types.h"
#include "core/core_roi.h"
#include <string.h>

/*
** Rôle: hunt_series_process_shot — Traite tir en appliquant les validations
**       et transformations propres à cette opération, puis laisse les
**       données concernées dans un état cohérent.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: pos — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_session_on_shot(),
**            hunt_series_raw_is_hit().
** Appelants: hunt_series_process_row().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_process.c -> hunt_series_process_shot() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_process_shot(t_hunt_series *series,
		const t_hunt_csv_row_view *row, const t_hunt_series_row_position *pos)
{
	int	is_hit;

	is_hit = hunt_series_raw_is_hit(row->brut);
	series->buckets[pos->bucket_index].shots++;
	core_session_on_shot(&series->core, is_hit);
	if (is_hit)
		series->buckets[pos->bucket_index].hits++;
}

/*
** Rôle: hunt_series_process_kill — Traite kill en appliquant les validations
**       et transformations propres à cette opération, puis laisse les
**       données concernées dans un état cohérent.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: pos — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_session_on_kill(),
**            hunt_series_mark_loot_kill(), hunt_series_push_hits(),
**            hunt_series_push_kill(), hunt_series_push_shots().
** Appelants: hunt_series_process_row().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_process.c -> hunt_series_process_kill() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_process_kill(t_hunt_series *series,
		const t_hunt_series_row_position *pos)
{
	long	segment_shots;
	long	segment_hits;

	series->buckets[pos->bucket_index].kills++;
	core_session_on_kill(&series->core, &segment_shots, &segment_hits);
	hunt_series_push_kill(series, pos->time);
	hunt_series_push_hits(series, pos->time, segment_hits);
	hunt_series_push_shots(series, pos->time, segment_shots, segment_hits);
	hunt_series_mark_loot_kill(series, pos->time);
}

/*
** Rôle: hunt_series_process_expense — Traite expense en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: pos — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_money_add_clamped(),
**            core_session_add_expense(), hunt_csv_row_has_value().
** Appelants: hunt_series_process_row().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_process.c -> hunt_series_process_expense() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_process_expense(t_hunt_series *series,
		const t_hunt_csv_row_view *row, const t_hunt_series_row_position *pos)
{
	if (!hunt_csv_row_has_value(row) || row->valeur_uPED == 0)
		return ;
	series->buckets[pos->bucket_index].expense_uPED = core_money_add_clamped(
			series->buckets[pos->bucket_index].expense_uPED,
			row->valeur_uPED);
	core_session_add_expense(&series->core, row->valeur_uPED);
}

/*
** Rôle: hunt_series_process_loot — Traite loot en appliquant les validations
**       et transformations propres à cette opération, puis laisse les
**       données concernées dans un état cohérent.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: pos — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_money_add_clamped(),
**            core_session_add_loot(), hunt_csv_row_has_value(),
**            hunt_series_loot_name_excluded(), hunt_series_push_loot().
** Appelants: hunt_series_process_row().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_process.c -> hunt_series_process_loot() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_process_loot(t_hunt_series *series,
		const t_hunt_csv_row_view *row, const t_hunt_series_row_position *pos)
{
	t_money	value;

	if (hunt_series_loot_name_excluded(row->type_evenement, row->cible))
		return ;
	value = 0;
	if (hunt_csv_row_has_value(row) && row->valeur_uPED > 0)
		value = row->valeur_uPED;
	if (value > 0)
	{
		series->buckets[pos->bucket_index].loot_uPED = core_money_add_clamped(
				series->buckets[pos->bucket_index].loot_uPED, value);
		core_session_add_loot(&series->core, value);
	}
	if (strcmp(row->type_evenement, "SWEAT") != 0
		&& strcmp(row->type_evenement, "RECEIVED_OTHER") != 0)
		hunt_series_push_loot(series, pos->time, row->id_kill, value);
}

/*
** Rôle: hunt_series_process_row — Traite ligne en appliquant les validations
**       et transformations propres à cette opération, puis laisse les
**       données concernées dans un état cohérent.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: row — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_event_type_is_expense(),
**            hunt_event_type_is_loot_or_sweat(), hunt_series_prepare_row(),
**            hunt_series_process_expense(), hunt_series_process_kill(),
**            hunt_series_process_loot(), hunt_series_process_shot().
** Appelants: hunt_series_rebuild_read(), hunt_series_update_read().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_process.c -> hunt_series_process_row() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=7; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	hunt_series_process_row(t_hunt_series *series,
		const t_hunt_csv_row_view *row)
{
	t_hunt_series_row_position	position;

	if (!hunt_series_prepare_row(series, row, &position))
		return ;
	if (row->type_evenement && strcmp(row->type_evenement, "SHOT") == 0)
		hunt_series_process_shot(series, row, &position);
	else if (row->type_evenement
		&& strncmp(row->type_evenement, "KILL", 4) == 0)
		hunt_series_process_kill(series, &position);
	else if (row->type_evenement
		&& hunt_event_type_is_expense(row->type_evenement))
		hunt_series_process_expense(series, row, &position);
	else if (row->type_evenement
		&& hunt_event_type_is_loot_or_sweat(row->type_evenement))
		hunt_series_process_loot(series, row, &position);
}
