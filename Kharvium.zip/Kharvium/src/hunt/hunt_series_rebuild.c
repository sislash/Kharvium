/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_rebuild.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_internal.h"
#include "io/csv_index.h"
#include "platform/file_system.h"
#include <limits.h>
#include <string.h>

/*
** Rôle: hunt_series_range_normalize — Normalise les données de chasse série
**       plage vers leur forme canonique.
** Paramètre: source — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: target — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : target.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_rebuild_range().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_rebuild.c -> hunt_series_range_normalize() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_range_normalize(
	const t_hunt_series_range_request *source,
	t_hunt_series_range_request *target)
{
	*target = *source;
	if (target->start_line < 0)
		target->start_line = 0;
	if (target->end_line >= 0 && target->end_line < target->start_line)
		target->end_line = target->start_line;
}

/*
** Rôle: hunt_series_rebuild_seek — Met à jour rebuild seek en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: stream — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : stream.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> csv_index_lookup_row_offset().
** Appelants: hunt_series_rebuild_range().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_rebuild.c -> hunt_series_rebuild_seek() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fseek(), memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_rebuild_seek(t_hunt_series_stream *stream,
		const t_hunt_series_range_request *request)
{
	t_csv_index_checkpoint	checkpoint;
	t_csv_index_row_query	query;

	stream->data_index = 0;
	if (request->start_line <= 0)
		return ;
	memset(&checkpoint, 0, sizeof(checkpoint));
	query.csv_path = request->csv_path;
	query.row_index = (unsigned long long)request->start_line;
	if (!csv_index_lookup_row_offset(&query, &checkpoint, NULL))
		return ;
	if (checkpoint.byte_offset > (unsigned long long)LONG_MAX)
		return ;
	if (fseek(stream->file, (long)checkpoint.byte_offset, SEEK_SET) == 0)
		stream->data_index = (long)checkpoint.row_index;
}

/*
** Rôle: hunt_series_rebuild_read — Lit l’état associé à chasse série
**       rebuild.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: stream — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : series, stream.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_csv_line_is_header(),
**            hunt_csv_parse_row_inplace(), hunt_series_process_row().
** Appelants: hunt_series_rebuild_range().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_rebuild.c -> hunt_series_rebuild_read() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fgets().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_rebuild_read(t_hunt_series *series,
		const t_hunt_series_range_request *request,
		t_hunt_series_stream *stream)
{
	stream->first = 1;
	while (fgets(stream->line, (int)sizeof(stream->line), stream->file))
	{
		stream->line[sizeof(stream->line) - 1] = '\0';
		if (stream->first && hunt_csv_line_is_header(stream->line))
		{
			stream->first = 0;
			continue ;
		}
		stream->first = 0;
		if (stream->data_index >= request->start_line
			&& (request->end_line < 0
				|| stream->data_index < request->end_line)
			&& hunt_csv_parse_row_inplace(stream->line, &stream->row))
		{
			hunt_series_process_row(series, &stream->row);
			series->version++;
		}
		stream->data_index++;
		if (request->end_line >= 0
			&& stream->data_index >= request->end_line)
			break ;
	}
}

/*
** Rôle: hunt_series_rebuild_range — Calcule ou applique la plage utilisée
**       par chasse série rebuild.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : series.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> file_system_open_shared_read(),
**            hunt_series_range_normalize(), hunt_series_rebuild_read(),
**            hunt_series_rebuild_seek(), hunt_series_reset().
** Appelants: benchmark_series_run(), hunt_series_live_update_range(),
**            test_hunt_eviction_verify(), extreme_build(),
**            test_hunt_long_verify(), test_hunt_loot_context_init().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_rebuild.c -> hunt_series_rebuild_range() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_series_rebuild_range(t_hunt_series *series,
		const t_hunt_series_range_request *request)
{
	t_hunt_series_range_request	range;
	t_hunt_series_stream		stream;

	if (!series || !request || !request->csv_path)
		return (0);
	hunt_series_range_normalize(request, &range);
	hunt_series_reset(series, range.start_line, range.bucket_sec);
	series->initialized = 1;
	series->file_pos = 0;
	stream.file = file_system_open_shared_read(range.csv_path);
	if (!stream.file)
		return (0);
	hunt_series_rebuild_seek(&stream, &range);
	hunt_series_rebuild_read(series, &range, &stream);
	fclose(stream.file);
	series->version++;
	return (1);
}
