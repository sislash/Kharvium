/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_build_internal.h                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUNT_SERIES_BUILD_INTERNAL_H
# define HUNT_SERIES_BUILD_INTERNAL_H

# include "hunt/hunt_series.h"

typedef struct s_hunt_series_build_state
{
	int		start;
	int		index;
	int		count;
	double		maximum;
	double		accumulated;
	t_money		money;
	t_money		logged;
	t_money		model;
} 	t_hunt_series_build_state;

typedef struct s_hunt_series_metric_value
{
	int	valid;
	double	number;
	t_money	money;
} 	t_hunt_series_metric_value;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_output_prepare — Prépare l’état associé à chasse série
**       output.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_output_prepare().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_output_prepare(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_series_output_prepare(const t_hunt_series *series,
		t_hunt_series_output *output);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_bucket_start — Démarre l’état associé à chasse série
**       bucket.
** Paramètre: series — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: last_n_buckets — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_bucket_start().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_bucket_start(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_series_bucket_start(const t_hunt_series *series,
		int last_n_buckets);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_event_start — Démarre l’état associé à chasse série
**       événement.
** Paramètre: seconds — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: count — nombre d’éléments disponibles ou à traiter.
** Paramètre: last_minutes — valeur d’entrée dont le nom et le type
**            définissent directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_event_start().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_event_start(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_series_event_start(const int *seconds, int count,
		int last_minutes);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_event_value — Calcule ou retourne la valeur associée à
**       chasse série événement.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: valid — identifiant stable servant à retrouver ou associer
**            l’élément.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : valid.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_event_value().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_event_value(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	hunt_series_event_value(
		const t_hunt_series_event_request *request, int index, int *valid);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_metric_read_value — Calcule metric read valeur à partir
**       des entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: value — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : value.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_metric_read_value().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_metric_read_value(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_series_metric_read_value(
		const t_hunt_series_bucket_request *request, int index,
		t_hunt_series_metric_value *value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_metric_result — Construit ou vérifie le résultat de
**       chasse série metric.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: state — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: value — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : state.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_metric_result().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_metric_result(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	hunt_series_metric_result(
		const t_hunt_series_bucket_request *request,
		t_hunt_series_build_state *state,
		const t_hunt_series_metric_value *value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_metric_emit — Émet la donnée ou l’événement produit par
**       chasse série metric.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: state — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : output, state.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_metric_emit().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_metric_emit(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	hunt_series_metric_emit(
		const t_hunt_series_bucket_request *request,
		t_hunt_series_output *output, t_hunt_series_build_state *state);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_bucket_metric_build — Construit l’état associé à chasse
**       série bucket metric.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_bucket_metric_build().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_bucket_metric_build(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_series_bucket_metric_build(
		const t_hunt_series_bucket_request *request,
		t_hunt_series_output *output);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_bucket_cost_build — Construit l’état associé à chasse
**       série bucket cost.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_bucket_cost_build().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_bucket_cost_build(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_series_bucket_cost_build(
		const t_hunt_series_bucket_request *request,
		t_hunt_series_output *output);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: hunt_series_bucket_roi_build — Construit l’état associé à chasse
**       série bucket roi.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: hunt_series_bucket_roi_build().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                hunt_series_bucket_roi_build(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	hunt_series_bucket_roi_build(
		const t_hunt_series_bucket_request *request,
		t_hunt_series_output *output);

#endif
