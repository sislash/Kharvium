/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_build_roi.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_build_internal.h"
#include "core/core_loot_aggregate.h"
#include "core/core_roi.h"

/*
** Rôle: hunt_series_roi_add — Ajoute l’état associé à chasse série roi.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: state — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : state.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_money_add_clamped(),
**            core_money_multiply_long_clamped().
** Appelants: hunt_series_roi_emit(), hunt_series_roi_prefix().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_roi.c -> hunt_series_roi_add() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_roi_add(
	const t_hunt_series_bucket_request *request,
	t_hunt_series_build_state *state, int index)
{
	const t_hs_bucket	*bucket;

	bucket = &request->series->buckets[index];
	state->money = core_money_add_clamped(state->money, bucket->loot_uPED);
	if (request->series->core.expense_total_uPED != 0)
		state->logged = core_money_add_clamped(state->logged,
				bucket->expense_uPED);
	if (request->cost_shot_uped > 0 && bucket->shots > 0)
		state->model = core_money_add_clamped(state->model,
				core_money_multiply_long_clamped(request->cost_shot_uped,
					(long)bucket->shots));
}

/*
** Rôle: hunt_series_roi_prefix — Calcule et retourne roi prefix à partir des
**       paramètres fournis sans modifier les entrées déclarées en lecture
**       seule.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: state — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : state.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_roi_add().
** Appelants: hunt_series_bucket_roi_build().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_roi.c -> hunt_series_roi_prefix() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_roi_prefix(
	const t_hunt_series_bucket_request *request,
	t_hunt_series_build_state *state)
{
	state->index = 0;
	while (state->index < state->start)
	{
		hunt_series_roi_add(request, state, state->index);
		state->index++;
	}
}

/*
** Rôle: hunt_series_roi_emit — Émet la donnée ou l’événement produit par
**       chasse série roi.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: state — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : output, state.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_cost_pick_maximum(),
**            core_roi_percent(), hunt_series_roi_add().
** Appelants: hunt_series_bucket_roi_build().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_roi.c -> hunt_series_roi_emit() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU, quantité, secondes/timestamp.
** Performance: boucles while locales=1; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_roi_emit(
	const t_hunt_series_bucket_request *request,
	t_hunt_series_output *output, t_hunt_series_build_state *state)
{
	t_money	cost;
	long	absolute;

	while (state->index < request->series->count
		&& state->count < HS_MAX_POINTS)
	{
		hunt_series_roi_add(request, state, state->index);
		cost = core_cost_pick_maximum(state->logged, state->model);
		output->values[state->count] = core_roi_percent(state->money, cost);
		if (output->values[state->count] > state->maximum)
			state->maximum = output->values[state->count];
		absolute = request->series->first_bucket + state->index;
		output->x_seconds[state->count] = (int)(absolute
				* (long)request->series->bucket_sec);
		state->count++;
		state->index++;
	}
}

/*
** Rôle: hunt_series_bucket_roi_build — Construit l’état associé à chasse
**       série bucket roi.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_bucket_start(),
**            hunt_series_output_prepare(), hunt_series_roi_emit(),
**            hunt_series_roi_prefix().
** Appelants: hunt_series_build_bucket().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_roi.c -> hunt_series_bucket_roi_build() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_series_bucket_roi_build(
	const t_hunt_series_bucket_request *request,
	t_hunt_series_output *output)
{
	t_hunt_series_build_state	state;

	if (!hunt_series_output_prepare(request->series, output))
		return (0);
	if (request->series->count <= 0)
		return (1);
	state = (t_hunt_series_build_state){0};
	state.start = hunt_series_bucket_start(request->series,
			request->last_n_buckets);
	hunt_series_roi_prefix(request, &state);
	state.index = state.start;
	hunt_series_roi_emit(request, output, &state);
	output->count = state.count;
	output->maximum = state.maximum;
	return (1);
}
