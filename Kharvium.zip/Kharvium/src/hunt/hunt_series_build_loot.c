/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hunt_series_build_loot.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hunt_series_build_internal.h"
#include "core/core_loot_aggregate.h"
#include "core/core_roi.h"
#include "common/money.h"

/*
** Rôle: hunt_series_loot_valid — Vérifie si loot possède l’état valide
**       attendu avant de poursuivre l’opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: index — indice de l’élément ciblé dans la collection
**            concernée.
** Paramètre: has_kills — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_build_loot(), hunt_series_loot_prefix().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_loot.c -> hunt_series_loot_valid() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	hunt_series_loot_valid(
	const t_hunt_series_loot_request *request, int index, int has_kills)
{
	if (request->series->loot_ev_uPED[index] <= 0)
		return (0);
	if (has_kills && !request->series->loot_ev_has_kill[index])
		return (0);
	return (1);
}

/*
** Rôle: hunt_series_loot_prefix — Met à jour loot prefix en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: state — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: has_kills — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : state.
** Invariants: les accès indexés sont bornés avant lecture ou écriture; un
**             kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_money_add_clamped(),
**            hunt_series_loot_valid().
** Appelants: hunt_series_build_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_loot.c -> hunt_series_loot_prefix() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_loot_prefix(
	const t_hunt_series_loot_request *request,
	t_hunt_series_build_state *state, int has_kills)
{
	state->index = 0;
	while (request->cumulative && state->index < state->start)
	{
		if (hunt_series_loot_valid(request, state->index, has_kills))
			state->money = core_money_add_clamped(state->money,
					request->series->loot_ev_uPED[state->index]);
		state->index++;
	}
}

/*
** Rôle: hunt_series_loot_metadata — Met à jour loot metadata en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: source — source consultée pour produire le résultat sans en
**            modifier la signification.
** Paramètre: target — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_series_loot_write().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_loot.c -> hunt_series_loot_metadata() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_loot_metadata(
	const t_hunt_series_loot_request *request,
	t_hunt_series_output *output, int source, int target)
{
	if (output->group_counts)
	{
		output->group_counts[target] =
			request->series->loot_ev_group_count[source];
		if (output->group_counts[target] <= 0)
			output->group_counts[target] = 1;
	}
	if (output->kill_ids)
		output->kill_ids[target] =
			request->series->loot_ev_kill_id[source];
	if (output->has_kill)
		output->has_kill[target] =
			request->series->loot_ev_has_kill[source] != 0;
}

/*
** Rôle: hunt_series_loot_write — Écrit l’état associé à chasse série loot.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Paramètre: state — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : output, state.
** Invariants: un kill garde un horodatage unique et les objets restent
**             associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> core_money_add_clamped(),
**            hunt_series_loot_metadata(), money_to_ped_double().
** Appelants: hunt_series_build_loot().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_loot.c -> hunt_series_loot_write() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED, quantité, secondes/timestamp.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	hunt_series_loot_write(
	const t_hunt_series_loot_request *request,
	t_hunt_series_output *output, t_hunt_series_build_state *state)
{
	t_money	value;

	output->x_seconds[state->count] =
		request->series->loot_ev_sec[state->index];
	hunt_series_loot_metadata(request, output, state->index, state->count);
	value = request->series->loot_ev_uPED[state->index];
	if (request->cumulative)
	{
		state->money = core_money_add_clamped(state->money, value);
		value = state->money;
	}
	output->values[state->count] = money_to_ped_double(value);
	if (output->values[state->count] > state->maximum)
		state->maximum = output->values[state->count];
	state->count++;
}

/*
** Rôle: hunt_series_build_loot — Construit loot à partir des paramètres
**       fournis et initialise tous les champs requis avant qu’ils soient lus
**       par une autre opération.
** Paramètre: request — requête structurée contenant les paramètres
**            nécessaires à l’opération.
** Paramètre: output — série Tracker reconstruite à partir des événements de
**            chasse.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : output.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation; les accès indexés sont bornés avant lecture ou
**             écriture; un kill garde un horodatage unique et les objets
**             restent associés à la même enveloppe de loot.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> hunt_series_event_start(),
**            hunt_series_loot_prefix(), hunt_series_loot_valid(),
**            hunt_series_loot_write(), hunt_series_output_prepare().
** Appelants: hunt_chart_build_loot(), extreme_build(),
**            test_hunt_loot_context_init().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        hunt_series_build_loot.c -> hunt_series_build_loot() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=5; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	hunt_series_build_loot(const t_hunt_series_loot_request *request,
		t_hunt_series_output *output)
{
	t_hunt_series_build_state	state;
	int				has_kills;

	if (!request || !request->series
		|| !hunt_series_output_prepare(request->series, output))
		return (0);
	if (request->series->loot_ev_count <= 0)
		return (1);
	state = (t_hunt_series_build_state){0};
	has_kills = (request->series->kill_ev_count > 0);
	state.start = hunt_series_event_start(request->series->loot_ev_sec,
			request->series->loot_ev_count, request->last_minutes);
	hunt_series_loot_prefix(request, &state, has_kills);
	state.index = state.start;
	while (state.index < request->series->loot_ev_count
		&& state.count < HS_MAX_POINTS)
	{
		if (hunt_series_loot_valid(request, state.index, has_kills))
			hunt_series_loot_write(request, output, &state);
		state.index++;
	}
	output->count = state.count;
	output->maximum = state.maximum;
	return (1);
}
