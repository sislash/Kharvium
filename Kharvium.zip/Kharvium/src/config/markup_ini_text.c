/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   markup_ini_text.c                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config_internal.h"
#include "common/string_operations.h"

#include <ctype.h>
#include <string.h>

/*
** Rôle: markup_ini_is_empty_or_comment — Détermine si ini empty or comment
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: markup_ini_process_line(), markup_ini_parse_key_value().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_text.c -> markup_ini_is_empty_or_comment() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> isspace().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_ini_is_empty_or_comment(const char *text)
{
	if (!text)
		return (1);
	while (*text && isspace((unsigned char)*text))
		text++;
	return (*text == '\0' || *text == ';' || *text == '#');
}

/*
** Rôle: markup_ini_parse_section — Analyse ini section depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: markup_ini_start_section().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_text.c -> markup_ini_parse_section() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memcpy(), strchr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_ini_parse_section(const char *line, char *out, size_t size)
{
	const char	*open;
	const char	*close;
	size_t		length;

	open = strchr(line, '[');
	if (!open)
		return (0);
	close = strchr(open + 1, ']');
	if (!close)
		return (0);
	length = (size_t)(close - (open + 1));
	if (length == 0 || size == 0)
		return (0);
	if (length >= size)
		length = size - 1;
	memcpy(out, open + 1, length);
	out[length] = '\0';
	return (1);
}

/*
** Rôle: markup_ini_parse_key_value — Calcule ini touche valeur à partir des
**       entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: buffers — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : line, buffers.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_ini_is_empty_or_comment(),
**            string_copy_safe(), string_trim_left(), string_trim_right().
** Appelants: markup_ini_process_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_text.c -> markup_ini_parse_key_value() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strchr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_ini_parse_key_value(char *line, t_markup_parse_buffers *buffers)
{
	char	*equal;
	char	*text;

	text = line;
	buffers->key[0] = '\0';
	buffers->value[0] = '\0';
	string_trim_left(&text);
	string_trim_right(text);
	if (markup_ini_is_empty_or_comment(text))
		return (0);
	equal = strchr(text, '=');
	if (!equal)
		return (0);
	*equal = '\0';
	string_trim_right(text);
	string_trim_left(&text);
	string_copy_safe(buffers->key, sizeof(buffers->key), text);
	equal++;
	string_trim_left(&equal);
	string_trim_right(equal);
	string_copy_safe(buffers->value, sizeof(buffers->value), equal);
	return (1);
}

/*
** Rôle: markup_ini_parse_type — Analyse ini type depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: type — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : type.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_equal_case_insensitive().
** Appelants: markup_ini_apply_value().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_text.c -> markup_ini_parse_type() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_ini_parse_type(const char *text, t_markup_type *type)
{
	if (!text || !type)
		return (0);
	if (string_equal_case_insensitive(text, "percent"))
		*type = MARKUP_PERCENT;
	else if (string_equal_case_insensitive(text, "tt_plus"))
		*type = MARKUP_TT_PLUS;
	else if (string_equal_case_insensitive(text, "unit_value"))
		*type = MARKUP_UNIT_VALUE;
	else
		return (0);
	return (1);
}
