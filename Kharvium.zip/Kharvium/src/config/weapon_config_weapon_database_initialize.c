/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_config_weapon_database_initialize.c         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "weapon_config_modules.h"

/*
** Rôle: weapon_database_initialize — Initialise l’état associé à arme base
**       de données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_database_free(), weapon_database_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_database_initialize.c ->
**        weapon_database_initialize() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_database_initialize(t_weapon_database *db)
{
    db->items = NULL;
    db->count = 0;
    db->amps.items = NULL;
    db->amps.count = 0;
    db->player_name[0] = '\0';
}

/*
** Rôle: weapon_config_context_initialize — Initialise l’état associé à arme
**       configuration context.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> amplifier_set_defaults(),
**            weapon_stats_set_defaults().
** Appelants: weapon_database_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_database_initialize.c ->
**        weapon_config_context_initialize() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_config_context_initialize(t_parse_ctx *ctx)
{
    weapon_stats_set_defaults(&ctx->cur);
    amplifier_set_defaults(&ctx->cur_amp);
    ctx->have_section = 0;
    ctx->in_player = 0;
    ctx->in_amp = 0;
}

/*
** Rôle: weapon_config_save_previous_section — Enregistre précédent section
**       vers la destination prévue en respectant le format persistant, les
**       capacités de buffer et la propagation des erreurs.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db, ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> amplifier_database_append(),
**            weapon_database_append().
** Appelants: weapon_database_load(), weapon_config_parse_section_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_database_initialize.c ->
**        weapon_config_save_previous_section() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_config_save_previous_section(t_weapon_database *db,
	t_parse_ctx *ctx)
{
    if (!ctx->have_section)
        return ;
    if (ctx->in_amp)
        (void)amplifier_database_append(db, &ctx->cur_amp);
    else if (!ctx->in_player)
        (void)weapon_database_append(db, &ctx->cur);
}

/*
** Rôle: weapon_config_start_section — Démarre section en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: sec — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> amplifier_set_defaults(),
**            string_copy_safe(), weapon_stats_set_defaults().
** Appelants: weapon_config_parse_section_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_database_initialize.c ->
**        weapon_config_start_section() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strncmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_config_start_section(t_parse_ctx *ctx, const char *sec)
{
    ctx->have_section = 1;
    ctx->in_player = 0;
    ctx->in_amp = 0;
    if (strcmp(sec, "PLAYER") == 0)
        ctx->in_player = 1;
    else if (strncmp(sec, "AMP:", 4) == 0)
    {
        ctx->in_amp = 1;
        amplifier_set_defaults(&ctx->cur_amp);
        string_copy_safe(ctx->cur_amp.name, sizeof(ctx->cur_amp.name), sec + 4);
    }
    else
    {
        weapon_stats_set_defaults(&ctx->cur);
        string_copy_safe(ctx->cur.name, sizeof(ctx->cur.name), sec);
    }
}

/*
** Rôle: weapon_config_parse_section_line — Analyse section ligne depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : db, ctx, p.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> weapon_config_save_previous_section(),
**            weapon_config_start_section().
** Appelants: weapon_config_process_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_database_initialize.c ->
**        weapon_config_parse_section_line() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strchr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	weapon_config_parse_section_line(t_weapon_database *db,
	t_parse_ctx *ctx, char *p)
{
    char	*end;
    char	*sec;

    end = strchr(p, ']');
    if (!end)
        return (0);
    *end = '\0';
    weapon_config_save_previous_section(db, ctx);
    sec = p + 1;
    weapon_config_start_section(ctx, sec);
    return (1);
}
