/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_custom_database.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include <string.h>

/*
** Rôle: fishing_rod_database_replace_preset — Remplace un preset de même nom
**       sans changer l'ordre du fichier ni la capacité de la base.
** Relations: strcmp().
** Appelants: fishing_rod_database_upsert_preset().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**    fishing_rod_database_replace_preset().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static int	fishing_rod_database_replace_preset(
	t_fishing_rod_database *database, const t_fishing_rod_preset *preset)
{
	size_t	index;

	index = 0;
	while (index < database->count)
	{
		if (strcmp(database->items[index].name, preset->name) == 0)
		{
			database->items[index] = *preset;
			return (1);
		}
		index++;
	}
	return (0);
}

/*
** Rôle: fishing_rod_database_upsert_preset — Valide puis ajoute/remplace un
**       montage utilisateur transactionnellement.
** Relations: fishing_rod_resolve_preset(),
**            fishing_rod_database_replace_preset(),
**            fishing_rod_database_append().
** Appelants: configurateur Fishing et tests E91.
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**    fishing_rod_database_upsert_preset().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
int	fishing_rod_database_upsert_preset(t_fishing_rod_database *database,
	const t_fishing_rod_preset *preset, const t_catalog_registry *catalog)
{
	t_fishing_rod_preset	copy;

	if (!database || !preset || !catalog)
		return (0);
	copy = *preset;
	if (!fishing_rod_resolve_preset(&copy, catalog))
		return (0);
	if (fishing_rod_database_replace_preset(database, &copy))
		return (1);
	return (fishing_rod_database_append(database, &copy));
}

/*
** Rôle: fishing_rod_component_matches_selector — Filtre un composant selon
**       kind/slot; selector négatif désigne l'ammo.
** Relations: aucune.
** Appelants: fishing_rod_database_collect_components().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**    fishing_rod_component_matches_selector().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static int	fishing_rod_component_matches_selector(
	const t_fishing_rod_component *component, int selector)
{
	if (selector < 0)
		return (component->kind == FISHING_ROD_COMPONENT_AMMO);
	return (component->kind == FISHING_ROD_COMPONENT_GEAR
		&& component->slot == (t_fishing_gear_slot)selector);
}

/*
** Rôle: fishing_rod_database_collect_components — Expose les composants d'un
**       slot dans l'ordre stable du fichier pour la liste UI.
** Relations: fishing_rod_component_matches_selector().
** Appelants: configurateur Fishing et tests E91.
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**    fishing_rod_database_collect_components().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
size_t	fishing_rod_database_collect_components(
	const t_fishing_rod_database *database, int selector,
	const t_fishing_rod_component **output, size_t capacity)
{
	size_t	index;
	size_t	count;

	if (!database || !output)
		return (0);
	index = 0;
	count = 0;
	while (index < database->component_count && count < capacity)
	{
		if (fishing_rod_component_matches_selector(
				&database->components[index], selector))
			output[count++] = &database->components[index];
		index++;
	}
	return (count);
}
