/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_rods.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config/fishing_rod_config.h"
#include <string.h>

/*
** Rôle: fishing_rod_database_default_for_rod — Retourne le premier montage
**       complet déclaré pour une canne donnée afin d'offrir une sélection
**       directe de Rod comparable au picker des armes.
** Paramètre: database — base validée contenant les presets LOADOUT.
** Paramètre: rod_name — nom canonique exact de la canne recherchée.
** Retour: pointeur interne vers le preset par défaut, ou NULL si absent.
** Effets: aucun.
** Invariants: le premier preset complet du fichier reste le défaut stable;
**             aucun montage incomplet n'est proposé automatiquement.
** Relations: strcmp().
** Appelants: picker Fishing et tests de sélection directe E107.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**        fishing_rod_database_default_for_rod().
** Dépendances: base fishing_rods.ini déjà validée.
** Mémoire: aucune allocation; pointeur lié à la durée de vie de database.
** État partagé: lecture seule.
** Concurrence: réentrante pour une base non modifiée simultanément.
** I/O: aucune.
** Unités: aucune.
** Performance: O(nombre de presets).
** Portabilité: C99 Windows/Linux.
*/
const t_fishing_rod_preset	*fishing_rod_database_default_for_rod(
		const t_fishing_rod_database *database, const char *rod_name)
{
	size_t	index;

	if (!database || !rod_name || !rod_name[0])
		return (NULL);
	index = 0;
	while (index < database->count)
	{
		if (database->items[index].complete
			&& strcmp(database->items[index].rod_name, rod_name) == 0)
			return (&database->items[index]);
		index++;
	}
	return (NULL);
}

/*
** Rôle: fishing_rod_output_has — Indique si une Rod est déjà représentée
**       dans la liste de presets par défaut construite pour le picker.
** Paramètre: output — tableau des presets déjà retenus.
** Paramètre: count — nombre de pointeurs valides dans output.
** Paramètre: rod_name — nom canonique de la canne recherchée.
** Retour: 1 si la canne existe déjà, sinon 0.
** Effets: aucun.
** Invariants: seuls les indices strictement inférieurs à count sont lus.
** Relations: strcmp().
** Appelants: fishing_rod_database_collect_default_rods().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_output_has().
** Dépendances: noms de Rod non NULL provenant de presets validés.
** Mémoire: aucune allocation.
** État partagé: lecture seule.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: nombre de presets.
** Performance: O(count).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_output_has(const t_fishing_rod_preset **output,
		size_t count, const char *rod_name)
{
	size_t	index;

	index = 0;
	while (index < count)
	{
		if (strcmp(output[index]->rod_name, rod_name) == 0)
			return (1);
		index++;
	}
	return (0);
}

/*
** Rôle: fishing_rod_database_collect_default_rods — Construit la liste des
**       cannes uniques sélectionnables; chaque ligne pointe vers son premier
**       montage complet afin qu'un clic produise immédiatement un loadout.
** Paramètre: database — base de presets Fishing validée.
** Paramètre: output — tableau recevant un preset par canne unique.
** Paramètre: capacity — nombre maximal de pointeurs inscriptibles.
** Retour: nombre de cannes uniques effectivement placées dans output.
** Effets: écrit uniquement les pointeurs output[0..retour-1].
** Invariants: l'ordre suit fishing_rods.ini; deux presets d'une même Rod ne
**             créent jamais deux lignes dans le picker principal.
** Relations: fishing_rod_output_has().
** Appelants: fishing_rod_picker_fill_items() et tests E107.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**        fishing_rod_database_collect_default_rods().
** Dépendances: noms de Rod canoniques des presets validés.
** Mémoire: aucune allocation dynamique.
** État partagé: lecture seule.
** Concurrence: réentrante pour une base stable.
** I/O: aucune.
** Unités: nombre de cannes.
** Performance: O(n²) au pire; catalogue Fishing de petite taille.
** Portabilité: C99 Windows/Linux.
*/
size_t	fishing_rod_database_collect_default_rods(
		const t_fishing_rod_database *database,
		const t_fishing_rod_preset **output, size_t capacity)
{
	const t_fishing_rod_preset	*preset;
	size_t				index;
	size_t				count;

	if (!database || !output || capacity == 0)
		return (0);
	index = 0;
	count = 0;
	while (index < database->count && count < capacity)
	{
		preset = &database->items[index++];
		if (preset->complete && preset->rod_name[0]
			&& !fishing_rod_output_has(output, count, preset->rod_name))
			output[count++] = preset;
	}
	return (count);
}
