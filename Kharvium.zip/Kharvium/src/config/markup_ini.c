/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   markup_ini.c                                      +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/31                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config_internal.h"
#include "config/markup_ini.h"

#include <stdio.h>

/*
** Rôle: markup_ini_parse_stream — Analyse ini stream depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db, file,
**         context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_ini_context_flush(),
**            markup_ini_process_line().
** Appelants: markup_ini_parse_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini.c -> markup_ini_parse_stream() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> ferror(), fgets().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	markup_ini_parse_stream(t_markup_db *db, FILE *file,
		t_ini_ctx *context)
{
	char			buffer[512];
	t_markup_parse_buffers	buffers;

	while (fgets(buffer, sizeof(buffer), file))
	{
		if (markup_ini_process_line(db, context, buffer, &buffers) != 0)
			return (-1);
	}
	if (ferror(file) || markup_ini_context_flush(db, context) != 0)
		return (-1);
	return (0);
}

/*
** Rôle: markup_ini_parse_file — Analyse ini depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_ini_context_reset(),
**            markup_ini_parse_stream().
** Appelants: markup_database_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini.c -> markup_ini_parse_file() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_ini_parse_file(t_markup_db *db, const char *path)
{
	FILE		*file;
	t_ini_ctx	context;
	int		result;

	if (!db || !path)
		return (-1);
	file = fopen(path, "rb");
	if (!file)
		return (-1);
	markup_ini_context_reset(&context);
	result = markup_ini_parse_stream(db, file, &context);
	fclose(file);
	return (result);
}
