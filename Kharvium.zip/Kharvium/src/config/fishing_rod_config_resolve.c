/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_resolve.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"

/*
** Rôle: fishing_rod_resolve_gear — Résout un nom canonique et vérifie que
**       l'item appartient exactement au slot attendu du montage.
** Retour: gear canonique const ou NULL si nom/slot invalide.
** Effets: aucun.
** Invariants: Reel, Blank, Line et Lure ne peuvent pas être intervertis.
** Relations: catalog_registry_find_fishing_gear_by_name().
** Appelants: fishing_rod_resolve_standard(), fishing_rod_resolve_preset().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_resolve_gear().
** Dépendances: catalogue Fishing local.
** Mémoire: aucune; pointeur détenu par catalog.
** État partagé: aucun.
** Concurrence: réentrante en lecture seule.
** I/O: aucune.
** Unités: slot et ID canoniques.
** Performance: O(n) catalogue gear.
** Portabilité: C99 Windows/Linux.
*/
const t_catalog_fishing_gear	*fishing_rod_resolve_gear(
	const t_catalog_registry *catalog, const char *name,
	t_fishing_gear_slot slot)
{
	const t_catalog_fishing_gear	*gear;

	gear = catalog_registry_find_fishing_gear_by_name(catalog, name);
	if (!gear || gear->slot != slot)
		return (NULL);
	return (gear);
}

/*
** Rôle: fishing_rod_resolve_ammo — Résout l'ammo Fishing par nom exact sans
**       confondre Spool Cell et Default Restricted Spool Cell.
** Retour: définition ammo const ou NULL si absente.
** Effets: aucun.
** Invariants: la résolution par nom ne réalise aucune substitution.
** Relations: catalog_registry_find_fishing_ammo_by_name().
** Appelants: fishing_rod_resolve_standard().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_resolve_ammo().
** Dépendances: catalogue Fishing ammo local.
** Mémoire: aucune; pointeur détenu par catalog.
** État partagé: aucun.
** Concurrence: réentrante en lecture seule.
** I/O: aucune.
** Unités: ID canonique d'ammo.
** Performance: O(n) catalogue ammo.
** Portabilité: C99 Windows/Linux.
*/
const t_catalog_fishing_ammo	*fishing_rod_resolve_ammo(
	const t_catalog_registry *catalog, const char *name)
{
	if (!catalog || !name || !name[0])
		return (NULL);
	return (catalog_registry_find_fishing_ammo_by_name(catalog, name));
}

/*
** Rôle: fishing_rod_ammo_matches_rod — Vérifie qu'une ammo déclarée peut
**       alimenter la canne sans confondre identité et variante restreinte.
** Retour: 1 si l'ammo attendue ou son alternative Restricted est valide.
** Effets: aucun.
** Invariants: Restricted remplace uniquement une Spool Cell normale; aucune
**             autre substitution d'ammo n'est autorisée.
** Relations: catalog_registry_find_fishing_ammo().
** Appelants: fishing_rod_resolve_standard().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_ammo_matches_rod().
** Dépendances: type canonique de l'ammo référencée par la Rod.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante en lecture seule.
** I/O: aucune.
** Unités: type et ID canoniques d'ammo.
** Performance: O(n) sur le petit catalogue ammo.
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_ammo_matches_rod(const t_catalog_registry *catalog,
	const t_catalog_fishing_gear *rod, const t_catalog_fishing_ammo *ammo)
{
	const t_catalog_fishing_ammo	*expected;

	if (!catalog || !rod || !ammo)
		return (0);
	if (ammo->item_type_id == rod->ammo_item_type_id)
		return (1);
	expected = catalog_registry_find_fishing_ammo(catalog,
			rod->ammo_item_type_id);
	if (!expected || expected->kind != FISHING_AMMO_SPOOL_CELL)
		return (0);
	return (ammo->kind == FISHING_AMMO_RESTRICTED_SPOOL_CELL);
}

/*
** Rôle: fishing_rod_resolve_component — Valide une section composant v2
**       contre le catalogue canonique local et conserve son ID stable.
** Retour: 1 si le nom/slot ou l'ammo correspondent, 0 sinon.
** Effets: renseigne component->item_id uniquement sur succès.
** Invariants: une section GEAR respecte son slot; une section AMMO ne peut
**             jamais résoudre un gear portant le même texte.
** Relations: fishing_rod_resolve_gear(), fishing_rod_resolve_ammo().
** Appelants: fishing_rod_finish_section().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_resolve_component().
** Dépendances: catalogues Fishing locaux packagés.
** Mémoire: aucune allocation.
** État partagé: aucun.
** Concurrence: réentrante pour composants distincts.
** I/O: aucune.
** Unités: ID canonique.
** Performance: O(n) catalogue Fishing.
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_resolve_component(t_fishing_rod_component *component,
	const t_catalog_registry *catalog)
{
	const t_catalog_fishing_gear	*gear;
	const t_catalog_fishing_ammo	*ammo;

	if (!component || !catalog || !component->name[0])
		return (0);
	if (component->kind == FISHING_ROD_COMPONENT_AMMO)
	{
		ammo = fishing_rod_resolve_ammo(catalog, component->name);
		if (!ammo)
			return (0);
		component->item_id = ammo->item_type_id;
		return (1);
	}
	if (component->kind != FISHING_ROD_COMPONENT_GEAR)
		return (0);
	gear = fishing_rod_resolve_gear(catalog, component->name, component->slot);
	if (!gear)
		return (0);
	component->item_id = gear->item_type_id;
	return (1);
}
