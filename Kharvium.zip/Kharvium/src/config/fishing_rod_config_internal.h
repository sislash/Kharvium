/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_internal.h                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FISHING_ROD_CONFIG_INTERNAL_H
# define FISHING_ROD_CONFIG_INTERNAL_H

# include "config/fishing_rod_config.h"
# include <stdio.h>

typedef enum e_fishing_rod_section_kind
{
	FISHING_ROD_SECTION_NONE = 0,
	FISHING_ROD_SECTION_LOADOUT = 1,
	FISHING_ROD_SECTION_GEAR = 2,
	FISHING_ROD_SECTION_AMMO = 3
}   t_fishing_rod_section_kind;

typedef struct s_fishing_rod_parse_context
{
	t_fishing_rod_database		*database;
	const t_catalog_registry	*catalog;
	t_fishing_rod_preset		current;
	t_fishing_rod_component		component;
	t_fishing_rod_section_kind	section_kind;
	int				failed;
}   t_fishing_rod_parse_context;

void	fishing_rod_database_initialize(t_fishing_rod_database *database);
int	fishing_rod_database_append(t_fishing_rod_database *database,
		const t_fishing_rod_preset *preset);
int	fishing_rod_database_append_component(t_fishing_rod_database *database,
		const t_fishing_rod_component *component);
int	fishing_rod_copy_value(char *destination, size_t capacity,
		const char *value);
int	fishing_rod_apply_pair(t_fishing_rod_preset *preset, const char *key,
		const char *value);
int	fishing_rod_finish_section(t_fishing_rod_parse_context *context);
int	fishing_rod_open_section(t_fishing_rod_parse_context *context,
		char *line);
int	fishing_rod_parse_line(t_fishing_rod_parse_context *context, char *line);
int	fishing_rod_parse_stream(t_fishing_rod_parse_context *context,
		FILE *stream);
int	fishing_rod_resolve_preset(t_fishing_rod_preset *preset,
		const t_catalog_registry *catalog);
int	fishing_rod_resolve_component(t_fishing_rod_component *component,
		const t_catalog_registry *catalog);
int	fishing_rod_write_components(FILE *stream,
		const t_fishing_rod_database *database);
const t_catalog_fishing_gear	*fishing_rod_resolve_gear(
		const t_catalog_registry *catalog, const char *name,
		t_fishing_gear_slot slot);
const t_catalog_fishing_ammo	*fishing_rod_resolve_ammo(
		const t_catalog_registry *catalog, const char *name);
int	fishing_rod_ammo_matches_rod(const t_catalog_registry *catalog,
		const t_catalog_fishing_gear *rod,
		const t_catalog_fishing_ammo *ammo);

#endif
