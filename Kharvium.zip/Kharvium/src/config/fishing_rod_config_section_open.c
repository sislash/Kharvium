/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_section_open.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include "common/string_operations.h"
#include <string.h>

/*
** Rôle: fishing_rod_section_slot — Convertit un préfixe v2 en slot canonique.
** Retour: slot Rod/Reel/Blank/Line/Lure ou UNKNOWN.
** Effets: aucun.
** Invariants: aucun alias implicite n'est accepté.
** Relations: strcmp().
** Appelants: fishing_rod_open_component().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_section_slot().
** Dépendances: enum Fishing gear.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: enum slot.
** Performance: O(1) pratique.
** Portabilité: C99 Windows/Linux.
*/
static t_fishing_gear_slot	fishing_rod_section_slot(const char *prefix)
{
	if (strcmp(prefix, "ROD") == 0)
		return (FISHING_GEAR_SLOT_ROD);
	if (strcmp(prefix, "REEL") == 0)
		return (FISHING_GEAR_SLOT_REEL);
	if (strcmp(prefix, "BLANK") == 0)
		return (FISHING_GEAR_SLOT_BLANK);
	if (strcmp(prefix, "LINE") == 0)
		return (FISHING_GEAR_SLOT_LINE);
	if (strcmp(prefix, "LURE") == 0)
		return (FISHING_GEAR_SLOT_LURE);
	return (FISHING_GEAR_SLOT_UNKNOWN);
}
/*
** Rôle: fishing_rod_open_loadout — Initialise une section LOADOUT v1/v2.
** Retour: 1 si le nom tient sans troncature, 0 sinon.
** Effets: remplit current.name et section_kind.
** Invariants: un nom vide est rejeté par l'appelant.
** Relations: fishing_rod_copy_value().
** Appelants: fishing_rod_open_section().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_open_loadout().
** Dépendances: structure preset.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: contexte mono-propriétaire.
** I/O: aucune.
** Unités: chaîne.
** Performance: O(longueur du nom).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_open_loadout(t_fishing_rod_parse_context *context,
	const char *name)
{
	context->section_kind = FISHING_ROD_SECTION_LOADOUT;
	return (fishing_rod_copy_value(context->current.name,
			sizeof(context->current.name), name));
}
/*
** Rôle: fishing_rod_open_component — Initialise une section composant v2.
** Retour: 1 si le préfixe/nom est valide, 0 sinon.
** Effets: configure kind/slot/name de component et section_kind.
** Invariants: AMMO est distinct des cinq slots gear.
** Relations: fishing_rod_section_slot(), fishing_rod_copy_value(), strcmp().
** Appelants: fishing_rod_open_section().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_open_component().
** Dépendances: modèle component v2.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: contexte mono-propriétaire.
** I/O: aucune.
** Unités: slot et nom canonique.
** Performance: O(longueur du nom).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_open_component(t_fishing_rod_parse_context *context,
	const char *prefix, const char *name)
{
	t_fishing_gear_slot	slot;

	if (strcmp(prefix, "AMMO") == 0)
	{
		context->component.kind = FISHING_ROD_COMPONENT_AMMO;
		context->section_kind = FISHING_ROD_SECTION_AMMO;
	}
	else
	{
		slot = fishing_rod_section_slot(prefix);
		if (slot == FISHING_GEAR_SLOT_UNKNOWN)
			return (0);
		context->component.kind = FISHING_ROD_COMPONENT_GEAR;
		context->component.slot = slot;
		context->section_kind = FISHING_ROD_SECTION_GEAR;
	}
	return (fishing_rod_copy_value(context->component.name,
			sizeof(context->component.name), name));
}
/*
** Rôle: fishing_rod_split_section — Découpe [TYPE:nom] en préfixe et nom.
** Retour: 1 si les deux parties sont non vides, 0 sinon.
** Effets: remplace ':' et ']' par NUL, puis retourne des pointeurs internes.
** Invariants: une section sans ':' n'appartient pas au schéma Fishing.
** Relations: strlen(), strchr(), string_trim_left(), string_trim_right().
** Appelants: fishing_rod_open_section().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_split_section().
** Dépendances: syntaxe INI locale.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante pour buffers distincts.
** I/O: aucune.
** Unités: aucune.
** Performance: O(longueur section).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_split_section(char *line, char **prefix, char **name)
{
	char	*separator;
	size_t	length;

	length = strlen(line);
	if (length < 5 || line[0] != '[' || line[length - 1] != ']')
		return (0);
	line[length - 1] = '\0';
	separator = strchr(line + 1, ':');
	if (!separator)
		return (0);
	*separator = '\0';
	*prefix = line + 1;
	*name = separator + 1;
	string_trim_right(*prefix);
	string_trim_left(prefix);
	string_trim_right(*name);
	string_trim_left(name);
	return ((*prefix)[0] != '\0' && (*name)[0] != '\0');
}
/*
** Rôle: fishing_rod_open_section — Ouvre LOADOUT ou composant après avoir
**       finalisé atomiquement la section précédente.
** Retour: 1 si la nouvelle section est valide, 0 sinon.
** Effets: modifie le contexte courant.
** Invariants: schéma v1 LOADOUT reste accepté; v2 ajoute six types composants.
** Relations: fishing_rod_split_section(), fishing_rod_finish_section(),
**            fishing_rod_open_loadout(), fishing_rod_open_component().
** Appelants: fishing_rod_parse_line().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_open_section().
** Dépendances: schéma fishing_rods.ini v2 rétrocompatible.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: contexte mono-propriétaire.
** I/O: aucune.
** Unités: aucune.
** Performance: O(longueur section + validation précédente).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_open_section(t_fishing_rod_parse_context *context,
	char *line)
{
	char	*prefix;
	char	*name;

	if (!fishing_rod_split_section(line, &prefix, &name))
		return (0);
	if (!fishing_rod_finish_section(context))
		return (0);
	if (strcmp(prefix, "LOADOUT") == 0)
		return (fishing_rod_open_loadout(context, name));
	return (fishing_rod_open_component(context, prefix, name));
}
