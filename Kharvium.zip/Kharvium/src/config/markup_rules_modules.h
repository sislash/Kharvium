/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   markup_rules_modules.h                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MARKUP_RULES_MODULES_H
# define MARKUP_RULES_MODULES_H

# include "config/markup_rules.h"
# include "config/markup_ini.h"
# include "common/string_operations.h"
# include <stdlib.h>
# include <string.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_entry_clear — Vide l’état associé à markup entry.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: n — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : p.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_entry_clear().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_entry_clear(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	markup_entry_clear(void *p, size_t n);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_reserve — Réserve l’état associé à markup base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: need — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_reserve().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_reserve(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_database_reserve(t_markup_db *db, size_t need);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_append — Ajoute l’état associé à markup base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: r — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_append().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_append(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_database_append(t_markup_db *db, const t_markup_rule *r);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_update_existing — Met à jour database existing à
**       partir des valeurs courantes et conserve l’état partagé cohérent
**       pour la suite de la frame ou du calcul.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: r — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_update_existing().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_update_existing(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_database_update_existing(t_markup_db *db,
	const t_markup_rule *r);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_initialize — Initialise l’état associé à markup
**       base de données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_initialize(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	markup_database_initialize(t_markup_db *db);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_free — Libère l’état associé à markup base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_free(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	markup_database_free(t_markup_db *db);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_load — Charge l’état associé à markup base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_database_load(t_markup_db *db, const char *path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_get — Retourne l’état associé à markup base de
**       données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: item_name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_get().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_get(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_database_get(const t_markup_db *db, const char *item_name,
                  t_markup_rule *out);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_apply — Applique l’état associé à markup.
** Paramètre: r — objet source consulté en lecture seule par cette fonction.
** Paramètre: tt_value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_apply().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_apply(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	markup_apply(const t_markup_rule *r, double tt_value);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_default_rule — Met à jour par défaut rule en appliquant
**       explicitement les paramètres, bornes et invariants décrits par le
**       contrat de cette fonction.
** Retour: Retourne le résultat de type t_markup_rule; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_default_rule().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_default_rule(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_markup_rule	markup_default_rule(void);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_database_insert_or_update — Met à jour l’état associé à
**       markup base de données insert or.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: r — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_database_insert_or_update().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_database_insert_or_update(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_database_insert_or_update(t_markup_db *db, const t_markup_rule *r);

#endif
