/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_parse.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include "common/string_operations.h"
#include <string.h>

/*
** Rôle: fishing_rod_line_ignored — Identifie une ligne INI vide/commentée.
** Retour: 1 si la ligne doit être ignorée, 0 sinon.
** Effets: aucun.
** Invariants: ';' et '#' ouvrent un commentaire de ligne uniquement.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_rod_parse_line().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_line_ignored().
** Dépendances: syntaxe INI Fishing locale.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: aucune.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_line_ignored(const char *line)
{
	if (!line || !line[0])
		return (1);
	return (line[0] == ';' || line[0] == '#');
}
/*
** Rôle: fishing_rod_parse_pair — Sépare strictement une paire key=value.
** Retour: 1 si la clé est présente, 0 sinon.
** Effets: découpe line en deux sous-chaînes NUL-terminées.
** Invariants: aucune clé vide n'est acceptée.
** Relations: strchr(), string_trim_left(), string_trim_right().
** Appelants: fishing_rod_parse_line().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_parse_pair().
** Dépendances: helpers de chaînes bornées du projet.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante pour buffers distincts.
** I/O: aucune.
** Unités: aucune.
** Performance: O(longueur de ligne).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_parse_pair(char *line, char **key, char **value)
{
	char	*separator;

	separator = strchr(line, '=');
	if (!separator)
		return (0);
	*separator = '\0';
	*key = line;
	*value = separator + 1;
	string_trim_right(*key);
	string_trim_left(key);
	string_trim_right(*value);
	string_trim_left(value);
	return ((*key)[0] != '\0');
}
/*
** Rôle: fishing_rod_parse_line — Route une ligne vers section ou paire.
** Retour: 1 si la ligne respecte le schéma actif, 0 sinon.
** Effets: peut modifier contexte/preset courant.
** Invariants: les paires key=value n'existent que dans LOADOUT; les sections
**             composants v2 tirent leur nom directement de l'en-tête.
** Relations: string_trim_left(), string_trim_right(),
**            fishing_rod_line_ignored(), fishing_rod_open_section(),
**            fishing_rod_parse_pair(), fishing_rod_apply_pair().
** Appelants: fishing_rod_parse_stream().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_parse_line().
** Dépendances: parser INI Fishing v1/v2.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: contexte mono-propriétaire.
** I/O: aucune.
** Unités: aucune.
** Performance: O(longueur ligne).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_parse_line(t_fishing_rod_parse_context *context, char *line)
{
	char	*text;
	char	*key;
	char	*value;

	string_trim_right(line);
	text = line;
	string_trim_left(&text);
	if (fishing_rod_line_ignored(text))
		return (1);
	if (text[0] == '[')
		return (fishing_rod_open_section(context, text));
	if (context->section_kind != FISHING_ROD_SECTION_LOADOUT)
		return (0);
	if (!fishing_rod_parse_pair(text, &key, &value))
		return (0);
	return (fishing_rod_apply_pair(&context->current, key, value));
}
