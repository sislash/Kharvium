/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_parse_stream.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include <string.h>

/*
** Rôle: fishing_rod_parse_stream — Lit l'INI ligne par ligne, refuse toute
**       ligne tronquée et finalise la dernière section v1/v2 à EOF.
** Retour: 1 si tout le flux est valide et contient au moins une entrée.
** Effets: ajoute les presets validés à context->database.
** Invariants: une erreur de syntaxe ou catalogue invalide tout le fichier.
** Relations: fgets(), feof(), ferror(), strchr(),
**            fishing_rod_parse_line(), fishing_rod_finish_section().
** Appelants: fishing_rod_database_load().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_parse_stream().
** Dépendances: stdio C et parser local.
** Mémoire: allocations déléguées à database_append().
** État partagé: aucun.
** Concurrence: lecture séquentielle mono-thread.
** I/O: lecture du flux INI fourni.
** Unités: aucune.
** Performance: O(taille du fichier).
** Portabilité: C99 Windows/Linux, LF et CRLF acceptés.
*/
int	fishing_rod_parse_stream(t_fishing_rod_parse_context *context,
	FILE *stream)
{
	char	line[512];

	if (!context || !stream)
		return (0);
	while (fgets(line, sizeof(line), stream))
	{
		if (!strchr(line, '\n') && !feof(stream))
			return (0);
		if (!fishing_rod_parse_line(context, line))
			return (0);
	}
	if (ferror(stream) || !fishing_rod_finish_section(context))
		return (0);
	return (context->database->count > 0
		|| context->database->component_count > 0);
}
