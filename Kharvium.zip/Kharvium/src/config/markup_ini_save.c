/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   markup_ini_save.c                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/16                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "config/markup_rules.h"
#include <stdio.h>

/*
** Rôle: markup_database_write_type — Écrit le type d'une règle MU dans le
**       flux INI déjà ouvert par l'appelant.
** Paramètre: f — flux destination ouvert en écriture.
** Paramètre: r — règle MU consultée en lecture seule.
** Retour: Ne retourne rien; une ligne type= est écrite dans le flux.
** Effets: effectue une écriture stdio sur le flux fourni.
** Invariants: f et r sont valides pendant tout l'appel.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune fonction projet.
** Appelants: markup_database_save().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_save.c -> markup_database_write_type().
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable direct; fonction réentrante pour
**              des flux et règles indépendants.
** I/O: primitive stdio directe -> fprintf().
** Unités: type MU; aucune conversion monétaire effectuée ici.
** Performance: boucles locales=0; coût constant O(1).
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	markup_database_write_type(FILE *f, const t_markup_rule *r)
{
	if (r->type == MARKUP_TT_PLUS)
		fprintf(f, "type=tt_plus\n");
	else if (r->type == MARKUP_UNIT_VALUE)
		fprintf(f, "type=unit_value\n");
	else
		fprintf(f, "type=percent\n");
}

/*
** Rôle: markup_database_save — Sauvegarde l’état associé à markup base de
**       données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_database_write_type().
** Appelants: config_markup_save_selected(), markup_frame_delete_commit().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_save.c -> markup_database_save() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fprintf().
** Unités: pourcentage/MU, quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_database_save(const t_markup_db *db, const char *path)
{
	FILE				*f;
	size_t				i;
	const t_markup_rule	*r;
	if (!db || !path)
		return (-1);
	f = fopen(path, "wb");
	if (!f)
		return (-1);
	i = 0;
	while (i < db->count)
	{
		r = &db->items[i];
		fprintf(f, "[%s]\n", r->name);
		markup_database_write_type(f, r);
		if (r->value_known)
			fprintf(f, "value=%.10g\n\n", r->value);
		else
			fprintf(f, "value=unknown\n\n");
		i++;
	}
	fclose(f);
	return (0);
}
