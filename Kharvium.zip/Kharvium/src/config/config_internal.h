/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   config_internal.h                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CONFIG_INTERNAL_H
# define CONFIG_INTERNAL_H

# include "config/weapon_config.h"
# include "config/markup_rules.h"

typedef struct s_parse_ctx
{
    t_weapon_stats	cur;
    t_amp_stats	cur_amp;
    int			have_section;
    int			in_player;
    int			in_amp;
}	t_parse_ctx;

typedef struct s_ini_ctx
{
    t_markup_rule	cur;
    int			in_section;
    int			has_type;
    int			has_value;
}	t_ini_ctx;

typedef struct s_markup_parse_buffers
{
	char	section[128];
	char	key[64];
	char	value[256];
}t_markup_parse_buffers;

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_ini_is_empty_or_comment — Détermine si ini empty or comment
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_ini_is_empty_or_comment().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_ini_is_empty_or_comment(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_ini_is_empty_or_comment(const char *text);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_ini_parse_section — Analyse ini section depuis la source
**       fournie, contrôle le format utile et ne renseigne la destination
**       qu’avec des données validées.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: size — taille ou longueur utilisée pour borner l’accès aux
**            données.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_ini_parse_section().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_ini_parse_section(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_ini_parse_section(const char *line, char *out, size_t size);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_ini_parse_key_value — Calcule ini touche valeur à partir des
**       entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: buffers — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : line, buffers.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_ini_parse_key_value().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_ini_parse_key_value(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_ini_parse_key_value(char *line, t_markup_parse_buffers *buffers);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_ini_parse_type — Analyse ini type depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: type — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : type.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_ini_parse_type().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_ini_parse_type(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_ini_parse_type(const char *text, t_markup_type *type);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_ini_context_reset — Réinitialise l’état associé à markup ini
**       context.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_ini_context_reset().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_ini_context_reset(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	markup_ini_context_reset(t_ini_ctx *context);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_ini_context_flush — Force l’écriture de ini contexte vers la
**       destination prévue en respectant le
**       format, les bornes et la politique
**       d’erreur du module.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db, context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_ini_context_flush().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_ini_context_flush(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_ini_context_flush(t_markup_db *db, t_ini_ctx *context);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: markup_ini_process_line — Traite ini ligne en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: buffers — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db, context,
**         line, buffers.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: markup_ini_process_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                markup_ini_process_line(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	markup_ini_process_line(t_markup_db *db, t_ini_ctx *context,
		char *line, t_markup_parse_buffers *buffers);

#endif
