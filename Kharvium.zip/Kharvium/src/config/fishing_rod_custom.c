/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_custom.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include "common/string_operations.h"
#include <string.h>

/*
** Rôle: fishing_rod_preset_initialize — Initialise un draft de montage sans
**       aucune valeur économique et avec un nom borné.
** Relations: memset(), string_copy_safe().
** Appelants: configurateur Fishing et tests E91.
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_preset_initialize().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
void	fishing_rod_preset_initialize(t_fishing_rod_preset *preset,
	const char *name)
{
	if (!preset)
		return ;
	memset(preset, 0, sizeof(*preset));
	if (name)
		string_copy_safe(preset->name, sizeof(preset->name), name);
}

/*
** Rôle: fishing_rod_custom_clear_standard — Efface les attachments/ammo lors
**       du passage au Baitfishing Rod, qui n'en utilise pas.
** Relations: memset().
** Appelants: fishing_rod_preset_set_component().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**    fishing_rod_custom_clear_standard().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static void	fishing_rod_custom_clear_standard(t_fishing_rod_preset *preset)
{
	preset->reel_name[0] = '\0';
	preset->blank_name[0] = '\0';
	preset->line_name[0] = '\0';
	preset->lure_name[0] = '\0';
	preset->ammo_name[0] = '\0';
	preset->reel_id = 0;
	preset->blank_id = 0;
	preset->line_id = 0;
	preset->lure_id = 0;
	preset->ammo_id = 0;
}

/*
** Rôle: fishing_rod_custom_set_gear — Copie un gear dans le champ du slot
**       canonique correspondant sans permettre de permutation de type.
** Relations: string_copy_safe().
** Appelants: fishing_rod_preset_set_component().
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_custom_set_gear().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
static int	fishing_rod_custom_set_gear(t_fishing_rod_preset *preset,
	const t_fishing_rod_component *component)
{
	char	*target;
	size_t	capacity;

	target = NULL;
	capacity = CATALOG_NAME_CAP;
	if (component->slot == FISHING_GEAR_SLOT_ROD)
		target = preset->rod_name;
	else if (component->slot == FISHING_GEAR_SLOT_REEL)
		target = preset->reel_name;
	else if (component->slot == FISHING_GEAR_SLOT_BLANK)
		target = preset->blank_name;
	else if (component->slot == FISHING_GEAR_SLOT_LINE)
		target = preset->line_name;
	else if (component->slot == FISHING_GEAR_SLOT_LURE)
		target = preset->lure_name;
	if (!target)
		return (0);
	string_copy_safe(target, capacity, component->name);
	return (1);
}

/*
** Rôle: fishing_rod_preset_set_rod_default — Remplace la canne du draft par
**       son montage par défaut complet afin d'éviter de conserver des pièces
**       incompatibles provenant de la canne précédemment sélectionnée.
** Relations: fishing_rod_database_default_for_rod(),
**            fishing_rod_preset_set_component(), string_copy_safe().
** Appelants: configurateur Fishing E108 et tests de régression.
** Retour: 1 si la canne est appliquée, 0 si les paramètres sont invalides.
** Effets: remplace les slots du draft par le preset par défaut de la canne.
** Invariants: le nom/notes du draft utilisateur sont conservés; aucune donnée
**             économique n'est inventée ni copiée depuis une source marché.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_preset_set_rod_default().
** Dépendances: base fishing_rods.ini validée et catalogue Fishing local.
** Mémoire: buffers fixes sur pile uniquement.
** État partagé: aucun; seul preset fourni est modifié.
** Concurrence: réentrante pour des drafts distincts.
** I/O: aucune.
** Unités: noms et IDs canoniques de composants Fishing.
** Performance: O(nombre de presets) pour retrouver le défaut de la canne.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque ajoutée.
*/
int	fishing_rod_preset_set_rod_default(t_fishing_rod_preset *preset,
	const t_fishing_rod_database *database,
	const t_fishing_rod_component *component, const t_catalog_registry *catalog)
{
	const t_fishing_rod_preset	*source;
	char				name[FISHING_ROD_CONFIG_NAME_CAP];
	char				notes[FISHING_ROD_CONFIG_NOTES_CAP];

	if (!preset || !database || !component || !catalog)
		return (0);
	if (component->kind != FISHING_ROD_COMPONENT_GEAR
		|| component->slot != FISHING_GEAR_SLOT_ROD)
		return (fishing_rod_preset_set_component(preset, component, catalog));
	source = fishing_rod_database_default_for_rod(database, component->name);
	if (!source)
		return (fishing_rod_preset_set_component(preset, component, catalog));
	string_copy_safe(name, sizeof(name), preset->name);
	string_copy_safe(notes, sizeof(notes), preset->notes);
	*preset = *source;
	string_copy_safe(preset->name, sizeof(preset->name), name);
	string_copy_safe(preset->notes, sizeof(preset->notes), notes);
	return (preset->complete);
}

/*
** Rôle: fishing_rod_preset_set_component — Modifie un slot du draft puis
**       recalcule sa validité; les états incomplets restent éditables.
** Relations: catalog_registry_find_fishing_gear(),
**            fishing_rod_custom_set_gear(), fishing_rod_resolve_preset().
** Appelants: configurateur Fishing et tests E91.
** Retour: respecte le type de retour déclaré; aucun résultat caché.
** Effets: modifie uniquement les objets explicitement non const.
** Invariants: valide les préconditions et conserve les bornes locales.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_preset_set_component().
** Dépendances: API C du projet et en-têtes inclus par ce module.
** Mémoire: aucune propriété implicite; allocations suivies par leur API.
** État partagé: état mutable limité aux structures reçues explicitement.
** Concurrence: utilisée sur les objets possédés par le thread appelant.
** I/O: aucune E/S implicite au-delà des appels explicitement présents.
** Unités: conserve les unités définies par les structures manipulées.
** Performance: travail borné ou linéaire sur la collection locale.
** Portabilité: C99 portable Windows/Linux, sans C++ ni bibliothèque
**    ajoutée.
*/
int	fishing_rod_preset_set_component(t_fishing_rod_preset *preset,
	const t_fishing_rod_component *component,
	const t_catalog_registry *catalog)
{
	const t_catalog_fishing_gear	*gear;
	t_fishing_rod_preset		copy;

	if (!preset || !component || !catalog)
		return (0);
	if (component->kind == FISHING_ROD_COMPONENT_AMMO)
		string_copy_safe(preset->ammo_name, sizeof(preset->ammo_name),
			component->name);
	else if (!fishing_rod_custom_set_gear(preset, component))
		return (0);
	gear = catalog_registry_find_fishing_gear(catalog, component->item_id);
	if (gear && gear->slot == FISHING_GEAR_SLOT_ROD
		&& gear->method == FISHING_METHOD_BAITFISHING)
		fishing_rod_custom_clear_standard(preset);
	copy = *preset;
	preset->complete = fishing_rod_resolve_preset(&copy, catalog);
	if (preset->complete)
		*preset = copy;
	return (1);
}
