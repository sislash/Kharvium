/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_section.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include <string.h>

/*
** Rôle: fishing_rod_finish_loadout — Résout et stocke la section LOADOUT.
** Retour: 1 sur validation/ajout, 0 sinon.
** Effets: peut réallouer le tableau de presets.
** Invariants: aucun montage incomplet n'est conservé.
** Relations: fishing_rod_resolve_preset(), fishing_rod_database_append().
** Appelants: fishing_rod_finish_section().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_finish_loadout().
** Dépendances: catalogue et stockage INI.
** Mémoire: allocation possible via append.
** État partagé: aucun.
** Concurrence: contexte mono-propriétaire.
** I/O: aucune.
** Unités: IDs canoniques.
** Performance: O(recherches catalogue).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_finish_loadout(t_fishing_rod_parse_context *context)
{
	if (!fishing_rod_resolve_preset(&context->current, context->catalog))
		return (0);
	return (fishing_rod_database_append(context->database, &context->current));
}
/*
** Rôle: fishing_rod_finish_component — Résout et stocke une section v2.
** Retour: 1 sur validation/ajout, 0 sinon.
** Effets: peut réallouer le tableau de composants.
** Invariants: le type/slot déclaré doit correspondre au catalogue local.
** Relations: fishing_rod_resolve_component(),
**            fishing_rod_database_append_component().
** Appelants: fishing_rod_finish_section().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_finish_component().
** Dépendances: catalogue et stockage INI v2.
** Mémoire: allocation possible via append.
** État partagé: aucun.
** Concurrence: contexte mono-propriétaire.
** I/O: aucune.
** Unités: ID canonique.
** Performance: O(recherches catalogue).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_finish_component(t_fishing_rod_parse_context *context)
{
	if (!fishing_rod_resolve_component(&context->component, context->catalog))
		return (0);
	return (fishing_rod_database_append_component(context->database,
			&context->component));
}
/*
** Rôle: fishing_rod_finish_section — Finalise atomiquement la section active.
** Retour: 1 si aucune section ou si la section est entièrement valide.
** Effets: stocke l'entrée puis réinitialise les buffers de parsing.
** Invariants: aucune section partielle n'est conservée après échec.
** Relations: fishing_rod_finish_loadout(), fishing_rod_finish_component(),
**            memset().
** Appelants: fishing_rod_open_section(), fishing_rod_parse_stream().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_finish_section().
** Dépendances: schémas INI v1/v2.
** Mémoire: déléguée aux append.
** État partagé: aucun.
** Concurrence: contexte mono-propriétaire.
** I/O: aucune.
** Unités: aucune.
** Performance: O(validation de section).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_finish_section(t_fishing_rod_parse_context *context)
{
	int	ok;

	if (!context || context->section_kind == FISHING_ROD_SECTION_NONE)
		return (1);
	ok = 0;
	if (context->section_kind == FISHING_ROD_SECTION_LOADOUT)
		ok = fishing_rod_finish_loadout(context);
	else if (context->section_kind == FISHING_ROD_SECTION_GEAR
		|| context->section_kind == FISHING_ROD_SECTION_AMMO)
		ok = fishing_rod_finish_component(context);
	if (!ok)
		return (0);
	memset(&context->current, 0, sizeof(context->current));
	memset(&context->component, 0, sizeof(context->component));
	context->section_kind = FISHING_ROD_SECTION_NONE;
	return (1);
}
