/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_config_weapon_stats_set_defaults.c          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "weapon_config_modules.h"

/*
** Rôle: weapon_stats_set_defaults — Met à jour defaults à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: w — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_config_context_initialize(),
**            weapon_config_start_section().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_stats_set_defaults.c ->
**        weapon_stats_set_defaults() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_stats_set_defaults(t_weapon_stats *w)
{
	size_t i;
    memset(w, 0, sizeof(*w));
    w->markup_mu_1e4 = 10000;
    w->ammo_mu_1e4 = 10000;
    w->weapon_mu_1e4 = 0;
    w->amp_mu_1e4 = 0;
    w->amp_name[0] = '\0';
    {

        i = 0;
        while (i < WEAPON_ENHANCER_SLOTS)
        {
            w->enhancers[i].markup_mu_1e4 = 10000;
            i++;
        }
    }
}

/*
** Rôle: amplifier_set_defaults — Met à jour amplifier defaults à partir des
**       valeurs courantes et conserve l’état partagé cohérent pour la suite
**       de la frame ou du calcul.
** Paramètre: a — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : a.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_config_context_initialize(),
**            weapon_config_start_section().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_stats_set_defaults.c ->
**        amplifier_set_defaults() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	amplifier_set_defaults(t_amp_stats *a)
{
    memset(a, 0, sizeof(*a));
    a->amp_mu_1e4 = 10000;
}

/*
** Rôle: amplifier_database_append — Ajoute l’état associé à amplifier base
**       de données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: a — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_config_save_previous_section().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_stats_set_defaults.c ->
**        amplifier_database_append() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> realloc().
** Mémoire: opérations directes -> realloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	amplifier_database_append(t_weapon_database *db,
	const t_amp_stats *a)
{
    t_amp_stats	*tmp;

    tmp = (t_amp_stats *)realloc(db->amps.items,
                               (db->amps.count + 1) * sizeof(*db->amps.items));
    if (!tmp)
        return (0);
    db->amps.items = tmp;
    db->amps.items[db->amps.count] = *a;
    db->amps.count++;
    return (1);
}

/*
** Rôle: weapon_database_append — Ajoute l’état associé à arme base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: w — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_config_save_previous_section().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_stats_set_defaults.c ->
**        weapon_database_append() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> realloc().
** Mémoire: opérations directes -> realloc(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	weapon_database_append(t_weapon_database *db,
	const t_weapon_stats *w)
{
    t_weapon_stats	*tmp;

    tmp = (t_weapon_stats *)realloc(db->items,
                                (db->count + 1) * sizeof(*db->items));
    if (!tmp)
        return (0);
    db->items = tmp;
    db->items[db->count] = *w;
    db->count++;
    return (1);
}

/*
** Rôle: amplifier_database_find — Recherche l’état associé à amplifier base
**       de données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_database_link_amplifiers().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_stats_set_defaults.c ->
**        amplifier_database_find() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
const t_amp_stats	*amplifier_database_find(
	const t_weapon_database *db, const char *name)
{
    size_t	i;

    if (!db || !name || !name[0])
        return (NULL);
    i = 0;
    while (i < db->amps.count)
    {
        if (strcmp(db->amps.items[i].name, name) == 0)
            return (&db->amps.items[i]);
        i++;
    }
    return (NULL);
}
