/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_validate.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"

/*
** Rôle: fishing_rod_resolve_slot — Résout un attachment et conserve son ID
**       uniquement lorsque le slot déclaré correspond au slot attendu.
** Retour: 1 si l'attachment est valide, 0 sinon.
** Effets: écrit l'ID canonique dans output_id sur succès.
** Invariants: aucun slot ne peut être remplacé par un autre type de pièce.
** Relations: fishing_rod_resolve_gear().
** Appelants: fishing_rod_resolve_standard().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_resolve_slot().
** Dépendances: catalogue Fishing local.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: ID canonique.
** Performance: O(n) catalogue gear.
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_resolve_slot(const t_catalog_registry *catalog,
	const char *name, t_fishing_gear_slot slot, t_entity_id *output_id)
{
	const t_catalog_fishing_gear	*gear;

	gear = fishing_rod_resolve_gear(catalog, name, slot);
	if (!gear || !output_id)
		return (0);
	*output_id = gear->item_type_id;
	return (1);
}

/*
** Rôle: fishing_rod_resolve_standard — Valide les quatre attachments et
**       l'ammo d'une canne standard puis conserve leurs IDs canoniques.
** Retour: 1 si le montage standard est complet, 0 sinon.
** Effets: renseigne reel_id, blank_id, line_id, lure_id et ammo_id.
** Invariants: l'ammo est celle de la Rod ou la variante Restricted valide.
** Relations: fishing_rod_resolve_slot(), fishing_rod_ammo_matches_rod().
** Appelants: fishing_rod_resolve_preset().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_resolve_standard().
** Dépendances: slots officiels Rod/Reel/Blank/Line/Lure et catalogue local.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: IDs canoniques et quantité d'ammo référencée par la Rod.
** Performance: cinq recherches catalogue.
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_resolve_standard(t_fishing_rod_preset *preset,
	const t_catalog_registry *catalog, const t_catalog_fishing_gear *rod)
{
	const t_catalog_fishing_ammo	*ammo;

	if (!fishing_rod_resolve_slot(catalog, preset->reel_name,
			FISHING_GEAR_SLOT_REEL, &preset->reel_id))
		return (0);
	if (!fishing_rod_resolve_slot(catalog, preset->blank_name,
			FISHING_GEAR_SLOT_BLANK, &preset->blank_id))
		return (0);
	if (!fishing_rod_resolve_slot(catalog, preset->line_name,
			FISHING_GEAR_SLOT_LINE, &preset->line_id))
		return (0);
	if (!fishing_rod_resolve_slot(catalog, preset->lure_name,
			FISHING_GEAR_SLOT_LURE, &preset->lure_id))
		return (0);
	ammo = fishing_rod_resolve_ammo(catalog, preset->ammo_name);
	if (!ammo || !fishing_rod_ammo_matches_rod(catalog, rod, ammo))
		return (0);
	preset->ammo_id = ammo->item_type_id;
	return (1);
}

/*
** Rôle: fishing_rod_resolve_preset — Valide une section LOADOUT contre le
**       catalogue et distingue le Baitfishing Rod des cannes standard.
** Retour: 1 si le preset est utilisable et complet, 0 sinon.
** Effets: renseigne les IDs et le drapeau complete.
** Invariants: Baitfishing n'invente ni attachments ni ammo; une Rod standard
**             exige Reel + Blank + Line + Lure + son ammo déclarée.
** Relations: fishing_rod_resolve_gear(), fishing_rod_resolve_standard().
** Appelants: fishing_rod_finish_section(), fishing_rod_preset_is_complete().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_resolve_preset().
** Dépendances: méthode et slots du catalogue Fishing local.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante pour presets distincts.
** I/O: aucune.
** Unités: IDs canoniques.
** Performance: O(recherches catalogue).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_resolve_preset(t_fishing_rod_preset *preset,
	const t_catalog_registry *catalog)
{
	const t_catalog_fishing_gear	*rod;

	if (!preset || !catalog || !preset->name[0])
		return (0);
	rod = fishing_rod_resolve_gear(catalog, preset->rod_name,
			FISHING_GEAR_SLOT_ROD);
	if (!rod)
		return (0);
	preset->rod_id = rod->item_type_id;
	preset->complete = 0;
	if (rod->method == FISHING_METHOD_BAITFISHING)
	{
		preset->complete = 1;
		return (1);
	}
	if (!fishing_rod_resolve_standard(preset, catalog, rod))
		return (0);
	preset->complete = 1;
	return (1);
}

/*
** Rôle: fishing_rod_preset_is_complete — Réévalue un preset sans modifier
**       l'original afin de vérifier qu'il reste compatible avec le catalogue.
** Retour: 1 si le montage est complet selon le schéma courant, 0 sinon.
** Effets: aucun sur preset; utilise une copie locale temporaire.
** Invariants: le drapeau persistant complete n'est jamais cru aveuglément.
** Relations: fishing_rod_resolve_preset().
** Appelants: UI/picker Fishing et tests de configuration.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_preset_is_complete().
** Dépendances: validation canonique des composants Fishing.
** Mémoire: aucune allocation.
** État partagé: aucun.
** Concurrence: réentrante en lecture seule.
** I/O: aucune.
** Unités: booléen de complétude.
** Performance: O(recherches catalogue).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_preset_is_complete(const t_fishing_rod_preset *preset,
	const t_catalog_registry *catalog)
{
	t_fishing_rod_preset	copy;

	if (!preset)
		return (0);
	copy = *preset;
	return (fishing_rod_resolve_preset(&copy, catalog));
}
