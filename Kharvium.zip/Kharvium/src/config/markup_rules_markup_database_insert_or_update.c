/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   markup_rules_markup_database_insert_or_update.c    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "markup_rules_modules.h"

/*
** Rôle: markup_database_insert_or_update — Met à jour l’état associé à
**       markup base de données insert or.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: r — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_database_append(),
**            markup_database_update_existing().
** Appelants: markup_ini_context_flush().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_rules_markup_database_insert_or_update.c ->
**        markup_database_insert_or_update() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_database_insert_or_update(t_markup_db *db, const t_markup_rule *r)
{
    int	updated;

    if (!db || !r)
        return (-1);
    updated = markup_database_update_existing(db, r);
    if (updated == 1)
        return (0);
    return (markup_database_append(db, r));
}
