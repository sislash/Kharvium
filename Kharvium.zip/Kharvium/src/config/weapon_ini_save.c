/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_ini_save.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "weapon_ini_write.h"

/*
** Rôle: weapon_ini_write_player — Écrit ini player vers la destination prévue
**       en respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_database_save().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_ini_save.c -> weapon_ini_write_player() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	weapon_ini_write_player(FILE *file, const t_weapon_database *db)
{
	if (!db->player_name[0])
		return ;
	fprintf(file, "[PLAYER]\n");
	fprintf(file, "name=%s\n\n", db->player_name);
}

/*
** Rôle: weapon_ini_write_amplifiers — Écrit ini amplifiers vers la
**       destination prévue en respectant le format persistant, les capacités
**       de buffer et la propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> weapon_ini_write_markup(),
**            weapon_ini_write_money().
** Appelants: weapon_database_save().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_ini_save.c -> weapon_ini_write_amplifiers() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: pourcentage/MU, quantité.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	weapon_ini_write_amplifiers(FILE *file,
	const t_weapon_database *db)
{
	size_t	index;

	index = 0;
	while (index < db->amps.count)
	{
		fprintf(file, "[AMP:%s]\n", db->amps.items[index].name);
		weapon_ini_write_money(file, "amp_ammo_shot",
			db->amps.items[index].amp_ammo_shot);
		weapon_ini_write_money(file, "amp_decay_shot",
			db->amps.items[index].amp_decay_shot);
		weapon_ini_write_markup(file, "amp_mu",
			db->amps.items[index].amp_mu_1e4);
		if (db->amps.items[index].notes[0])
			fprintf(file, "notes=%s\n", db->amps.items[index].notes);
		fprintf(file, "\n");
		index++;
	}
}

/*
** Rôle: weapon_ini_write_weapon — Écrit ini vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: weapon — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> weapon_ini_write_double(),
**            weapon_ini_write_enhancers(), weapon_ini_write_markup(),
**            weapon_ini_write_money(), weapon_ini_write_tier().
** Appelants: weapon_ini_write_weapons().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_ini_save.c -> weapon_ini_write_weapon() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=5; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	weapon_ini_write_weapon(FILE *file, const t_weapon_stats *weapon)
{
	fprintf(file, "[%s]\n", weapon->name);
	weapon_ini_write_double(file, "dpp", weapon->dpp);
	weapon_ini_write_money(file, "ammo_shot", weapon->ammo_shot);
	weapon_ini_write_money(file, "decay_shot", weapon->decay_shot);
	weapon_ini_write_money(file, "amp_ammo_shot", weapon->amp_ammo_shot);
	weapon_ini_write_money(file, "amp_decay_shot", weapon->amp_decay_shot);
	weapon_ini_write_markup(file, "markup", weapon->markup_mu_1e4);
	weapon_ini_write_markup(file, "ammo_mu", weapon->ammo_mu_1e4);
	weapon_ini_write_markup(file, "weapon_mu", weapon->weapon_mu_1e4);
	weapon_ini_write_markup(file, "amp_mu", weapon->amp_mu_1e4);
	weapon_ini_write_tier(file, weapon->tier_x100);
	weapon_ini_write_enhancers(file, weapon);
	if (weapon->amp_name[0])
		fprintf(file, "amp=%s\n", weapon->amp_name);
	if (weapon->notes[0])
		fprintf(file, "notes=%s\n", weapon->notes);
	fprintf(file, "\n");
}

/*
** Rôle: weapon_ini_write_weapons — Écrit ini weapons vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : file.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> weapon_ini_write_weapon().
** Appelants: weapon_database_save().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_ini_save.c -> weapon_ini_write_weapons() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	weapon_ini_write_weapons(FILE *file, const t_weapon_database *db)
{
	size_t	index;

	index = 0;
	while (index < db->count)
	{
		weapon_ini_write_weapon(file, &db->items[index]);
		index++;
	}
}

/*
** Rôle: weapon_database_save — Sauvegarde l’état associé à arme base de
**       données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> weapon_ini_write_amplifiers(),
**            weapon_ini_write_player(), weapon_ini_write_weapons().
** Appelants: weapon_config_save_selected(), weapon_frame_delete_commit(),
**            run_weapon_roundtrip().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_ini_save.c -> weapon_database_save() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	weapon_database_save(const t_weapon_database *db, const char *path)
{
	FILE	*file;

	if (!db || !path)
		return (0);
	file = fopen(path, "wb");
	if (!file)
		return (0);
	weapon_ini_write_player(file, db);
	weapon_ini_write_amplifiers(file, db);
	weapon_ini_write_weapons(file, db);
	fclose(file);
	return (1);
}
