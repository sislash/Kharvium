/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_ini_write_enhancers.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "weapon_ini_write.h"

/*
** Rôle: weapon_ini_write_enhancer — Écrit ini Enhancer vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: slot — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> weapon_ini_write_markup(),
**            weapon_ini_write_money().
** Appelants: weapon_ini_write_enhancers().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_ini_write_enhancers.c -> weapon_ini_write_enhancer() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: uPED, pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_ini_write_enhancer(FILE *file, const t_enhancer_slot *value,
	int slot)
{
	char	key[64];

	if (!file || !value || !value->installed || !value->name[0])
		return ;
	snprintf(key, sizeof(key), "enhancer%d", slot + 1);
	fprintf(file, "%s=%s\n", key, value->name);
	snprintf(key, sizeof(key), "enhancer%d_tt", slot + 1);
	weapon_ini_write_money(file, key, value->tt_uPED);
	snprintf(key, sizeof(key), "enhancer%d_cost", slot + 1);
	weapon_ini_write_money(file, key, value->acquisition_cost_uPED);
	snprintf(key, sizeof(key), "enhancer%d_mu", slot + 1);
	weapon_ini_write_markup(file, key, value->markup_mu_1e4);
	snprintf(key, sizeof(key), "enhancer%d_breaks", slot + 1);
	fprintf(file, "%s=%llu\n", key,
		(unsigned long long)value->break_count);
}

/*
** Rôle: weapon_ini_write_enhancers — Écrit ini Enhancers vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: weapon — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : file.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> weapon_ini_write_enhancer().
** Appelants: weapon_ini_write_weapon().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_ini_write_enhancers.c -> weapon_ini_write_enhancers()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_ini_write_enhancers(FILE *file, const t_weapon_stats *weapon)
{
	int	index;

	index = 0;
	while (index < WEAPON_ENHANCER_SLOTS)
	{
		weapon_ini_write_enhancer(file, &weapon->enhancers[index], index);
		index++;
	}
}
