/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   selected_fishing_rod.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config/selected_fishing_rod.h"
#include "common/string_operations.h"
#include <stdio.h>

/*
** Rôle: selected_fishing_rod_load — Charge le nom du preset Fishing actif
**       depuis un petit fichier texte, comme la sélection d'arme historique.
** Retour: 0 sur lecture valide, -1 si le fichier ou les arguments échouent.
** Effets: remplit output avec une ligne sans terminaison CR/LF.
** Invariants: aucune sélection n'est inventée lorsque le fichier est absent.
** Relations: fopen(), fgets(), fclose(), string_trim_line_end().
** Appelants: futur cache/picker Tracker Fishing et tests E90.
** Index: docs/FUNCTION_CALL_GRAPH.md -> selected_fishing_rod_load().
** Dépendances: stdio C et helper de chaîne du projet.
** Mémoire: aucune allocation.
** État partagé: aucun.
** Concurrence: réentrante hors accès simultané au même fichier.
** I/O: lecture d'un fichier local.
** Unités: nom de preset.
** Performance: O(longueur du nom).
** Portabilité: C99 Windows/Linux.
*/
int	selected_fishing_rod_load(const char *path, char *output,
	size_t output_size)
{
	FILE	*stream;

	if (!path || !output || output_size == 0)
		return (-1);
	output[0] = '\0';
	stream = fopen(path, "rb");
	if (!stream)
		return (-1);
	if (!fgets(output, (int)output_size, stream))
	{
		fclose(stream);
		return (-1);
	}
	fclose(stream);
	string_trim_line_end(output);
	return (0);
}

/*
** Rôle: selected_fishing_rod_save — Persiste le nom exact du preset Fishing
**       actif sans dupliquer sa composition dans les logs.
** Retour: 0 si la sélection est écrite, -1 sinon.
** Effets: remplace le fichier cible par name suivi d'un saut de ligne.
** Invariants: la composition reste uniquement dans fishing_rods.ini.
** Relations: fopen(), fprintf(), fclose().
** Appelants: futur picker Tracker Fishing et tests E90.
** Index: docs/FUNCTION_CALL_GRAPH.md -> selected_fishing_rod_save().
** Dépendances: stdio C.
** Mémoire: aucune allocation.
** État partagé: aucun.
** Concurrence: synchronisation externe sur le chemin cible.
** I/O: écriture d'un fichier local.
** Unités: nom de preset.
** Performance: O(longueur du nom).
** Portabilité: C99 Windows/Linux.
*/
int	selected_fishing_rod_save(const char *path, const char *name)
{
	FILE	*stream;
	int	ok;

	if (!path || !name || !name[0])
		return (-1);
	stream = fopen(path, "wb");
	if (!stream)
		return (-1);
	ok = fprintf(stream, "%s\n", name) >= 0;
	if (fclose(stream) != 0)
		ok = 0;
	if (!ok)
		return (-1);
	return (0);
}
