/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_ini_save.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include <stdio.h>

/*
** Rôle: fishing_rod_write_pair — Écrit une paire key=value sans conversion.
** Retour: 1 si fprintf réussit, 0 sinon.
** Effets: écrit dans stream.
** Invariants: les chaînes sont déjà bornées par le modèle.
** Relations: fprintf().
** Appelants: fishing_rod_write_preset().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_write_pair().
** Dépendances: stdio C.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: dépend du flux fourni.
** I/O: écriture texte.
** Unités: aucune.
** Performance: O(longueur des chaînes).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_write_pair(FILE *stream, const char *key,
	const char *value)
{
	return (fprintf(stream, "%s=%s\n", key, value) >= 0);
}
/*
** Rôle: fishing_rod_write_preset — Sérialise un montage complet sans prix.
** Retour: 1 si toute la section LOADOUT est écrite, 0 sinon.
** Effets: ajoute la section au flux.
** Invariants: aucun MU, prix courant, TT mesuré ou base historique n'est écrit.
** Relations: fprintf(), fishing_rod_write_pair().
** Appelants: fishing_rod_write_presets().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_write_preset().
** Dépendances: schéma LOADOUT v1/v2.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: dépend du flux fourni.
** I/O: écriture texte.
** Unités: noms canoniques.
** Performance: O(taille section).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_write_preset(FILE *stream,
	const t_fishing_rod_preset *preset)
{
	if (fprintf(stream, "[LOADOUT:%s]\n", preset->name) < 0)
		return (0);
	if (!fishing_rod_write_pair(stream, "rod", preset->rod_name)
		|| !fishing_rod_write_pair(stream, "reel", preset->reel_name))
		return (0);
	if (!fishing_rod_write_pair(stream, "blank", preset->blank_name)
		|| !fishing_rod_write_pair(stream, "line", preset->line_name))
		return (0);
	if (!fishing_rod_write_pair(stream, "lure", preset->lure_name)
		|| !fishing_rod_write_pair(stream, "ammo", preset->ammo_name))
		return (0);
	if (!fishing_rod_write_pair(stream, "notes", preset->notes))
		return (0);
	return (fprintf(stream, "\n") >= 0);
}
/*
** Rôle: fishing_rod_write_presets — Sérialise tous les montages validés.
** Retour: 1 sur écriture complète, 0 au premier échec.
** Effets: écrit dans stream.
** Invariants: ordre mémoire conservé pour une sauvegarde déterministe.
** Relations: fishing_rod_write_preset().
** Appelants: fishing_rod_database_save().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_write_presets().
** Dépendances: base de presets.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: lecture seule de database.
** I/O: écriture texte.
** Unités: aucune.
** Performance: O(nombre de presets).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_write_presets(FILE *stream,
	const t_fishing_rod_database *database)
{
	size_t	index;

	index = 0;
	while (index < database->count)
	{
		if (!fishing_rod_write_preset(stream, &database->items[index]))
			return (0);
		index++;
	}
	return (1);
}
/*
** Rôle: fishing_rod_database_save — Sauvegarde le schéma v2 complet.
** Retour: 1 si fichier écrit et fermé, 0 sinon.
** Effets: remplace le chemin cible par composants puis LOADOUT.
** Invariants: le fichier reste compositionnel et ne fige aucune valeur marché.
** Relations: fopen(), fclose(), fishing_rod_write_components(),
**            fishing_rod_write_presets().
** Appelants: UI/config Fishing et tests E90.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_database_save().
** Dépendances: stdio C et schéma INI v2 rétrocompatible en lecture.
** Mémoire: aucune allocation.
** État partagé: aucun.
** Concurrence: synchronisation externe sur le chemin cible.
** I/O: écriture fichier INI.
** Unités: noms canoniques.
** Performance: O(composants + presets).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_database_save(const t_fishing_rod_database *database,
	const char *path)
{
	FILE	*stream;
	int	ok;

	if (!database || !path)
		return (0);
	stream = fopen(path, "wb");
	if (!stream)
		return (0);
	ok = fprintf(stream, "; KHARVIUM fishing_rods.ini - schema v2\n") >= 0;
	ok = ok && fprintf(stream,
			"; Components + loadouts; no fixed market prices.\n\n") >= 0;
	ok = ok && fishing_rod_write_components(stream, database);
	ok = ok && fishing_rod_write_presets(stream, database);
	if (fclose(stream) != 0)
		ok = 0;
	return (ok);
}
