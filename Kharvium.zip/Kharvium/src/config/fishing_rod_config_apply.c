/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_apply.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config/fishing_rod_config.h"

/*
** Rôle: fishing_rod_apply_component — Installe un gear canonique dans le
**       snapshot sans inventer de TT avant/après ni de coût d'acquisition.
** Retour: 1 si l'ID existe et peut être installé, 0 sinon.
** Effets: modifie le slot correspondant dans snapshot.
** Invariants: les mesures économiques restent absentes tant qu'elles ne sont
**             pas réellement saisies ou observées.
** Relations: catalog_registry_find_fishing_gear(),
**            fishing_loadout_set_component().
** Appelants: fishing_rod_preset_apply().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_apply_component().
** Dépendances: catalogue gear et modèle E88.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante pour snapshots distincts.
** I/O: aucune.
** Unités: ID canonique; TT inconnu représenté par -1.
** Performance: O(n) recherche catalogue.
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_apply_component(t_fishing_loadout_snapshot *snapshot,
	const t_catalog_registry *catalog, t_entity_id item_id)
{
	const t_catalog_fishing_gear	*gear;

	gear = catalog_registry_find_fishing_gear(catalog, item_id);
	if (!gear)
		return (0);
	return (fishing_loadout_set_component(snapshot, gear, -1, -1));
}

/*
** Rôle: fishing_rod_apply_standard — Installe les quatre attachments et
**       l'ammo d'un preset standard dans un snapshot Fishing.
** Retour: 1 si tous les composants sont installés, 0 sinon.
** Effets: modifie snapshot de façon séquentielle avant calcul des stats.
** Invariants: aucune quantité ammo n'est inventée lors du chargement preset.
** Relations: fishing_rod_apply_component(),
**            catalog_registry_find_fishing_ammo(), fishing_loadout_set_ammo().
** Appelants: fishing_rod_preset_apply().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_apply_standard().
** Dépendances: catalogue local et modèle loadout E88.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante pour snapshots distincts.
** I/O: aucune.
** Unités: IDs canoniques; quantités inconnues = -1.
** Performance: cinq recherches catalogue.
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_apply_standard(t_fishing_loadout_snapshot *snapshot,
	const t_fishing_rod_preset *preset, const t_catalog_registry *catalog)
{
	const t_catalog_fishing_ammo	*ammo;

	if (!fishing_rod_apply_component(snapshot, catalog, preset->reel_id)
		|| !fishing_rod_apply_component(snapshot, catalog, preset->blank_id))
		return (0);
	if (!fishing_rod_apply_component(snapshot, catalog, preset->line_id)
		|| !fishing_rod_apply_component(snapshot, catalog, preset->lure_id))
		return (0);
	ammo = catalog_registry_find_fishing_ammo(catalog, preset->ammo_id);
	if (!ammo)
		return (0);
	return (fishing_loadout_set_ammo(snapshot, ammo, -1, -1));
}

/*
** Rôle: fishing_rod_preset_apply — Charge une canne complète et ses objets
**       dans un snapshot runtime puis recalcule ses paramètres combinés.
** Retour: 1 si le preset complet est appliqué, 0 sinon.
** Effets: réinitialise snapshot puis installe Rod et attachments/ammo requis.
** Invariants: aucune valeur TT, acquisition ou MU n'est créée par le preset.
** Relations: fishing_rod_preset_is_complete(), fishing_loadout_initialize(),
**            fishing_rod_apply_component(), fishing_rod_apply_standard(),
**            fishing_loadout_compute_stats().
** Appelants: Tracker Fishing/picker futur et tests E90.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_preset_apply().
** Dépendances: configuration Fishing + catalogue + loadout E88.
** Mémoire: aucune allocation.
** État partagé: aucun.
** Concurrence: réentrante pour snapshots distincts.
** I/O: aucune.
** Unités: stats x100/cm; valeurs économiques restent inconnues.
** Performance: O(recherches catalogue fixes).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_preset_apply(t_fishing_loadout_snapshot *snapshot,
	const t_fishing_rod_preset *preset, const t_catalog_registry *catalog)
{
	const t_catalog_fishing_gear	*rod;

	if (!snapshot || !fishing_rod_preset_is_complete(preset, catalog))
		return (0);
	fishing_loadout_initialize(snapshot);
	if (!fishing_rod_apply_component(snapshot, catalog, preset->rod_id))
		return (0);
	rod = catalog_registry_find_fishing_gear(catalog, preset->rod_id);
	if (!rod)
		return (0);
	if (rod->method != FISHING_METHOD_BAITFISHING
		&& !fishing_rod_apply_standard(snapshot, preset, catalog))
		return (0);
	return (fishing_loadout_compute_stats(snapshot, catalog));
}
