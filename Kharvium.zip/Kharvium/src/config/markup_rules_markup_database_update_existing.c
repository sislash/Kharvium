/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   markup_rules_markup_database_update_existing.c     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "markup_rules_modules.h"

/*
** Rôle: markup_database_update_existing — Met à jour database existing à
**       partir des valeurs courantes et conserve l’état partagé cohérent
**       pour la suite de la frame ou du calcul.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: r — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_equal_case_insensitive().
** Appelants: markup_database_insert_or_update().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_rules_markup_database_update_existing.c ->
**        markup_database_update_existing() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU, quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_database_update_existing(t_markup_db *db,
	const t_markup_rule *r)
{
    size_t	i;

    i = 0;
    while (i < db->count)
    {
        if (string_equal_case_insensitive(db->items[i].name, r->name))
        {
            db->items[i] = *r;
            return (1);
        }
        i++;
    }
    return (0);
}

/*
** Rôle: markup_database_load — Charge l’état associé à markup base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_database_free(),
**            markup_database_initialize(), markup_ini_parse_file().
** Appelants: hunt_stats_core_load_markup_database(),
**            config_markup_initialize_once(), markup_frame_reload(),
**            config_regression_markup().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_rules_markup_database_update_existing.c ->
**        markup_database_load() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_database_load(t_markup_db *db, const char *path)
{
    if (!db || !path)
        return (-1);
    markup_database_free(db);
    markup_database_initialize(db);
    if (markup_ini_parse_file(db, path) != 0)
    {
        markup_database_free(db);
        return (-1);
    }
    return (0);
}

/*
** Rôle: markup_database_get — Retourne l’état associé à markup base de
**       données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: item_name — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 0 sur le chemin final normal et 1 lorsqu’une branche
**         d’erreur explicitement détectée est empruntée.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_equal_case_insensitive().
** Appelants: hunt_stats_core_apply_markup_value().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_rules_markup_database_update_existing.c ->
**        markup_database_get() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU, quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_database_get(const t_markup_db *db, const char *item_name,
                  t_markup_rule *out)
{
    size_t	i;

    if (!db || !item_name || !out)
        return (0);
    i = 0;
    while (i < db->count)
    {
        if (string_equal_case_insensitive(db->items[i].name, item_name))
        {
            *out = db->items[i];
            return (1);
        }
        i++;
    }
    return (0);
}

/*
** Rôle: markup_apply — Applique l’état associé à markup.
** Paramètre: r — objet source consulté en lecture seule par cette fonction.
** Paramètre: tt_value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_rules_markup_database_update_existing.c -> markup_apply()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
double	markup_apply(const t_markup_rule *r, double tt_value)
{
    if (!r || !r->value_known)
        return (tt_value);
    if (r->type == MARKUP_TT_PLUS)
        return (tt_value + r->value);
    if (r->type == MARKUP_UNIT_VALUE)
        return (r->value);
    return (tt_value * r->value);
}

/*
** Rôle: markup_default_rule — Calcule et retourne par défaut rule à partir
**       des paramètres fournis sans modifier les entrées déclarées en
**       lecture seule.
** Retour: Retourne le résultat de type t_markup_rule; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_entry_clear().
** Appelants: hunt_stats_core_apply_markup_value().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_rules_markup_database_update_existing.c ->
**        markup_default_rule() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strncpy().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_markup_rule	markup_default_rule(void)
{
    t_markup_rule	r;

    markup_entry_clear(&r, sizeof(r));
    strncpy(r.name, "(default)", sizeof(r.name) - 1);
    r.type = MARKUP_PERCENT;
    r.value = 1.0;
    r.value_known = 0;
    return (r);
}
