/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   markup_ini_context.c                              +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config_internal.h"
#include "common/string_operations.h"

#include <stdlib.h>
#include <string.h>

int	markup_database_insert_or_update(t_markup_db *db,
		const t_markup_rule *rule);

/*
** Rôle: markup_ini_context_reset — Réinitialise l’état associé à markup ini
**       context.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: markup_ini_parse_file().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_context.c -> markup_ini_context_reset() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	markup_ini_context_reset(t_ini_ctx *context)
{
	memset(&context->cur, 0, sizeof(context->cur));
	context->in_section = 0;
	context->has_type = 0;
	context->has_value = 0;
}

/*
** Rôle: markup_ini_context_flush — Force l’écriture de ini contexte vers la
**       destination prévue en respectant le
**       format, les bornes et la politique
**       d’erreur du module.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db, context.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_database_insert_or_update().
** Appelants: markup_ini_parse_stream(), markup_ini_start_section().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_context.c -> markup_ini_context_flush() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_ini_context_flush(t_markup_db *db, t_ini_ctx *context)
{
	if (!context->in_section || !context->cur.name[0]
		|| !context->has_value)
		return (0);
	if (!context->has_type)
		context->cur.type = MARKUP_PERCENT;
	if (markup_database_insert_or_update(db, &context->cur) != 0)
		return (-1);
	return (0);
}

/*
** Rôle: markup_ini_start_section — Démarre ini section en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: buffers — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db, context,
**         line, buffers.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_ini_context_flush(),
**            markup_ini_parse_section(), string_copy_safe().
** Appelants: markup_ini_process_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_context.c -> markup_ini_start_section() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> memset().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static int	markup_ini_start_section(t_markup_db *db, t_ini_ctx *context,
		char *line, t_markup_parse_buffers *buffers)
{
	if (markup_ini_context_flush(db, context) != 0)
		return (-1);
	memset(&context->cur, 0, sizeof(context->cur));
	context->has_type = 0;
	context->has_value = 0;
	if (!markup_ini_parse_section(line, buffers->section,
			sizeof(buffers->section)))
		return (0);
	string_copy_safe(context->cur.name, sizeof(context->cur.name),
		buffers->section);
	context->in_section = 1;
	return (0);
}

/*
** Rôle: markup_ini_apply_value — Calcule ini apply valeur à partir des
**       entrées courantes en respectant les unités, bornes et règles
**       d’arrondi du module.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: buffers — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : context.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_ini_parse_type(),
**            string_equal_case_insensitive().
** Appelants: markup_ini_process_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_context.c -> markup_ini_apply_value() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> strtod().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	markup_ini_apply_value(t_ini_ctx *context,
		const t_markup_parse_buffers *buffers)
{
	if (string_equal_case_insensitive(buffers->key, "type"))
	{
		if (markup_ini_parse_type(buffers->value, &context->cur.type))
			context->has_type = 1;
	}
	else if (string_equal_case_insensitive(buffers->key, "value"))
	{
		context->cur.value_known = 1;
		if (string_equal_case_insensitive(buffers->value, "unknown")
			|| string_equal_case_insensitive(buffers->value, "n/a"))
		{
			context->cur.value = 1.0;
			context->cur.value_known = 0;
		}
		else
			context->cur.value = strtod(buffers->value, NULL);
		context->has_value = 1;
	}
}

/*
** Rôle: markup_ini_process_line — Traite ini ligne en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: context — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: buffers — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : db, context,
**         line, buffers.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> markup_ini_apply_value(),
**            markup_ini_is_empty_or_comment(), markup_ini_parse_key_value(),
**            markup_ini_start_section(), string_trim_left(),
**            string_trim_right().
** Appelants: markup_ini_parse_stream().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        markup_ini_context.c -> markup_ini_process_line() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	markup_ini_process_line(t_markup_db *db, t_ini_ctx *context,
		char *line, t_markup_parse_buffers *buffers)
{
	string_trim_left(&line);
	string_trim_right(line);
	if (markup_ini_is_empty_or_comment(line))
		return (0);
	if (line[0] == '[')
		return (markup_ini_start_section(db, context, line, buffers));
	if (!context->in_section)
		return (0);
	if (markup_ini_parse_key_value(line, buffers))
		markup_ini_apply_value(context, buffers);
	return (0);
}
