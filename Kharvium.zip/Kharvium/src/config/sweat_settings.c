/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sweat_settings.c                                  +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/31                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config/sweat_settings.h"
#include "common/options_file.h"
#include <stdio.h>
#include <string.h>

/*
** Rôle: sweat_settings_load — Charge l’état associé à sweat settings.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: enabled — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: peut modifier les paramètres non const suivants : enabled.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> options_file_get_int().
** Appelants: hunt_stats_core_is_sweat_enabled(), cache_refresh_options(),
**            parse_engine_sweat_enabled(),
**            hunt_tracker_toggle_sweat_setting().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sweat_settings.c -> sweat_settings_load() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	sweat_settings_load(const char *path, int *enabled)
{
	int rc;
	int v;

	if (!enabled || !path)
		return (-1);
	*enabled = 0;
	v = 0;
	rc = options_file_get_int(path, "sweat_tracker", &v);
	if (rc == 1)
		*enabled = (v != 0);
	return (0);
}

/*
** Rôle: sweat_settings_save — Sauvegarde l’état associé à sweat settings.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: enabled — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> options_file_set_int().
** Appelants: hunt_secondary_buttons_render(),
**            hunt_tracker_toggle_sweat_setting().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        sweat_settings.c -> sweat_settings_save() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	sweat_settings_save(const char *path, int enabled)
{
	if (!path)
		return (-1);
	if (options_file_set_int(path, "sweat_tracker", (enabled != 0)) != 0)
		return (-1);
	return (0);
}
