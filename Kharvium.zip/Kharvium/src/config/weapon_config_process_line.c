/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_config_process_line.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "weapon_config_modules.h"

/*
** Rôle: weapon_config_process_line — Traite ligne en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db, ctx, line.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> line_is_comment_or_empty(),
**            parse_key_value_line(), string_trim_left(),
**            string_trim_right(), weapon_config_apply_amplifier_entry(),
**            weapon_config_apply_player_entry(),
**            weapon_config_parse_entry(),
**            weapon_config_parse_section_line().
** Appelants: weapon_database_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_process_line.c -> weapon_config_process_line()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=8; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_config_process_line(t_weapon_database *db, t_parse_ctx *ctx,
	char *line)
{
    char	*p;
    char	*key;
    char	*val;

	string_trim_right(line);
	p = line;
	string_trim_left(&p);
    if (line_is_comment_or_empty(p))
        return ;
    if (*p == '[')
        (void)weapon_config_parse_section_line(db, ctx, p);
    else if (ctx->have_section && parse_key_value_line(p, &key, &val))
    {
        if (ctx->in_player)
            weapon_config_apply_player_entry(db, key, val);
        else if (ctx->in_amp)
            weapon_config_apply_amplifier_entry(ctx, key, val);
        else
            weapon_config_parse_entry(ctx, key, val);
    }
}

/*
** Rôle: weapon_database_load — Charge l’état associé à arme base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> weapon_config_context_initialize(),
**            weapon_config_process_line(),
**            weapon_config_save_previous_section(),
**            weapon_database_initialize(),
**            weapon_database_link_amplifiers().
** Appelants: hunt_stats_core_load_weapon_model(), app_weapon_picker_open(),
**            parse_worker_inject_player_name(),
**            weapon_config_initialize_once(), weapon_frame_reload(),
**            hunt_tracker_load_weapon_database() (+2; index complet dans
**            docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_process_line.c -> weapon_database_load() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fgets(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=5; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	weapon_database_load(t_weapon_database *db, const char *path)
{
    FILE		*fp;
    char		line[512];
    t_parse_ctx	ctx;

    if (!db || !path)
        return (0);
    weapon_database_initialize(db);
    fp = fopen(path, "r");
    if (!fp)
        return (0);
    weapon_config_context_initialize(&ctx);
    while (fgets(line, sizeof(line), fp))
        weapon_config_process_line(db, &ctx, line);
    weapon_config_save_previous_section(db, &ctx);
    weapon_database_link_amplifiers(db);
    fclose(fp);
    return (1);
}

/*
** Rôle: weapon_database_free — Libère l’état associé à arme base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> weapon_database_initialize().
** Appelants: hunt_stats_core_load_weapon_model(), app_weapon_picker_close(),
**            parse_worker_inject_player_name(), weapon_config_menu_reset(),
**            weapon_frame_reload(), hunt_tracker_action_reload_weapons()
**            (+6; index complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_process_line.c -> weapon_database_free() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> free().
** Mémoire: opérations directes -> free(); le transfert de propriété reste
**          défini par Retour/Effets et les contrats des fonctions appelées.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_database_free(t_weapon_database *db)
{
    if (!db)
        return ;
    free(db->items);
    free(db->amps.items);
    weapon_database_initialize(db);
}

/*
** Rôle: weapon_database_find — Recherche l’état associé à arme base de
**       données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: hunt_stats_core_load_weapon_model(),
**            hunt_tracker_screen_weapon_active(),
**            test_weapon_check_database().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_process_line.c -> weapon_database_find() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: quantité.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
const t_weapon_stats	*weapon_database_find(const t_weapon_database *db,
	const char *name)
{
    size_t	i;

    if (!db || !name)
        return (NULL);
    i = 0;
    while (i < db->count)
    {
        if (strcmp(db->items[i].name, name) == 0)
            return (&db->items[i]);
        i++;
    }
    return (NULL);
}

/*
** Rôle: weapon_markup_or_default — Fournit la valeur ou configuration par
**       défaut de arme markup or.
** Paramètre: markup — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_cost_per_shot_uped(),
**            weapon_cost_with_component_markup().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_process_line.c -> weapon_markup_or_default() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int64_t	weapon_markup_or_default(int64_t markup)
{
	if (markup > 0)
		return (markup);
	return (10000);
}
