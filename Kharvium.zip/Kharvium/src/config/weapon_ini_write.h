/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_ini_write.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/28                               #+#    #+#             */
/*   Updated: 2026/08/28                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WEAPON_INI_WRITE_H
# define WEAPON_INI_WRITE_H

# include "config/weapon_config.h"
# include <stdio.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_ini_write_double — Écrit ini double vers la destination prévue
**       en respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: value — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_ini_write_double().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_ini_write_double(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_ini_write_double(FILE *file, const char *key, double value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_ini_write_money — Écrit ini vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: value — montant en représentation entière fixe; aucune valeur
**            flottante persistante n’est requise.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_ini_write_money().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_ini_write_money(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_ini_write_money(FILE *file, const char *key, t_money value);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_ini_write_markup — Écrit ini vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: markup — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_ini_write_markup().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_ini_write_markup(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_ini_write_markup(FILE *file, const char *key, int64_t markup);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_ini_write_tier — Écrit ini Tier vers la destination prévue en
**       respectant le format persistant, les capacités de buffer et la
**       propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: tier_x100 — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_ini_write_tier().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_ini_write_tier(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_ini_write_tier(FILE *file, int tier_x100);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_ini_write_enhancer — Écrit ini Enhancer vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: slot — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : file.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_ini_write_enhancer().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_ini_write_enhancer(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_ini_write_enhancer(FILE *file, const t_enhancer_slot *value,
			int slot);
/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_ini_write_enhancers — Écrit ini Enhancers vers la destination
**       prévue en respectant le format persistant, les capacités de buffer
**       et la propagation des erreurs.
** Paramètre: file — flux de fichier déjà ouvert dont le cycle de vie reste
**            celui prévu par l’appelant.
** Paramètre: weapon — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : file.
** Invariants: les accès indexés sont bornés avant lecture ou écriture.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_ini_write_enhancers().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_ini_write_enhancers(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_ini_write_enhancers(FILE *file, const t_weapon_stats *weapon);

#endif
