/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_config_apply_player_entry.c                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "weapon_config_modules.h"

/*
** Rôle: weapon_config_apply_player_entry — Applique player entrée en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: val — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_copy_safe().
** Appelants: weapon_config_process_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_apply_player_entry.c ->
**        weapon_config_apply_player_entry() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_config_apply_player_entry(t_weapon_database *db,
	const char *key, const char *val)
{
    if (strcmp(key, "name") == 0)
        string_copy_safe(db->player_name, sizeof(db->player_name), val);
}

/*
** Rôle: weapon_config_apply_amplifier_entry — Applique amplifier entrée en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: val — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_flexible(),
**            parse_markup_ratio_1e4(), string_copy_safe().
** Appelants: weapon_config_process_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_apply_player_entry.c ->
**        weapon_config_apply_amplifier_entry() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_config_apply_amplifier_entry(t_parse_ctx *ctx,
	const char *key, const char *val)
{
    if (strcmp(key, "amp_ammo_shot") == 0)
		(void)money_parse_flexible(val, &ctx->cur_amp.amp_ammo_shot);
    else if (strcmp(key, "amp_decay_shot") == 0)
		(void)money_parse_flexible(val, &ctx->cur_amp.amp_decay_shot);
    else if (strcmp(key, "amp_mu") == 0)
        (void)parse_markup_ratio_1e4(val, &ctx->cur_amp.amp_mu_1e4, 0, 10000);
    else if (strcmp(key, "notes") == 0)
        string_copy_safe(ctx->cur_amp.notes, sizeof(ctx->cur_amp.notes), val);
}

/*
** Rôle: weapon_config_parse_entry — Analyse entrée depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: val — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_parse_flexible(),
**            number_parse_flexible_double(), parse_markup_ratio_1e4(),
**            parse_weapon_tier_x100(), string_copy_safe(),
**            weapon_config_apply_enhancer_entry().
** Appelants: weapon_config_process_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_apply_player_entry.c -> weapon_config_parse_entry()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=6; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_config_parse_entry(t_parse_ctx *ctx, const char *key,
	const char *val)
{
    if (strcmp(key, "dpp") == 0)
		(void)number_parse_flexible_double(val, &ctx->cur.dpp);
    else if (strcmp(key, "ammo_shot") == 0)
		(void)money_parse_flexible(val, &ctx->cur.ammo_shot);
    else if (strcmp(key, "decay_shot") == 0)
		(void)money_parse_flexible(val, &ctx->cur.decay_shot);
    else if (strcmp(key, "amp_ammo_shot") == 0)
		(void)money_parse_flexible(val, &ctx->cur.amp_ammo_shot);
    else if (strcmp(key, "amp_decay_shot") == 0)
		(void)money_parse_flexible(val, &ctx->cur.amp_decay_shot);
    else if (strcmp(key, "markup") == 0)
        (void)parse_markup_ratio_1e4(val, &ctx->cur.markup_mu_1e4, 0, 10000);
    else if (strcmp(key, "ammo_mu") == 0)
        (void)parse_markup_ratio_1e4(val, &ctx->cur.ammo_mu_1e4, 0, 10000);
    else if (strcmp(key, "weapon_mu") == 0)
        (void)parse_markup_ratio_1e4(val, &ctx->cur.weapon_mu_1e4, 1, 0);
    else if (strcmp(key, "amp_mu") == 0)
        (void)parse_markup_ratio_1e4(val, &ctx->cur.amp_mu_1e4, 1, 0);
    else if (strcmp(key, "tier") == 0)
        (void)parse_weapon_tier_x100(val, &ctx->cur.tier_x100);
    else if (weapon_config_apply_enhancer_entry(&ctx->cur, key, val)) return ;
    else if (strcmp(key, "notes") == 0)
        string_copy_safe(ctx->cur.notes, sizeof(ctx->cur.notes), val);
    else if (strcmp(key, "amp") == 0)
        string_copy_safe(ctx->cur.amp_name, sizeof(ctx->cur.amp_name), val);
}

/*
** Rôle: parse_key_value_line — Analyse key valeur ligne.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: key — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: val — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : p, key, val.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_trim_left(), string_trim_right().
** Appelants: weapon_config_process_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_apply_player_entry.c -> parse_key_value_line()
**        (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> strchr().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	parse_key_value_line(char *p, char **key, char **val)
{
    char	*eq;

    eq = strchr(p, '=');
    if (!eq)
        return (0);
    *eq = '\0';
	*key = p;
	string_trim_left(key);
	string_trim_right(*key);
	*val = eq + 1;
	string_trim_left(val);
	string_trim_right(*val);
    return (1);
}

/*
** Rôle: weapon_database_link_amplifiers — Écrit database link amplifiers dans
**       le fichier ou flux prévu en respectant le format persistant et les
**       erreurs d’E/S.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : db.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> amplifier_database_find().
** Appelants: weapon_database_load().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_apply_player_entry.c ->
**        weapon_database_link_amplifiers() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fprintf().
** Unités: pourcentage/MU, quantité.
** Performance: boucles while locales=1; appels projet directs=1; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	weapon_database_link_amplifiers(t_weapon_database *db)
{
    size_t			i;
    const t_amp_stats	*amp;

    i = 0;
    while (i < db->count)
    {
        if (db->items[i].amp_name[0] != '\0')
        {
            amp = amplifier_database_find(db, db->items[i].amp_name);
            if (amp)
            {
                db->items[i].amp_ammo_shot = amp->amp_ammo_shot;
                db->items[i].amp_decay_shot = amp->amp_decay_shot;
                db->items[i].amp_mu_1e4 = amp->amp_mu_1e4;
            }
            else
            {
                fprintf(stderr, "[WARN] Amp '%s' not found for '%s'\n",
                        db->items[i].amp_name, db->items[i].name);
            }
        }
        i++;
    }
}
