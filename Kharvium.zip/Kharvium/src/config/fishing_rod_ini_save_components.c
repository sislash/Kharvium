/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_ini_save_components.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"

/*
** Rôle: fishing_rod_component_prefix — Retourne le préfixe INI v2 d'un
**       composant déjà résolu par le chargeur.
** Retour: ROD/REEL/BLANK/LINE/LURE/AMMO, ou NULL si état invalide.
** Effets: aucun.
** Invariants: AMMO est distingué du slot UNKNOWN des gear.
** Relations: aucune fonction projet appelée directement.
** Appelants: fishing_rod_write_components().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_component_prefix().
** Dépendances: enums du modèle Fishing.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: aucune.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
static const char	*fishing_rod_component_prefix(
	const t_fishing_rod_component *component)
{
	if (component->kind == FISHING_ROD_COMPONENT_AMMO)
		return ("AMMO");
	if (component->slot == FISHING_GEAR_SLOT_ROD)
		return ("ROD");
	if (component->slot == FISHING_GEAR_SLOT_REEL)
		return ("REEL");
	if (component->slot == FISHING_GEAR_SLOT_BLANK)
		return ("BLANK");
	if (component->slot == FISHING_GEAR_SLOT_LINE)
		return ("LINE");
	if (component->slot == FISHING_GEAR_SLOT_LURE)
		return ("LURE");
	return (NULL);
}
/*
** Rôle: fishing_rod_write_components — Sérialise le catalogue exposé v2.
** Retour: 1 si toutes les sections sont écrites, 0 sinon.
** Effets: ajoute une section par composant au flux.
** Invariants: aucune statistique/prix n'est dupliqué depuis les CSV canoniques.
** Relations: fishing_rod_component_prefix(), fprintf().
** Appelants: fishing_rod_database_save().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_write_components().
** Dépendances: schéma fishing_rods.ini v2.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: dépend du flux fourni.
** I/O: écriture texte.
** Unités: noms canoniques uniquement.
** Performance: O(nombre de composants).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_write_components(FILE *stream,
	const t_fishing_rod_database *database)
{
	const char	*prefix;
	size_t		index;

	index = 0;
	while (index < database->component_count)
	{
		prefix = fishing_rod_component_prefix(&database->components[index]);
		if (!prefix || fprintf(stream, "[%s:%s]\n\n", prefix,
				database->components[index].name) < 0)
			return (0);
		index++;
	}
	return (1);
}
