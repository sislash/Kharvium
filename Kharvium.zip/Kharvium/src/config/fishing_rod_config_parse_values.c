/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_parse_values.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include "common/string_operations.h"
#include <string.h>

/*
** Rôle: fishing_rod_copy_value — Copie une valeur INI sans troncature afin
**       qu'un nom canonique trop long provoque une erreur explicite.
** Retour: 1 si la valeur tient entièrement dans destination, 0 sinon.
** Effets: écrit destination sur succès.
** Invariants: aucune troncature silencieuse d'un nom d'item n'est admise.
** Relations: string_copy_fits().
** Appelants: fishing_rod_apply_pair().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_copy_value().
** Dépendances: helper borné de chaîne du projet.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: octets de chaîne.
** Performance: O(longueur de value).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_copy_value(char *destination, size_t capacity,
	const char *value)
{
	if (!destination || !value || capacity == 0)
		return (0);
	return (string_copy_fits(destination, capacity, value));
}

/*
** Rôle: fishing_rod_apply_component_pair — Applique les clés de composition
**       Rod/Reel/Blank/Line/Lure dans le preset courant.
** Retour: 1 si key est reconnue et copiée, 0 si elle ne correspond pas.
** Effets: met à jour exactement un nom de composant du preset.
** Invariants: les noms restent textuels jusqu'à validation catalogue.
** Relations: strcmp(), fishing_rod_copy_value().
** Appelants: fishing_rod_apply_pair().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_apply_component_pair().
** Dépendances: libc strcmp() et copie bornée locale.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante pour presets distincts.
** I/O: aucune.
** Unités: aucune.
** Performance: O(longueur de valeur).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_apply_component_pair(t_fishing_rod_preset *preset,
	const char *key, const char *value)
{
	if (strcmp(key, "rod") == 0)
		return (fishing_rod_copy_value(preset->rod_name,
				sizeof(preset->rod_name), value));
	if (strcmp(key, "reel") == 0)
		return (fishing_rod_copy_value(preset->reel_name,
				sizeof(preset->reel_name), value));
	if (strcmp(key, "blank") == 0)
		return (fishing_rod_copy_value(preset->blank_name,
				sizeof(preset->blank_name), value));
	if (strcmp(key, "line") == 0)
		return (fishing_rod_copy_value(preset->line_name,
				sizeof(preset->line_name), value));
	if (strcmp(key, "lure") == 0)
		return (fishing_rod_copy_value(preset->lure_name,
				sizeof(preset->lure_name), value));
	return (0);
}

/*
** Rôle: fishing_rod_apply_pair — Applique une clé INI autorisée au preset
**       sans accepter de champ économique de marché ou de clé inconnue.
** Retour: 1 si la clé est reconnue et copiée, 0 sinon.
** Effets: modifie le preset courant.
** Invariants: aucun MU/prix fixe n'est stocké dans fishing_rods.ini.
** Relations: strcmp(), fishing_rod_apply_component_pair(),
**            fishing_rod_copy_value().
** Appelants: fishing_rod_parse_line().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_apply_pair().
** Dépendances: schéma INI Fishing version 1.
** Mémoire: aucune.
** État partagé: aucun.
** Concurrence: réentrante.
** I/O: aucune.
** Unités: aucune donnée économique.
** Performance: O(longueur de valeur).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_apply_pair(t_fishing_rod_preset *preset,
	const char *key, const char *value)
{
	if (fishing_rod_apply_component_pair(preset, key, value))
		return (1);
	if (strcmp(key, "ammo") == 0)
		return (fishing_rod_copy_value(preset->ammo_name,
				sizeof(preset->ammo_name), value));
	if (strcmp(key, "notes") == 0)
		return (fishing_rod_copy_value(preset->notes,
				sizeof(preset->notes), value));
	return (0);
}
