/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   selected_weapon.c                                 +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/31                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config/selected_weapon.h"
#include "common/string_operations.h"

#include <stdio.h>
#include <string.h>

/*
** Rôle: selected_weapon_load — Charge l’état associé à sélectionné arme.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> string_trim_line_end().
** Appelants: weapon_load_selected(), hunt_stats_live_state_reset(),
**            hunt_stats_live_config_sync(), cache_refresh_options(),
**            hunt_tracker_load_selected_weapon().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        selected_weapon.c -> selected_weapon_load() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fgets(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	selected_weapon_load(const char *path, char *out, size_t outsz)
{
	FILE	*f;

	if (!out || outsz == 0 || !path)
		return (-1);
	out[0] = '\0';
	f = fopen(path, "rb");
	if (!f)
		return (-1);
	if (!fgets(out, (int)outsz, f))
	{
		fclose(f);
		return (-1);
	}
	fclose(f);
	string_trim_line_end(out);
	return (0);
}

/*
** Rôle: selected_weapon_save — Sauvegarde l’état associé à sélectionné
**       arme.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_picker_select(), hunt_tracker_weapon_choose_confirm().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        selected_weapon.c -> selected_weapon_save() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	selected_weapon_save(const char *path, const char *name)
{
	FILE	*f;

	if (!path || !name)
		return (-1);
	f = fopen(path, "wb");
	if (!f)
		return (-1);
	fprintf(f, "%s\n", name);
	fclose(f);
	return (0);
}
