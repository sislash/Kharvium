/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config_storage.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include <stdlib.h>
#include <string.h>

/*
** Rôle: fishing_rod_database_reserve — Agrandit le tableau de presets sans
**       perdre l'ancien bloc si realloc échoue.
** Retour: 1 si une place libre existe, 0 si allocation impossible.
** Effets: peut remplacer database->items et augmenter capacity.
** Invariants: count reste inchangé pendant la réservation.
** Relations: realloc().
** Appelants: fishing_rod_database_append().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_database_reserve().
** Dépendances: libc realloc().
** Mémoire: réalloue le tableau propriétaire de database.
** État partagé: aucun.
** Concurrence: synchronisation externe si database est partagée.
** I/O: aucune.
** Unités: nombre de presets.
** Performance: amortie O(1).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_database_reserve(t_fishing_rod_database *database)
{
	t_fishing_rod_preset	*items;
	size_t			capacity;

	if (database->count < database->capacity)
		return (1);
	capacity = database->capacity * 2;
	if (capacity < 8)
		capacity = 8;
	items = realloc(database->items, capacity * sizeof(*items));
	if (!items)
		return (0);
	database->items = items;
	database->capacity = capacity;
	return (1);
}

/*
** Rôle: fishing_rod_database_append — Copie un preset validé dans la base
**       en refusant tout nom de preset déjà présent.
** Retour: 1 sur ajout, 0 sur doublon ou allocation échouée.
** Effets: augmente database->count sur succès.
** Invariants: les noms de sections LOADOUT restent uniques.
** Relations: fishing_rod_database_find(), fishing_rod_database_reserve().
** Appelants: fishing_rod_finish_section().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_database_append().
** Dépendances: stockage dynamique local.
** Mémoire: peut agrandir le tableau de presets.
** État partagé: aucun.
** Concurrence: synchronisation externe si partagé.
** I/O: aucune.
** Unités: nombre de presets.
** Performance: O(n) pour la détection du doublon.
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_database_append(t_fishing_rod_database *database,
	const t_fishing_rod_preset *preset)
{
	if (!database || !preset || !preset->name[0])
		return (0);
	if (fishing_rod_database_find(database, preset->name))
		return (0);
	if (!fishing_rod_database_reserve(database))
		return (0);
	database->items[database->count] = *preset;
	database->count++;
	return (1);
}

/*
** Rôle: fishing_rod_component_reserve — Agrandit le tableau v2 des
**       composants exposés sans perdre l'ancien bloc en cas d'échec.
** Retour: 1 si une place libre existe, 0 si realloc échoue.
** Effets: peut remplacer database->components et sa capacité.
** Invariants: component_count reste inchangé pendant la réservation.
** Relations: realloc().
** Appelants: fishing_rod_database_append_component().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_component_reserve().
** Dépendances: libc realloc().
** Mémoire: réalloue le tableau de composants possédé par database.
** État partagé: aucun.
** Concurrence: synchronisation externe si database est partagée.
** I/O: aucune.
** Unités: nombre de composants.
** Performance: amortie O(1).
** Portabilité: C99 Windows/Linux.
*/
static int	fishing_rod_component_reserve(t_fishing_rod_database *database)
{
	t_fishing_rod_component	*items;
	size_t			capacity;

	if (database->component_count < database->component_capacity)
		return (1);
	capacity = database->component_capacity * 2;
	if (capacity < 16)
		capacity = 16;
	items = realloc(database->components, capacity * sizeof(*items));
	if (!items)
		return (0);
	database->components = items;
	database->component_capacity = capacity;
	return (1);
}

/*
** Rôle: fishing_rod_database_append_component — Ajoute un composant INI v2
**       déjà résolu en refusant tout doublon de nom canonique.
** Retour: 1 sur ajout, 0 sur entrée invalide, doublon ou allocation échouée.
** Effets: augmente component_count et peut réallouer components.
** Invariants: chaque nom de composant n'est exposé qu'une fois dans l'INI.
** Relations: fishing_rod_database_find_component(),
**            fishing_rod_component_reserve().
** Appelants: fishing_rod_finish_section().
** Index: docs/FUNCTION_CALL_GRAPH.md ->
**        fishing_rod_database_append_component().
** Dépendances: stockage dynamique v2.
** Mémoire: peut agrandir le tableau components.
** État partagé: aucun.
** Concurrence: synchronisation externe si partagé.
** I/O: aucune.
** Unités: quantité de composants.
** Performance: O(n) pour la détection du doublon.
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_database_append_component(t_fishing_rod_database *database,
	const t_fishing_rod_component *component)
{
	if (!database || !component || !component->name[0])
		return (0);
	if (fishing_rod_database_find_component(database, component->name))
		return (0);
	if (!fishing_rod_component_reserve(database))
		return (0);
	database->components[database->component_count] = *component;
	database->component_count++;
	return (1);
}
