/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   selected_creature.c                               +:+      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tracker_loot <tracker_loot@student.42.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/12                               #+#    #+#             */
/*   Updated: 2026/02/19                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "config/selected_creature.h"
#include "common/string_operations.h"

#include <stdio.h>
#include <string.h>
#include <ctype.h>

/*
** Rôle: selected_creature_name_is_set — Définit l’état associé à
**       sélectionné creature nom is.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: modal_creature_content(), app_creature_available(),
**            overlay_prompt_validate(), overlay_action_start().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        selected_creature.c -> selected_creature_name_is_set() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	selected_creature_name_is_set(const char *name)
{
	if (!name)
		return (0);
	return (name[0] != '\0');
}

/*
** Rôle: selected_creature_trim_spaces — Calcule les espacements de
**       sélectionné creature trim et
**       renseigne les positions utilisées
**       par la mise en page.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: selected_creature_sanitize().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        selected_creature.c -> selected_creature_trim_spaces() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strlen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=3; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
static void	selected_creature_trim_spaces(char *s)
{
	size_t	len;
	size_t	i;
	size_t	start;

	if (!s)
		return ;
	len = strlen(s);
	start = 0;
	while (start < len && (s[start] == ' ' || s[start] == '\t'))
		start++;
	if (start > 0)
	{
		i = 0;
		while (s[start])
			s[i++] = s[start++];
		s[i] = '\0';
		len = strlen(s);
	}
	while (len > 0 && (s[len - 1] == ' ' || s[len - 1] == '\t'))
		s[--len] = '\0';
}

/*
** Rôle: selected_creature_sanitize — Formate sélection creature sanitize dans
**       le buffer destination fourni, avec une taille explicitement bornée
**       par l’appelant.
** Paramètre: s — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : s.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> selected_creature_trim_spaces(),
**            string_trim_line_end().
** Appelants: creature_prompt_ensure(), creature_prompt_handle_buttons(),
**            creature_prompt_handle_enter(), selected_creature_load(),
**            selected_creature_save(), session_export_write() (+5; index
**            complet dans docs/FUNCTION_CALL_GRAPH.md).
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        selected_creature.c -> selected_creature_sanitize() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	selected_creature_sanitize(char *s)
{
	size_t			i;
	size_t			j;
	unsigned char	c;

	if (!s)
		return ;
	string_trim_line_end(s);
	i = 0;
	j = 0;
	while (s[i])
	{
		c = (unsigned char)s[i++];
		if (c == ',')
			c = ' ';
		if (c < 32 || c == 127)
			continue ;
		s[j++] = (char)c;
		if (j + 1 >= 128)
			break ;
	}
	s[j] = '\0';
	selected_creature_trim_spaces(s);
}

/*
** Rôle: selected_creature_load — Charge l’état associé à sélectionné
**       creature.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: outsz — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> selected_creature_sanitize().
** Appelants: creature_prompt_ensure(), session_export_write(),
**            app_creature_available(), overlay_load_creature(),
**            overlay_action_start().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        selected_creature.c -> selected_creature_load() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fgets(), fopen().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	selected_creature_load(const char *path, char *out, size_t outsz)
{
	FILE	*f;

	if (!out || outsz == 0 || !path)
		return (-1);
	out[0] = '\0';
	f = fopen(path, "rb");
	if (!f)
		return (-1);
	if (!fgets(out, (int)outsz, f))
	{
		fclose(f);
		return (-1);
	}
	fclose(f);
	selected_creature_sanitize(out);
	return (0);
}

/*
** Rôle: selected_creature_save — Sauvegarde l’état associé à sélectionné
**       creature.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> selected_creature_sanitize().
** Appelants: creature_prompt_ensure(), selected_creature_clear(),
**            modal_creature_finish(), overlay_prompt_accept().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        selected_creature.c -> selected_creature_save() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> fclose(), fopen(),
**              fprintf(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: primitives système/stdio directes -> fclose(), fopen(), fprintf().
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=4. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	selected_creature_save(const char *path, const char *name)
{
	FILE	*f;
	char	buf[128];

	if (!path || !name)
		return (-1);
	snprintf(buf, sizeof(buf), "%s", name);
	selected_creature_sanitize(buf);
	f = fopen(path, "wb");
	if (!f)
		return (-1);
	fprintf(f, "%s\n", buf);
	fclose(f);
	return (0);
}
