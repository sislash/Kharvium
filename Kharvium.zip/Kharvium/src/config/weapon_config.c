/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_config.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "weapon_config_modules.h"

/*
** Rôle: line_is_comment_or_empty — Détermine si ligne comment or empty
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: s — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_config_process_line().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config.c -> line_is_comment_or_empty() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> isspace().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=1; appels projet directs=0; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	line_is_comment_or_empty(const char *s)
{
    if (!s)
        return (1);
    while (*s && isspace((unsigned char)*s))
        s++;
    if (!*s)
        return (1);
    return (*s == ';' || *s == '#');
}

/*
** Rôle: parse_markup_ratio_1e4 — Analyse markup ratio 1e4.
** Paramètre: s — objet source consulté en lecture seule par cette fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: zero_ok — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: def — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> ratio_parse_fixed_1e4().
** Appelants: weapon_config_apply_enhancer_entry(),
**            weapon_config_apply_amplifier_entry(),
**            weapon_config_parse_entry().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config.c -> parse_markup_ratio_1e4() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	parse_markup_ratio_1e4(const char *s, int64_t *out,
	int zero_ok, int64_t def)
{
	int64_t	value;

	if (!out)
		return (0);
	if (!s || !s[0])
	{
		*out = def;
		return (1);
	}
	if (!ratio_parse_fixed_1e4(s, &value))
		return (0);
	if (!zero_ok && value <= 0)
		value = def;
	if (zero_ok && value < 0)
		value = 0;
	*out = value;
	return (1);
}

/*
** Rôle: parse_weapon_tier_x100 — Analyse arme tier x100.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> ratio_parse_fixed_1e4().
** Appelants: weapon_config_parse_entry().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config.c -> parse_weapon_tier_x100() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	parse_weapon_tier_x100(const char *text, int *out)
{
	int64_t	value;

	if (!text || !out || !ratio_parse_fixed_1e4(text, &value))
		return (0);
	value = (value + 50) / 100;
	if (value < 0 || value > 1000)
		return (0);
	*out = (int)value;
	return (1);
}

/*
** Rôle: enhancer_key_parse_slot — Analyse Enhancer touche slot depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: slot — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: suffix — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : slot.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: weapon_config_apply_enhancer_entry().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config.c -> enhancer_key_parse_slot() (chemin complet dans
**        l'index).
** Dépendances: appels externes/macros directs -> isdigit(), strncmp(),
**              strtol().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=3. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	enhancer_key_parse_slot(const char *key, int *slot,
	const char **suffix)
{
	const char	*p;
	char		*end;
	long		value;

	if (!key || strncmp(key, "enhancer", 8) != 0)
		return (0);
	p = key + 8;
	if (!isdigit((unsigned char)*p))
		return (0);
	value = strtol(p, &end, 10);
	if (value < 1 || value > WEAPON_ENHANCER_SLOTS)
		return (0);
	*slot = (int)value - 1;
	*suffix = end;
	return (1);
}

/*
** Rôle: weapon_config_apply_enhancer_entry — Applique Enhancer entrée en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: weapon — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : weapon.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> enhancer_key_parse_slot(),
**            money_parse_flexible(), parse_markup_ratio_1e4(),
**            string_copy_safe().
** Appelants: weapon_config_parse_entry().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config.c -> weapon_config_apply_enhancer_entry() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> strcmp(), strtoull().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, pourcentage/MU, quantité.
** Performance: boucles while locales=0; appels projet directs=4; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	weapon_config_apply_enhancer_entry(t_weapon_stats *weapon,
	const char *key, const char *value)
{
	t_enhancer_slot	*enhancer;
	const char	*suffix;
	int		slot;

	if (!enhancer_key_parse_slot(key, &slot, &suffix))
		return (0);
	enhancer = &weapon->enhancers[slot];
	if (*suffix == '\0')
	{
		string_copy_safe(enhancer->name, sizeof(enhancer->name), value);
		enhancer->installed = value[0] != '\0';
	}
	else if (strcmp(suffix, "_tt") == 0)
		(void)money_parse_flexible(value, &enhancer->tt_uPED);
	else if (strcmp(suffix, "_cost") == 0)
		(void)money_parse_flexible(value, &enhancer->acquisition_cost_uPED);
	else if (strcmp(suffix, "_mu") == 0)
		(void)parse_markup_ratio_1e4(value, &enhancer->markup_mu_1e4, 0, 10000);
	else if (strcmp(suffix, "_breaks") == 0)
		enhancer->break_count = (uint64_t)strtoull(value, NULL, 10);
	else
		return (0);
	return (1);
}
