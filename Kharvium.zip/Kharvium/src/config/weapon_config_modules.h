/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_config_modules.h                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WEAPON_CONFIG_MODULES_H
# define WEAPON_CONFIG_MODULES_H

# include "config_internal.h"
# include "config/weapon_config.h"
# include "common/number_parse.h"
# include "common/string_operations.h"
# include "common/money.h"
# include <ctype.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: line_is_comment_or_empty — Détermine si ligne comment or empty
**       respecte la condition attendue, sans modifier les données
**       consultées.
** Paramètre: s — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type int; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: line_is_comment_or_empty().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                line_is_comment_or_empty(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	line_is_comment_or_empty(const char *s);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_markup_ratio_1e4 — Analyse markup ratio 1e4.
** Paramètre: s — objet source consulté en lecture seule par cette fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Paramètre: zero_ok — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Paramètre: def — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_markup_ratio_1e4().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_markup_ratio_1e4(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	parse_markup_ratio_1e4(const char *s, int64_t *out,
	int zero_ok, int64_t def);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_weapon_tier_x100 — Analyse arme tier x100.
** Paramètre: text — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Paramètre: out — destination renseignée avec le résultat, dans la
**            capacité fournie par l’appelant.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : out.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_weapon_tier_x100().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_weapon_tier_x100(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	parse_weapon_tier_x100(const char *text, int *out);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: enhancer_key_parse_slot — Analyse Enhancer touche slot depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: slot — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: suffix — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : slot.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: enhancer_key_parse_slot().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                enhancer_key_parse_slot(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	enhancer_key_parse_slot(const char *key, int *slot,
	const char **suffix);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_apply_enhancer_entry — Applique Enhancer entrée en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: weapon — objet ou buffer fourni par l’appelant; il peut être
**            mis à jour lorsque le contrat de la fonction l’exige.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: value — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : weapon.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_apply_enhancer_entry().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_apply_enhancer_entry(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	weapon_config_apply_enhancer_entry(t_weapon_stats *weapon,
	const char *key, const char *value);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_stats_set_defaults — Met à jour defaults à partir des valeurs
**       courantes et conserve l’état partagé cohérent pour la suite de la
**       frame ou du calcul.
** Paramètre: w — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : w.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_stats_set_defaults().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_stats_set_defaults(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_stats_set_defaults(t_weapon_stats *w);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: amplifier_set_defaults — Met à jour amplifier defaults à partir des
**       valeurs courantes et conserve l’état partagé cohérent pour la suite
**       de la frame ou du calcul.
** Paramètre: a — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : a.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: amplifier_set_defaults().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                amplifier_set_defaults(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	amplifier_set_defaults(t_amp_stats *a);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: amplifier_database_append — Ajoute l’état associé à amplifier base
**       de données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: a — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: amplifier_database_append().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                amplifier_database_append(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	amplifier_database_append(t_weapon_database *db,
	const t_amp_stats *a);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_database_append — Ajoute l’état associé à arme base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: w — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_database_append().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_database_append(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	weapon_database_append(t_weapon_database *db,
	const t_weapon_stats *w);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: amplifier_database_find — Recherche l’état associé à amplifier base
**       de données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: amplifier_database_find().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                amplifier_database_find(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const t_amp_stats	*amplifier_database_find(
	const t_weapon_database *db, const char *name);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_database_initialize — Initialise l’état associé à arme base
**       de données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_database_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_database_initialize(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_database_initialize(t_weapon_database *db);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_context_initialize — Initialise l’état associé à arme
**       configuration context.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_context_initialize().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_context_initialize(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_config_context_initialize(t_parse_ctx *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_save_previous_section — Enregistre précédent section
**       vers la destination prévue en respectant le format persistant, les
**       capacités de buffer et la propagation des erreurs.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db, ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_save_previous_section().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_save_previous_section(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_config_save_previous_section(t_weapon_database *db,
	t_parse_ctx *ctx);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_start_section — Démarre section en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: sec — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_start_section().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_start_section(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_config_start_section(t_parse_ctx *ctx, const char *sec);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_parse_section_line — Analyse section ligne depuis la
**       source fournie, contrôle le format utile et ne renseigne la
**       destination qu’avec des données validées.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : db, ctx, p.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_parse_section_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_parse_section_line(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	weapon_config_parse_section_line(t_weapon_database *db,
	t_parse_ctx *ctx, char *p);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_apply_player_entry — Applique player entrée en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: val — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_apply_player_entry().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_apply_player_entry(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_config_apply_player_entry(t_weapon_database *db,
	const char *key, const char *val);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_apply_amplifier_entry — Applique amplifier entrée en
**       appliquant les validations et transformations propres à cette
**       opération, puis laisse les données concernées dans un état cohérent.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: val — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_apply_amplifier_entry().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_apply_amplifier_entry(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_config_apply_amplifier_entry(t_parse_ctx *ctx,
	const char *key, const char *val);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_parse_entry — Analyse entrée depuis la source fournie,
**       contrôle le format utile et ne renseigne la destination qu’avec des
**       données validées.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: key — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: val — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_parse_entry().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_parse_entry(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_config_parse_entry(t_parse_ctx *ctx, const char *key,
	const char *val);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: parse_key_value_line — Analyse key valeur ligne.
** Paramètre: p — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: key — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Paramètre: val — objet ou buffer fourni par l’appelant; il peut être mis
**            à jour lorsque le contrat de la fonction l’exige.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : p, key, val.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: parse_key_value_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                parse_key_value_line(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	parse_key_value_line(char *p, char **key, char **val);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_database_link_amplifiers — Met à jour database link amplifiers
**       en appliquant explicitement les paramètres, bornes et invariants
**       décrits par le contrat de cette fonction.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : db.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_database_link_amplifiers().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_database_link_amplifiers(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_database_link_amplifiers(t_weapon_database *db);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_config_process_line — Traite ligne en appliquant les
**       validations et transformations propres à cette opération, puis
**       laisse les données concernées dans un état cohérent.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: line — texte d’entrée lu, analysé, copié ou affiché selon le
**            rôle de la fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : db, ctx, line.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_config_process_line().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_config_process_line(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_config_process_line(t_weapon_database *db, t_parse_ctx *ctx,
	char *line);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_markup_or_default — Fournit la valeur ou configuration par
**       défaut de arme markup or.
** Paramètre: markup — valeur d’entrée dont le nom et le type définissent
**            directement la sémantique dans ce module.
** Retour: Retourne le résultat de type int64_t; les chemins d’erreur
**         restent ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_markup_or_default().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_markup_or_default(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int64_t	weapon_markup_or_default(int64_t markup);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_cost_with_component_markup — Calcule coût with component à
**       partir de l’état courant en
**       respectant les unités, bornes
**       et conventions du module.
** Paramètre: w — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_cost_with_component_markup().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_cost_with_component_markup(); résolution indirecte
**                possible pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	weapon_cost_with_component_markup(const t_weapon_stats *w);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_database_load — Charge l’état associé à arme base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Paramètre: path — chemin du fichier ou répertoire ciblé par l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: effectue directement des E/S fichier ou une modification de
**         chemin; peut modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_database_load().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_database_load(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
int	weapon_database_load(t_weapon_database *db, const char *path);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_database_free — Libère l’état associé à arme base de
**       données.
** Paramètre: db — objet ou buffer fourni par l’appelant; il peut être mis à
**            jour lorsque le contrat de la fonction l’exige.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: effectue directement une gestion de mémoire dynamique; peut
**         modifier les paramètres non const suivants : db.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_database_free().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_database_free(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
void	weapon_database_free(t_weapon_database *db);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_database_find — Recherche l’état associé à arme base de
**       données.
** Paramètre: db — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: name — objet source consulté en lecture seule par cette
**            fonction.
** Retour: Retourne le pointeur trouvé/produit; NULL peut signaler une
**         absence, une entrée invalide ou un échec selon le contrat local.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_database_find().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_database_find(); résolution indirecte possible pour
**                callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
const t_weapon_stats	*weapon_database_find(const t_weapon_database *db,
	const char *name);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_cost_per_shot_uped — Calcule coût per tir uPED à partir de
**       l’état courant en respectant les
**       unités, bornes et conventions du
**       module.
** Paramètre: w — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_cost_per_shot_uped().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_cost_per_shot_uped(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
t_money	weapon_cost_per_shot_uped(const t_weapon_stats *w);

/*
** API-déclaration: contrat de la fonction déclarée ci-dessous.
** Rôle: weapon_cost_per_shot_ped — Calcule coût per tir PED à partir de
**       l’état courant en respectant les unités,
**       bornes et conventions du module.
** Paramètre: w — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens API auto-vérifiés ---
** Implémentation: weapon_cost_per_shot_ped().
** Relations API: nom suivi dans docs/FUNCTION_CALL_GRAPH.md sous
**                weapon_cost_per_shot_ped(); résolution indirecte possible
**                pour callbacks et backends plateforme.
** --- Fin des liens API auto-vérifiés ---
*/
double	weapon_cost_per_shot_ped(const t_weapon_stats *w);

#endif
