/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   weapon_config_weapon_cost_with_component_markup.c  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "weapon_config_modules.h"

/*
** Rôle: weapon_cost_with_component_markup — Calcule coût with component à
**       partir de l’état courant en
**       respectant les unités, bornes
**       et conventions du module.
** Paramètre: w — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_apply_markup(),
**            weapon_markup_or_default().
** Appelants: weapon_cost_per_shot_uped().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_cost_with_component_markup.c ->
**        weapon_cost_with_component_markup() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_money	weapon_cost_with_component_markup(const t_weapon_stats *w)
{
	return (money_apply_markup(w->ammo_shot + w->amp_ammo_shot,
			weapon_markup_or_default(w->ammo_mu_1e4))
		+ money_apply_markup(w->decay_shot,
			weapon_markup_or_default(w->weapon_mu_1e4))
		+ money_apply_markup(w->amp_decay_shot,
			weapon_markup_or_default(w->amp_mu_1e4)));
}

/*
** Rôle: weapon_cost_per_shot_uped — Calcule coût per tir uPED à partir de
**       l’état courant en respectant les
**       unités, bornes et conventions du
**       module.
** Paramètre: w — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne un montant monétaire entier, compatible avec la
**         précision fixe du projet.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_apply_markup(),
**            weapon_cost_with_component_markup(),
**            weapon_markup_or_default().
** Appelants: weapon_cost_per_shot_ped(), hunt_tracker_weapon_build_lines().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_cost_with_component_markup.c ->
**        weapon_cost_per_shot_uped() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, pourcentage/MU.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
t_money	weapon_cost_per_shot_uped(const t_weapon_stats *w)
{
	int64_t	markup;

	if (!w)
		return (0);
	if (w->weapon_mu_1e4 > 0 || w->amp_mu_1e4 > 0)
		return (weapon_cost_with_component_markup(w));
	markup = weapon_markup_or_default(w->markup_mu_1e4);
	return (w->ammo_shot + w->amp_ammo_shot + money_apply_markup(
			w->decay_shot + w->amp_decay_shot, markup));
}

/*
** Rôle: weapon_cost_per_shot_ped — Calcule coût per tir PED à partir de
**       l’état courant en respectant les unités,
**       bornes et conventions du module.
** Paramètre: w — objet source consulté en lecture seule par cette fonction.
** Retour: Retourne le résultat de type double; les chemins d’erreur restent
**         ceux explicitement codés dans la fonction.
** Effets: ce corps n’effectue pas directement d’E/S externe ni d’allocation
**         dynamique visible.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> money_to_ped_double(),
**            weapon_cost_per_shot_uped().
** Appelants: aucun appelant direct détecté.
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        weapon_config_weapon_cost_with_component_markup.c ->
**        weapon_cost_per_shot_ped() (chemin complet dans l'index).
** Dépendances: appels externes/macros directs -> aucune.
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: uPED, PED.
** Performance: boucles while locales=0; appels projet directs=2; dépendances
**              externes/macros=0. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
double	weapon_cost_per_shot_ped(const t_weapon_stats *w)
{
    return (money_to_ped_double(weapon_cost_per_shot_uped(w)));
}
