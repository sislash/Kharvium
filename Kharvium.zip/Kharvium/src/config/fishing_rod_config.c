/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fishing_rod_config.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/30                               #+#    #+#             */
/*   Updated: 2026/08/30                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fishing_rod_config_internal.h"
#include <stdlib.h>
#include <string.h>

/*
** Rôle: fishing_rod_database_initialize — Initialise une base de presets
**       Fishing vide et libérable sans condition.
** Retour: aucun.
** Effets: remet pointeur, compteur et capacité à zéro.
** Invariants: database ne possède aucune allocation après l'appel.
** Relations: memset().
** Appelants: fishing_rod_database_load(), fishing_rod_database_free().
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_database_initialize().
** Dépendances: libc memset().
** Mémoire: aucune allocation; toute ancienne allocation doit être libérée.
** État partagé: aucun.
** Concurrence: réentrante pour des bases distinctes.
** I/O: aucune.
** Unités: nombre de presets.
** Performance: O(1).
** Portabilité: C99 Windows/Linux.
*/
void	fishing_rod_database_initialize(t_fishing_rod_database *database)
{
	if (!database)
		return ;
	memset(database, 0, sizeof(*database));
}

/*
** Rôle: fishing_rod_database_free — Libère la collection dynamique des
**       presets Fishing puis réinitialise la base.
** Retour: aucun.
** Effets: libère database->items et remet la base à zéro.
** Invariants: aucun pointeur vers un preset ne reste valide après l'appel.
** Relations: free(), fishing_rod_database_initialize().
** Appelants: chargements, shutdown et tests de configuration Fishing.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_database_free().
** Dépendances: libc free().
** Mémoire: libère l'unique tableau possédé par database.
** État partagé: aucun.
** Concurrence: synchronisation externe si la base est partagée.
** I/O: aucune.
** Unités: aucune.
** Performance: O(1) hors allocateur.
** Portabilité: C99 Windows/Linux.
*/
void	fishing_rod_database_free(t_fishing_rod_database *database)
{
	if (!database)
		return ;
	free(database->items);
	free(database->components);
	fishing_rod_database_initialize(database);
}

/*
** Rôle: fishing_rod_database_find — Recherche un preset de canne par son
**       nom de section exact sans fallback implicite.
** Retour: preset interne const ou NULL si absent.
** Effets: aucun.
** Invariants: le pointeur retourné dépend de la durée de vie de database.
** Relations: strcmp().
** Appelants: picker/config Fishing et tests de chargement INI.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_database_find().
** Dépendances: libc strcmp().
** Mémoire: aucune allocation.
** État partagé: aucun.
** Concurrence: réentrante en lecture seule.
** I/O: aucune.
** Unités: index de preset.
** Performance: O(n) sur le nombre de presets utilisateur.
** Portabilité: C99 Windows/Linux.
*/
const t_fishing_rod_preset	*fishing_rod_database_find(
	const t_fishing_rod_database *database, const char *name)
{
	size_t	index;

	if (!database || !name)
		return (NULL);
	index = 0;
	while (index < database->count)
	{
		if (strcmp(database->items[index].name, name) == 0)
			return (&database->items[index]);
		index++;
	}
	return (NULL);
}

/*
** Rôle: fishing_rod_database_find_component — Recherche un composant v2
**       par son nom canonique exact, quel que soit son slot Fishing.
** Retour: composant interne const ou NULL si absent.
** Effets: aucun.
** Invariants: un nom canonique ne peut apparaître qu'une fois dans le catalogue
**             INI validé, et le pointeur dépend de la durée de vie de database.
** Relations: strcmp().
** Appelants: stockage v2, UI de construction de canne et tests INI.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_database_find_component().
** Dépendances: libc strcmp().
** Mémoire: aucune allocation.
** État partagé: aucun.
** Concurrence: réentrante en lecture seule.
** I/O: aucune.
** Unités: aucune.
** Performance: O(n) sur le nombre de composants exposés.
** Portabilité: C99 Windows/Linux.
*/
const t_fishing_rod_component	*fishing_rod_database_find_component(
	const t_fishing_rod_database *database, const char *name)
{
	size_t	index;

	if (!database || !name)
		return (NULL);
	index = 0;
	while (index < database->component_count)
	{
		if (strcmp(database->components[index].name, name) == 0)
			return (&database->components[index]);
		index++;
	}
	return (NULL);
}

/*
** Rôle: fishing_rod_database_load — Charge transactionnellement
**       fishing_rods.ini v1/v2 et valide presets/composants contre les
**       catalogues.
** Retour: 1 si tout le fichier est valide, 0 sinon.
** Effets: remplace database uniquement par un ensemble entièrement valide.
** Invariants: tout preset/composant invalide invalide le chargement complet.
** Relations: fopen(), fclose(), fishing_rod_parse_stream(),
**            fishing_rod_database_free().
** Appelants: bootstrap/picker Fishing et tests E90.
** Index: docs/FUNCTION_CALL_GRAPH.md -> fishing_rod_database_load().
** Dépendances: parser INI local et catalogues Fishing packagés.
** Mémoire: possède le tableau alloué par le parser sur succès seulement.
** État partagé: aucun.
** Concurrence: réentrante pour des bases et fichiers distincts.
** I/O: lecture séquentielle du fichier INI local.
** Unités: noms et IDs canoniques; aucun prix marché.
** Performance: O(lignes INI * recherches catalogue).
** Portabilité: C99 Windows/Linux.
*/
int	fishing_rod_database_load(t_fishing_rod_database *database,
	const char *path, const t_catalog_registry *catalog)
{
	t_fishing_rod_parse_context	context;
	FILE				*stream;
	int				ok;

	if (!database || !path || !catalog)
		return (0);
	fishing_rod_database_free(database);
	memset(&context, 0, sizeof(context));
	context.database = database;
	context.catalog = catalog;
	stream = fopen(path, "rb");
	if (!stream)
		return (0);
	ok = fishing_rod_parse_stream(&context, stream);
	fclose(stream);
	if (!ok)
		fishing_rod_database_free(database);
	return (ok);
}
