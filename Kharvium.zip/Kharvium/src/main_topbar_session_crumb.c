/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_topbar_session_crumb.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kharvium <kharvium@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/29                               #+#    #+#             */
/*   Updated: 2026/08/29                              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main_modules.h"

/*
** Rôle: topbar_session_crumb — Construit le fil d’Ariane correspondant à
**       barre supérieure session pour refléter précisément la navigation
**       active.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: topbar_tracker_crumb().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_topbar_session_crumb.c -> topbar_session_crumb() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	topbar_session_crumb(t_topbar_context *ctx)
{
	if (ctx->app->page != PAGE_SESSIONS)
		return (0);
	snprintf(ctx->crumb, sizeof(ctx->crumb), "%s / %s",
		LOCALIZE("Sessions", "Sessions"), LOCALIZE("Exports", "Exports"));
	return (1);
}

/*
** Rôle: topbar_tracker_crumb — Construit le fil d’Ariane correspondant à
**       barre supérieure pour refléter précisément la navigation active.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Retourne 1 sur le chemin final valide et 0 lorsqu’une
**         précondition ou une opération intermédiaire échoue.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> topbar_session_crumb().
** Appelants: topbar_build_crumb().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_topbar_session_crumb.c -> topbar_tracker_crumb() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=1; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
int	topbar_tracker_crumb(t_topbar_context *ctx)
{
	const char	*mode;

	if (topbar_session_crumb(ctx))
		return (1);
	mode = LOCALIZE("Replay", "Replay");
	if (ctx->app->page == PAGE_HUNT)
	{
		if (ctx->app->hunt_mode_live)
			mode = LOCALIZE("Live", "Live");
		snprintf(ctx->crumb, sizeof(ctx->crumb), "%s / %s",
			LOCALIZE("Chasse", "Hunt"), mode);
		return (1);
	}
	if (ctx->app->page != PAGE_GLOBAL_EVENTS)
		return (0);
	if (ctx->app->global_events_mode_live)
		mode = LOCALIZE("Live", "Live");
	snprintf(ctx->crumb, sizeof(ctx->crumb), "%s / %s",
		LOCALIZE("Globals", "Globals"), mode);
	return (1);
}

/*
** Rôle: topbar_build_crumb — Construit le fil d’Ariane correspondant à barre
**       supérieure build pour refléter précisément la navigation active.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> topbar_application_crumb(),
**            topbar_finance_crumb(), topbar_tracker_crumb().
** Appelants: app_draw_top_bar().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_topbar_session_crumb.c -> topbar_build_crumb() (chemin complet
**        dans l'index).
** Dépendances: appels externes/macros directs -> snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=1. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	topbar_build_crumb(t_topbar_context *ctx)
{
	const char	*label;

	label = topbar_finance_crumb(ctx->app->page);
	if (label)
		snprintf(ctx->crumb, sizeof(ctx->crumb), "%s", label);
	else if (topbar_tracker_crumb(ctx))
		return ;
	else
	{
		label = topbar_application_crumb(ctx->app->page);
		if (!label)
			label = APP_BRAND_NAME;
		snprintf(ctx->crumb, sizeof(ctx->crumb), "%s", label);
	}
}

/*
** Rôle: topbar_draw_left_text — Dessine barre supérieure left texte dans le
**       contexte graphique courant en respectant la géométrie, le clipping
**       et l’état des widgets fournis.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: les pointeurs ou états obligatoires sont contrôlés avant leur
**             utilisation.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> app_navigation_page_is_tracker(),
**            chat_log_is_available(), ui_draw_text_fit().
** Appelants: app_draw_top_bar().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_topbar_session_crumb.c -> topbar_draw_left_text() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=3; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	topbar_draw_left_text(t_topbar_context *ctx)
{
	const char	*chat_label;
	unsigned int	color;
	int			chat_ok;

	if (!app_navigation_page_is_tracker(ctx->app->page))
	{
		ui_draw_text_fit(ctx->w, (t_rect){ctx->layout->topbar.x + ctx->pad,
			ctx->text_y, ctx->layout->topbar.w / 2 - ctx->pad * 2, 18},
			ctx->crumb, ctx->ui->theme->text);
		return ;
	}
	chat_ok = chat_log_is_available(ctx->chat_path, sizeof(ctx->chat_path));
	chat_label = LOCALIZE("chat.log absent", "chat.log missing");
	color = ctx->ui->theme->warn;
	if (chat_ok)
	{
		chat_label = "chat.log OK";
		color = ctx->ui->theme->text;
	}
	snprintf(ctx->left_text, sizeof(ctx->left_text), "%s | %s",
		ctx->crumb, chat_label);
	ui_draw_text_fit(ctx->w, (t_rect){ctx->layout->topbar.x + ctx->pad,
		ctx->text_y, ctx->layout->topbar.w / 2 - ctx->pad * 2, 18},
		ctx->left_text, color);
}

/*
** Rôle: topbar_format_range_status — Retourne barre supérieure format plage
**       état dans la forme directement utilisable par le rendu ou
**       l’appelant.
** Paramètre: ctx — contexte regroupant l’état et les dépendances
**            nécessaires à l’opération.
** Paramètre: hunt_state — objet source consulté en lecture seule par cette
**            fonction.
** Paramètre: globals_state — objet source consulté en lecture seule par
**            cette fonction.
** Retour: Ne retourne rien; les sorties éventuelles sont appliquées
**         uniquement par les effets explicitement décrits.
** Effets: peut modifier les paramètres non const suivants : ctx.
** Invariants: un échec doit laisser les données partagées dans l’état
**             cohérent prévu par les contrôles du module.
** --- Liens techniques auto-vérifiés ---
** Relations: appelle directement -> aucune.
** Appelants: topbar_build_tracker_status().
** Index: entrée complète -> docs/FUNCTION_CALL_GRAPH.md ; repère
**        main_topbar_session_crumb.c -> topbar_format_range_status() (chemin
**        complet dans l'index).
** Dépendances: appels externes/macros directs -> LOCALIZE(), snprintf().
** Mémoire: aucune allocation/libération directe détectée dans le corps.
** État partagé: aucun symbole global g_* référencé directement.
** Concurrence: aucun état global mutable g_* direct détecté; la réentrance
**              dépend des objets passés et des fonctions appelées.
** I/O: aucune primitive système/stdio d'I/O appelée directement.
** Unités: aucune unité métier/temps explicite repérée.
** Performance: boucles while locales=0; appels projet directs=0; dépendances
**              externes/macros=2. Le coût des fonctions appelées peut
**              dominer.
** Portabilité: C99 portable au niveau de cette fonction.
** --- Fin des liens techniques auto-vérifiés ---
*/
void	topbar_format_range_status(t_topbar_context *ctx,
	const char *hunt_state, const char *globals_state)
{
	snprintf(ctx->center, sizeof(ctx->center), "%s:%s  %s:%s  %s %ld..%ld",
		LOCALIZE("Chasse", "Hunt"), hunt_state,
		LOCALIZE("Globals", "Globals"), globals_state,
		LOCALIZE("VUE Range:", "VIEW Range:"),
		ctx->app->session_range_start, ctx->app->session_range_end);
}
