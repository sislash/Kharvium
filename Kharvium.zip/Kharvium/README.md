# Kharvium

Kharvium is a desktop management application for **Entropia Universe** that
combines a financial ledger with a loot tracker. The project is written in
**C99** and targets Linux and Windows.

The program starts on a clean Finance dashboard. A fresh package contains no
personal or financial records. Only the Tracker reference files `weapons.ini`, `fishing_rods.ini`
and `markup.ini` are supplied as active data.

> Kharvium is an independent project and is not affiliated with or endorsed by
> MindArk or Entropia Universe.

## Main features

### Finance

- PED Card and editable fortune/assets.
- Inventory with TT value, market value, historical cost and unrealized P/L.
- Purchases and sales with book cost and realized profit/loss.
- Market valuation modes: percentage, TT+ per unit, TT+ total and a current
  unit market price that can be updated whenever supply/demand changes. Manual
  price updates also create dated/source-labelled market observations.
- Craft and Culture recipes with multiple steps and ingredients.
- Production tracking using historical inventory cost.
- Deposits and audited cancellations.
- Withdrawals with Requested, Committed, Received and Cancelled states.
- Equipment, decay, repair, Tier and Enhancer accounting.
- Draft runs for Hunt, Mining, Craft, Culture and other activities.
- Historical run analysis by period, target, zone and setup.
- Daily snapshots for PED, stock, fortune, total capital and performance.
- Tracker-to-Finance import as a **draft** only: no automatic stock invention.

### Loot Tracker

The Tracker keeps the historical V3 Hunt/Fishing journal for compatibility and
also maintains a generic V4 `tracker_events.csv` sidecar with stable event,
session, activity and parent relations. Runtime journals remain excluded from
clean source packages.


- LIVE and REPLAY parsing of Entropia Universe `chat.log`.
- Hunt and Fishing modes in the same responsive loot-tracker interface.
- Hunt statistics, fishing catches, globals, session exports and live graph views.
- Fishing catches are grouped by timestamp and confirmed by `Fish Scrap`; a catch
  can contain one or several loot items, including a `Fish Scrap`-only catch.
- Weapon/amplifier configuration, Tier 0.00-10.00 and 10 Enhancer slots.
- Loot-first MU/value configuration with quantity-aware per-unit rules.
- Optional always-on-top overlay.
- Read-only interaction with the game log: no injection and no game hook.

## Accounting precision

Money is stored as signed 64-bit fixed-point integers.

- `1 PED = 100,000` internal units.
- `1 PEC = 1,000` internal units.
- Minimum accounting precision: `0.00001 PED = 0.001 PEC`.
- Monetary totals do not use `float` or `double` as the source of truth.

See [docs/FINANCE.md](docs/FINANCE.md) and
[docs/DATA_FORMATS.md](docs/DATA_FORMATS.md).

## Navigation

The left sidebar is intentionally compact:

- **Finance**: Dashboard only. Finance sub-pages are opened from the dashboard.
- **Tracker**: Loot Tracker (Hunt/Fishing), Globals, Graph LIVE and Sessions/Exports.
- **Application**: Configuration.
- **System**: Health, Maintenance, Help and Quit.

Global `FINANCE`, `TRACKER` and `BACK` actions allow free movement throughout
the application. BACK uses a real navigation history. Finance pages preserve
selection, scroll, search and sort when you leave and return.

Important actions use confirmation dialogs. Closing the main window is guarded
when a Finance form, a run draft or an unsaved state could be lost.

## Build

### Linux

Requirements:

- GCC or Clang with C99 support;
- GNU Make;
- X11 development libraries;
- Xext development libraries are optional but recommended for overlay
  click-through.

Debian/Ubuntu example:

```bash
sudo apt install build-essential libx11-dev libxext-dev pkg-config
make
./bin/kharvium
```

Useful targets:

```bash
make run
make debug
make release
make test
make test-sanitize
make sanitize
make win-platform-check
make LEGACY=1
```

### Windows

Native MSYS2/MinGW and Linux-to-Windows MinGW-w64 builds are supported by the
source tree:

```bash
make win
```

The expected binary is `bin/kharvium.exe`. `make win-platform-check` is also
available on a Linux host without MinGW: it compiles the `_WIN32` branch of the
portable file layer with test-only CRT stubs and `-Werror`, catching branch
regressions early. It is automatically included in `make test`.

The current release process validates Linux builds in this environment. The
host-side Windows probe does not replace a real MinGW build: a Windows release
should still be built and smoke-tested on Windows before public or external
delivery.

See [docs/PLATFORMS.md](docs/PLATFORMS.md).

## First run

1. Build and start Kharvium.
2. The Finance database is empty by design.
3. Configure the location of Entropia Universe `chat.log` if it is not found
   automatically.
4. Review `weapons.ini`, `fishing_rods.ini` and `markup.ini` in Configuration.
   `markup.ini` is intentionally loot-first: it provides TT->MU rules and
   quantity-aware per-unit values for Tracker `LOOT_ITEM` names. Weapon
   operating MU belongs in `weapons.ini`; Fishing gear acquisition cost belongs
   to the Fishing loadout snapshot.
5. Use Tracker > Loot Tracker, then choose Hunt or Fishing for live tracking.
   In Fishing mode, use `Choisir une canne / Choose a rod` to select one of the
   canonical Rods directly. `Personnaliser / Customize` exposes named Rod, Reel,
   Blank, Line, Lure and Ammo slots; changing the Rod first reloads its compatible
   default loadout before individual parts are changed.
6. Use Finance > Dashboard to create financial records only when needed.

Finance data is stored at runtime in `logs/finance_book.csv`. Runtime logs,
exports and offsets are **never included in clean source packages**.

## Repository layout

```text
includes/        Headers mirroring the domain/module directories
src/app/         Application state, routing and page coordination
src/core/        Session/combat/loot invariants shared by activities
src/hunt/        Hunt-only domain behavior
src/fishing/     Fishing domain model, loadout costs and session economics
src/finance/     Financial domain model and persistence
src/integration/ Explicit Tracker <-> Finance bridge
src/parse/       chat.log parsing and normalization
src/analytics/   Derived statistics
src/config/      INI/configuration parsing and selected equipment state
src/catalog/     Canonical item/catalog registries
src/io/          CSV and tracker persistence
src/storage/     Atomic file primitives
src/monitor/     Parser/system-health telemetry independent of the UI pages
src/platform/    Linux X11 / Windows Win32 platform layer
src/ui/          UI widgets, dialogs and native rendering
src/common/      Shared low-level C utilities
config/          Configuration examples/resources
tests/           Unit and integration tests
tools/           Outils QA, Strict42 et packaging en C99 pur
docs/            Maintained technical documentation
```

The current desktop renderer is implemented through native X11/Win32 platform
backends. Platform-specific code is isolated under `src/platform/`.

## Quality gates

Normal development uses:

```text
make
make LEGACY=1
make test
make norm
make doc-audit
```

All QA commands are implemented by the C99 `kharvium_devtool` binary.
After adding, moving or renaming functions, update the local relation blocks and
`docs/FUNCTION_CALL_GRAPH.md`, then run `make doc-audit`.

Additional validation includes GCC `-fanalyzer`, ASan/UBSan and real UI smoke
tests when the environment permits it.

Clean release packaging:

```bash
make package-clean
make package-audit
make package-selftest
```

The packaging audit rejects build output, runtime logs, Finance databases,
backups, temporary files and unexpected active INI/CSV data.

See [docs/QA_RELEASE.md](docs/QA_RELEASE.md).

## Documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Audit des actions UI E112](docs/UI_ACTION_AUDIT_E112.md)
- [Finance model](docs/FINANCE.md)
- [Tracker](docs/TRACKER.md)
- [Data formats and precision](docs/DATA_FORMATS.md)
- [Platforms and build](docs/PLATFORMS.md)
- [QA and release process](docs/QA_RELEASE.md)
- [Function documentation guide](docs/FUNCTION_DOCUMENTATION_GUIDE.md)
- [C function call graph](docs/FUNCTION_CALL_GRAPH.md)
- [Changelog](CHANGELOG.md)
- [Contributing](CONTRIBUTING.md)
- [Security](SECURITY.md)

## License

Kharvium is proprietary software. Personal, non-commercial use is permitted
under the terms in [LICENSE](LICENSE). Redistribution is not permitted without
prior written authorization from the copyright holder.
